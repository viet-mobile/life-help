import fs from "node:fs";
import {R as R1} from "./r1.mjs"; import {R as R2} from "./r2.mjs"; import {D} from "./r3.mjs"; import {M} from "./m.mjs"; import {S} from "./s.mjs";
const seq=[2,0,3,1,1,3,0,2,3,1,2,0,0,2,1,3,1,0,3,2,2,1,0,3,3,0,1,2];
let c=0;
const mkq=(q,key,ds,why)=>{const p=seq[c++%seq.length];const o=[...ds];o.splice(p,0,key);return {q,o,a:p,why};};
const mkP=(k)=>(r)=>({k,title:r.title,text:r.text,...(r.std?{std:r.std}:{}),qs:r.qs.map(x=>mkq(...x))});
const DROP=new Set(["A Student Journalist's Dilemma","Notice: New Comment Policy","Podcast Episode 48: The Last Print Shop"]);const R1x=R1.filter(r=>!DROP.has(r.title)),R2x=R2.filter(r=>!DROP.has(r.title));const Mx=M.filter(m=>!m[0].startsWith("Which sentence correctly attributes"));
const items=[...[...R1x,...R2x].map(mkP("r")),...D.map(mkP("d")),...Mx.map(([q,key,ds,why,cat,std])=>({k:"m",...mkq(q,key,ds,why),cat,...(std?{std:[std]}:{})})),...S.map(s=>({k:"s",...s}))];
import {P} from "./p.mjs";
const used=new Set();const fix=(x)=>{for(const [i,[a,b]] of P.entries()) if(x===a && !(i%3===0 && b.length>a.length)){used.add(a);return b;}return x;};
for(const it of items){const L=it.qs?it.qs:(it.k==="m"?[it]:[]);for(const q of L){const key=q.o[q.a];q.o=q.o.map(fix);}}
console.log(P.filter(p=>!used.has(p[0])).map(p=>"UNUSED "+p[0]));
console.log([...R1x,...R2x].length,D.length,Mx.length,S.length);
// word counts
for(const r of [...R1x,...R2x,...D]) {const n=r.text.split(/\s+/).length; if(n<112) console.log("short",n,r.title);}
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H18-h-media.json",JSON.stringify({packet:"H18-h-media",sections:[{skill:"e.h.media",items}]},null,1));
