export const D = [
{title:"Planning the School News Video",text:`Yuna: Our school news video needs a topic. Any ideas?
Marcus: What about the new recycling program? Everyone has seen the colored bins, but nobody knows how they work.
Yuna: Good idea. But a video made only of talking is boring. How can we show the process?
Marcus: We could film the bins being emptied, then follow the bags to the sorting center. Close-ups of the machines would be dramatic.
Yuna: True, but we must get permission before filming anyone. And let's interview the cleaning staff. They know more than anybody.
Marcus: Agreed. Should we add background music?
Yuna: Only softly. If it's too loud, viewers won't hear the interviews.
Marcus: Okay. And we'll add captions, so people can watch in the hallway without sound.
Yuna: Perfect. Let's write the script tonight and film on Thursday.`,std:["12미영01-06","12미영01-07"],qs:[
["What is the main topic of the conversation?","Deciding how to make an interesting video about recycling",["Choosing a new school recycling program","Arguing about who should star in the video","Repairing the school's video equipment"],"재활용 프로그램에 대한 영상을 어떻게 흥미롭게 만들지 논의해요."],
["Why does Yuna want to avoid a video made only of talking?","She thinks it would be dull",["She believes talking is not allowed","She dislikes the cleaning staff","She wants the video to be shorter"],"말만 나오는 영상은 지루하다고 해요."],
["Why will the students add captions?","Viewers may watch without sound in a hallway",["The interviews are in a foreign language","The cleaning staff speak too quietly","The school requires captions on all videos"],"복도에서 소리 없이 볼 수 있기 때문이에요."],
["What does Yuna say about background music?","It should be quiet enough for the interviews to be heard",["It should be loud and dramatic","It is unnecessary for any school video","It should be chosen by the cleaning staff"],"음악이 크면 인터뷰가 들리지 않는다고 해요."],
["What must the students do before filming people?","Get permission from them",["Pay them a small fee","Write them a formal invitation","Practice the interview questions"],"사람을 촬영하기 전에 허락을 받아야 한다고 해요."]]},
{title:"Checking the Source",text:`Ms. Reyes: Jisoo, your presentation says that teenagers sleep only four hours on average. Where did you find that?
Jisoo: In a post with a colorful chart. It had thousands of shares.
Ms. Reyes: Popularity isn't evidence. Who made the chart?
Jisoo: Um, I didn't see a name. It just said "Health Facts Daily."
Ms. Reyes: And did it mention how the data was collected?
Jisoo: No. But the numbers looked official.
Ms. Reyes: That's the trick. A professional design can make weak information appear strong. Try searching for the figure along with the word "survey."
Jisoo: I found a study from a national health agency. It says the average is just under eight hours for fourteen-year-olds.
Ms. Reyes: So the chart was wrong by half. What will you change?
Jisoo: I'll use the study, and add the date and the link to my slides.`,std:["12미영01-04","12미영01-09"],qs:[
["Why does Ms. Reyes question Jisoo's chart?","Its creator and method of collecting data are not identified",["The colors of the chart are too bright","The chart is too large for the slide","The chart was not shared enough times"],"제작자와 자료 수집 방법이 밝혀지지 않았어요."],
["What does Ms. Reyes mean by \"That's the trick\"?","Professional-looking design can hide weak evidence",["Charts are always unreliable","Teachers like to test students","Searching online is difficult"],"전문적인 디자인이 부실한 정보를 강해 보이게 만든다는 뜻이에요."],
["What did Jisoo find after searching again?","A study giving a much higher average for sleep",["A second chart supporting four hours","A video by a popular creator","A message from the chart's author"],"전국 보건 기관 연구에서 평균이 8시간 가까이였어요."],
["What will Jisoo add to her slides?","The date and the link of the study",["A second colorful chart","Her teacher's opinion","The number of times the post was shared"],"날짜와 링크를 추가하겠다고 해요."]]},
{title:"The Ad That Seemed Too Good",text:`Hana: Did you see that ad for Glowfast? "Clear skin in three days or your money back!"
Tomás: I did. A lot of people in the comments say it worked.
Hana: Have you noticed that the comments are all very similar? "Amazing!" "Changed my life!" They sound like they were written by the same person.
Tomás: Maybe. But the before-and-after photos are impressive.
Hana: The two photos have different lighting, though. In the "after" picture, she's also wearing makeup.
Tomás: Hm, I hadn't noticed. What about the money-back promise?
Hana: I clicked the link. You have to return the unopened bottle within twenty-four hours, which is impossible if you want to test it for three days.
Tomás: Oh. So it only looks like a guarantee.
Hana: Exactly. I'd rather ask a pharmacist.`,std:["12미영01-04","12미영01-07"],qs:[
["Why does Hana doubt the comments?","They are similar and seem to have a single author",["They are written in different languages","They are much too long","They criticize the product too strongly"],"비슷한 댓글들이 한 사람이 쓴 것처럼 보여요."],
["What problem does Hana notice with the before-and-after photos?","The conditions in the two pictures are not the same",["The photos are too small to see","The pictures show different people","The photos were taken years apart"],"조명이 다르고 '이후' 사진에서는 화장도 했어요."],
["What is wrong with the money-back promise?","The return deadline is shorter than the testing period",["The product costs more than advertised","The company is located abroad","The bottle must be empty to be returned"],"3일 사용 후 효과를 보려면 24시간 내 반품이 불가능해요."],
["What will Hana most likely do about her skin problem?","Seek advice from a professional",["Buy the product to test it","Post a comment praising the ad","Wait for another advertisement"],"약사에게 묻겠다고 해요."],
["Tomás's final comment, \"it only looks like a guarantee,\" means that the offer","seems safe but is not in practice",["is sure to work","is hidden from buyers","is available only in stores"],"겉보기엔 보증이지만 실제로는 그렇지 않다는 뜻이에요."]]},
{title:"Fixing a Mistake in the Story",text:`Editor: Joon, a reader wrote that your article on the bus strike has the wrong date. You wrote the 12th, but the strike began on the 21st.
Joon: Really? I'll check my notes. Oh no, I swapped the digits. I'm sorry.
Editor: It happens. The important thing is how we respond. Have you fixed the online version?
Joon: Yes, I just did. Should I delete the old sentence quietly?
Editor: No. We add a line at the bottom saying what was changed and when. Otherwise readers who saw the first version may wonder.
Joon: That makes sense. What about the newsletter that went out this morning?
Editor: We'll include a short correction in tomorrow's edition. And next time, ask a colleague to read the dates and numbers aloud before publication.
Joon: I will. Thank you for explaining it calmly.`,std:["12미영01-10"],qs:[
["What mistake did Joon make?","He wrote a wrong date by switching digits",["He misspelled the name of a union leader","He quoted a source who did not exist","He attached the wrong photo to the article"],"12일과 21일의 숫자를 바꿔 썼어요."],
["Why does the editor tell Joon not to delete the old sentence quietly?","Readers who saw the first version deserve to know about the change",["The old sentence was accurate","The website cannot be edited twice","The strike dates were not important"],"처음 버전을 본 독자를 위해 수정 사실을 밝혀야 해요."],
["How will the mistake be handled in the newsletter?","A short correction will appear in the next edition",["The newsletter will be recalled","Joon will resign from his post","Subscribers will be sent a refund"],"내일 호에 짧은 정정문을 싣겠다고 해요."],
["What does the editor advise for the future?","Have a colleague read dates and numbers aloud before publishing",["Avoid writing about strikes","Use fewer numbers in articles","Publish stories before checking"],"동료가 날짜와 숫자를 소리 내어 읽어 주게 하라고 해요."]]},
];
