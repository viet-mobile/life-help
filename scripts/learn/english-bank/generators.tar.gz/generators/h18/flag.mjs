import fs from "node:fs";
const j=JSON.parse(fs.readFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H18-h-media.json"));
const out=[];
const chk=(q,t)=>{const L=q.o.map(x=>x.length),a=L[q.a];if(a===Math.max(...L)&&L.filter(x=>x===a).length===1){out.push(`${t}\n  Q: ${q.q}\n  K(${a}): ${q.o[q.a]}\n`+q.o.map((x,i)=>i===q.a?null:`   D(${x.length}): ${x}`).filter(Boolean).join("\n"));}};
let n=0;for(const it of j.sections[0].items){if(it.k==="m"){n++;chk(it,"m");}else if(it.qs){for(const q of it.qs){n++;chk(q,it.title);}}}
console.log(n,out.length);fs.writeFileSync("flag.txt",out.join("\n"));
