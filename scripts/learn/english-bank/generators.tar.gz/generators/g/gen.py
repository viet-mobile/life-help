import json
def s(good,ko,bad,st,ok,wr,rule,hint=None,ord=True):
    d={"k":"s","good":good,"ko":ko,"bad":bad,"cz":{"st":st,"ok":ok,"wr":wr},"rule":rule}
    if hint:d["hint"]=hint
    if not ord:d["ord"]=False
    return d
def m(q,o,a,why,cat):return {"k":"m","q":q,"o":o,"a":a,"why":why,"cat":cat}
def r(title,text,qs):return {"k":"r","title":title,"text":text,"qs":[{"q":a,"o":b,"a":c,"why":d} for a,b,c,d in qs]}
def w(en,pos,ko,ex,exko,z,syn,sp):return {"k":"w","en":en,"pos":pos,"ko":ko,"ex":ex,"exko":exko,"z":z,"syn":syn,"sp":sp}

L_RULE="I 다음에는 like를 써요. -s를 붙이지 않아요."
like_s=[
s("I like apples.","나는 사과를 좋아해요.",["I likes apples.","I am like apples.","I apples like."],"I ___ apples.","like",["likes","am like","liking"],"I 다음에는 like를 써요. likes나 liking은 쓰지 않아요.","좋아하는 것을 말할 때 쓰는 동사의 모양을 확인해 보세요."),
s("I have a pen.","나는 펜이 있어요.",["I has a pen.","I have pen a.","I am have a pen."],"I ___ a pen.","have",["has","having","haves"],"I 다음에는 has가 아니라 have를 써요."),
s("I have a red bag.","나는 빨간 가방이 있어요.",["I have red a bag.","I have a bag red.","I a have red bag."],"I have a ___ bag.","red",["eat","run","jump"],"'a + 색깔 + 물건' 순서로 말해요. 색깔 낱말은 물건 앞에 와요."),
s("We like soccer.","우리는 축구를 좋아해요.",["We likes soccer.","We soccer like.","Us like soccer."],"___ like soccer.","We",["Us","Me","Him"],"'우리는'은 We예요. Us는 주어로 쓰지 않아요."),
s("You have a nice hat.","너는 멋진 모자가 있구나.",["You has a nice hat.","You have nice a hat.","You are have a nice hat."],"You have a ___ hat.","nice",["are","very","at"],"You 다음에는 have를 써요. 꾸며 주는 말은 물건 앞에 와요."),
s("They have two dogs.","그들은 개가 두 마리 있어요.",["They has two dogs.","They have two dog.","They have dogs two."],"They have ___ dogs.","two",["a","an","one"],"둘 이상일 때는 숫자 뒤의 명사에 -s를 붙여요."),
s("I like my school.","나는 우리 학교를 좋아해요.",["I like school my.","I like me school.","I likes my school."],"I like ___ school.","my",["me","I","mine"],"'나의'는 my예요. me, I는 명사 앞에 쓰지 않아요."),
s("I don't like carrots.","나는 당근을 좋아하지 않아요.",["I no like carrots.","I not like carrots.","I don't likes carrots."],"I ___ like carrots.","don't",["no","not","doesn't"],"좋아하지 않는다고 할 때는 I don't like ...라고 해요.","'좋아하지 않아요'를 만드는 말을 생각해 보세요."),
s("I have a sister.","나는 여동생(언니)이 있어요.",["I have sister a.","I have an sister.","I has a sister."],"I have ___ sister.","a",["an","two","three"],"자음 소리 앞에는 a를 써요. 하나일 때는 명사에 -s를 붙이지 않아요."),
s("Do you like pizza?","너는 피자를 좋아하니?",["Do you likes pizza?","Do like you pizza?","Are you like pizza?"],"Do you ___ pizza?","like",["likes","liking","liked"],"'~하니?'는 Do you ...?로 물어요. Do 뒤에는 동사 원래 모양을 써요."),
s("Do you have a pen?","너는 펜이 있니?",["Do you has a pen?","Have you do a pen?","Do you have pen a?"],"___ you have a pen?","Do",["Are","Is","Does"],"you가 주어인 질문은 Do you ...?로 시작해요.","질문을 시작하는 말을 확인해 보세요."),
s("I like cats and dogs.","나는 고양이와 개를 좋아해요.",["I like cats and dog.","I like cats dogs and.","I like and cats dogs."],"I like cats ___ dogs.","and",["is","am","are"],"'~와'는 and로 이어요. 여러 마리면 명사에 -s를 붙여요."),
s("We have a big house.","우리는 큰 집이 있어요.",["We has a big house.","We have a house big.","We are have a big house."],"We have a ___ house.","big",["at","he","is"],"We 다음에는 have를 써요. 크기를 말하는 낱말은 명사 앞에 와요."),
s("I like this song.","나는 이 노래를 좋아해요.",["I like this songs.","I like these song.","I like song this."],"I like ___ song.","this",["these","those","an"],"노래가 하나일 때는 this를 써요. these와 those는 여러 개일 때 써요."),
s("I have a new bike.","나는 새 자전거가 있어요.",["I have a bike new.","I have an new bike.","I having a new bike."],"I have a ___ bike.","new",["at","on","is"],"'a + 꾸미는 말 + 물건' 순서예요. new는 n으로 시작하지만 자음 소리라 an이 아니라 a를 써요."),
s("I like hot soup.","나는 뜨거운 수프를 좋아해요.",["I like soup hot.","I hot like soup.","I like hot a soup."],"I like ___ soup.","hot",["very","at","is"],"꾸며 주는 낱말(hot)은 음식 이름 앞에 와요."),
s("I like you.","나는 너를 좋아해요.",["I like your.","I you like.","I like are."],"I like ___.","you",["your","I","are"],"'너를'은 you예요. your는 뒤에 명사가 와야 해요."),
s("We have a dog and a cat.","우리는 개와 고양이가 있어요.",["We have a dog and cat a.","We has a dog and a cat.","We have a dog and an cat."],"We have a dog and ___ cat.","a",["an","two","many"],"cat은 자음 소리로 시작해서 a를 써요. 하나일 때는 -s를 붙이지 않아요."),
s("I like soccer very much.","나는 축구를 아주 많이 좋아해요.",["I like very much soccer.","I like soccer much very.","I like soccer very many."],"I like soccer very ___.","much",["many","lot","big"],"'아주 많이'는 very much예요. 목적어(soccer) 뒤에 와요.",ord=False),
s("I have a cold.","나는 감기에 걸렸어요.",["I has a cold.","I have cold a.","I am have a cold."],"I have a ___.","cold",["the","and","am"],"‘have a cold’는 ‘감기에 걸렸다’는 뜻이에요. I 다음에는 have를 써요."),
s("I have breakfast.","나는 아침을 먹어요.",["I has breakfast.","I breakfast have.","I have a breakfasts."],"I ___ breakfast.","have",["haves","has","am have"],"I 다음에는 have를 써요. 'have breakfast'는 '아침을 먹다'라는 뜻이에요."),
]
like_m=[
m("‘나는 우유를 좋아해요.’를 영어로 하면?",["I have milk.","I like milk.","I am milk.","You like milk."],1,"‘좋아해요’는 like예요. I have milk는 ‘나는 우유가 있어요’예요.","grammar"),
m("‘나는 연필이 있어요.’를 영어로 하면?",["I like a pencil.","You have a pencil.","I have a pencil.","I am a pencil."],2,"‘있어요(가지고 있어요)’는 I have ...로 말해요.","grammar"),
m("빈칸에 알맞은 말은? (나는 자전거가 있어요.)\nI ___ a bike.",["has","have","likes","having"],1,"I 다음에는 have를 써요.","grammar"),
m("빈칸에 알맞은 말은? (나는 개를 좋아해요.)\nI ___ dogs.",["likes","has","like","liking"],2,"I 다음에는 like를 써요. likes는 I와 함께 쓰지 않아요.","grammar"),
m("그림 🍌에 알맞은 문장은?",["I have a banana.","I like banana a.","I a banana have.","I has a banana."],0,"‘I have a ...’ 순서로 써요. a 뒤에 명사가 와요.","grammar"),
m("A: Do you like pizza?\nB: ___",["Yes, I am.","Yes, I does.","Yes, I do.","Yes, I like do."],2,"Do you ...?라고 물으면 Yes, I do.라고 대답해요.","grammar"),
m("A: Do you have a pen?\nB: No, I ___.",["don't","doesn't","am not","not"],0,"Do you ...?에 ‘아니요’라고 답할 때는 No, I don't.라고 해요.","grammar"),
m("빈칸에 알맞은 말은? I have ___ egg.",["a","an","two","many"],1,"egg는 모음 소리로 시작해서 an을 써요.","grammar"),
m("‘나는 파란 모자가 있어요.’를 영어로 하면?",["I like a blue hat.","You have a blue hat.","I am a blue hat.","I have a blue hat."],3,"‘I have a + 색깔 + 물건’으로 말해요.","grammar"),
m("빈칸에 알맞은 말은? (그들은 강아지가 있어요.)\nThey ___ a puppy.",["have","has","likes","are"],0,"They 다음에는 have를 써요. has는 쓰지 않아요.","grammar"),
m("‘좋아하는 것’을 말하는 문장은?",["I have a ball.","I like red.","I am ten.","I see a cat."],1,"I like ...는 좋아하는 것을 말할 때 써요.","grammar"),
m("‘가지고 있는 것’을 말하는 문장은?",["I like music.","I like summer.","I have a robot.","I like my class."],2,"I have ...는 가지고 있는 것을 말할 때 써요.","grammar"),
m("낱말을 바르게 배열한 문장은? (like / I / books)",["Like I books.","I books like.","I like books.","Books like I."],2,"영어 문장은 ‘누가 → 어떻게 한다 → 무엇을’ 순서예요.","word order"),
m("A: What do you like?\nB: I ___ bananas.",["like","has","am","is"],0,"무엇을 좋아하는지 말할 때는 I like ...라고 해요.","grammar"),
m("A: What do you have?\nB: I ___ a kite.",["can","likes","has","have"],3,"가진 것을 말할 때는 I have ...라고 해요.","grammar"),
m("‘나는 연필 세 자루가 있어요.’를 영어로 하면?",["I have three pencil.","I have three pencils.","I have a three pencil.","I like three pencil."],1,"둘 이상일 때는 명사에 -s를 붙여요.","grammar"),
m("‘Yes, I do. I have a cat.’에 알맞은 질문은?",["Do you have a pet?","Are you a pet?","What is your name?","Is it a cat?"],0,"Do you have ...?에 Yes, I do.로 대답할 수 있어요.","conversation"),
m("빈칸에 알맞은 말은? (나는 우리 엄마를 좋아해요.)\nI like ___ mom.",["me","my","I","mine"],1,"‘나의’는 my예요.","grammar"),
m("A: Look at my new cap!\nB: Wow! I ___ it.",["has","am","like","is"],2,"마음에 든다고 말할 때는 I like it.이라고 해요.","conversation"),
m("‘I like’ 뒤에 올 수 없는 낱말은?",["pizza","music","am","snow"],2,"like 뒤에는 좋아하는 대상(명사)이 와요. am은 올 수 없어요.","grammar"),
m("그림 🍦을 보고 ‘나는 아이스크림을 좋아해요.’라고 말하려면?",["I like ice cream.","I has ice cream.","I am ice cream.","I ice cream like."],0,"‘I like + 좋아하는 것’ 순서로 말해요.","grammar"),
m("철자가 바른 문장은?",["I lik cats.","I like cats.","I lyke cats.","I liek cats."],1,"좋아하다는 like로 써요.","spelling"),
m("Tom이 ‘I like blue.’라고 말했어요. Tom이 말한 내용은?",["파란색을 좋아해요.","파란색 옷이 있어요.","파란색이에요.","파란색을 싫어해요."],0,"I like ...는 ‘나는 ...을 좋아해요’라는 뜻이에요.","reading"),
m("빈칸에 알맞은 말은? (나는 펜이 없어요.)\nI don't ___ a pen.",["have","has","having","haves"],0,"don't 뒤에는 동사 원래 모양(have)을 써요.","grammar"),
m("친구에게 ‘나는 너의 모자가 좋아.’라고 말하려면?",["I like your hat.","I have your hat.","I like you hat.","I am your hat."],0,"‘너의’는 your예요. I have your hat은 ‘내가 네 모자를 가지고 있어’라는 뜻이에요.","grammar"),
m("A: What is in your bag?\nB: I ___ a book and a pen.",["is","has","have","can"],2,"가방에 있는 것을 말할 때는 I have ...를 써요.","conversation"),
]
like_r=[
r("My Room","I have a small room. I have a bed and a desk. I like my room. I have a blue lamp on my desk. It is nice.",[
("글쓴이가 가지고 있는 것은?",["a bed and a desk","a cat and a dog","a car and a bike","a bag and a hat"],0,"둘째 문장에서 bed와 desk가 있다고 해요."),
("램프는 어디에 있나요?",["in the bed","on my desk","on the chair","in my bag"],1,"on my desk라고 나와요."),
("램프의 색은?",["red","green","blue","yellow"],2,"a blue lamp라고 나와요."),
("글의 내용과 맞는 것은?",["I have a big room.","I have a red lamp.","I have two beds.","I like my room."],3,"I like my room.이 글에 나와요. 방은 작고, 램프는 파란색이에요.")]),
r("My Friend","I have a friend. Her name is Mina. We like soccer. We have a red ball. We play after school. We like pizza too.",[
("두 친구가 좋아하는 운동은?",["tennis","baseball","swimming","soccer"],3,"We like soccer.라고 나와요."),
("두 친구가 가진 것은?",["a red ball","a blue ball","a red bat","a green cap"],0,"We have a red ball.이라고 나와요."),
("두 친구가 또 좋아하는 것은?",["soup","pizza","cake","rice"],1,"We like pizza too.라고 나와요."),
("‘We’는 누구를 뜻하나요?",["글쓴이의 선생님과 반 친구들","글쓴이의 가족","글쓴이와 미나","미나와 미나의 동생"],2,"글쓴이와 친구 Mina를 함께 말해요.")]),
r("At the Zoo","I like the zoo. I like monkeys. They are funny. I have a monkey toy at home. I like it very much.",[
("이 글의 주제로 알맞은 것은?",["동물원 가는 방법","원숭이 장난감 만들기","내가 키우는 반려동물","동물원과 원숭이를 좋아함"],3,"동물원과 원숭이, 원숭이 장난감을 좋아한다는 내용이에요."),
("글쓴이가 집에 가지고 있는 것은?",["a monkey toy","a dog toy","a zoo ticket","a monkey book"],0,"I have a monkey toy at home.이라고 나와요."),
("‘They’는 무엇을 가리키나요?",["toys","zoos","monkeys","I"],2,"앞 문장의 monkeys를 가리켜요."),
("글쓴이는 장난감을 어떻게 생각하나요?",["무서워해요","싫어해요","잃어버렸어요","아주 좋아해요"],3,"I like it very much.라고 나와요.")]),
r("Snack Time","It is snack time. I have a banana. I have milk too. I like bananas, but I don't like milk. Jin and I are friends. We are happy.",[
("글쓴이가 좋아하지 않는 것은?",["bananas","snack time","milk","Jin"],2,"I don't like milk.라고 나와요."),
("글쓴이가 가진 것은?",["a cake and juice","a banana and milk","a cookie and tea","an apple and rice"],1,"I have a banana. I have milk too.라고 나와요."),
("‘but’의 뜻과 가장 가까운 것은?",["그리고","그래서","하지만","왜냐하면"],2,"앞뒤 내용이 반대라서 ‘하지만’이에요."),
("마지막 문장에서 글쓴이의 기분은?",["tired","happy","angry","sad"],1,"We are happy.라고 나와요.")]),
]
sent_s=[
s("I am a student.","나는 학생이에요.",["I are a student.","I is a student.","I a student am."],"I ___ a student.","am",["are","is","do"],"I 다음에는 am을 써요."),
s("You are tall.","너는 키가 커요.",["You am tall.","You is tall.","You tall are."],"You ___ tall.","are",["am","is","do"],"You 다음에는 are를 써요.","You와 짝이 되는 말을 떠올려 보세요."),
s("I am happy.","나는 행복해요.",["I are happy.","I is happy.","I am happily."],"I am ___.","happy",["happily","happiness","happys"],"‘어떤 상태’를 말할 때는 am 뒤에 happy 같은 형용사를 써요."),
s("You are my friend.","너는 내 친구야.",["You are me friend.","You is my friend.","You are friend my."],"You are ___ friend.","my",["me","I","mine"],"‘나의’는 my예요. me는 명사 앞에 쓰지 않아요."),
s("We are in the park.","우리는 공원에 있어요.",["We am in the park.","We is in the park.","We in are the park."],"We ___ in the park.","are",["am","is","a"],"We 다음에는 are를 써요."),
s("They are good friends.","그들은 좋은 친구예요.",["They is good friends.","They are good friend.","They are friends good."],"They are good ___.","friends",["friend","a friend","friendly"],"They는 여러 명이니까 friends처럼 -s를 붙여요."),
s("I run fast.","나는 빨리 달려요.",["I runs fast.","I fast run.","I run fastly."],"I ___ fast.","run",["runs","running","am run"],"I 다음 동사에는 -s를 붙이지 않아요. ‘누가 → 한다 → 어떻게’ 순서예요."),
s("You jump high.","너는 높이 뛰어요.",["You jumps high.","You high jump.","You jump highly."],"You ___ high.","jump",["jumps","jumping","are jump"],"You 다음에는 동사 원래 모양(jump)을 써요."),
s("We eat lunch.","우리는 점심을 먹어요.",["We eats lunch.","We lunch eat.","We are eat lunch."],"We eat ___.","lunch",["happy","kind","and"],"‘누가 → 한다 → 무엇을’ 순서예요. eat 뒤에는 먹는 것이 와요."),
s("I am nine years old.","나는 아홉 살이에요.",["I am nine year old.","I have nine years old.","I am years nine old."],"I am nine ___ old.","years",["year","yearly","yearing"],"나이를 말할 때는 I am ... years old라고 해요. 둘 이상이면 years예요."),
s("You are a good dancer.","너는 춤을 잘 추는 사람이야.",["You are good a dancer.","You are a good dance.","You a are good dancer."],"You are a good ___.","dancer",["dance","dancing","danced"],"‘춤추는 사람’은 dancer예요. 사람을 말할 때 -er을 붙여요."),
s("I am not sad.","나는 슬프지 않아요.",["I not am sad.","I am no sad.","I are not sad."],"I am ___ sad.","not",["no","don't","isn't"],"‘~이 아니에요’는 am 뒤에 not을 붙여요."),
s("Are you hungry?","너는 배고프니?",["Is you hungry?","Do you hungry?","Am you hungry?"],"___ you hungry?","Are",["Is","Am","Do"],"you에 대한 질문은 Are you ...?로 시작해요."),
s("I read a book.","나는 책을 읽어요.",["I reads a book.","I read book a.","I read an book."],"I read ___ book.","a",["an","two","many"],"book은 자음 소리로 시작해서 a를 써요. 하나일 때는 -s를 붙이지 않아요."),
s("They play soccer.","그들은 축구를 해요.",["They plays soccer.","They soccer play.","They are play soccer."],"___ play soccer.","They",["Them","Him","Her"],"‘그들은’은 They예요. Them은 주어로 쓰지 않아요."),
s("This is my room.","이곳은 내 방이에요.",["This are my room.","This is I room.","This my is room."],"This ___ my room.","is",["are","am","do"],"This 다음에는 is를 써요."),
s("I see a bird in the tree.","나는 나무 위의 새를 봐요.",["I see a bird in tree the.","I a bird see in the tree.","See I a bird in the tree."],"I see a bird ___ the tree.","in",["is","am","a"],"‘누가 → 본다 → 무엇을 → 어디에’ 순서예요.",ord=False),
s("You are very smart.","너는 아주 똑똑해요.",["You are smart very.","You very are smart.","You are very smartly."],"You are ___ smart.","very",["much","many","a lot"],"‘아주’는 very예요. 형용사 앞에 와요."),
s("I am from Korea.","나는 한국에서 왔어요.",["I from am Korea.","I am from Korean.","I are from Korea."],"I am ___ Korea.","from",["to","at","on"],"‘~에서 왔다’는 am from이라고 해요."),
s("My bag is blue.","내 가방은 파란색이에요.",["My bag are blue.","My bag blue is.","Me bag is blue."],"___ bag is blue.","My",["Me","I","Mine"],"‘나의’는 My예요. 'My + 명사' 형태로 써요."),
s("You and I are friends.","너와 나는 친구예요.",["You and I is friends.","You and I am friends.","I and you is friends."],"You and I ___ friends.","are",["is","am","do"],"둘 이상이 주어일 때는 are를 써요."),
]
sent_m=[
m("‘나는 열 살이에요.’를 영어로 하면?",["I are ten.","I ten am.","I am ten.","I is ten."],2,"I 다음에는 am을 써요.","grammar"),
m("‘너는 키가 커요.’를 영어로 하면?",["You is tall.","You tall are.","You am tall.","You are tall."],3,"You 다음에는 are를 써요.","grammar"),
m("빈칸에 알맞은 말은? I ___ at home.",["are","is","am","do"],2,"I 다음에는 am을 써요.","grammar"),
m("빈칸에 알맞은 말은? You ___ my best friend.",["is","am","are","do"],2,"You 다음에는 are를 써요.","grammar"),
m("문장 ‘We eat rice.’에서 ‘누가’에 해당하는 말은?",["rice","eat","We","We eat"],2,"‘누가’에 해당하는 주어는 We예요.","sentence parts"),
m("문장 ‘They sing well.’에서 ‘어떻게’에 해당하는 말은?",["well","They","sing","They sing"],0,"well은 ‘잘’이라는 뜻으로 어떻게 하는지를 말해요.","sentence parts"),
m("낱말을 바르게 배열한 문장은? (a / I / am / boy)",["I a am boy.","I am a boy.","I boy am a.","Boy a am I."],1,"‘I am a + 명사’ 순서예요.","word order"),
m("물음표(?)로 끝나야 하는 문장은?",["Are you hungry","I am hungry","You are my friend","We are happy"],0,"‘~이니?’라고 묻는 문장은 물음표(?)로 끝나요.","punctuation"),
m("문장 안에서도 항상 대문자로 쓰는 낱말은?",["am","I","is","a"],1,"‘나’를 뜻하는 I는 어디에 있어도 대문자로 써요.","capital letters"),
m("빈칸에 알맞은 말은? We ___ in the same class.",["am","is","are","be"],2,"We 다음에는 are를 써요.","grammar"),
m("빈칸에 알맞은 말은? Mina and Joon are my friends. ___ are tall.",["He","She","They","It"],2,"두 사람은 They로 말해요.","grammar"),
m("그림 ☀️에 알맞은 문장은?",["It is sunny.","It are sunny.","It am sunny.","It sunny is."],0,"It 다음에는 is를 써요.","grammar"),
m("‘너는’이 주어가 아닌 문장은?",["You are tall.","You run fast.","I am tall.","You are kind."],2,"I am tall.의 주어는 I(나)예요.","sentence parts"),
m("am을 넣어 알맞은 문장이 되는 것은?",["You ___ my friend.","We ___ in class.","They ___ tall.","I ___ nine."],3,"am은 I와 함께 써요.","grammar"),
m("are를 쓰면 틀린 문장은?",["You are kind.","We are happy.","They are tall.","I are tall."],3,"I 다음에는 are가 아니라 am을 써요.","grammar"),
m("A: Are you a student?\nB: Yes, I ___.",["are","am","is","do"],1,"Are you ...?에는 Yes, I am.으로 대답해요.","conversation"),
m("A: Are you sad?\nB: No, I ___ not.",["am","are","is","do"],0,"‘아니에요’는 No, I am not.이에요.","conversation"),
m("A: Who are you?\nB: I ___ Sora.",["is","are","do","am"],3,"이름을 말할 때는 I am ...이라고 해요.","conversation"),
m("‘우리는 친구예요.’를 영어로 하면?",["We are friends.","We is friends.","We am friends.","We friends are."],0,"We 다음에는 are를 써요.","grammar"),
m("‘동작’을 나타내는 낱말은?",["happy","tall","jump","kind"],2,"jump(뛰다)는 동작이고 나머지는 상태를 나타내요.","word type"),
m("I am ___.에 들어갈 수 있는 ‘기분’ 낱말은?",["eat","run","sing","sad"],3,"am 뒤에는 sad 같은 상태를 나타내는 말이 와요.","word type"),
m("‘I am Jina.’의 뜻은?",["나는 지나예요.","너는 지나예요.","우리는 지나예요.","그들은 지나예요."],0,"I am은 ‘나는 ~이에요’예요.","translation"),
m("‘You are my teacher.’의 뜻은?",["나는 선생님이에요.","당신은 나의 선생님이에요.","우리는 선생님이에요.","그는 선생님이에요."],1,"You are는 ‘너는(당신은) ~이에요’예요.","translation"),
m("철자가 바른 문장은?",["I amm ten.","I ham ten.","I am ten.","I um ten."],2,"am의 철자는 a-m이에요.","spelling"),
m("빈칸에 알맞은 말은? (나는 아홉 살이에요.)\n___ am nine.",["You","We","They","I"],3,"am과 짝이 되는 주어는 I예요.","grammar"),
m("빈칸에 알맞은 말은? (너희는 내 친구예요.)\n___ are my friends.",["I","You","He","It"],1,"‘너희는’은 You예요.","grammar"),
]
sent_r=[
r("I Am Tom","Hello. I am Tom. I am eight. I am a student. I am in Class 3. You are my friend. We are happy.",[
("톰은 몇 살인가요?",["seven","eight","nine","ten"],1,"I am eight.라고 나와요."),
("톰은 누구인가요?",["a teacher","a doctor","a student","a farmer"],2,"I am a student.라고 나와요."),
("톰이 ‘You’라고 부르는 사람은?",["톰의 선생님","톰의 친구","톰의 엄마","톰의 동생"],1,"You are my friend.라고 나와요."),
("‘We are happy.’의 뜻은?",["우리는 행복해요.","우리는 배고파요.","우리는 늦었어요.","우리는 슬퍼요."],0,"happy는 ‘행복한’이라는 뜻이에요.")]),
r("Our Class","Hi, I am Yuna. This is my class. We are in Class 2. Mina and Joon are my friends. They are tall. I am short. We are a good team.",[
("유나는 몇 반인가요?",["Class 1","Class 2","Class 3","Class 4"],1,"We are in Class 2.라고 나와요."),
("Mina와 Joon은 누구인가요?",["선생님","동생","친구","이웃"],2,"Mina and Joon are my friends.라고 나와요."),
("유나의 키는 어떤가요?",["tall","big","old","short"],3,"I am short.라고 나와요."),
("‘They’는 누구를 가리키나요?",["Mina and Joon","Yuna and Mina","Yuna and Joon","Yuna and the teacher"],0,"앞 문장의 Mina and Joon을 가리켜요.")]),
r("At the Park","We are at the park. The sky is blue. You are on the swing. I am on the slide. Dad is here. We are happy.",[
("글쓴이는 어디에 있나요?",["on the swing","on the slide","on the bench","in the car"],1,"I am on the slide.라고 나와요."),
("‘You’는 어디에 있나요?",["on the swing","on the slide","at home","at school"],0,"You are on the swing.이라고 나와요."),
("누가 함께 있나요?",["Mom","Grandpa","Dad","Sister"],2,"Dad is here.라고 나와요."),
("이 글의 장소로 알맞은 것은?",["school","park","zoo","home"],1,"We are at the park.라고 나와요.")]),
r("A Short Note","Dear Ben, I am sad today. I am not at school. I am at home. You are my best friend. Are you OK? Please come here. Love, Joy",[
("조이는 오늘 기분이 어떤가요?",["happy","angry","sad","tired"],2,"I am sad today.라고 나와요."),
("조이는 지금 어디에 있나요?",["at school","at home","at the park","at the zoo"],1,"I am at home.이라고 나와요."),
("조이가 이 글을 쓴 까닭은?",["친구를 부르려고","시험을 알리려고","선물을 사려고","길을 물으려고"],0,"Please come here.라고 친구를 오게 해요."),
("벤은 조이에게 어떤 사람인가요?",["선생님","동생","가장 친한 친구","이웃"],2,"You are my best friend.라고 나와요.")]),
]
W_like=[w("like","v","좋아하다","I like milk.","나는 우유를 좋아해요.",["run","jump","sleep"],["love","enjoy"],["lik","liek","likke"]),
 w("have","v","가지고 있다","I have a new bag.","나는 새 가방이 있어요.",["sing","walk","swim"],["own"],["hav","haev","havve"])]
W_sent=[w("student","n","학생","I am a student.","나는 학생이에요.",["table","window","tree"],["pupil"],["studant","studdent","stuedent"]),
 w("friend","n","친구","You are my friend.","너는 내 친구야.",["lamp","door","hill"],["pal"],["freind","frend","friand"])]
out={"packet":"E05-e2","sections":[{"skill":"e.e2.like","items":W_like+like_s+like_m+like_r},{"skill":"e.e2.sent","items":W_sent+sent_s+sent_m+sent_r}]}
open('/home/user/life-help-eng/scripts/learn/english-bank/pools/E05-e2.json','w').write(json.dumps(out,ensure_ascii=False,indent=1)+"\n")
print(len(like_s),len(like_m),len(like_r),len(sent_s),len(sent_m),len(sent_r))
