let ctr = 0;
const PAT = [2, 0, 3, 1, 1, 3, 0, 2, 3, 2, 1, 0, 0, 1, 3, 2];
export const STD = ["12영Ⅱ-01-04", "12영Ⅱ-01-06"];
export const Q = (q, key, wr, why) => ({ q, key, wr, why });
function place(key, wr) { const a = PAT[ctr++ % PAT.length]; const o = [...wr]; o.splice(a, 0, key); return { o, a }; }
function fin(qs) { return qs.map((x) => { if (x.o) return x; const { o, a } = place(x.key, x.wr); return { q: x.q, o, a, why: x.why }; }); }
const insQ = (given, n, why) => ({ q: `Where does the following sentence best fit in the passage?\n"${given}"`, o: ["[1]", "[2]", "[3]", "[4]"], a: n - 1, why });
export function ins({ title, x, s: s0, at = [1, 2, 3, 4], given, n, why, qs, pos = 0, std = STD, d }) {
  const s = x ? [...s0, x] : s0;
  let text = ""; let m = 0;
  s.forEach((x, i) => { text += (i ? " " : "") + x; if (at.includes(i + 1)) text += ` [${++m}]`; });
  const all = fin(qs); all.splice(pos, 0, insQ(given, n, why));
  const it = { k: "r", title, text, qs: all, std }; if (d) it.d = d; return it;
}
const L = ["A", "B", "C", "D"];
export function permsOf(n) { const r = []; const go = (a, rest) => { if (!rest.length) r.push(a); rest.forEach((x, i) => go([...a, x], rest.filter((_, j) => j !== i))); }; go([], [...Array(n).keys()]); return r; }
export function ordQ(paras, perm, why, lead = "What is the most natural order of (A), (B) and (C) after the given paragraph?") {
  const label = (k) => L[perm.indexOf(k)];
  const correct = paras.map((_, k) => `(${label(k)})`).join("-");
  const all = permsOf(paras.length).map((p) => p.map((i) => `(${L[i]})`).join("-")).filter((x) => x !== correct);
  const pick = [all[(ctr * 2) % all.length], all[(ctr * 2 + 1) % all.length], all[(ctr * 2 + 3) % all.length]];
  const uniq = [...new Set(pick)]; for (const x of all) { if (uniq.length >= 3) break; if (!uniq.includes(x)) uniq.push(x); }
  const { o, a } = place(correct, uniq.slice(0, 3));
  return { q: lead, o, a, why };
}
export function ord({ title, intro, paras, perm, why, qs, std = STD, d }) {
  const text = intro + "\n\n" + perm.map((k, i) => `(${L[i]}) ${paras[k]}`).join("\n\n");
  const all = [ordQ(paras, perm, why), ...fin(qs)];
  const it = { k: "r", title, text, qs: all, std }; if (d) it.d = d; return it;
}
export function dlg({ title, lines, at, given, n, why, qs, pos = 0, std = STD, d }) {
  let text = ""; let m = 0;
  lines.forEach((x, i) => { text += (i ? "\n" : "") + x; if (at.includes(i + 1)) text += `\n[${++m}]`; });
  const all = fin(qs); all.splice(pos, 0, insQ(given, n, why).q ? { ...insQ(given, n, why), q: `Where does the following line best fit in the dialogue?\n"${given}"` } : null);
  const it = { k: "d", title, text, qs: all, std }; if (d) it.d = d; return it;
}
// standalone
export function mord(stem, paras, perm, why, d) {
  const text = (stem ? stem + "\n" : "") + perm.map((k, i) => `(${L[i]}) ${paras[k]}`).join("\n");
  const x = ordQ(paras, perm, why, "");
  return { k: "m", q: `Choose the most natural order of the sentences.\n${text}`, o: x.o, a: x.a, why, std: STD, ...(d ? { d } : {}) };
}
export function mins(sents, at, given, n, why, d) {
  let text = ""; let m = 0;
  sents.forEach((x, i) => { text += (i ? " " : "") + x; if (at.includes(i + 1)) text += ` [${++m}]`; });
  return { k: "m", q: `Where does the given sentence best fit?\nGiven: "${given}"\n${text}`, o: ["[1]", "[2]", "[3]", "[4]"], a: n - 1, why, std: STD, ...(d ? { d } : {}) };
}
export function M(q, key, wr, why, d) { const { o, a } = place(key, wr); return { k: "m", q, o, a, why, std: STD, ...(d ? { d } : {}) }; }
export const S = (o) => ({ k: "s", ...o });
export function stats(items) {
  const w = (t) => t.replace(/\[\d\]/g, "").split(/\s+/).filter(Boolean).length;
  let n = 0, lc = 0; const out = [];
  for (const it of items) {
    if (it.k === "r" || it.k === "d") { const c = w(it.text); if (c < 112) out.push(`SHORT ${c} ${it.title}`); }
    const qs = it.qs ?? (it.k === "m" ? [it] : []);
    for (const q of qs) { n++; const l = q.o.map((x) => x.length); const m = Math.max(...l); if (l[q.a] === m && l.filter((x) => x === m).length === 1) lc++; }
  }
  out.push(`questions ${n}, longest-correct ${lc} (${Math.round(100 * lc / n)}%)`);
  return out;
}
