import { stats } from "./lib.mjs";
import fs from "node:fs";
const parts = process.argv.slice(2);
const all = [];
for (const p of parts) all.push(...(await import("./" + p)).default);
console.log(stats(all).join("\n"));
fs.writeFileSync("all.json", JSON.stringify(all));
