import fs from "node:fs";
import { stats } from "./lib.mjs";
const parts = ["c1","c2","c3","c4","c5","c6"];
let all = [];
for (const p of parts) all.push(...(await import("./" + p + ".mjs")).default);
console.log(stats(all.filter(x=>x.k!=="s")).join("\n"));
const cnt = {}; for (const i of all) cnt[i.k] = (cnt[i.k]||0)+1; console.log(cnt);
const out = { packet: "H13-h3-ins", sections: [{ skill: "e.h3.ins", items: all }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H13-h3-ins.json", JSON.stringify(out, null, 1) + "\n");
