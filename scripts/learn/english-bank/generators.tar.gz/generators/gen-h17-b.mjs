import { Q, R } from "./gen-h17-a.mjs";
const S1 = ["12직영01-01"];
export const rs2 = [
R("A Friendly Payment Reminder",
`Subject: Invoice 2209 – payment reminder

Dear Mr. Brooks,

I hope you are well. This is a friendly reminder that invoice 2209, for the website redesign completed on September 3, is still unpaid. The payment was due on October 3, which means it is now twelve days overdue. I understand that invoices are sometimes missed during busy periods, so I have attached another copy for your convenience.

If the payment has already been sent, please accept my thanks and ignore this message. If there is a problem with the invoice, such as a wrong amount or missing details, please let me know and I will correct it immediately. Otherwise, I would be grateful if you could arrange payment by October 22.

Kind regards,
Sora Kim
Freelance Web Designer`,
[
Q("What is Sora's main purpose in writing?", "To ask politely for an overdue payment", ["To offer Mr. Brooks a new website design", "To correct a mistake in the amount charged", "To complain about a late project schedule"], "연체된 대금을 정중하게 요청하는 이메일이에요.", S1),
Q("Why did Sora attach another copy of the invoice?", "The first one might have been overlooked", ["The first copy contained a wrong amount", "Mr. Brooks had asked her to resend it", "The bank required two copies for payment"], "invoices are sometimes missed during busy periods라고 했어요.", S1),
Q("What does Sora ask Mr. Brooks to do if the invoice has a mistake?", "Contact her so she can fix it", ["Pay the amount that he thinks is right", "Wait until October 22 to say anything", "Send the invoice to a different address"], "let me know and I will correct it이라고 했어요.", ["12직영01-04"]),
Q("How would you describe the tone of the email?", "Polite and patient", ["Angry and threatening", "Playful and casual", "Cold and uninterested"], "friendly reminder, I would be grateful 등에서 정중하고 인내심 있는 어조를 알 수 있어요.", S1),
]),
R("Learning a Trade at School",
`In recent years, more teenagers have chosen vocational high schools over traditional academic ones. Su-bin, a second-year student at a school that specializes in cooking, says she made the decision after watching her uncle run a small restaurant. "I wanted to do something practical," she explains.

Her week is divided between regular subjects and kitchen training. Twice a month, students also work at partner restaurants, where professional chefs supervise them. Su-bin admits that the early mornings are difficult, but she says the experience has changed how she sees her future. "In a normal class, you sometimes wonder why you are studying something. In the kitchen, you see the result on the plate immediately."

Educators note that such programs help students discover their strengths early, although they warn that teenagers should still keep other options open.`,
[
Q("What is the passage mainly about?", "A student's experience in job-focused education", ["The history of a family restaurant business", "Complaints about early morning classes at school", "Advice for opening a new kitchen"], "직업계 고등학교에서의 학생 경험에 관한 글이에요.", S1),
Q("Why did Su-bin choose a vocational school?", "She wanted to learn something practical", ["Her parents ordered her to study cooking", "She had failed an exam at her old school", "Her uncle gave her a job in his kitchen"], "I wanted to do something practical이라고 했어요.", S1),
Q("What does Su-bin like about kitchen training?", "She can see the results at once", ["She never has to get up early", "She can skip the regular subjects", "She earns a salary from the school"], "you see the result on the plate immediately라고 했어요.", S1),
Q("What do educators warn about?", "Students should not close off other choices", ["Partner restaurants are too strict", "Vocational schools are too expensive to join", "Cooking is not a useful skill at all"], "keep other options open이라고 했어요.", S1),
]),
R("Reporting a Software Bug",
`Subject: Bug – the Save button freezes the app

Hello team,

While testing version 2.4 on my laptop this morning, I found a problem with the Save button. When I enter a note longer than 500 characters and press Save, the app freezes for about ten seconds and then closes without saving anything.

Steps to reproduce:
1. Open a new note.
2. Paste in a text of more than 500 characters.
3. Press Save.

Expected result: The note is saved and a confirmation message appears.
Actual result: The app freezes and closes, and the note is lost.

I tried this three times with the same result. Shorter notes work normally. Since users could lose important work, I suggest that we fix this before the release on Friday. I have attached a screen recording.

Thanks,
Ha-neul`,
[
Q("What is the writer's purpose?", "To report a fault and ask for it to be fixed", ["To announce the release date of the app", "To praise the team for finishing version 2.4", "To ask for help with a new laptop"], "버그를 보고하고 수정을 요청하는 글이에요.", ["12직영01-01", "12직영01-05"]),
Q("When does the problem happen?", "When a long note is saved", ["When the app is opened on a laptop", "When a short note is pasted in", "When a screen recording is attached"], "500자보다 긴 메모를 저장할 때 발생해요.", ["12직영01-05"]),
Q("What can be inferred about the writer's suggestion?", "She feels the bug is serious enough to delay the release", ["She wants the team to stop testing the app", "She thinks the release should be moved to the middle of next year", "She feels that shorter notes should be banned"], "릴리스 전에 고치자고 한 것은 문제가 심각하다고 보기 때문이에요.", ["12직영01-05"]),
Q("What is the purpose of the numbered steps?", "To let others repeat the problem", ["To show how to write a long note", "To explain what the app is designed for", "To list the features of version 2.4"], "Steps to reproduce는 문제를 재현하게 해 줘요.", ["12직영01-03"]),
Q("What does “reproduce” mean in this text?", "Make the same problem happen again", ["Copy a note for several users", "Create a better version of the app", "Print the report on paper"], "reproduce는 같은 현상을 다시 일으키는 것을 뜻해요.", ["12직영01-05"]),
]),
R("Smart Farming",
`Farming is changing quickly. On a strawberry farm in Nonsan, sensors placed among the plants measure temperature, moisture, and light every few minutes and send the data to a farmer's phone. If the soil becomes too dry, the system can switch on the watering equipment automatically, even in the middle of the night.

Farmer Lee Dong-gu says that the technology has not reduced his workload as much as he expected. "I still walk through the greenhouse every day," he says. "But now I know where to look." He also reports that his harvest has risen by about fifteen percent, while his water use has fallen.

Experts caution, however, that smart farms are costly to build. Young farmers often need government support to buy equipment, and learning to read the data takes time.`,
[
Q("What is the main idea of the passage?", "Technology is changing how some farms operate", ["Strawberries grow best in cool greenhouses", "Farmers should avoid using their phones at work", "Water is becoming too costly for farms"], "스마트 농업이 농장 운영을 바꾸고 있다는 글이에요.", S1),
Q("What does Mr. Lee say about his work?", "He still has to check the greenhouse daily", ["He no longer needs to visit the farm", "He works only at night with the sensors", "He has hired experts to read all the data"], "I still walk through the greenhouse every day라고 했어요.", S1),
Q("What benefit does the passage mention?", "A larger harvest with less water", ["A lower price for farm equipment", "A shorter walk through the fields", "A faster delivery to the market"], "수확량이 15% 늘고 물 사용은 줄었어요.", S1),
Q("What can be inferred from the final paragraph?", "Starting a smart farm is hard for newcomers", ["Government support has made the equipment free", "Reading data is easier than using a phone", "Experts want farmers to stop using sensors"], "비용이 많이 들고 데이터를 읽는 법을 배우는 데 시간이 걸린다고 했어요.", S1),
]),
R("Conference Call Etiquette",
`Conference calls save time and travel costs, but they can easily go wrong without good manners. First, join a few minutes early and test your microphone so that the meeting can start on time. Keep yourself on mute when you are not speaking, as background noise such as typing or a barking dog can distract everyone.

When you do speak, state your name briefly, particularly in a large group, because participants cannot see each other's body language. Try not to interrupt; if two people begin speaking at once, one of them should politely offer the other the chance to continue. Finally, summarize the key decisions at the end and say who will take each action. A short follow-up email that repeats these points helps to prevent confusion afterward.`,
[
Q("What is the passage mainly about?", "Good manners for phone and video meetings", ["How to repair a broken microphone", "Why meetings should always be held in person", "Ways to travel to a faraway office"], "전화·화상 회의 예절에 관한 글이에요.", ["12직영01-04"]),
Q("Why should participants mute their microphones?", "Background sounds may disturb other people", ["The call connection becomes more expensive", "Other speakers cannot use their own names", "The meeting leader cannot hear the questions"], "background noise ... can distract everyone이라고 했어요.", ["12직영01-04"]),
Q("Why is it useful to say your name before speaking?", "Others cannot see who is talking", ["The company keeps a list of every word", "Names are needed to start the meeting", "Quiet people are often forgotten otherwise"], "participants cannot see each other's body language라고 했어요.", ["12직영01-04"]),
Q("What is the purpose of the follow-up email?", "To avoid confusion about what was agreed", ["To invite more people to the meeting", "To apologize for noise during the call", "To ask everyone to turn on the camera"], "to prevent confusion afterward라고 했어요.", ["12직영01-05"]),
]),
R("A Letter of Resignation",
`Dear Ms. Kang,

Please accept this letter as formal notice that I will leave my position as sales assistant on November 30. This was not an easy decision, as I have enjoyed my two years at Greenfield Supplies and have learned a great deal from you and the rest of the team.

I have been offered a place on a part-time training course in logistics, which I believe will help me to reach my long-term career goals. To make the transition smooth, I would be happy to train my replacement and to complete all my current orders before I leave. Please let me know if you would like me to prepare a handover document.

Thank you for your support and guidance during my time here.

Sincerely,
Jun-seo Baek`,
[
Q("Why is Jun-seo writing the letter?", "To announce his plan to leave a job", ["To ask for a promotion in the sales team", "To apply for a place on a training course", "To complain about the support he received"], "퇴직 의사를 공식적으로 알리는 사직서예요.", ["12직영01-06"]),
Q("Why is he leaving?", "He wants to study for a different career path", ["He is unhappy with his two years of work", "His manager asked him to find a new job", "The company will close at the end of November"], "물류 교육 과정에 합격하여 장기 목표를 이루고자 해요.", ["12직영01-06"]),
Q("What does he offer to do before leaving?", "Help his replacement learn the job", ["Look for a new company for his team", "Work extra hours until the next year", "Pay for the cost of the training course"], "train my replacement라고 했어요.", ["12직영01-06"]),
Q("What can be inferred about the writer's attitude?", "He is grateful and wants to leave on good terms", ["He is angry and wants to leave at once", "He is nervous and wants to ask for a bigger salary", "He is bored and wants to avoid work"], "감사 표현과 인수인계 제안에서 좋은 관계로 떠나려는 태도를 알 수 있어요.", ["12직영01-06"]),
]),
R("Responding to a Complaint",
`Dear Mr. Nam,

Thank you for your message about your visit to our restaurant last Saturday. I am sorry to hear that your main course arrived cold and that you waited forty minutes for your meal. This is not the standard we aim for, and I fully understand your disappointment.

After speaking with our kitchen team, I learned that two cooks were absent that evening and that we did not warn customers about longer waiting times. We have since changed our schedule so that this will not happen again. We would like to invite you and a guest to dinner next month, as our guests, so that we can show you the quality we normally provide.

Please call me at 02-555-0142 to arrange a date.

Yours sincerely,
Min-ji Seo, Manager`,
[
Q("What is the manager's main purpose?", "To respond to a complaint and make up for it", ["To advertise a new menu to many old customers", "To explain how to cook a main course", "To hire two more cooks for Saturdays"], "불만에 답하고 보상을 제안하는 글이에요.", S1),
Q("According to the letter, what caused the long wait?", "Some kitchen staff were missing", ["The restaurant had too few tables", "The customers arrived at the wrong time", "The manager was away from the restaurant"], "two cooks were absent라고 했어요.", S1),
Q("What does the restaurant promise?", "To prevent the same problem in the future", ["To return the cost of last Saturday's meal", "To close on Saturday evenings from now on", "To stop serving main courses completely"], "changed our schedule so that this will not happen again이라고 했어요.", S1),
Q("What does Mr. Nam need to do to accept the invitation?", "Phone the manager to choose a date", ["Write back with the name of his guest", "Visit the restaurant to pay a deposit", "Fill in a form on the restaurant's website"], "call me ... to arrange a date라고 했어요.", ["12직영01-03"]),
Q("The phrase “the standard we aim for” means", "the level of quality we try to reach", ["the number of tables in our hall", "the rule that we always copy from others", "the time we open on weekends"], "standard는 목표로 하는 수준을 뜻해요.", S1),
]),
R("Preparing for a Job Interview",
`A job interview is not only a test; it is a conversation in which both sides learn about each other. The most successful candidates usually prepare in three ways.

First, they research the organization. Knowing what a company makes, whom it serves, and what it values allows you to connect your own skills with its needs. Second, they practise answering common questions aloud, such as “Tell me about a time you solved a problem.” A good answer gives a brief situation, describes the action you took, and explains the result. Third, they prepare one or two questions of their own, for example about training opportunities.

On the day, arrive ten minutes early, listen carefully, and be honest. Interviewers often remember a sincere answer longer than a perfect one.`,
[
Q("What is the main point of the passage?", "Preparation helps candidates do well in interviews", ["Interviews are tests that few people pass", "Companies prefer candidates who talk the most in interviews", "Every interview asks exactly the same questions"], "면접 준비 방법에 관한 글이에요.", ["12직영01-04"]),
Q("What is the purpose of researching the company?", "To link your skills to its needs", ["To find out how much the staff earn", "To prove that the company is wrong", "To learn the names of all its customers"], "connect your own skills with its needs라고 했어요.", ["12직영01-04"]),
Q("According to the passage, a good answer to a problem-solving question includes", "the situation, your action, and the result", ["a long list of your best personal qualities and hobbies", "a complaint about a former manager", "the exact words of the interviewer"], "상황, 행동, 결과의 순서로 답하라고 했어요.", ["12직영01-03"]),
Q("What does the last sentence suggest?", "Honesty can be more memorable than perfection", ["Perfect answers are always the best choice for interviews", "Interviewers dislike people who are late", "Sincere candidates never make a mistake"], "sincere answer를 완벽한 대답보다 오래 기억한다고 했어요.", ["12직영01-04"]),
]),
R("A New Bakery Opens",
`PRESS RELEASE

Maple & Grain, a neighborhood bakery run by two former classmates, will open its doors in Jeonju on Saturday, May 3. Owners Ye-rin Choi and Tomás Rivera met at a baking course and spent three years saving money for the business.

The bakery will offer breads made from locally grown wheat, along with seasonal pastries. “We want people to taste where their food comes from,” said Ms. Choi. To celebrate the opening, the first fifty customers will receive a free loaf, and all visitors can watch bread being shaped by hand between 9 and 11 a.m.

Maple & Grain will employ six local residents, including two recent graduates of a vocational school. The bakery is located at 14 Hanok Street and will be open from 7 a.m. to 7 p.m., Tuesday to Sunday.

Contact: press@maplegrain.example`,
[
Q("What is the purpose of the press release?", "To announce the opening of a business", ["To advertise a baking course for students", "To report a change in the price of wheat", "To ask readers to invest in a bakery"], "새 빵집 개업을 알리는 보도자료예요.", S1),
Q("According to the text, how did the owners prepare?", "They saved money for three years", ["They worked in a big factory for years", "They asked the city to pay for the shop", "They moved their family to another town"], "spent three years saving money라고 했어요.", S1),
Q("What will happen at the opening?", "Visitors can see bread being shaped", ["Every customer will receive free pastries", "The owners will teach a baking class", "The bakery will stay open until midnight"], "watch bread being shaped by hand라고 했어요.", S1),
Q("What can be inferred about the bakery's attitude to its community?", "It values local people and local products", ["It plans to import wheat from far away", "It wants to hire only very experienced chefs", "It will sell mainly to tourists"], "지역 밀과 지역 주민 고용에서 지역 사회를 중시함을 알 수 있어요.", ["12직영01-07"]),
]),
R("From Truck to Customer",
`Every parcel that reaches your door has passed through a chain of steps in a distribution center. When a truck arrives, workers first check the delivery note against the number of boxes to make sure nothing is missing. The goods are then unloaded and scanned, which records their arrival in the computer system.

Next, each parcel is sorted by destination. Large centers use conveyor belts and machines for this task, while smaller ones depend on workers who read the labels. Sorted parcels are placed into containers, which are loaded onto vans according to their route. Finally, drivers scan every parcel again when it leaves the building and when it reaches the customer. This final scan allows the sender to follow the delivery online.

Because mistakes at any stage can delay a parcel, workers are trained to check labels carefully and to report damaged boxes immediately.`,
[
Q("What does the passage mainly describe?", "The steps a parcel goes through before delivery", ["How to become a skilled delivery driver in a short time", "Why parcels are often damaged on trucks", "The history of conveyor belts in factories"], "택배가 배송되기까지의 단계를 설명하는 글이에요.", ["12직영01-03"]),
Q("What happens right after the goods are unloaded?", "They are scanned into the system", ["They are sorted by their destination", "They are put into containers", "They are loaded into vans"], "unloaded and scanned라고 했으므로 하역 직후에는 스캔해서 시스템에 기록해요.", ["12직영01-03"]),
Q("Why do drivers scan parcels at the end?", "So that the sender can follow the delivery", ["So that the center can find broken boxes", "So that large machines can sort them", "So that customers can sign for the parcel on the van"], "This final scan allows the sender to follow the delivery online이라고 했어요.", ["12직영01-03"]),
Q("What can be inferred about careless workers?", "Their errors could slow down deliveries", ["They are not allowed to scan parcels", "They are given the most difficult routes", "They are replaced by machines at once"], "어느 단계의 실수든 배송을 지연시킬 수 있다고 했어요.", S1),
]),
R("Volunteers Needed",
`The Riverside Community Center is looking for volunteers to help at its Winter Food Drive, which runs from December 1 to December 14. Volunteers will sort donated food, pack boxes for families, and greet donors at the front entrance. No special skills are needed, but volunteers must be at least sixteen years old.

Shifts are three hours long, and each volunteer is asked to commit to at least two shifts. A short training session will be held on November 28 to explain safety rules and how to handle donor records. All personal information on these records is confidential, and volunteers must not share it outside the center.

Volunteering is a good way to gain experience for a résumé and meet people from different backgrounds. To sign up, visit the center's front desk or email the coordinator.`,
[
Q("What is the purpose of this notice?", "To recruit people for a charity event", ["To ask for donations of money", "To announce the closing of the community center", "To advertise a paid winter job"], "봉사자를 모집하는 공지예요.", S1),
Q("Which statement is true about the volunteers?", "They have to be at least sixteen", ["They must have special food-handling skills", "They can choose to work only one shift", "They will be paid after each shift"], "volunteers must be at least sixteen years old라고 했어요.", S1),
Q("Why is there a training session on November 28?", "To teach safety rules and record handling", ["To select who will work at the front entrance", "To collect food from the donors", "To explain how to write a résumé"], "safety rules and how to handle donor records라고 했어요.", ["12직영01-08"]),
Q("What does the notice say about donor records?", "Their details must not be shared outside", ["They can be copied for personal use", "They are kept only for sixteen days", "They are shown to every volunteer online"], "confidential이며 센터 밖에서 공유하면 안 돼요.", ["12직영01-08"]),
]),
R("Scheduling Across Time Zones",
`Subject: Proposed times for our project call

Hi Elena and team,

Since we are working from three different countries, finding a convenient time for our weekly call is not simple. When it is 9 a.m. in Seoul, it is 8 p.m. the previous day in New York and 2 a.m. in Berlin. I have therefore listed two options that I hope are fair.

Option A: Thursday, 8 a.m. Seoul / 7 p.m. Wednesday New York / 1 a.m. Berlin.
Option B: Thursday, 3 p.m. Seoul / 2 a.m. New York / 8 a.m. Berlin.

I am aware that both options are inconvenient for someone, so I suggest that we rotate the time each month. Could you please let me know which you prefer by Monday? If neither works, feel free to propose another time.

Thanks for your flexibility,
Hyeon-ho`,
[
Q("Why is Hyeon-ho writing the email?", "To find a suitable time for a regular meeting", ["To cancel the weekly call completely", "To explain how time zones were first created long ago", "To introduce three new team members"], "회의 시간을 조율하려는 이메일이에요.", ["12직영01-04"]),
Q("What does Hyeon-ho propose to make things fair?", "Changing the meeting time every month", ["Holding all meetings in Seoul", "Asking the Berlin team to join the call late", "Reducing the calls to once a year"], "rotate the time each month라고 했어요.", ["12직영01-07"]),
Q("What can be inferred about Option B?", "It is a bad hour for the New York member", ["It is the best hour for everyone", "It takes place in the middle of Friday morning", "It is held in the morning in Seoul"], "Option B는 뉴욕에서 새벽 2시예요.", ["12직영01-04"]),
Q("What does Hyeon-ho ask the readers to do by Monday?", "Say which option they would like", ["Send him a list of other topics", "Book a room for the meeting", "Translate the email for their team"], "let me know which you prefer by Monday라고 했어요.", ["12직영01-04"]),
]),
R("Life as a Freelancer",
`Freelancers are self-employed workers who take on jobs for different clients rather than working for one employer. Writers, designers, translators, and programmers often choose this path because it offers freedom. A freelancer can decide when and where to work, and which projects to accept.

However, this freedom comes with trade-offs. Income can change greatly from month to month, so many freelancers keep savings to cover quiet periods. They are also responsible for tasks that an employer would normally handle, such as sending invoices, paying taxes, and finding new clients. Some experienced freelancers say the hardest part is not the work itself but the discipline needed to stay organized when no one is watching.

For those who are considering this option, a sensible first step is to start part-time while keeping a regular job, and to build a reputation slowly.`,
[
Q("What is the main idea of the passage?", "Freelancing offers freedom but also real challenges", ["Freelancers always earn much more than employees do", "Writers and designers should never be employed", "Taxes are the only difficulty for freelancers"], "자유와 함께 어려움도 있다는 글이에요.", S1),
Q("Why do many freelancers keep savings?", "Their income is not the same every month", ["They must pay their clients in advance", "Their tools are very expensive to repair", "They are not allowed to borrow money"], "Income can change greatly from month to month라고 했어요.", S1),
Q("What does the writer say about experienced freelancers?", "They find self-discipline especially hard", ["They no longer need to send invoices", "They prefer to work for just one employer", "They never accept new projects"], "the discipline needed to stay organized가 가장 힘들다고 했어요.", S1),
Q("What does the writer recommend to beginners?", "Begin on a part-time basis at first", ["Quit a job before looking for clients", "Accept every project that is offered", "Work only for friends and family"], "start part-time while keeping a regular job이라고 했어요.", S1),
Q("In the passage, “trade-offs” are", "good and bad points that come together", ["items that are traded for money", "prices that are set by the clients", "jobs that are swapped with other freelancers"], "trade-off는 장점을 얻는 대신 감수해야 하는 단점을 뜻해요.", S1),
]),
];

const D = (title, text, qs) => R(title, text, qs, "d");
export const ds = [
D("Booking a Meeting Room",
`Receptionist: Good morning, Pinewood Offices. How can I help you?
Caller: Hello. I'd like to book a meeting room for next Wednesday afternoon, please.
Receptionist: Certainly. How many people will be attending?
Caller: Eight, and we'll need a projector for a presentation.
Receptionist: The Maple Room seats ten and has a projector. It's available from one to three, or after four o'clock.
Caller: One to three is perfect. Could I also get some coffee for everyone?
Receptionist: Of course, but catering has to be ordered at least a day in advance. May I have your name and company?
Caller: It's Jae-won Han from Daon Software. And please send the confirmation to my email.
Receptionist: Will do, Mr. Han. We look forward to seeing you on Wednesday.`,
[
Q("Why does the caller phone the receptionist?", "To reserve a room for a meeting", ["To complain about an office projector", "To ask for a job at the front desk", "To cancel a presentation next week"], "회의실을 예약하려고 전화했어요.", ["12직영01-02"]),
Q("Which time does the caller choose?", "Between one and three o'clock", ["After four o'clock in the afternoon", "Between ten and noon in the morning", "At three o'clock sharp, for an hour"], "One to three is perfect라고 했어요.", ["12직영01-02"]),
Q("What must be done a day before the meeting?", "The coffee has to be ordered", ["The projector has to be tested", "The name has to be changed", "The room has to be cleaned"], "catering has to be ordered at least a day in advance라고 했어요.", ["12직영01-03"]),
Q("What is the relationship between the speakers?", "A service provider and a customer", ["Two coworkers at one software firm", "A teacher and her student", "A manager and a new employee"], "접수 담당자와 예약 고객 사이의 관계예요.", ["12직영01-02"]),
]),
D("A Mock Interview",
`Interviewer: Thank you for coming in, Nari. Could you tell me why you applied to our travel agency?
Nari: Of course. I've always loved planning trips for my friends, and I'd like to turn that hobby into a career.
Interviewer: That's interesting. Can you give me an example of a time you solved a problem?
Nari: Last year, our school trip nearly got cancelled because the bus company made a mistake. I called two other companies and found a cheaper option within a day.
Interviewer: Impressive. How do you handle a customer who is upset?
Nari: I try to stay calm, listen until they finish, and then explain what I can do to help.
Interviewer: Good. Finally, do you have any questions for us?
Nari: Yes. What kind of training do new employees receive in their first month?
Interviewer: We offer a two-week course, followed by a mentor. I'll send details by email.`,
[
Q("What is the interviewer's first question about?", "Nari's reason for applying", ["Nari's earlier school trips", "The cost of a bus company", "The training for new staff"], "첫 질문은 지원 동기예요.", ["12직영01-02"]),
Q("How did Nari solve the problem with the school trip?", "She found another transport company", ["She asked the school to pay more", "She cancelled the trip herself", "She travelled with friends by train"], "I called two other companies라고 했어요.", ["12직영01-02"]),
Q("What can be inferred about Nari's way of treating upset customers?", "She puts listening before offering help", ["She avoids speaking to them directly at all", "She gives them a refund straight away", "She asks the manager to take over"], "listen until they finish, and then explain에서 알 수 있어요.", ["12직영01-04"]),
Q("What does Nari's last question show?", "She is interested in learning at the job", ["She wants to leave the job after one month", "She is worried about the salary", "She dislikes working with a mentor"], "교육 내용을 묻는 것은 배움에 관심이 있음을 보여 줘요.", ["12직영01-04"]),
]),
D("Handing Over a Project",
`Dahee: Hi Marcus, do you have a few minutes? I'm going on leave tomorrow, so I'd like to hand over the Cho account.
Marcus: Sure. Is there anything urgent?
Dahee: Just one thing. The client wants the revised brochure by Thursday, and the printer needs the final file a day before.
Marcus: So I'll have to send it on Wednesday at the latest.
Dahee: Exactly. All the files are in the shared folder called "Cho 2025", and my notes are in the first document.
Marcus: Great. Who should I contact if the client has questions about the budget?
Dahee: Talk to Ms. Park in finance. She knows the details better than I do.
Marcus: Got it. Thanks for being so organized.
Dahee: No problem. I'll check my email on Friday, just in case.`,
[
Q("What are the speakers mainly discussing?", "How to transfer work during a leave", ["How to design a new brochure", "When to meet the client in person", "Which printer is the cheapest to use"], "휴가 전 업무 인수인계에 관한 대화예요.", ["12직영01-02", "12직영01-05"]),
Q("When must Marcus send the file to the printer?", "On Wednesday", ["By Thursday night", "On Tuesday", "On Friday"], "client deadline이 Thursday이고 인쇄소는 하루 전에 파일이 필요하니 Wednesday예요.", ["12직영01-03"]),
Q("Who should Marcus ask about the budget?", "Ms. Park", ["The client", "Dahee", "The printer"], "Talk to Ms. Park in finance라고 했어요.", ["12직영01-02"]),
Q("What can be inferred about Dahee?", "She is prepared and can still be reached", ["She is angry about leaving her work", "She will be away for several months", "She has not saved any useful notes for Marcus"], "정리된 메모와 금요일 이메일 확인으로 알 수 있어요.", ["12직영01-02"]),
]),
D("Asking for Time Off",
`Employee: Excuse me, Ms. Lim. Do you have a moment to talk about my schedule?
Manager: Of course, Tae-yang. Please sit down.
Employee: I'd like to request three days of leave in the second week of March. My cousin is getting married overseas.
Manager: Congratulations to your family. Let me check the calendar. Hmm, we have the product launch on the twelfth.
Employee: I know. That's why I'd like to leave on the fourteenth, after the launch is over.
Manager: That should work. But would you be able to finish the monthly report before you go?
Employee: Yes, I can send it by the thirteenth.
Manager: Then I'm happy to approve it. Please fill in the leave form and submit it to HR this week.
Employee: I'll do that today. Thank you so much for understanding.`,
[
Q("Why does Tae-yang talk to Ms. Lim?", "To ask for permission to take leave", ["To report a mistake in the calendar", "To offer help with the product launch", "To invite her to his cousin's wedding"], "휴가를 요청하는 대화예요.", ["12직영01-02"]),
Q("Why did Tae-yang choose the fourteenth?", "The product launch will have finished", ["The wedding will be held on the twelfth", "The monthly report is due that day", "HR is closed until the fourteenth"], "launch가 12일이므로 이후인 14일을 골랐어요.", ["12직영01-02"]),
Q("What condition does Ms. Lim set?", "He has to complete the monthly report", ["He has to find a replacement driver", "He has to lead the product launch", "He has to work on the next weekend"], "finish the monthly report before you go라고 했어요.", ["12직영01-04"]),
Q("What will Tae-yang do next?", "Fill out a leave form for HR", ["Call his cousin overseas", "Check the calendar for the launch", "Send the report to the client"], "fill in the leave form and submit it to HR라고 했어요.", ["12직영01-03"]),
]),
];
