// passages 1-12. Each: [title, text, [ [q, key, [d1,d2,d3], why, std] ... ]]
const S = ["9영01-03", "9영02-07"], D = ["9영01-02"], I = ["9영01-04"], P = ["9영01-06"], V = ["9영01-07"];
export default [
["Why Bees Matter",
"Bees do more than make honey. When a bee visits a flower to drink nectar, pollen sticks to its legs. The bee then carries the pollen to the next flower, and this helps plants make fruit and seeds. Many of the foods we eat, such as apples, almonds, and blueberries, depend on this work. Without bees, farms would produce much less food. That is why many towns now plant wildflowers and protect bee homes. Even a small garden can help.",
[
["Which is the best summary of the passage?", "Bees help plants make fruit and seeds, so protecting them keeps food safe.", ["Bees make honey from nectar and store it in homes that towns try to protect.", "Gardens are the only places where bees can find enough flowers to live well.", "Many kinds of insects are useful to people in cities, farms, and wild places."], "중심 내용은 벌이 꽃가루를 옮겨 식물이 열매를 맺게 돕고, 그래서 벌을 보호해야 한다는 것이에요. 나머지는 세부 내용이거나 글에 없거나 너무 넓은 내용이에요.", S],
["How does pollen move from one flower to another?", "It sticks to a bee's legs.", ["Strong wind carries it across fields.", "Farmers move it with small tools.", "Rain washes it from flower to flower."], "본문에 꿀벌이 꽃에서 꿀을 마시는 동안 꽃가루가 다리에 붙는다고 나와 있어요.", D],
["Why does the writer mention apples, almonds, and blueberries?", "To give examples of foods that need bees", ["To explain which fruits taste the sweetest", "To show that farms grow only a few foods", "To tell readers what bees like to eat"], "세 가지는 벌의 일에 의존하는 음식의 예로 쓰였어요.", P],
["What would most likely happen without bees?", "Farms would grow less food.", ["Flowers would stop growing in towns and gardens.", "Honey would become cheaper in every store.", "Wildflowers would take over all the farms."], "글에서 벌이 없으면 농장이 훨씬 적은 음식을 생산할 것이라고 해요.", I]
]],
["Join the Green Club",
"Are you tired of seeing trash on the school grounds? The Green Club is looking for new members. Every Wednesday after lunch, we pick up litter, sort the recycling bins, and water the flowers near the gym. Last month we also made posters that remind students to turn off the lights. You do not need any special skills. All you need is a bit of free time and a kind heart. Come to Room 204 this week and bring a friend!",
[
["Which sentence is the best summary of the notice?", "The Green Club invites students to join and care for the school.", ["The Green Club meets in Room 204 and sometimes makes posters about lights.", "Every student must clean the school grounds once a week after lunch.", "Students who love the environment should start clubs in many schools."], "공지의 목적은 학교를 함께 가꿀 새 회원을 모집하는 것이에요.", S],
["What is the purpose of the notice?", "To ask students to become members", ["To report how much trash was collected", "To explain how to recycle at home", "To thank students for cleaning the gym"], "필자는 새 회원을 구하고 있어요.", P],
["According to the notice, what do new members need?", "Some free time and a kind heart", ["Experience in making posters", "A friend who is already a member", "Special tools for sorting trash"], "특별한 기술은 필요 없고 시간과 친절한 마음이면 된다고 해요.", D],
["The phrase \"tired of\" in the first sentence is closest in meaning to", "unhappy about", ["proud of", "curious about", "afraid of"], "be tired of는 '~에 싫증 나다, 지겹다'라는 뜻이라 unhappy about과 가까워요.", V]
]],
["Sleep and Your Brain",
"Many teenagers stay up late to study or look at their phones, but sleep is just as important as homework. During sleep, the brain sorts what you learned during the day and stores the important parts. Teenagers need about eight to ten hours each night. Students who sleep too little often find it hard to focus, and they may feel upset more easily. A simple habit, such as putting the phone away thirty minutes before bed, can make falling asleep easier.",
[
["What is the passage mainly about?", "Why enough sleep matters for teenagers", ["How to finish homework faster at night", "Why phones are bad for the brain", "Which foods help students focus in class"], "글 전체가 충분한 수면이 십대에게 왜 중요한지를 설명해요. 휴대폰은 한 가지 습관으로만 나와요.", S],
["Which summary adds information that is NOT in the passage?", "Teenagers who sleep more than ten hours get better grades.", ["Sleep helps the brain keep what students learned.", "Too little sleep can make teenagers upset and unable to focus.", "Putting the phone away early can help teenagers fall asleep."], "성적에 관한 내용은 글에 없어요. 나머지는 모두 글에 있는 내용이에요.", S],
["What does the brain do during sleep?", "It sorts what was learned.", ["It stops working until morning.", "It forgets the hard homework.", "It grows bigger every night."], "자는 동안 뇌는 낮에 배운 것을 정리하고 중요한 부분을 저장해요.", D],
["Which advice does the writer give?", "Put your phone away.", ["Study until you feel sleepy.", "Sleep during the school day.", "Do homework before dinner."], "마지막 문장에서 잠들기 30분 전에 휴대폰을 치우라고 조언해요.", D]
]],
["An Email About the Bike",
"Hi Mr. Park, I bought a bike from your shop last Saturday, and I am happy with it, but I have a small problem. The front brake makes a loud noise when I stop, and it feels a little loose. I rode only to school and back, so I do not think I damaged it. Could I bring it in this Friday afternoon? I can also leave it with you for a day if you need more time. Thank you for your help. Best, Jiho",
[
["Which sentence summarizes the email best?", "Jiho asks the shop to look at a noisy brake on his new bike.", ["Jiho tells Mr. Park that he rides his bike to school and back every day.", "Jiho is angry because the shop sold him a broken bike last Saturday.", "Jiho wants to buy a better bike from the shop on Friday afternoon."], "이메일의 핵심은 새 자전거의 브레이크 문제를 봐 달라는 부탁이에요.", S],
["Why does Jiho write that he rode only to school and back?", "To show he did not damage it", ["To ask for a cheaper price", "To say that school is far away", "To explain why he is late"], "자신이 자전거를 망가뜨리지 않았다는 점을 알리려는 거예요.", P],
["What is Jiho's feeling about the bike?", "Happy but a bit worried", ["Bored and tired of it", "Proud and completely sure", "Angry and ready to quit"], "자전거에는 만족하지만 브레이크가 걱정이에요.", ["9영01-05"]],
["When does Jiho want to bring the bike?", "On Friday afternoon", ["Last Saturday morning", "This Sunday evening", "On Monday after school"], "Friday afternoon에 가져가도 되는지 묻고 있어요.", D]
]],
["Night Market Notes",
"Last weekend my cousin took me to a night market in her city. The air smelled of fried noodles and sweet cakes, and the streets were full of lights. We tried spicy rice cakes first, then shared a cup of fruit juice. My favorite part was a game where you throw rings over bottles. I did not win, but the owner gave me a small sticker anyway. We walked for three hours, and my feet hurt, but I want to go back next year.",
[
["Which is the best summary of the blog post?", "The writer enjoyed a fun evening of food and games at a night market.", ["The writer's feet hurt, so the writer will never visit a night market again.", "Night markets in big cities sell only fried noodles and sweet cakes.", "The writer won a prize by throwing rings over bottles at the market."], "중심 내용은 야시장에서 음식과 게임을 즐긴 즐거운 저녁이에요.", S],
["What did the writer receive from the game owner?", "A sticker", ["A cup of juice", "A bag of cakes", "A ring"], "이기지는 못했지만 주인이 작은 스티커를 줬어요.", D],
["How does the writer feel about the visit?", "Happy, though the walk was tiring", ["Sorry that the games were too hard", "Worried about the crowded streets", "Disappointed with the food"], "발은 아팠지만 내년에 또 가고 싶다고 해요.", ["9영01-05"]],
["Which happened first?", "They ate spicy rice cakes.", ["They shared a cup of fruit juice.", "They played the ring-throwing game.", "They walked for three hours."], "먼저 매운 떡볶이를 먹고 그다음 주스를 나눠 마셨어요.", I]
]],
["Learning to Swim",
"When I was nine, I was afraid of water. My friends jumped into the pool, but I stayed at the edge with my feet in. One summer my aunt offered to teach me. On the first day, I only blew bubbles. On the second day, I held a board and kicked. It took many weeks before I could swim across the pool without help. I still remember how proud I felt when I touched the far wall. Now I tell younger children that small steps really work.",
[
["What is the main message of the story?", "Small steps can help you overcome a fear.", ["Summer is the best time to learn any sport.", "Friends should never leave a scared child alone.", "Swimming boards are needed for every beginner."], "두려움도 작은 단계를 차근차근 밟으면 이겨낼 수 있다는 것이 핵심이에요.", S],
["Which sentence is too detailed to be a good summary of the whole story?", "On the second day, the writer held a board and kicked.", ["A girl who feared water learned to swim step by step.", "The writer feels proud of overcoming a childhood fear.", "With her aunt's help, the writer finally swam across the pool."], "둘째 날 이야기는 하루의 세부 내용일 뿐 전체를 요약하지 못해요.", S],
["Who taught the writer to swim?", "Her aunt", ["Her friends", "A pool worker", "Her cousin"], "여름에 이모(고모)가 가르쳐 주겠다고 했어요.", D],
["What does \"far wall\" refer to?", "The wall at the pool's far end", ["The wall behind the writer's house", "The wall next to the writer's feet", "The wall near the school gate"], "수영장을 가로질러 맞은편 벽을 짚었다는 뜻이에요.", V]
]],
["Why Do Volcanoes Erupt?",
"Deep under the ground, rock can become so hot that it melts. This melted rock, called magma, is lighter than the rock around it, so it slowly rises. Gas is also trapped inside the magma. As the magma gets closer to the surface, the pressure grows, like in a shaken bottle of soda. At last the magma breaks through a weak spot in the ground and shoots out as lava, ash, and gas. This is an eruption. Scientists watch the ground and the gas near volcanoes to warn people early.",
[
["Which sentence is the best summary of the passage?", "Hot magma full of gas rises and bursts out, causing an eruption.", ["Scientists watch the ground near volcanoes in order to warn people early.", "Lava, ash, and gas are three things that people can see near mountains.", "Soda bottles and volcanoes work in exactly the same way in every case."], "마그마가 올라오고 압력이 쌓여 터지는 과정이 중심 내용이에요.", S],
["Why does the writer mention a shaken bottle of soda?", "To show how pressure grows", ["To show how scientists test gas", "To explain why lava is hot", "To describe how magma tastes"], "소다병과 비교해 압력이 커지는 모습을 쉽게 설명해요.", P],
["What do scientists do to warn people?", "They watch the ground and gas.", ["They cool the magma with water.", "They close the weak spots.", "They count the rocks nearby."], "땅과 가스를 관찰해서 미리 경고해요.", D],
["The word \"trapped\" is closest in meaning to", "caught", ["lost", "heated", "hidden"], "trapped는 '갇힌'이라는 뜻이라 caught와 가까워요.", V]
]],
["Dinner Without Phones",
"In the Kim family, there is a new rule: no phones at the dinner table. At first, Sora thought the idea was silly. She had to leave her phone in a basket by the door, and the first few dinners felt quiet and strange. But soon the family began to talk about their day, share jokes, and even play word games. Her little brother said it was the best part of the evening. Now Sora checks her messages after dinner, and she says she does not miss the screen at all.",
[
["Which is the best summary of the passage?", "A no-phone rule at dinner helped one family talk and enjoy time together.", ["Sora's brother thinks that word games are the best part of the evening.", "Families around the world should put their phones in baskets by the door.", "Sora was angry about the rule and wanted her old habits back at once."], "중심 내용은 식사 중 휴대폰 금지 규칙이 가족 대화를 늘렸다는 것이에요.", S],
["How did Sora feel about the rule at first?", "She thought it was silly.", ["She felt it was a great idea.", "She was afraid of her parents.", "She was too sleepy to care."], "처음에는 어리석다고 생각했어요.", ["9영01-05"]],
["What can be inferred about Sora at the end?", "She changed her mind about the rule.", ["She dislikes talking with her brother.", "She plans to quit using her phone.", "She wants a new phone."], "마지막에는 화면이 그립지 않다고 하니 생각이 바뀐 것을 알 수 있어요.", I],
["When does Sora check her messages now?", "After dinner", ["Before dinner", "During dinner", "Before school"], "저녁 식사 후에 메시지를 확인해요.", D]
]],
["School Lunch Review",
"Our school's new lunch menu has been out for a month, and students have mixed opinions. Many like the colorful salads and the tasty baked chicken. However, the soup is often cold by the time it reaches the table, and some students say the portions are too small for sports club members. The kitchen staff have promised to buy warmer serving trays and to offer extra rice on request. If you have more ideas, you can write them on the board in the hallway.",
[
["Which sentence summarizes the review best?", "The new lunches have good and bad points, and the staff will make changes.", ["The new school lunches are so bad that students should bring their own food.", "Students may write their ideas on the board that stands in the hallway.", "The kitchen staff have decided to serve baked chicken every day."], "장단점이 섞여 있고 급식실이 개선하겠다는 것이 중심이에요.", S],
["What is one problem mentioned in the review?", "The soup arrives cold.", ["The salads are not colorful.", "The chicken is not baked enough.", "The hallway board is broken."], "수프가 식어서 도착한다는 문제가 언급돼요.", D],
["What will the kitchen staff do?", "Buy warmer trays and more rice", ["Remove the salad from the menu", "Make the soup much sweeter", "Ask club members to cook"], "더 따뜻한 쟁반을 사고 요청 시 밥을 더 줄 거예요.", D],
["The word \"mixed\" in the first sentence means", "good and bad", ["completely happy", "very confused", "easy to change"], "mixed opinions는 좋은 의견과 나쁜 의견이 섞여 있다는 뜻이에요.", V]
]],
["How a Rainbow Forms",
"A rainbow needs two things: sunlight and water drops. When the sun shines after or during rain, light enters the tiny drops in the air. Inside each drop, the white light bends and splits into many colors, from red to violet. The colors then bounce back toward your eyes. To see a rainbow, you must stand with the sun behind you and look at the rain in front of you. That is why you can see one in the morning or late afternoon, but almost never at noon in summer.",
[
["Which is the best summary of the passage?", "Rainbows appear when sunlight bends and splits inside water drops in the air.", ["Rainbows are seen in the morning or late afternoon more than at noon in summer.", "Red and violet are the two colors found at the ends of every rainbow shape.", "Rain falls whenever the sun is shining brightly behind a person's back."], "중심 내용은 햇빛이 물방울 속에서 꺾이고 나뉘어 무지개가 생긴다는 것이에요.", S],
["Where should you stand to see a rainbow?", "With the sun behind you", ["With the sun in front of you", "Directly under the rain", "Far from any water"], "해가 등 뒤에 있어야 맞은편 비를 볼 수 있어요.", D],
["When can you usually see a rainbow in summer?", "In the morning or late afternoon", ["At noon on a clear day", "Late at night after the rain", "Only when the sun is behind the rain"], "본문: 아침이나 늦은 오후에는 볼 수 있지만 여름 정오에는 거의 볼 수 없어요.", D],
["Which happens first?", "Light enters a water drop.", ["The colors bounce back to your eyes.", "White light splits into colors.", "You look at the rain."], "빛이 물방울에 들어간 뒤 색으로 나뉘고 반사돼요.", I]
]],
["New Library Hours",
"Starting next Monday, the town library will open one hour earlier on weekdays, at eight o'clock in the morning. It will still close at six in the evening. On Saturdays, the children's room will stay open until five so that families can read together after soccer practice. Please note that the computer room will be closed for repairs during the first two weeks of the new schedule. Library cards can be renewed online, which means you no longer have to wait in line at the front desk.",
[
["What is the main purpose of this notice?", "To announce the library's new hours", ["To invite people to a soccer game", "To ask readers to return their books", "To sell new library cards"], "새로운 운영 시간과 변경 사항을 알리는 공지예요.", P],
["Which sentence is the best summary?", "The library is changing its hours and adding some services.", ["The library will close at six in the evening on all weekdays.", "The library has been closed for a long time because of repairs.", "The library will give free cards to all children who play soccer."], "운영 시간 변경과 몇 가지 새 서비스가 중심이에요.", S],
["Which service is closed for the first two weeks?", "The computer room", ["The children's room", "The front desk", "The online card system"], "컴퓨터실은 처음 2주 동안 수리로 닫혀요.", D],
["What is the benefit of renewing a card online?", "People can skip the line at the desk.", ["People can borrow more books each time.", "People can use the computers at night.", "People can read in the children's room."], "온라인으로 갱신하면 데스크에서 줄을 설 필요가 없어요.", D]
]],
["Kimchi Making Day",
"Every November, my grandmother's village holds a kimchi making day. Neighbors gather in her yard with huge bowls of salted cabbage and red pepper paste. The adults mix the paste while the children carry the cabbages. The work is hard, but the yard is filled with laughter and stories. At the end of the day, each family takes home several boxes of kimchi and shares a warm meal with the others. My grandmother says that making kimchi together is a way to keep the village close.",
[
["What is the passage mainly about?", "A village's shared kimchi tradition", ["The best way to mix red pepper paste", "A child's first job on the farm", "Why cabbage is salted before winter"], "마을 사람들이 함께 김장하며 가까워지는 전통이 중심이에요.", S],
["Which sentence is too narrow to be a summary of the passage?", "Children carry the cabbages and adults mix the paste.", ["Neighbors make kimchi together every November in a village.", "Making kimchi is a shared task that also builds friendships.", "Families make kimchi together and enjoy a meal at the end."], "아이들과 어른들의 역할 이야기는 세부 내용이라 전체 요약으로는 좁아요.", S],
["What does the grandmother believe?", "Working together keeps people close.", ["Kimchi tastes best when made alone.", "Children should not help with the work.", "November is the coldest month."], "마지막 문장에서 함께 김치를 담그는 것이 마을을 가깝게 한다고 해요.", D],
["What does each family get at the end of the day?", "Several boxes of kimchi", ["A bowl of red pepper paste", "A bag of salted cabbage", "A new cooking pot"], "각 가족이 김치 몇 통을 집에 가져가요.", D]
]]
];
