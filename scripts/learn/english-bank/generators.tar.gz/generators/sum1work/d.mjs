const S = ["9영01-03", "9영02-07"], D = ["9영01-02"], I = ["9영01-04"], P = ["9영01-06"], V = ["9영01-07"], E = ["9영01-05"];
export default [
["Planning the Class Trip",
"Sumi: Our teacher wants us to choose a place for the class trip.\nJack: I vote for the amusement park. The rides are exciting.\nSumi: They are fun, but tickets cost a lot, and we would wait in line for hours.\nJack: Hmm, that is true. What do you suggest?\nSumi: How about the science garden? The tickets are cheap, and there is a workshop where we can make our own robots.\nJack: Robots sound great! But is it far from school?\nSumi: Only thirty minutes by bus.\nJack: Okay, you have convinced me. Let's tell the class.",
[
["Which is the best summary of the conversation?", "Sumi persuades Jack that the science garden is a better trip.", ["Jack and Sumi cannot decide because the bus ride takes too long.", "The class will visit an amusement park to ride all of the exciting rides.", "Sumi asks the teacher to build robots for the class during the trip."], "수미가 과학 정원이 더 좋은 선택이라고 잭을 설득했어요.", S],
["Why does Sumi not like the amusement park idea?", "Tickets cost much and lines are long.", ["The rides are too exciting.", "It is much too far from the school.", "The teacher dislikes parks."], "표가 비싸고 줄이 길다고 말해요.", D],
["How does Jack feel at the end?", "He likes the new plan.", ["He is angry at Sumi.", "He is tired of waiting.", "He is afraid of robots."], "robots sound great, you have convinced me라고 했어요.", E],
["How far is the science garden from school?", "Half an hour by bus", ["One hour by bus", "Ten minutes on foot", "Two hours by train"], "버스로 30분이에요.", D]
]],
["Help with a Book Report",
"Eun: Dad, can you help me with my book report? I have read the book, but I don't know how to start.\nDad: Of course. First, tell me the story in two sentences.\nEun: Well, a boy finds a map in his attic and follows it to a hidden island. There he learns to trust his younger sister.\nDad: That's a good start. Those two sentences are almost a summary already.\nEun: But I want to write about the storm and the cave and the funny parrot too.\nDad: Those are details. Put the most interesting ones in the middle, but keep the first part short.\nEun: Okay. I will begin with the two sentences.",
[
["What does Dad advise Eun to do?", "Start with a short summary.", ["Write about the parrot first.", "Read the book a second time.", "Copy the story from the cover."], "두 문장 요약으로 시작하고 세부 내용은 중간에 넣으라고 조언해요.", S],
["Which sentence is the best summary of the conversation?", "Dad shows Eun how to begin a book report with a summary.", ["Dad reads the book about an island and tells Eun about the parrot.", "Eun is upset because her father does not like adventure stories.", "Eun and her father plan a trip to find a hidden island."], "아빠가 독후감을 요약으로 시작하는 법을 알려 줘요.", S],
["Which of these does Eun call a detail in the book?", "The funny parrot", ["The boy's younger sister", "The map in the attic", "The hidden island"], "아빠가 폭풍, 동굴, 앵무새를 세부 내용이라고 불러요.", D],
["What does Eun probably do next?", "She begins with two sentences.", ["She throws away the book.", "She asks for a new topic.", "She writes about the storm first."], "마지막에 두 문장으로 시작하겠다고 했어요.", I]
]],
["Noise in the Library",
"Tom: Excuse me, could you keep your voice down? Some of us are trying to study.\nLily: Oh, I am sorry. I did not notice that I was so loud.\nTom: That's okay. It's just that I have a math test tomorrow.\nLily: Me too! I was talking because I do not understand the last chapter.\nTom: Really? I can explain it if you want. We can go to the study room at the end of the hall.\nLily: That would be wonderful. Thank you so much!\nTom: No problem. Let's go before it gets crowded.",
[
["Which sentence summarizes the dialogue best?", "A noise complaint ends with two students studying together.", ["Tom and Lily argue loudly and are sent out of the library.", "Lily teaches Tom the last chapter of the math book in the hall.", "Tom decides to stay in the library and ignore Lily."], "조용히 해 달라는 말이 함께 공부하는 것으로 끝나요.", S],
["Why was Lily speaking aloud?", "She did not understand a chapter.", ["She was calling a friend on her phone.", "She wanted to disturb Tom.", "She was reading a story."], "마지막 장이 이해되지 않아서 이야기하고 있었다고 해요.", I],
["Where will they study?", "In a study room down the hall", ["At Lily's house after school", "In the school gym next door", "At a desk near the library door"], "복도 끝 학습실로 가요.", D],
["How does Tom's attitude change?", "He goes from annoyed to helpful.", ["He moves from being kind to being angry.", "He stays calm and doesn't talk.", "He leaves Lily alone."], "처음엔 조용히 해 달라고 했지만 나중에는 설명해 주겠다고 도와요.", E]
]],
["Choosing a Gift",
"Ben: Dana's birthday is on Saturday, and I still have no idea what to buy.\nAnna: What does she like?\nBen: She loves painting and listening to music.\nAnna: Then why not buy a set of watercolor paints? They are not too expensive.\nBen: Good idea, but she already has some paints.\nAnna: Maybe a sketchbook then. Artists always need more paper.\nBen: I like that. I could write a short card inside it, too.\nAnna: She will love it. Let's go to the stationery shop after school.",
[
["Which is the best summary of the conversation?", "Ben gets help choosing a gift for a friend who likes art.", ["Ben and Anna are painting pictures for Dana's party on Saturday.", "Anna wants to buy music for Ben's birthday after school.", "Dana is going to the stationery shop to buy some paper."], "친구의 생일 선물을 고르는 것을 도와주는 대화예요.", S],
["Why does Ben reject the paints?", "Dana already owns some.", ["They cost too much.", "Dana dislikes painting.", "The shop is closed."], "다나가 이미 물감이 있다고 해요.", D],
["What do they decide to do?", "Buy a sketchbook and a card", ["Make a music box", "Paint a picture together for her", "Wait until Saturday"], "스케치북을 사고 카드를 쓰기로 해요.", D],
["What will Ben and Anna do after school?", "Go to a stationery shop", ["Visit Dana's house together", "Paint in the art room", "Go to a music store"], "방과 후 문구점에 가요.", D]
]],
["The School Newspaper",
"Mr. Lee: Thanks for coming. Our school newspaper needs new writers this term.\nHana: What kind of articles do you want?\nMr. Lee: Interviews, club news, and short reviews of books or movies.\nHana: I would like to write about the cooking club. They won a prize last month.\nMr. Lee: Wonderful. Please talk to the club members and take a few photos.\nHana: How long should the article be?\nMr. Lee: About two hundred words. Keep it short, clear, and focused on the main points.\nHana: I understand. I will send you a draft by Friday.",
[
["Which sentence is the best summary of the conversation?", "Mr. Lee explains the job, and Hana agrees to write about a club.", ["Hana wants to cook food for the teachers at the school.", "Mr. Lee asks the cooking club to take photos on Friday.", "The school newspaper is closing because it has too few writers."], "리 선생님이 기사 방향을 설명하고 하나가 요리 동아리 기사를 쓰기로 해요.", S],
["How long should the article be?", "About two hundred words", ["About one hundred words", "About five hundred words", "One page with photos"], "약 200단어를 요청해요.", D],
["Why does Hana choose the cooking club?", "It won a prize.", ["She is a member of it.", "It has many photos.", "Mr. Lee asked her to."], "지난달 상을 받았기 때문이에요.", D],
["What does Mr. Lee mean by \"focused on the main points\"?", "Include only the key points.", ["Add as many facts as possible.", "Use long and difficult words.", "Make the article funny."], "핵심만 담으라는 요약의 원칙과 같아요.", V]
]],
["A Phone Call About Plans",
"Mom: Hello, Jiwon. How was your day?\nJiwon: Good, Mom. I stayed after school to help my friends with our science project.\nMom: That's nice. Will you be home for dinner?\nJiwon: Probably not until seven, because we have to finish the poster.\nMom: All right, but please text me when you leave school.\nJiwon: I will. Also, can Sena stay over on Saturday?\nMom: I think so. Let me check with Dad first.\nJiwon: Thanks, Mom. I will see you tonight.",
[
["Which is the best summary of the phone call?", "Jiwon tells Mom she will be late and asks about a friend's visit.", ["Jiwon's mother is angry because the science project is not finished.", "Jiwon calls Sena to ask her to stay over on Saturday night.", "Mom and Dad plan to come to the school and see the poster."], "귀가가 늦는다는 것과 친구 방문 허락을 구하는 것이 핵심이에요.", S],
["Why will Jiwon be home late?", "She has to finish a poster.", ["She has a dentist visit.", "She is going to Sena's house.", "She missed the bus."], "과학 프로젝트 포스터를 끝내야 해요.", I],
["What does Mom ask Jiwon to do?", "Text when she leaves school", ["Cook dinner for the family", "Meet Dad at the station", "Call Sena's mother right away"], "학교를 떠날 때 문자를 보내라고 해요.", D],
["What will Mom do about Saturday?", "Ask Dad first", ["Say no at once", "Call Sena's mother", "Plan a trip"], "아빠와 먼저 상의해 본다고 했어요.", D]
]]
];
