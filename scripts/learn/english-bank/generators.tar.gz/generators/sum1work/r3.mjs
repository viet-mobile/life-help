const S = ["9영01-03", "9영02-07"], D = ["9영01-02"], I = ["9영01-04"], P = ["9영01-06"], V = ["9영01-07"], E = ["9영01-05"];
export default [
["Learning from a Loss",
"Our school soccer team lost 6 to 0 last Thursday. Everyone was quiet on the bus ride home, and a few players were close to tears. Then our coach said something I will not forget. She told us that the score showed only one day, not who we were. She asked each of us to name one thing we had done well. Hana said she had stopped two goals, and Joon said he had never given up running. By the time we arrived, we were already planning the next practice.",
[
["What is the main idea of the passage?", "A kind coach helped the team look past a bad loss.", ["A goalkeeper stopped two goals and became the star player.", "The team plans to change the coach after the heavy loss.", "Soccer is a game in which the score is not important at all."], "코치의 말이 팀이 패배를 딛고 다시 힘을 내게 했다는 것이 중심이에요.", S],
["How did the team feel on the bus at first?", "Sad and quiet", ["Excited and loud", "Angry at the referee", "Sleepy and relaxed"], "버스 안은 조용했고 눈물을 글썽이는 선수도 있었어요.", E],
["What did the coach want each player to do?", "Name one good thing they did", ["Promise to win the next game", "Blame the other team", "Write a letter to the school"], "각자 잘한 점 한 가지를 말하게 했어요.", D],
["What does the ending show about the team?", "They felt hopeful again.", ["They gave up the sport.", "They were angry at one another.", "They forgot the game."], "도착할 때쯤엔 다음 연습을 계획하고 있었으니 다시 희망을 찾았어요.", I]
]],
["Why Do We Yawn?",
"Everyone yawns, even babies before they are born. People often think that we yawn only when we are sleepy, but scientists say that is not the whole story. One idea is that a big yawn pulls in cool air and helps cool the brain. Another idea is that yawning wakes us up when we need to stay alert. Yawns also seem to spread from person to person; seeing someone yawn can make you do the same. Scientists are still studying why this happens, so there is no final answer yet.",
[
["Which sentence is the best summary of the passage?", "Scientists have several ideas about why people yawn, but none is certain yet.", ["People yawn only when they are tired, and babies yawn the most.", "Cool air is the main reason why a person's brain begins to work.", "Yawning is catching, so people should avoid looking at each other."], "하품의 이유에 대한 여러 가설이 있지만 아직 확실하지 않다는 것이 중심이에요.", S],
["Which idea about yawning is mentioned?", "It may cool the brain.", ["It makes the heart slow down.", "It helps people breathe less.", "It warms the body at night."], "큰 하품이 시원한 공기를 들여 뇌를 식힌다는 가설이 나와요.", D],
["What does \"spread\" mean in this passage?", "Pass from person to person", ["Become wider in size", "Make something much thinner", "Be hidden from other people"], "하품이 사람에서 사람으로 옮는다는 뜻이에요.", V],
["What can be inferred from the last sentence?", "No one fully knows the reason yet.", ["Yawning is not a real habit.", "Only babies really understand yawning.", "The question has been answered."], "아직 최종 답이 없다고 했으니 연구자들도 완전히 알지 못해요.", I]
]],
["Beach Clean-Up Report",
"On Sunday morning, forty students and teachers cleaned Dolphin Beach. In two hours, the group filled thirty bags with bottles, plastic bags, and old fishing nets. A student named Yuna counted the items and found that more than half were pieces of plastic. Some volunteers also saw a small crab hiding in a torn cup. When the work was finished, everyone sat on the sand to eat sandwiches and plan another clean-up for next month. The group hopes more families will join them next time.",
[
["What is the best summary of the report?", "A group cleaned a beach and plans to do it again with more people.", ["Yuna counted the plastic and discovered a crab in a cup on the beach.", "Forty students and teachers ate sandwiches on the sand after school.", "Fishing nets and old bottles are very dangerous for people at the beach."], "해변 청소 활동과 다음 계획이 핵심이에요.", S],
["What did most of the collected items turn out to be?", "Plastic pieces", ["Old fishing nets", "Glass bottles", "Pieces of paper"], "절반 넘게가 플라스틱 조각이었어요.", D],
["What do the volunteers plan to do next month?", "Hold another clean-up", ["Visit the crab", "Have a sandwich party", "Build a new beach"], "다음 달에 또 청소하기로 계획해요.", D],
["What is the purpose of the last sentence?", "To show they want more helpers", ["To say the beach is now clean", "To thank the teachers for helping", "To describe the weather"], "더 많은 가족이 참여하길 바란다는 희망을 나타내요.", P]
]],
["A Visit to the Science Museum",
"Our class visited the science museum on Friday. In the first hall, we touched a model of the solar system and learned that Earth is the third planet from the sun. The second hall had a machine that made a small tornado out of mist, and we watched it spin for a long time. After lunch, we made paper airplanes and tested which one flew the farthest. Mine landed in a plant pot, which made everyone laugh. On the bus, my teacher asked us to write one new fact we had learned.",
[
["Which sentence summarizes the passage best?", "The class had a fun and educational day at a science museum.", ["The writer's paper airplane flew farther than any of the others.", "Earth is the third planet from the sun and the biggest of all.", "Museums are better places to learn science than classrooms."], "과학관에서 즐겁게 배운 하루가 중심이에요.", S],
["What did the students do in the second hall?", "They watched a mist tornado.", ["They touched a model of the sun.", "They flew paper airplanes.", "They ate their lunch."], "두 번째 전시관에는 안개로 만든 작은 토네이도가 있었어요.", D],
["Why did everyone laugh?", "The plane landed in a plant pot.", ["The machine suddenly broke down.", "The teacher dropped a model.", "Someone fell on the bus."], "필자의 종이비행기가 화분에 떨어져 웃음이 났어요.", I],
["What did the teacher ask for on the bus?", "A new fact from each student", ["A short story about the sun", "A list of all the planets", "A paper airplane"], "버스에서 새로 배운 사실 하나를 쓰라고 했어요.", D]
]],
["The Tea Ceremony Idea",
"In many countries, drinking tea is more than a way to quench thirst. In some places, a tea gathering is slow and quiet, with every movement planned carefully. The host warms the cups, pours the tea, and offers it with both hands. Guests thank the host and drink in small sips. In other places, tea is shared loudly among friends, with sweets and long talks. Different as they are, both styles show the same idea: tea is a way to honor guests and enjoy time together.",
[
["Which is the best summary of the passage?", "Tea customs differ, but they all bring people together.", ["Hosts must use both hands and quiet voices whenever they serve tea.", "Loud tea gatherings with sweets are better than slow, quiet ones.", "Tea is the most popular drink in countries around the whole world."], "다른 방식이지만 차는 손님을 존중하고 함께 시간을 보내는 방법이라는 것이 중심이에요.", S],
["How is tea served at a quiet gathering?", "With both hands", ["With sweets and loud talk", "From a large pot on the floor", "By the guests themselves"], "주인이 두 손으로 차를 건네요.", D],
["What do the two styles have in common?", "They honor the guests.", ["They use the same cups.", "They have only quiet music.", "They cost very little."], "마지막 문장: 두 방식 모두 손님을 존중하고 함께 즐기는 방법이에요.", I],
["The phrase \"quench thirst\" is closest in meaning to", "stop feeling thirsty", ["start to feel hungry", "keep something warm", "make a drink sweet"], "quench thirst는 갈증을 해소한다는 뜻이에요.", V]
]],
["Paper or Screen?",
"Many students now read on tablets, but others prefer paper books. Paper readers say that they remember the story better because they can feel how far they have read. They also say the pages do not hurt their eyes. Screen readers answer that a tablet can hold hundreds of books, so they never need to carry a heavy bag. A tablet can also make letters bigger for easier reading. Experts say both ways work well; the best choice depends on what is comfortable for each reader.",
[
["What is the passage mainly about?", "The pros of paper and screen reading", ["How to choose a heavy bag for school", "Why tablets cost more than books", "Which stories are good for students"], "종이책과 화면 읽기 각각의 장점을 비교하는 글이에요.", S],
["Which summary best matches the last sentence?", "Neither way always wins, so readers should pick what suits them.", ["Paper books are better because they are easy to feel and carry.", "Tablets are better, so schools should stop buying paper books.", "Experts say that most students do not read enough books."], "전문가는 둘 다 좋으며 개인에게 편한 쪽을 고르라고 해요.", S],
["Why do some readers like tablets?", "It can hold many books.", ["Pages are easier to turn.", "Letters cannot be changed.", "They never need batteries."], "태블릿에는 수백 권을 담을 수 있어 가방이 가벼워요.", D],
["What is true about paper readers?", "They can feel their progress.", ["They need bigger letters.", "They carry more than one bag.", "They read faster than others."], "종이책 독자는 어디까지 읽었는지 느낄 수 있다고 해요.", D]
]],
["The New Student",
"When Mina walked into our classroom on Monday, nobody knew what to say. She had moved from another city, and she held her bag tightly in front of her. During the morning break, I noticed she was sitting alone. I remembered how lonely I felt when I started at this school, so I walked over and asked her to join our card game. She smiled for the first time. By Wednesday, she was laughing with us at lunch, and she taught us a new game from her old school.",
[
["Which sentence is the best summary of the story?", "The writer's kind invitation helped a new student feel welcome.", ["Mina taught her classmates a game from her old school on Wednesday.", "The writer felt lonely because nobody asked her to play cards.", "Students from other cities should be careful when they change schools."], "필자의 친절한 초대가 전학생이 적응하게 도왔다는 것이 핵심이에요.", S],
["Why did the writer ask Mina to join the game?", "She remembered being lonely.", ["The teacher gave an order.", "Mina asked for help first.", "The game needed one more player."], "자신이 처음 왔을 때의 외로움이 기억났기 때문이에요.", I],
["How did Mina feel on Monday morning?", "Nervous and alone", ["Excited and proud", "Angry and bored", "Tired and hungry"], "가방을 꼭 쥐고 혼자 앉아 있었어요.", E],
["What happened by Wednesday?", "Mina laughed with the group.", ["Mina moved to another city.", "Mina stopped playing games.", "Mina changed her seat."], "수요일에는 점심때 함께 웃고 있었어요.", D]
]],
["Earthquake Drill",
"Last week, our school held an earthquake drill. When the alarm rang, we dropped under our desks, covered our heads, and held on to the desk legs. After one minute, the teacher led us in a line to the playground, away from windows and tall walls. The principal said that the most important thing is to stay calm and listen to instructions. We all felt a bit silly at first, but later we understood that practicing now could keep us safe if a real earthquake ever happens.",
[
["What is the main idea of the passage?", "Drills teach students how to stay safe in an earthquake.", ["The principal ran the school alarm for a very long time.", "Windows and tall walls are the most dangerous things at school.", "Students feel silly when they learn something new in class."], "대피 훈련이 안전을 배우는 기회라는 것이 핵심이에요.", S],
["What did students do first when the alarm rang?", "They got under their desks.", ["They ran to the playground.", "They opened the windows.", "They called their parents."], "먼저 책상 아래로 몸을 낮췄어요.", I],
["Why did the students move away from windows and tall walls?", "These places can be unsafe.", ["The playground was noisy.", "The teacher liked the line.", "The alarm was too loud."], "창문과 높은 벽 근처는 위험하다고 추론할 수 있어요.", I],
["What does the writer say about the drill?", "It seemed silly but was useful.", ["It was much too long and tiring.", "It should be held every day.", "It made everyone feel afraid."], "처음엔 어색했지만 나중에 연습의 가치를 이해했어요.", E]
]],
["The Story of the Bicycle",
"The first bicycles looked very different from the ones we ride today. About two hundred years ago, some had no pedals at all; riders pushed the ground with their feet to move. Later, inventors added pedals to the front wheel, which made the bike faster but harder to ride. Then, makers put a chain on the back wheel and gave both wheels the same size. This design was safer and easier, and it is still the basic shape of most bicycles. Today, people use bikes for fun, sport, and daily travel.",
[
["Which sentence is the best summary of the passage?", "Bicycles changed over time until they reached today's safe design.", ["The first bicycles had no pedals, so riders pushed with their feet.", "People today use bikes only for sport and for fun on weekends.", "Inventors made bikes faster by putting the pedals on large front wheels."], "시간이 지나며 자전거가 오늘날의 안전한 모양으로 발전했다는 것이 중심이에요.", S],
["What made later bicycles easier and safer?", "A back-wheel chain and equal wheels", ["Large pedals on the front wheel only", "A larger back wheel", "No pedals at all"], "뒷바퀴 체인과 같은 크기의 두 바퀴가 더 안전하고 쉬웠어요.", I],
["Which came first?", "Bikes with no pedals", ["Bikes with a chain", "Bikes with equal wheels", "Bikes with pedals on the front wheel"], "페달 없는 자전거가 가장 먼저 나왔어요.", I],
["How did riders move the earliest bikes?", "By pushing off the ground", ["By using a very small engine", "By turning a handle", "By pedaling on the back wheel"], "발로 땅을 밀어 앞으로 나아갔어요.", D]
]],
["Why Breakfast Matters",
"Many students skip breakfast because they are in a hurry, but this can be a mistake. After a night of sleep, the body needs fuel. Students who eat breakfast often listen better in class and feel more cheerful. A good breakfast does not have to take long. A bowl of oatmeal with fruit, a boiled egg and toast, or a glass of milk with a banana can be ready in minutes. A sugary snack may give quick energy, but it fades fast and leaves you hungry again before lunch.",
[
["What is the passage mainly about?", "Why students should eat breakfast", ["How to make oatmeal with fruit quickly", "Why students never have time in the morning", "How sugary snacks are made"], "건강한 아침 식사가 학생에게 왜 좋은지가 중심이에요.", S],
["Which summary is too narrow?", "A boiled egg and toast can be a quick breakfast.", ["Eating breakfast helps students feel and learn better.", "Breakfast gives the body energy after a night of sleep.", "Quick, healthy breakfasts are easy to prepare."], "삶은 달걀과 토스트는 한 가지 예시일 뿐이라 요약으로는 좁아요.", S],
["According to the passage, what happens after a sugary snack?", "You get hungry soon.", ["You sleep for many hours.", "You listen better.", "You need less lunch."], "당분 간식은 에너지가 금방 사라져 점심 전에 다시 배가 고파요.", D],
["What does the writer want to say with \"this can be a mistake\"?", "Skipping breakfast is unwise.", ["Students should eat only fruit.", "Hurrying is a good habit.", "Mornings are always busy."], "아침을 거르는 것은 좋지 않다는 뜻이에요.", P]
]],
["Moon Shapes",
"The moon seems to change shape every night, but it is not really changing. The moon does not make its own light; we see it because it reflects sunlight. As the moon travels around Earth, we see different amounts of its bright side. When the whole bright side faces us, we see a full moon. A week later, we see only half of it. After about two weeks, the moon looks like a thin line or disappears from sight. The whole cycle, from one full moon to the next, takes about a month.",
[
["Which is the best summary of the passage?", "The moon seems to change shape as we see different parts of its lit side.", ["The moon is a ball of rock that makes its own light and really changes shape every night.", "A full moon appears one week after the moon looks like a thin line.", "The moon is closest to Earth when it looks like a thin line."], "달 모양이 변해 보이는 이유가 중심이에요. 달은 스스로 빛나지 않아요.", S],
["Why can we see the moon?", "It reflects sunlight.", ["It makes its own light.", "It is close to the stars.", "It is lit by the stars."], "달은 햇빛을 반사해서 보여요.", D],
["How long does a full cycle take?", "About a month", ["About a week", "About a full year", "About a day"], "보름달에서 다음 보름달까지 약 한 달이 걸려요.", D],
["What does the word \"reflects\" mean?", "Bounces light back", ["Makes sound", "Collects heat", "Gives water"], "reflect는 빛을 반사한다는 뜻이에요.", V]
]]
];
