import fs from "node:fs";
import { S } from "./s.mjs"; import { M } from "./m.mjs"; import { R } from "./r.mjs"; import { W } from "./w.mjs";
const out = { packet: "M11-m3-rel", sections: [{ skill: "e.m3.rel", items: [...S, ...M, ...R, ...W] }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M11-m3-rel.json", JSON.stringify(out, null, 1) + "\n");
console.log(S.length, M.length, R.length, W.length);
