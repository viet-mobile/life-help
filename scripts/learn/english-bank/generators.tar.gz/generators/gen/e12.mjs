import fs from "node:fs";
const W = (en,pos,ko,ex,exko,z,sp,syn=[]) => ({k:"w",en,pos,ko,ex,exko,z,syn,...(sp?{sp}:{}),std:["4영01-05"]});
const M = (q,o,a,why,cat,d) => ({k:"m",q,o,a,why,cat,...(d?{d}:{})});
const S = (good,ko,bad,st,ok,wr,rule,extra={}) => ({k:"s",good,ko,bad,cz:{st,ok,wr},rule,...extra});

const adjW = [
W("tall","adj","키가 큰","My father is very tall, so he can reach the high shelf.","우리 아빠는 키가 아주 커서 높은 선반에 손이 닿아요.",["sour","empty","wet"],["tal","taal","tahl"]),
W("long","adj","긴","The river is long, and it goes all the way to the sea.","그 강은 길어서 바다까지 쭉 이어져요.",["spicy","shy","sour"],["lang","lonng","loong"]),
W("heavy","adj","무거운","This bag is too heavy for me to carry.","이 가방은 너무 무거워서 내가 들 수 없어요.",["sour","shy","sunny"],["hevy","heavey","haevy"]),
W("fast","adj","빠른","The new train is very fast, so we arrive early.","새 기차는 아주 빨라서 우리는 일찍 도착해요.",["sour","shy","spicy"],["fasst","fsat","fastt"]),
W("slow","adj","느린","The turtle is slow, so it comes last in the race.","거북이는 느려서 경주에서 꼴찌로 들어와요.",["fast","sunny","sweet"],["slo","sloww","solw"]),
W("soft","adj","부드러운","My pillow is soft, so I sleep well at night.","내 베개는 부드러워서 나는 밤에 잘 자요.",["sour","salty","angry"],["sofft","soaft","sfot"]),
W("round","adj","둥근","A ball is round, so it rolls easily on the grass.","공은 둥글어서 잔디 위에서 잘 굴러요.",["sour","shy","tall"],["rownd","roud","rond"]),
W("young","adj","어린","The puppy is young, so it needs a lot of sleep.","그 강아지는 어려서 잠이 많이 필요해요.",["salty","sunny","round"],["yung","youg","yuong"]),
W("dirty","adj","더러운","My shoes are dirty because I played in the mud.","나는 진흙에서 놀아서 내 신발이 더러워요.",["clean","sweet","shy"],["durty","dirtey","dirti"]),
W("hungry","adj","배고픈","I am hungry because I did not eat breakfast.","나는 아침을 먹지 않아서 배가 고파요.",["full","sunny","round"],["hungery","hungri","hunngry"]),
W("angry","adj","화난","Mina is angry because her brother broke her toy.","미나는 남동생이 장난감을 망가뜨려서 화가 났어요.",["happy","sunny","salty"],["angery","angrey","angri"]),
W("tired","adj","피곤한","I am tired after a long walk, so I want to sleep.","나는 오래 걸어서 피곤하고, 자고 싶어요.",["spicy","sunny","thin"],["tierd","tyred","tirred"]),
W("quiet","adj","조용한","Please be quiet in the library.","도서관에서는 조용히 해 주세요.",["loud","noisy","sour"],["quiat","queit","quiett"]),
W("sweet","adj","달콤한","This cake is sweet because it has a lot of sugar.","이 케이크는 설탕이 많이 들어서 달콤해요.",["sour","salty","spicy"],["sweit","swete","sweeet"]),
W("sour","adj","신","A lemon is sour, so I make a funny face.","레몬은 시어서 나는 웃긴 표정을 지어요.",["sweet","soft","quiet"],["sourr","soure","sowr"]),
W("salty","adj","짠","The soup is too salty, so I need some water.","수프가 너무 짜서 나는 물이 필요해요.",["soft","quiet","tall"],["salti","saltey","saulty"]),
W("spicy","adj","매운","The tteokbokki is very spicy, so I need water.","떡볶이가 아주 매워서 나는 물이 필요해요.",["soft","tall","quiet"],["spicey","spisy","spycy"]),
W("bright","adj","밝은","The room is bright because the lights are on.","불이 켜져 있어서 방이 밝아요.",["dark","sour","salty"],["brite","briht","brigth"]),
W("wet","adj","젖은","I am wet because I walked in the rain without an umbrella.","나는 우산 없이 빗속을 걸어서 젖었어요.",["dry","sour","round"],["wett","weat","wte"]),
W("strong","adj","힘센","He is strong, so he can lift the heavy box.","그는 힘이 세서 무거운 상자를 들 수 있어요.",["shy","sunny","sour"],["strog","strnog","stronng"]),
W("shy","adj","수줍음 많은","Tom is shy, so he does not talk much in class.","톰은 수줍음이 많아서 수업 시간에 말을 많이 하지 않아요.",["loud","sunny","salty"]),
W("brave","adj","용감한","The little girl is brave, so she is not afraid of the dark.","그 어린 소녀는 용감해서 어둠이 무섭지 않아요.",["scared","sour","round"],["braev","brav","braive"]),
W("sunny","adj","화창한","It is sunny today, so I need my sunglasses.","오늘은 날씨가 화창해서 선글라스가 필요해요.",["rainy","salty","sour"],["suny","sunney","sunnie"]),
W("empty","adj","빈","The box is empty, so there is nothing in it.","상자가 비어 있어서 안에 아무것도 없어요.",["full","tall","sweet"],["emty","empy","emptey"]),
W("happy","adj","행복한","I am happy because today is my birthday.","오늘이 내 생일이라서 나는 행복해요.",["sad","sour","round"],["hapy","happi","happey"],["glad"]),
W("kind","adj","친절한","She is kind, so she helps her classmates.","그녀는 친절해서 반 친구들을 도와줘요.",["mean","rude","sour"],["kined","kynd","kidn"],["nice"]),
];

const adjS = [
S("I have a new pencil case.","나는 새 필통이 있어요.",["I have a pencil new case.","I have new a pencil case.","I have a new pencil cases."],"I have a ___ pencil case.","new",["newly","news","newness"],"형용사는 명사 바로 앞에 놓여 명사를 꾸며요. a와 명사 사이에 형용사를 넣어요."),
S("The soup is hot.","수프가 뜨거워요.",["The soup hot.","The soup is hotly.","The soup are hot."],"The soup ___ hot.","is",["are","am","be"],"주어를 설명하는 형용사 앞에는 be동사가 필요해요. soup는 3인칭 단수라서 is를 써요."),
S("This is an old house.","이것은 오래된 집이에요.",["This is a old house.","This is an old houses.","This is old an house."],"This is ___ old house.","an",["a","two","many"],"모음 소리로 시작하는 형용사(old) 앞에는 a 대신 an을 써요.",{hint:"old의 첫소리가 무엇인지 생각해 보세요."}),
S("The cake is very sweet.","그 케이크는 아주 달콤해요.",["The cake is sweet very.","The cake very is sweet.","The cake is very sweetly."],"The cake is very ___.","sweet",["sweetly","sweetness","sweets"],"very는 형용사 바로 앞에서 '아주'라는 뜻으로 정도를 나타내요."),
S("I feel tired today.","나는 오늘 피곤해요.",["I feel tiredly today.","I feel tire today.","I feeling tired today."],"I feel ___ today.","tired",["tiredly","tire","tiring"],"feel 뒤에는 기분을 나타내는 형용사가 와요. 부사(-ly)나 명사 형태는 쓰지 않아요."),
S("She has long legs.","그녀는 다리가 길어요.",["She has longs legs.","She has long leg.","She have long legs."],"She has ___ legs.","long",["longs","longly","length"],"형용사는 명사가 복수여도 모양이 변하지 않아요. long에는 s를 붙이지 않아요."),
];

const adjM = [
M("It is yellow and sour. You can put it in hot tea. What is it?",["a banana","a lemon","a carrot","a grape"],1,"노랗고 신 맛이 나는 것은 lemon(레몬)이에요. 바나나는 달고 당근은 주황색이에요.","riddle",2),
M("Which word is the opposite of “dark”?",["salty","soft","short","bright"],3,"dark(어두운)의 반대말은 bright(밝은)예요.","opposite",2),
M("맛을 나타내는 말이 아닌 것은?",["salty","sweet","round","spicy"],2,"round(둥근)는 모양을 나타내는 말이에요. 나머지는 모두 맛을 나타내요.","category",2),
M("Which word does NOT describe a feeling?",["tall","happy","angry","tired"],0,"tall(키가 큰)은 모습을 나타내고, 나머지는 기분이나 몸의 느낌을 나타내요.","category",2),
M("That is ___ old bike.",["a","two","an","many"],2,"old는 모음 소리로 시작하고 bike는 하나이므로 an을 써요.","article",3),
M("Choose the best English phrase for “큰 빨간 가방”.",["a red big bag","a bag big red","a big red bag","big a red bag"],2,"크기(big)를 나타내는 말은 색깔(red)보다 앞에 오고, 모두 a와 명사 bag 사이에 와요.","word order",4),
M("A: How is the weather today?\nB: ___",["It is a sun.","It is sunny.","I am sunny.","It is sunning."],1,"날씨를 말할 때는 It is 뒤에 sunny 같은 형용사를 써요.","dialogue",2),
M("I did not sleep last night. I feel ___ now.",["sleepy","spicy","sunny","salty"],0,"밤에 잠을 못 잤다면 졸린 느낌이므로 sleepy가 알맞아요.","feeling",2),
M("Which sentence is NOT true?",["Ice is cold.","Fire is hot.","Honey is sweet.","A turtle is fast."],3,"거북이는 느린 동물이에요. 그래서 'A turtle is fast.'는 사실이 아니에요.","fact",2),
M("Which pair are opposites?",["tall – short","hot – warm","big – large","happy – glad"],0,"tall(키가 큰)과 short(키가 작은)는 반대말이에요. 나머지는 뜻이 비슷한 말이에요.","opposite",3),
M("Which word means “full of color”?",["colorless","colored","colorful","coloring"],2,"-ful은 '~이 가득한'이라는 뜻이라서 colorful은 '색이 다채로운'이에요. colorless는 색이 없다는 뜻이에요.","word form",4),
M("Which animal is usually the slowest?",["a turtle","a rabbit","a horse","a cheetah"],0,"거북이는 걸음이 아주 느려요. 나머지는 빠르게 달리는 동물이에요.","fact",1),
M("Which thing is usually soft?",["a rock","a desk","a coin","a pillow"],3,"베개는 부드러워요. 바위, 책상, 동전은 단단해요.","fact",1),
M("Which word is the opposite of “dirty”?",["noisy","clean","empty","wet"],1,"dirty(더러운)의 반대말은 clean(깨끗한)이에요.","opposite",1),
M("Which sentence means almost the same as “The room is quiet”?",["It is silent.","There is a lot of noise.","There is no light.","There is no chair."],0,"quiet(조용한)는 silent(고요한)와 뜻이 비슷해요.","meaning",3),
M("Which phrase is correct?",["an sad man","an tall man","an angry man","an young man"],2,"angry는 모음 소리로 시작하므로 an을 써요. sad, tall, young은 자음 소리로 시작해서 a를 써요.","article",3),
M("Min-su ran for an hour. He says, “I am ___ and I want some water.”",["quiet","young","round","thirsty"],3,"오래 달린 뒤 물을 마시고 싶다면 목이 마른 것이므로 thirsty가 알맞아요.","context",3),
M("모양을 나타내는 말은?",["sour","noisy","round","happy"],2,"round(둥근)는 물건의 모양을 나타내요. 나머지는 맛, 소리, 기분을 나타내요.","category",2),
];

const prepW = [
W("on","prep","위에","The cat is sleeping on the sofa.","고양이가 소파 위에서 자고 있어요.",["between","toward","past"],["onn","oon","omn"],["above","over","on top of"]),
W("in","prep","안에","My pencil is in my bag.","내 연필은 가방 안에 있어요.",["between","toward","past"],null,["inside"]),
W("under","prep","아래에","Our shoes are under the bed.","우리 신발은 침대 아래에 있어요.",["into","along","past"],["undar","unnder","udner"],["below","beneath"]),
W("behind","prep","뒤에","The small boy is hiding behind his mother.","작은 남자아이가 엄마 뒤에 숨어 있어요.",["between","along","into"],["behined","bihind","behnid"]),
W("next to","phr","옆에","I sit next to my best friend in class.","나는 교실에서 가장 친한 친구 옆에 앉아요.",["between","inside","along"],null,["beside","by","near"]),
W("between","prep","사이에","The park is between the library and the school.","공원은 도서관과 학교 사이에 있어요.",["inside","into","through"],["betwen","beetween","betweeen"]),
W("in front of","phr","앞에","I stand in front of Mina in the line, so she goes after me.","나는 줄에서 미나 앞에 서서, 미나는 내 다음에 가요.",["behind","inside","between"]),
W("near","prep","가까이에","My school is near my house, so I walk there.","우리 학교는 집 가까이에 있어서 나는 걸어서 가요.",["through","into","up"],["neer","nere","nearr"],["nearby","next to"]),
W("inside","prep","안쪽에","The seed is inside the apple.","씨앗은 사과 안쪽에 있어요.",["along","toward","across"],["insaid","insied","inzide"],["in"]),
W("outside","prep","바깥에","The classroom is full, so we wait outside it.","교실이 가득 차서 우리는 교실 바깥에서 기다려요.",["inside","into","between"],["outsid","outsaid","owtside"]),
W("above","prep","위쪽에","The moon is above the tall tree tonight.","오늘 밤 달은 키 큰 나무 위쪽에 떠 있어요.",["into","between","through"],["abuve","abov","abbove"],["over","on"]),
W("across","prep","가로질러","A long bridge goes across the river to the other side.","긴 다리가 강을 가로질러 반대편으로 이어져요.",["inside","between","into"],["acros","accross","acrros"]),
W("around","prep","주위에","We sit around the table to eat dinner.","우리는 저녁을 먹으려고 식탁 주위에 앉아요.",["into","past","up"],["arround","arond","aroud"]),
W("through","prep","통과해서","The train goes through a long tunnel and then comes out.","기차는 긴 터널을 통과해서 밖으로 나와요.",["beside","above","between"],["throuh","thorugh","throug"]),
W("along","prep","따라","Many trees grow along the road.","길을 따라 나무가 많이 자라요.",["between","inside","past"],["alonge","alog","allong"]),
W("into","prep","안으로","Please put your hand into the box and take one card.","상자 안으로 손을 넣어 카드를 한 장 꺼내세요.",["between","past","along"]),
W("up","adv","위로","The balloon goes up into the sky.","풍선이 하늘로 위로 올라가요.",["down","here","inside"]),
W("down","adv","아래로","At night, the sun goes down and the sky gets dark.","밤이 되면 해가 아래로 내려가고 하늘이 어두워져요.",["up","here","inside"]),
W("upstairs","adv","위층에","My room is on the second floor, so it is upstairs.","내 방은 2층에 있어서 위층에 있어요.",["downstairs","outside","nearby"],["upstares","upstaris","upstiars"]),
W("downstairs","adv","아래층에","Dad is on the first floor. He is downstairs in the kitchen.","아빠는 1층에 있어요. 아빠는 아래층 부엌에 있어요.",["upstairs","outside","nearby"],["downstares","downstaris","dawnstairs"]),
W("far from","phr","멀리 떨어져","We cannot walk to the sea because our house is far from it.","우리 집은 바다에서 멀리 떨어져 있어서 걸어갈 수 없어요.",["near","next to","in front of"]),
W("out of","phr","밖으로","Water comes out of the faucet when I turn it on.","수도꼭지를 틀면 물이 밖으로 나와요.",["into","between","inside"]),
W("toward","prep","향해","The puppy runs toward me when I call its name.","강아지는 내가 이름을 부르면 나를 향해 달려와요.",["inside","between","above"],["towrd","toword","towerd"]),
W("past","prep","지나서","The bus goes past our school without stopping.","버스는 서지 않고 우리 학교를 지나서 가요.",["between","above","inside"]),
W("below","prep","아래쪽에","The basement is below the kitchen.","지하실은 부엌 아래쪽에 있어요.",["above","across","around"],["belou","belwo","bilow"],["under","beneath"]),
W("on top of","phr","맨 위에","The strawberry is on top of the cake, so you can see it first.","딸기가 케이크 맨 위에 있어서 가장 먼저 보여요.",["under","inside","between"],null,["on","above"]),
];
// fix the ex for "on top of": syn on lists; ok

const prepS = [
S("The ball is in front of the box.","공은 상자 앞에 있어요.",["The ball is in front the box.","The ball is front of the box.","The ball is in of front the box."],"The ball is in ___ of the box.","front",["fronts","fronting","frontal"],"'~ 앞에'는 in front of로 써요. of를 빠뜨리지 않도록 해요."),
S("The bank is between the school and the park.","은행은 학교와 공원 사이에 있어요.",["The bank is between the school the park.","The bank is between the school with the park.","The bank is between the school or the park."],"The bank is ___ the school and the park.","between",["behind","under","inside"],"between은 'A and B' 형태로 두 대상 사이를 말해요."),
S("The pencil is on the desk.","연필은 책상 위에 있어요.",["The pencil is on desk.","The pencil on is the desk.","The pencil is the on desk."],"The pencil is ___ the desk.","on",["under","behind","inside"],"장소를 나타내는 말 뒤에는 보통 the + 명사가 와요. on the desk처럼 쓰고 the를 빠뜨리지 않아요.",{hint:"연필은 책상 위에 있다는 뜻에 맞게 고르세요."}),
S("Where is my cap?","내 모자는 어디에 있어요?",["Where my cap is?","Where are my cap?","Where is cap my?"],"Where ___ my cap?","is",["are","do","does"],"Where 뒤에는 be동사가 먼저 오고 그 뒤에 주어가 와요. cap은 하나이므로 is를 써요."),
S("The children are standing around the tree.","아이들이 나무 주위에 서 있어요.",["The children are standing the tree around.","The children standing are around the tree.","The children are stand around the tree."],"The children are standing ___ the tree.","around",["into","on","inside"],"around는 '~ 주위에'라는 뜻으로 뒤에 장소를 나타내는 명사가 바로 와요. 현재진행은 are + 동사ing예요."),
S("She walks along the river with her dog.","그녀는 강을 따라 개와 함께 걸어요.",["She walks along to the river with her dog.","She walks the river along with her dog.","She walk along the river with her dog."],"She walks ___ the river with her dog.","along",["into","under","between"],"along은 '~을 따라'라는 뜻이고 to 없이 바로 장소가 와요. 주어가 She이면 동사에 s를 붙여요."),
];

const prepM = [
M("Mina is ___ school now.",["between","toward","at","above"],2,"'학교에 있다'고 말할 때는 at school이라고 해요.","collocation",2),
M("Jisu lives ___ Busan.",["on","to","in","at"],2,"도시 안에 산다고 할 때는 in을 써서 live in Busan이라고 해요.","collocation",2),
M("The picture is ___ the wall.",["toward","on","through","between"],1,"벽에 붙어 있는 그림은 on the wall이라고 해요.","collocation",2),
M("Look at the picture. A bird is sitting on the roof. A cat is under the tree. Where is the bird?",["Under the tree","In the water","Behind the house","On the roof"],3,"그림 설명에서 새는 지붕 위(on the roof)에 앉아 있어요.","reading",2),
M("Tom is in front of Ann. Ann is in front of Sue. Who is last in the line?",["Tom","Ann","Sue","Nobody"],2,"Tom, Ann, Sue 순서로 서 있으므로 맨 뒤에 있는 사람은 Sue예요.","logic",3),
M("Which sentence means the same as “The cup is on the table”?",["The table is under the cup.","The cup is under the table.","The table is on the cup.","The table is next to the cup."],0,"컵이 탁자 위에 있으면 탁자는 컵 아래에 있는 거예요.","meaning",3),
M("What is the opposite of “inside”?",["behind","outside","between","under"],1,"inside(안쪽에)의 반대말은 outside(바깥에)예요.","opposite",2),
M("What is the opposite of “in front of”?",["next to","near","between","behind"],3,"in front of(~ 앞에)의 반대말은 behind(~ 뒤에)예요.","opposite",2),
M("Ann stands between Tom and Sue. Who is in the middle?",["Ann","Tom","Sue","All of them"],0,"between Tom and Sue는 Tom과 Sue 사이이므로 가운데에 있는 사람은 Ann이에요.","logic",3),
M("Teacher says, “Put your book under your chair.” Where do you put it?",["On the chair","Behind the board","Between the desks","Under the chair"],3,"under는 '~ 아래에'라는 뜻이므로 의자 아래에 책을 놓아요.","instruction",2),
M("Which word is NOT a place word?",["above","happy","behind","under"],1,"happy(행복한)는 기분을 나타내요. 나머지는 위치를 나타내는 말이에요.","category",2),
M("The ball rolled ___ the road to the other side.",["between","across","behind","inside"],1,"길의 한쪽에서 반대쪽으로 가는 것은 across the road라고 해요.","context",3),
M("My house is ___ the school. I can walk there in two minutes.",["far from","between","under","near"],3,"걸어서 2분이면 가까운 거리이므로 near가 알맞아요.","context",2),
M("We walk ___ the hill to reach the top.",["down","into","up","between"],2,"언덕 꼭대기에 가려면 위로 올라가므로 walk up the hill이라고 해요.","context",3),
M("Our bedroom is on the second floor. We go ___ the stairs.",["down","up","under","behind"],1,"2층 침실로 가려면 계단을 올라가야 하므로 go up the stairs라고 해요.","context",2),
M("Which sentence is correct?",["The park is across of the school.","The park is cross the school.","The park is across from the school.","The park is across to school."],2,"'~의 맞은편에'는 across from으로 말해요.","expression",4),
M("The answer is “It is in the kitchen.” Which question fits?",["Who is the juice?","When is the juice?","Where is the juice?","How old is the juice?"],2,"장소를 묻는 말은 Where로 시작해요. 'in the kitchen'은 장소를 나타내요.","question",2),
M("Where do you wear a hat? You wear it ___ your head.",["on","in","between","toward"],0,"모자를 머리에 쓸 때는 on your head라고 해요.","collocation",2),
];

fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E12-e4.json", JSON.stringify({packet:"E12-e4",sections:[{skill:"e.e4.adj",items:[...adjW,...adjS,...adjM]},{skill:"e.e4.prep",items:[...prepW,...prepS,...prepM]}]},null,1));
console.log(adjW.length,adjS.length,adjM.length,prepW.length,prepS.length,prepM.length);
