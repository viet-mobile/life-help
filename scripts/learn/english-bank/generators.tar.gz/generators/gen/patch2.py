def sub(path, pairs):
    t=open(path,encoding='utf8').read()
    for a,b in pairs:
        if t.count(a)!=1: print("MISS",t.count(a),a[:60])
        t=t.replace(a,b)
    open(path,'w',encoding='utf8').write(t)
sub('h01r.mjs',[
('"Volunteers sometimes miss class."','"Volunteers sometimes miss class to finish their rounds."'),
('"The writer did something difficult."','"The writer succeeded in doing something difficult."'),
('"It has been away for a long time."','"It has not been in the lighthouse for a long time."'),
('"They had been apart for years."','"Her grandparents had been apart for a long time."'),
('"To show effort caused the change"','"To show that effort was the reason for the change"'),
('"It has fallen slightly."','"It has gone down since the program began."'),
('"Fixed the problem and added a room"','"Fixed the coffee problem and added a reading room"'),
('"The body is still recovering."','"The body may still be recovering from earlier lack of sleep."'),
('"A storm had destroyed ships nearby."','"Ships had been destroyed in a storm near the rocks."'),
('"To tell students how to log books"','"To tell students how to record their books"'),
('"Patience leads to success."','"Patience and steady effort lead to success."'),
])
