import fs from "node:fs";
import { S } from "./s.mjs"; import { M } from "./m.mjs"; import { R } from "./r.mjs";
const place = (key, ds, i) => { const p = [1,3,0,2][i%4]; const o = [...ds]; o.splice(p,0,key); return { o, a: p }; };
const s = S.map(([good,ko,bad,st,ok,wr,rule,ord]) => ({ k:"s", good, ko, bad, cz:{st,ok,wr}, rule, ...(ord===false?{ord:false}:{}) }));
const m = M.map(([q,key,ds,why],i) => { const {o,a}=place(key,ds,i); return { k:"m", q, o, a, why, cat:"clause" }; });
const r = R.map(([title,text,qs],ti) => ({ k:"r", title, text, qs: qs.map(([q,key,ds,why,std],i)=>{ const {o,a}=place(key,ds,i+ti); return {q,o,a,why,std}; }) }));
const w = [
{k:"w",en:"assume",pos:"v",ko:"가정하다, 추정하다",ex:"Don't assume that everyone knows the rule.",exko:"모든 사람이 그 규칙을 안다고 가정하지 마세요.",z:["drink","paint","carry"],syn:["suppose"],sp:["asume","assum","assumme"]},
{k:"w",en:"claim",pos:"v",ko:"주장하다",ex:"They claim that the store is open all night.",exko:"그들은 그 가게가 밤새 연다고 주장해요.",z:["wash","swim","bake"],syn:["insist","maintain"],sp:["clame","claime","cliam"]},
{k:"w",en:"doubt",pos:"n",ko:"의심, 의문",ex:"There is no doubt that she will win.",exko:"그녀가 이길 것이라는 데는 의심의 여지가 없어요.",z:["sugar","bridge","pocket"],syn:["suspicion"],sp:["dout","doupt","doubbt"]},
{k:"w",en:"reveal",pos:"v",ko:"드러내다, 밝히다",ex:"The test will reveal whether you understand the lesson.",exko:"그 시험은 네가 수업을 이해하는지 보여줄 거예요.",z:["borrow","climb","paint"],syn:["show","disclose","expose"],sp:["revael","reveel","reveil"]},
];
for (const x of r) for (const q of x.qs) if (!q.std) delete q.std;
const items=[...s,...m,...r,...w];
console.log("counts", {s:s.length,m:m.length,r:r.length,w:w.length});
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H02-h1-clause.json", JSON.stringify({packet:"H02-h1-clause",sections:[{skill:"e.h1.clause",items}]},null,1));
