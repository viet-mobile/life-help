import fs from "node:fs";
const R = (k, title, text, qs) => ({ k, title, text, qs: qs.map(([q, o, a, why]) => ({ q, o, a, why })) });
const M = (q, o, a, why) => ({ k: "m", q, o, a, why, cat: "reading" });
const S = (good, ko, bad, st, ok, wr, rule, hint) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...(hint ? { hint } : {}) });
const items = [
R("r","Mina's Cat","Mina has a cat. The cat is white. Its name is Nabi. Nabi likes milk. Nabi sleeps on Mina's bed.",[
["누가 고양이를 키우나요?",["Tom","Mina","Nabi","Mina's mom"],1,"첫 문장 “Mina has a cat.”에서 Mina가 고양이를 키워요."],
["고양이는 무슨 색인가요?",["black","gray","white","brown"],2,"“The cat is white.”라고 했어요."],
["Nabi가 좋아하는 것은 무엇인가요?",["milk","fish","bread","rice"],0,"“Nabi likes milk.”라고 했어요."],
["Nabi는 어디에서 자나요?",["on the chair","in a big box","on the sofa","on her bed"],3,"“Nabi sleeps on Mina's bed.”라고 했어요. her bed는 Mina의 침대예요."]]),
R("r","A Fun Day","I go to the park with my dad. We play with a ball. Dad kicks the ball, and I run and catch it. Then we eat ice cream. It is a fun day.",[
["글쓴이는 어디에 갔나요?",["the zoo","the park","the library","the beach"],1,"첫 문장에 “I go to the park”라고 나와요."],
["공을 차는 사람은 누구인가요?",["Dad","my friend","my brother","my teacher"],0,"“Dad kicks the ball”이라고 했어요."],
["마지막에 무엇을 먹었나요?",["cake","pizza","ice cream","bread"],2,"“Then we eat ice cream.”이라고 했어요."],
["이 글의 중심 내용은 무엇인가요?",["아빠와 공원에서 보낸 즐거운 하루","학교에서 본 어려운 시험","동물원에서 만난 여러 동물","비 오는 날 집에서 한 놀이"],0,"공원에서 아빠와 공놀이를 하고 아이스크림을 먹은 즐거운 하루 이야기예요."]]),
R("r","My Room","This is my room. I have a bed and a desk. A lamp is on the desk. My bag is under the chair. I like my room.",[
["What is on the desk?",["a bag","a lamp","a book","a cup"],1,"“A lamp is on the desk.”라고 했어요."],
["Where is the bag?",["on the bed","on the desk","under the chair","behind the door"],2,"“My bag is under the chair.”라고 했어요."],
["Which thing is NOT in the room?",["a TV","a bed","a desk","a lamp"],0,"방에 침대, 책상, 램프는 있지만 TV는 나오지 않아요."],
["How does the writer feel about the room?",["The writer wants a new one.","The writer likes it.","The writer thinks it is small.","The writer does not use it."],1,"마지막 문장 “I like my room.”에서 방을 좋아한다는 것을 알 수 있어요."]]),
R("r","Lunch Time","It is lunch time. I have rice and soup. Jun has a sandwich. We drink milk. I do not like carrots, but Jun likes them.",[
["글쓴이는 무엇을 먹나요?",["a sandwich and milk","noodles and juice","bread and soup","rice and soup"],3,"“I have rice and soup.”라고 했어요. sandwich는 Jun이 먹어요."],
["Jun이 먹는 것은 무엇인가요?",["a sandwich","rice","soup","an apple"],0,"“Jun has a sandwich.”라고 했어요."],
["두 사람이 함께 마시는 것은 무엇인가요?",["water","juice","milk","tea"],2,"“We drink milk.”라고 했어요."],
["당근을 좋아하는 사람은 누구인가요?",["I","Jun","Jun's mom","the teacher"],1,"“I do not like carrots, but Jun likes them.”에서 당근을 좋아하는 사람은 Jun이에요."]]),
R("r","Puddle Fun","It is rainy today. I take my yellow umbrella and wear blue boots. I jump in the water on the road. Mom says, \"Be careful!\"",[
["오늘 날씨는 어떤가요?",["sunny","snowy","rainy","windy"],2,"첫 문장 “It is rainy today.”에서 비가 온다는 것을 알 수 있어요."],
["우산은 무슨 색인가요?",["blue","yellow","red","green"],1,"“my yellow umbrella”라고 했어요. blue는 장화 색이에요."],
["글쓴이는 물에서 무엇을 하나요?",["jump","swim","sleep","dance"],0,"“I jump in the water”라고 했어요."],
["엄마가 한 말 “Be careful!”의 뜻은 무엇일까요?",["빨리 와!","고마워!","안녕!","조심해!"],3,"Be careful은 “조심해”라는 뜻이에요."]]),
R("r","Tom's Family","Tom has a mom, a dad, and a sister. His sister is six. She likes dolls. His dad is a cook, and his mom is a teacher.",[
["Tom까지 포함해 가족은 모두 몇 명인가요?",["three","four","five","six"],1,"Tom, 엄마, 아빠, 여동생으로 모두 네 명이에요."],
["Tom의 아빠는 무엇을 하나요?",["a cook","a teacher","a doctor","a farmer"],0,"“His dad is a cook”이라고 했어요. teacher는 엄마의 직업이에요."],
["“She likes dolls.”에서 She는 누구인가요?",["Tom's mom","a doll","Tom's sister","a teacher"],2,"앞 문장의 His sister를 가리켜요."],
["Tom의 여동생은 몇 살인가요?",["five","six","seven","eight"],1,"“His sister is six.”라고 했어요."]]),
R("r","A Day at the Zoo","We go to the zoo on Sunday. I see a big elephant. It has a long nose. Some monkeys climb a tree. I like the birds. They are pretty.",[
["동물원에는 무슨 요일에 가나요?",["Saturday","Sunday","Monday","Friday"],1,"“We go to the zoo on Sunday.”라고 했어요."],
["코가 긴 동물은 무엇인가요?",["bird","monkey","elephant","tiger"],2,"“I see a big elephant. It has a long nose.”에서 코가 긴 동물은 코끼리예요."],
["원숭이들은 무엇을 하나요?",["climb a tree","sleep in a bed","swim in a lake","eat lunch"],0,"“Some monkeys climb a tree.”라고 했어요."],
["“They are pretty.”에서 They는 무엇인가요?",["the monkeys","the birds","the trees","the elephants"],1,"바로 앞 문장의 the birds를 가리켜요."]]),
R("r","My Morning","I get up at seven. I wash my face and eat breakfast. At eight, I go to school. My school is near my house, so I walk.",[
["What time does the writer get up?",["six","seven","eight","nine"],1,"“I get up at seven.”이라고 했어요."],
["What time does the writer go to school?",["seven","nine","ten","eight"],3,"“At eight, I go to school.”이라고 했어요."],
["How does the writer go to school?",["by bus","by car","on foot","by bike"],2,"“I walk”는 걸어서 간다는 뜻이에요."],
["Why does the writer walk to school?",["The bus is late.","The school is far away.","It is a sunny day.","The school is near the house."],3,"“My school is near my house, so I walk.”에서 학교가 가깝기 때문이에요."]]),
R("r","Sora's Birthday","Today is Sora's birthday. She is eight. Her friends come to her house, and they bring gifts. Sora gets a red bag and a book. Her mom makes a cake.",[
["Sora는 몇 살인가요?",["seven","eight","nine","ten"],1,"“She is eight.”라고 했어요."],
["Sora가 받은 선물은 무엇인가요?",["a blue hat and a ball","a doll and a cup","a pen and a map","a red bag and a book"],3,"“Sora gets a red bag and a book.”이라고 했어요."],
["엄마는 무엇을 만드나요?",["a cake","soup","pizza","cookies"],0,"“Her mom makes a cake.”라고 했어요."],
["생일 파티는 어디에서 하나요?",["at school","at the park","at her house","at a shop"],2,"친구들이 “her house”로 온다고 했어요."]]),
R("r","Dan's Weekend","On Saturday, Dan plays soccer with his friends. On Sunday, he reads books at home. Dan likes both days.",[
["Dan은 토요일에 무엇을 하나요?",["reads books","plays soccer","goes swimming","cooks lunch"],1,"“On Saturday, Dan plays soccer”라고 했어요."],
["토요일에 누구와 함께 하나요?",["his friends","his dad","his sister","his dog"],0,"“with his friends”라고 했어요."],
["Dan은 일요일에 어디에 있나요?",["at the park","at school","at home","at a shop"],2,"“he reads books at home”이라고 했어요."],
["“both days”는 어떤 날들을 말하나요?",["Monday and Sunday","Friday and Saturday","Saturday and Sunday","Sunday and Tuesday"],2,"앞에서 말한 토요일과 일요일 두 날을 가리켜요."]]),
R("r","Library Rules","This is our school library. Please be quiet. Do not run. Do not eat here. Put the books back on the shelf.",[
["이 글은 어디에 붙어 있을까요?",["a gym","a library","a kitchen","a zoo"],1,"첫 문장에서 school library의 규칙이라고 알려 줘요."],
["“Do not run.”의 뜻은 무엇일까요?",["뛰지 마세요.","걸으세요.","줄을 서세요.","앉으세요."],0,"Do not은 “~하지 마세요”라는 뜻이고, run은 “달리다”예요."],
["여기에서 하면 안 되는 일은 무엇인가요?",["read books","be quiet","sit down","eat food"],3,"“Do not eat here.”라고 했어요."],
["책을 다 본 뒤에는 어떻게 해야 하나요?",["책을 가방에 넣어요.","책을 선반에 다시 꽂아요.","책을 책상 위에 두어요.","책을 친구에게 줘요."],1,"“Put the books back on the shelf.”라고 했어요."]]),
R("r","A Shopping Trip","I go to a fruit shop with Mom. Apples are red. Bananas are yellow. Grapes are purple. Mom buys apples and grapes. I want a banana.",[
["두 사람은 어디에 갔나요?",["a toy shop","a bookstore","a bakery","a fruit shop"],3,"첫 문장에 “a fruit shop”이라고 나와요."],
["엄마는 무엇을 사나요?",["apples and grapes","bananas and grapes","apples and bananas","grapes and pears"],0,"“Mom buys apples and grapes.”라고 했어요."],
["포도는 무슨 색인가요?",["red","yellow","purple","orange"],2,"“Grapes are purple.”이라고 했어요."],
["글쓴이가 원하는 것은 무엇인가요?",["an apple","a banana","grapes","a pear"],1,"마지막 문장 “I want a banana.”에서 알 수 있어요."]]),
R("r","My Pet Fish","I have a small fish. Its name is Bubble. Bubble is orange. It lives in a glass bowl. I give it food every morning.",[
["What is the fish's name?",["Bubble","Splash","Goldie","Coco"],0,"“Its name is Bubble.”이라고 했어요."],
["What color is the fish?",["red","white","blue","orange"],3,"“Bubble is orange.”라고 했어요."],
["Where does the fish live?",["in a plastic tank","in a small pond","in a glass bowl","in a paper cup"],2,"“It lives in a glass bowl.”이라고 했어요."],
["When does the writer give food to the fish?",["every evening","after school","on Sundays only","every morning"],3,"“I give it food every morning.”이라고 했어요."]]),
R("r","A Snowy Day","It is cold today. Snow is on the ground. The children make a snowman. It has a carrot nose and two black eyes. They put a hat on it. The snowman looks happy.",[
["눈사람의 코는 무엇으로 만들었나요?",["a carrot","an apple","a stone","a stick"],0,"“a carrot nose”라고 했어요."],
["“It has a carrot nose”에서 It은 무엇인가요?",["the snow","the hat","the children","the snowman"],3,"바로 앞 문장의 the snowman을 가리켜요."],
["오늘 날씨는 어떤가요?",["hot","rainy","cold","windy"],2,"첫 문장 “It is cold today.”라고 했어요."],
["눈사람의 모습은 어떤가요?",["sad","happy","angry","sleepy"],1,"마지막 문장 “The snowman looks happy.”라고 했어요."]]),
R("r","Our School Week","We have English on Monday. We have art on Tuesday. We have music on Wednesday. I like art best. In art class, I draw pictures.",[
["음악 수업은 무슨 요일에 있나요?",["Monday","Tuesday","Thursday","Wednesday"],3,"“We have music on Wednesday.”라고 했어요."],
["글쓴이가 가장 좋아하는 수업은 무엇인가요?",["music","art","English","math"],1,"“I like art best.”라고 했어요."],
["미술 시간에 글쓴이는 무엇을 하나요?",["draw pictures","read books","sing songs","play ball"],0,"“In art class, I draw pictures.”라고 했어요."],
["미술 수업이 있는 날은 언제인가요?",["Monday","Wednesday","Friday","Tuesday"],3,"“We have art on Tuesday.”라고 했어요."]]),
R("r","A Note from Mom","Dear Jin, I am at work. Your lunch is on the table. Please wash your hands first. I come home at six. Love, Mom",[
["엄마는 지금 어디에 있나요?",["at home","at work","at school","at the shop"],1,"“I am at work.”라고 했어요."],
["점심은 어디에 있나요?",["in the bag","on the bed","in the fridge","on the table"],3,"“Your lunch is on the table.”이라고 했어요."],
["Jin이 먼저 해야 할 일은 무엇인가요?",["손 씻기","숙제하기","엄마에게 전화하기","샤워하기"],0,"“Please wash your hands first.”라고 했어요."],
["엄마는 몇 시에 집에 오나요?",["five","six","seven","eight"],1,"“I come home at six.”라고 했어요."]]),
R("r","Visiting Grandma","On Sunday, we visit Grandma. Her house is in the countryside. We go by bus. Grandma has a small garden. She grows tomatoes, and we eat them for lunch.",[
["할머니 댁에 어떻게 가나요?",["by bus","by train","by car","by bike"],0,"“We go by bus.”라고 했어요."],
["할머니 댁은 어디에 있나요?",["in the city","by the sea","in the countryside","on a hill"],2,"“Her house is in the countryside.”라고 했어요."],
["“we eat them for lunch”에서 them은 무엇인가요?",["flowers","apples","carrots","tomatoes"],3,"앞 문장의 tomatoes를 가리켜요."],
["할머니의 정원은 어떤가요?",["big","small","new","dirty"],1,"“Grandma has a small garden.”이라고 했어요."]]),
R("d","At the Shop","A: Hello! Can I help you?\nB: Yes, please. I want two apples.\nA: OK. Here you are.\nB: How much is it?\nA: It is 2,000 won.\nB: Here you are.\nA: Thank you. Bye!\nB: Bye!",[
["B는 무엇을 사려고 하나요?",["two apples","two pears","one apple","one banana"],0,"B는 “I want two apples.”라고 말해요."],
["값은 얼마인가요?",["1,000 won","2,000 won","3,000 won","5,000 won"],1,"A가 “It is 2,000 won.”이라고 말해요."],
["두 사람은 어디에 있을까요?",["학교 교실","도서관","병원","과일 가게"],3,"A가 손님을 도와주고 사과를 파는 모습이니까 가게예요."],
["A는 어떤 사람일까요?",["손님","가게 주인","선생님","의사"],1,"“Can I help you?”라고 손님을 맞고 값을 말하는 사람은 가게 주인이에요."],
["“Here you are.”는 어떤 뜻일까요?",["어디 있어요?","잘 가요.","미안해요.","여기 있어요."],3,"물건이나 돈을 건넬 때 “여기 있어요”라는 뜻으로 써요."]]),
R("d","Drawing a Picture","A: Hi, Sam! What are you doing?\nB: I am drawing a picture.\nA: Wow! What is it?\nB: It is my dog.\nA: He is cute. What is his name?\nB: His name is Coco.\nA: Can I draw a picture, too?\nB: Sure! Here is a pencil.",[
["Sam은 지금 무엇을 하고 있나요?",["reading a book","drawing a picture","eating lunch","playing soccer"],1,"Sam은 “I am drawing a picture.”라고 말해요."],
["Sam의 그림은 무엇인가요?",["his cat","his bag","his mom","his dog"],3,"“It is my dog.”라고 했어요."],
["개의 이름은 무엇인가요?",["Cookie","Coco","Cora","Max"],1,"“His name is Coco.”라고 했어요."],
["A는 무엇을 부탁하나요?",["그림을 같이 그려도 되는지","연필을 빌려 달라고","개를 보여 달라고","집에 가자고"],0,"A는 “Can I draw a picture, too?”라고 물어요."],
["Sam은 A에게 무엇을 주나요?",["a pencil","a book","a ball","a cup"],0,"Sam은 “Here is a pencil.”이라고 말해요."]]),
M("다음 글을 읽고 답하세요.\nTom has a brown dog. The dog is big.\nTom의 개는 어떤가요?",["big","small","new","long"],0,"“The dog is big.”이라고 했어요."),
M("다음 글을 읽고 답하세요.\nI am hungry. I eat bread and milk.\n글쓴이는 왜 빵과 우유를 먹나요?",["졸려서","추워서","배가 고파서","심심해서"],2,"“I am hungry.”는 “배가 고파요”라는 뜻이에요."),
M("표지판 “No Swimming”은 무슨 뜻일까요?",["수영하세요","수영장이 열려 있어요","수영 모자를 쓰세요","수영하지 마세요"],3,"No는 “~하지 마라”라는 금지의 뜻이에요."),
M("엄마가 “Dinner is ready!”라고 말했어요. 무슨 뜻일까요?",["저녁이 준비됐어요.","저녁을 이미 먹었어요.","저녁이 없어요.","저녁이 늦었어요."],0,"ready는 “준비된”이라는 뜻이에요."),
M("시간표를 보고 답하세요.\nMath 9:00\nEnglish 10:00\nLunch 12:00\nWhat time is lunch?",["9:00","10:00","11:00","12:00"],3,"시간표에 Lunch는 12:00이라고 나와 있어요."),
M("메뉴를 보고 답하세요.\nPizza 5,000 won\nJuice 2,000 won\nSalad 3,000 won\n가장 싼 것은 무엇인가요?",["Pizza","Juice","Salad","Pizza and Salad"],1,"2,000 won인 Juice가 가장 싸요."),
M("이름표를 보고 답하세요.\nName: Jiho Kim\nAge: 8\nClass: 2-3\nJiho의 반은 어디인가요?",["2-1","3-2","8-3","2-3"],3,"이름표에 Class: 2-3이라고 쓰여 있어요."),
M("포스터를 보고 답하세요.\nDog Show! Saturday, 2 o'clock. At the playground.\n어디에서 하나요?",["the library","the playground","the gym","the park"],1,"“At the playground.”는 놀이터(운동장)에서 한다는 뜻이에요."),
M("이야기 순서에 맞게 놓으세요.\n(1) I eat breakfast. (2) I wake up. (3) I go to school.\n알맞은 순서는?",["2-1-3","1-2-3","3-2-1","2-3-1"],0,"일어나서(wake up) 아침을 먹고(eat breakfast) 학교에 가요(go to school)."),
M("글을 읽고 맞는 문장을 고르세요.\nBen has two sisters and one brother.",["Ben has one sister.","Ben has two brothers.","Ben has three sisters.","Ben has one brother."],3,"글에서 Ben에게는 누나(여동생) 두 명과 형(남동생) 한 명이 있어요."),
M("다음 글에서 it은 무엇을 가리키나요?\nAnna has a new bag. She likes it very much.",["the bag","Anna","school","a friend"],0,"it은 바로 앞에 나온 a new bag을 가리켜요."),
M("Why does the writer drink cold water?\nIt is hot today. I drink cold water.",["It is late.","It is rainy.","It is hot.","It is dark."],2,"“It is hot today.”라서 시원한 물을 마셔요."),
M("다음 글에서 quiet의 뜻과 가장 가까운 것은?\nThe baby is asleep. Please be quiet.",["시끄러운","빠른","큰","조용한"],3,"아기가 자고 있으니 조용히 해 달라는 뜻이에요."),
M("글을 읽고 답하세요.\nI have 3 apples. I eat 1 apple.\n지금 사과는 몇 개 남았나요?",["1","2","3","4"],1,"3개에서 1개를 먹었으니 2개가 남아요."),
M("다음 글에 가장 알맞은 제목은?\nMin likes cats. He has two cats. He plays with them every day.",["Min's New School","Min and His Cats","A Rainy Day","My Big Dog"],1,"민과 고양이들에 대한 글이라서 “Min and His Cats”가 알맞아요."),
M("메시지를 읽고 답하세요.\nHi Ella, I am at the park. Come at three. - Jay\n누가 이 메시지를 썼나요?",["Ella","Mom","Tom","Jay"],3,"맨 끝에 쓴 사람 이름이 Jay예요."),
M("How does Sam feel?\nSam has a big smile. He gets a new bike.",["sad","angry","happy","sleepy"],2,"큰 웃음을 짓고 새 자전거를 받았으니 기분이 좋아요."),
M("글을 읽고 답하세요.\nKate likes red, but she does not like green.\nKate가 좋아하지 않는 색은?",["red","green","blue","pink"],1,"“she does not like green”이라고 했어요."),
S("I am a student.","나는 학생이에요.",["I is a student.","I are a student.","I a student am."],"I ___ a student.","am",["is","are","be"],"I 다음에는 am을 써요.","주어 I와 짝이 되는 be동사를 생각해 보세요."),
S("Where is my bag?","내 가방은 어디에 있어요?",["Where my is bag?","Where are my bag?","Where is bag my?"],"Where ___ my bag?","is",["are","am","do"],"가방 한 개를 물을 때는 Where is ~?를 써요.","가방은 하나예요."),
S("Look at the bird!","저 새를 봐!",["Look the bird!","Look at bird the!","At look the bird!"],"Look ___ the bird!","at",["in","of","by"],"“~을 보다”라고 할 때는 look at을 써요.","look과 함께 쓰는 짝꿍 낱말을 떠올려 보세요."),
S("This is my pencil.","이것은 내 연필이에요.",["This are my pencil.","This is me pencil.","This my is pencil."],"This is ___ pencil.","my",["me","I","mine"],"“내 ~”라고 할 때 명사 앞에는 my를 써요.","“나의”를 뜻하는 말이 들어가요."),
S("I can see a big tree.","나는 큰 나무를 볼 수 있어요.",["I can sees a big tree.","I can see a tree big.","I can to see a big tree."],"I can ___ a big tree.","see",["sees","seeing","to see"],"can 뒤에는 동사 그대로(동사원형)를 써요.","can 바로 뒤에 오는 동사의 모양을 생각해 보세요."),
S("She is my friend.","그녀는 내 친구예요.",["She are my friend.","Her is my friend.","She is friend my."],"___ is my friend.","She",["Her","Him","They"],"“그녀는”이라고 주어로 쓸 때는 She를 써요.","우리말 뜻을 보고 누구인지 생각해 보세요.")
];
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E06-e2.json", JSON.stringify({ packet: "E06-e2", sections: [{ skill: "e.e2.read", items }] }, null, 1) + "\n");
console.log(items.length);
