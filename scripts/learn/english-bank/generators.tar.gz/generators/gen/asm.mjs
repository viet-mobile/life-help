import fs from "node:fs";
import r1 from "./r1.mjs"; import r2 from "./r2.mjs"; import r3 from "./r3.mjs"; import dd from "./d.mjs"; import mm from "./m.mjs"; import ss from "./s.mjs";
const cyc=[1,3,0,2,3,0,2,1,0,2,1,3,2,1,3,0];
let n=0;
const place=(key,ds)=>{const a=cyc[n++%cyc.length];const o=[...ds];o.splice(a,0,key);return [o,a];};
const L=[];
const pass=(k,[title,text,qs])=>({k,title,text,qs:qs.map(([q,key,ds,why,std])=>{const [o,a]=place(key,ds);L.push([key.length,Math.max(...ds.map(x=>x.length)),q.slice(0,50)]);return {q,o,a,why,std};})});
const items=[...[...r1,...r2,...r3].map(p=>pass("r",p)),...dd.map(p=>pass("d",p)),
...mm.map(([q,key,ds,why,std,cat])=>{const [o,a]=place(key,ds);L.push([key.length,Math.max(...ds.map(x=>x.length)),q.slice(-50)]);return {k:"m",q,o,a,why,std,...(cat?{cat}:{})};}),...ss];
const c=k=>items.filter(i=>i.k===k).length;
console.log("r",c("r"),"d",c("d"),"m",c("m"),"s",c("s"));
const lc=L.filter(([a,b])=>a>b);console.log("longest",lc.length,"/",L.length,Math.round(100*lc.length/L.length)+"%");
if(process.argv[2]==="list")for(const x of L)if(x[0]>x[1])console.log(x.join(" | "));
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M16-m2-sum1.json",JSON.stringify({packet:"M16-m2-sum1",sections:[{skill:"e.m2.sum1",items}]},null,1)+"\n");
