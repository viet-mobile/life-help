import fs from "node:fs";
import { items as s } from "./s.mjs"; import { items as m } from "./m.mjs"; import { items as r } from "./r.mjs";
const w = [
{k:"w",en:"sequence",pos:"n",ko:"순서",ex:"The numbers are not in the right sequence.",exko:"숫자들이 올바른 순서로 되어 있지 않아요.",z:["weather","holiday","umbrella"],syn:["order"],sp:["sequense","sequance","seqence"]},
{k:"w",en:"step",pos:"n",ko:"단계",ex:"Follow each step in the recipe carefully.",exko:"요리법의 각 단계를 조심스럽게 따라 하세요.",z:["village","holiday","shoulder"],syn:[],sp:["stepp","sstep","steap"]},
{k:"w",en:"instruction",pos:"n",ko:"지시",ex:"She gave a clear instruction to the class.",exko:"그녀는 반 학생들에게 분명한 지시를 했어요.",z:["village","holiday","shoulder"],syn:["direction"],sp:["instrucshun","intruction","instrution"]},
];
const all = [...s, ...m, ...r, ...w];
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M05-order.json", JSON.stringify({packet:"M05-order",sections:[{skill:"e.order",items:all}]},null,1)+"\n");
console.log(all.length);
