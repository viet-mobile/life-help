export const S = [];
const s = (good, ko, bad, st, ok, wr, rule, hint) => S.push({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...(hint ? { hint } : {}) });
s("The girl who sits next to me is my cousin.", "내 옆에 앉아 있는 소녀는 내 사촌이에요.",
 ["The girl which sits next to me is my cousin.", "The girl who sit next to me is my cousin.", "The girl who she sits next to me is my cousin."],
 "The girl ___ sits next to me is my cousin.", "who", ["which", "whose", "what"],
 "선행사가 사람이고 관계절에서 주어 역할을 하면 주격 관계대명사 who를 써요. 관계대명사가 이미 주어이므로 she를 또 쓰지 않아요.");
s("I lost the book which my aunt gave me.", "나는 이모가 준 책을 잃어버렸어요.",
 ["I lost the book who my aunt gave me.", "I lost the book which my aunt gave it to me.", "I lost the book what my aunt gave me."],
 "I lost the book ___ my aunt gave me.", "which", ["who", "whose", "what"],
 "선행사가 사물이면 which를 써요. 관계대명사가 목적어 역할을 하므로 it을 다시 쓰지 않아요.");
s("I know a boy whose father is a pilot.", "나는 아버지가 조종사인 소년을 알아요.",
 ["I know a boy who father is a pilot.", "I know a boy whose his father is a pilot.", "I know a boy which father is a pilot."],
 "I know a boy ___ father is a pilot.", "whose", ["who", "which", "whom"],
 "소유를 나타낼 때는 whose를 써요. whose는 his 같은 소유격을 대신하므로 뒤에 his를 또 쓰지 않아요.");
s("Everything that she said was true.", "그녀가 한 모든 말은 사실이었어요.",
 ["Everything what she said was true.", "Everything who she said was true.", "Everything she said it was true."],
 "Everything ___ she said was true.", "that", ["who", "what", "whose"],
 "everything, all, only 같은 말이 선행사일 때는 주로 that을 써요. 선행사가 이미 있으므로 what은 쓸 수 없어요.");
s("This is the best movie that I have ever seen.", "이것은 내가 지금까지 본 최고의 영화예요.",
 ["This is the best movie what I have ever seen.", "This is the best movie who I have ever seen.", "This is the best movie that I have ever seen it."],
 "This is the best movie ___ I have ever seen.", "that", ["who", "what", "whose"],
 "최상급이 포함된 선행사 뒤에는 관계대명사 that을 즐겨 써요.");
s("The teacher whom we respect retired last year.", "우리가 존경하는 선생님은 작년에 은퇴하셨어요.",
 ["The teacher whose we respect retired last year.", "The teacher whom we respect him retired last year.", "The teacher which we respect retired last year."],
 "The teacher ___ we respect retired last year.", "whom", ["which", "whose", "what"],
 "선행사가 사람이고 관계절에서 목적어 역할을 하면 목적격 whom을 써요. 사람에게 which는 쓰지 않아요.");
s("The girl with whom I danced was Mina.", "내가 함께 춤춘 소녀는 미나였어요.",
 ["The girl with who I danced was Mina.", "The girl whom with I danced was Mina.", "The girl with that I danced was Mina."],
 "The girl with ___ I danced was Mina.", "whom", ["who", "that", "which"],
 "전치사 바로 뒤에는 who나 that을 쓸 수 없고 사람이면 whom을 써요.");
s("This is the house in which my grandfather was born.", "이곳은 우리 할아버지가 태어나신 집이에요.",
 ["This is the house in that my grandfather was born.", "This is the house which in my grandfather was born.", "This is the house in who my grandfather was born."],
 "This is the house in ___ my grandfather was born.", "which", ["that", "who", "what"],
 "‘전치사 + 관계대명사’에서 사물이면 which를 써요. 전치사 바로 뒤에는 that을 쓰지 못해요.");
s("The song that I was listening to is my favorite.", "내가 듣고 있던 노래는 내가 가장 좋아하는 곡이에요.",
 ["The song that I was listening is my favorite.", "The song what I was listening to is my favorite.", "The song who I was listening to is my favorite."],
 "The song that I was listening ___ is my favorite.", "to", ["of", "with", "by"],
 "전치사를 관계절 끝에 남겨 두면 그 전치사(listen to)를 빠뜨리면 안 돼요.");
s("This is the park where we first met.", "여기가 우리가 처음 만난 공원이에요.",
 ["This is the park which we first met.", "This is the park who we first met.", "This is the park where we first met there."],
 "This is the park ___ we first met.", "where", ["which", "who", "whose"],
 "장소를 나타내는 선행사 뒤에서 ‘in/at + 장소’의 뜻을 대신하면 관계부사 where를 써요. where 뒤에는 there를 또 쓰지 않아요.");
s("I remember the day when we won the game.", "나는 우리가 경기에서 이겼던 날을 기억해요.",
 ["I remember the day where we won the game.", "I remember the day who we won the game.", "I remember the day which we won the game."],
 "I remember the day ___ we won the game.", "when", ["where", "who", "whose"],
 "시간을 나타내는 선행사(day, time, year) 뒤에는 관계부사 when을 써요.");
s("Tell me the reason why you are late.", "네가 늦은 이유를 말해 줘.",
 ["Tell me the reason when you are late.", "Tell me the reason where you are late.", "Tell me the reason who you are late."],
 "Tell me the reason ___ you are late.", "why", ["when", "where", "who"],
 "이유를 나타내는 reason 뒤에는 관계부사 why를 써요.");
s("My bike, which I bought last year, is already broken.", "내 자전거는 작년에 샀는데 벌써 고장 났어요.",
 ["My bike, that I bought last year, is already broken.", "My bike, who I bought last year, is already broken.", "My bike, which I bought it last year, is already broken."],
 "My bike, ___ I bought last year, is already broken.", "which", ["that", "who", "whose"],
 "쉼표 뒤에서 덧붙여 설명하는 관계절(계속적 용법)에는 that을 쓰지 않아요. 사물이므로 which를 써요.");
s("My uncle, who lives in Busan, is a chef.", "부산에 사시는 우리 삼촌은 요리사예요.",
 ["My uncle, that lives in Busan, is a chef.", "My uncle, which lives in Busan, is a chef.", "My uncle, who live in Busan, is a chef."],
 "My uncle, ___ lives in Busan, is a chef.", "who", ["that", "which", "whose"],
 "쉼표를 쓰는 관계절에서는 that을 쓰지 않아요. 사람이므로 who를 쓰고, 동사는 선행사(단수)에 맞춰 lives로 써요.");
s("The books that are on the desk belong to Jisu.", "책상 위에 있는 책들은 지수의 것이에요.",
 ["The books that is on the desk belong to Jisu.", "The books that are on the desk belongs to Jisu.", "The books what are on the desk belong to Jisu."],
 "The books that ___ on the desk belong to Jisu.", "are", ["is", "be", "being"],
 "주격 관계대명사 뒤의 동사는 선행사의 수에 맞춰요. books가 복수이므로 are를 써요.");
s("I live in a town whose streets are very narrow.", "나는 길이 매우 좁은 마을에 살아요.",
 ["I live in a town who streets are very narrow.", "I live in a town which streets are very narrow.", "I live in a town whose the streets are very narrow."],
 "I live in a town ___ streets are very narrow.", "whose", ["who", "which", "whom"],
 "whose는 사람뿐 아니라 사물의 소유 관계에도 쓰고, 바로 뒤에 관사 없이 명사가 와요.");
s("The man who is talking to Mr. Kim is our new coach.", "김 선생님과 이야기하고 있는 남자는 우리의 새 코치예요.",
 ["The man who talking to Mr. Kim is our new coach.", "The man whose is talking to Mr. Kim is our new coach.", "The man who is talk to Mr. Kim is our new coach."],
 "The man who ___ talking to Mr. Kim is our new coach.", "is", ["are", "be", "being"],
 "주격 관계대명사 뒤에는 동사가 와요. 진행형에서 be동사를 빠뜨리면 안 돼요.");
s("He is the only student that passed the test.", "그는 시험에 통과한 유일한 학생이에요.",
 ["He is the only student what passed the test.", "He is the only student whose passed the test.", "He is the only student that he passed the test."],
 "He is the only student ___ passed the test.", "that", ["what", "whose", "whom"],
 "the only가 붙은 선행사 뒤에는 that을 즐겨 써요. that이 주어 역할을 하므로 he를 또 쓰지 않아요.");
s("What I need is a good night's sleep.", "내게 필요한 것은 충분한 잠이에요.",
 ["That I need is a good night's sleep.", "Which I need is a good night's sleep.", "Who I need is a good night's sleep."],
 "___ I need is a good night's sleep.", "What", ["That", "Which", "Who"],
 "선행사 없이 ‘~하는 것’이라는 뜻의 명사절을 이끄는 관계대명사는 what이에요.");
s("I didn't understand what he said.", "나는 그가 말한 것을 이해하지 못했어요.",
 ["I didn't understand that he said.", "I didn't understand who he said.", "I didn't understand whose he said."],
 "I didn't understand ___ he said.", "what", ["that", "who", "whose"],
 "‘~하는 것’을 뜻하고 said의 목적어 역할을 하는 말은 what이에요.");
s("All that I want is a quiet room.", "내가 원하는 전부는 조용한 방이에요.",
 ["All what I want is a quiet room.", "All who I want is a quiet room.", "All that I want are a quiet room."],
 "All ___ I want is a quiet room.", "that", ["what", "who", "whose"],
 "all 뒤의 관계대명사는 that을 써요. what은 이미 선행사 all이 있으면 쓰지 않아요.");
s("He passed the exam, which made his parents happy.", "그는 시험에 합격했고, 그것이 부모님을 기쁘게 했어요.",
 ["He passed the exam, that made his parents happy.", "He passed the exam, who made his parents happy.", "He passed the exam, what made his parents happy."],
 "He passed the exam, ___ made his parents happy.", "which", ["that", "who", "what"],
 "which는 앞 문장 전체를 받아 ‘그것이 ~했다’는 뜻으로 쓸 수 있어요. 쉼표 뒤에는 that을 쓰지 않아요.");
s("The movie that we watched yesterday was boring.", "우리가 어제 본 영화는 지루했어요.",
 ["The movie that we watched it yesterday was boring.", "The movie who we watched yesterday was boring.", "The movie what we watched yesterday was boring."],
 "The movie ___ we watched yesterday was boring.", "that", ["who", "what", "whose"],
 "목적격 관계대명사는 관계절 안에서 목적어 역할을 하므로 it 같은 목적어를 또 쓰지 않아요.");
s("Mr. Han, whose son is my classmate, teaches music.", "아들이 내 반 친구인 한 선생님은 음악을 가르쳐요.",
 ["Mr. Han, who son is my classmate, teaches music.", "Mr. Han, whose his son is my classmate, teaches music.", "Mr. Han, which son is my classmate, teaches music."],
 "Mr. Han, ___ son is my classmate, teaches music.", "whose", ["who", "which", "whom"],
 "소유격 관계대명사 whose 뒤에는 바로 명사(son)가 와요. 쉼표는 덧붙이는 설명이에요.");
s("Ms. Lee, whom everyone admires, won the prize.", "모두가 존경하는 이 선생님이 상을 받았어요.",
 ["Ms. Lee, that everyone admires, won the prize.", "Ms. Lee, whom everyone admires her, won the prize.", "Ms. Lee, which everyone admires, won the prize."],
 "Ms. Lee, ___ everyone admires, won the prize.", "whom", ["which", "whose", "what"],
 "쉼표 뒤 관계절에서 사람이 목적어이면 whom을 써요. that은 쓰지 않고, 사람에게 which는 쓰지 않아요.");
s("Anyone who wants to join the club should sign up.", "동아리에 들어오고 싶은 사람은 누구든 신청해야 해요.",
 ["Anyone which wants to join the club should sign up.", "Anyone who want to join the club should sign up.", "Anyone whose wants to join the club should sign up."],
 "Anyone ___ wants to join the club should sign up.", "who", ["which", "whose", "whom"],
 "anyone은 사람을 가리키므로 who를 쓰고, 단수 취급하여 wants로 써요.");
s("Those who work hard will succeed.", "열심히 일하는 사람들은 성공할 거예요.",
 ["Those which work hard will succeed.", "Those who works hard will succeed.", "Those who work hard will succeeds."],
 "Those ___ work hard will succeed.", "who", ["which", "whose", "whom"],
 "‘those who ~’는 ‘~하는 사람들’이라는 뜻이고, 복수이므로 work로 써요.");
s("The thing that surprised me most was the price.", "나를 가장 놀라게 한 것은 가격이었어요.",
 ["The thing what surprised me most was the price.", "The thing who surprised me most was the price.", "The thing that surprised me most were the price."],
 "The thing ___ surprised me most was the price.", "that", ["what", "who", "whose"],
 "thing 같은 사물 선행사 뒤에서는 that을 쓸 수 있어요. what은 선행사와 함께 쓰지 않아요.");
s("We adopted a dog which was found on the street.", "우리는 길에서 발견된 개를 입양했어요.",
 ["We adopted a dog which found on the street.", "We adopted a dog which it was found on the street.", "We adopted a dog what was found on the street."],
 "We adopted a dog ___ was found on the street.", "which", ["whose", "whom", "what"],
 "주격 관계대명사 which 뒤에는 바로 동사(was found)가 와요. 주어 it을 또 쓰지 않아요.");
s("The man whose car was stolen called the police.", "차를 도둑맞은 남자가 경찰에 전화했어요.",
 ["The man who car was stolen called the police.", "The man whose his car was stolen called the police.", "The man whom car was stolen called the police."],
 "The man ___ car was stolen called the police.", "whose", ["who", "whom", "which"],
 "‘그 남자의 차’라는 소유 관계이므로 whose를 써요.");
s("The doctor who treated my grandmother was very kind.", "할머니를 치료해 주신 의사 선생님은 아주 친절했어요.",
 ["The doctor which treated my grandmother was very kind.", "The doctor who treated her my grandmother was very kind.", "The doctor who treated my grandmother were very kind."],
 "The doctor ___ treated my grandmother was very kind.", "who", ["which", "whose", "whom"],
 "사람 선행사의 주격 관계대명사는 who예요. 전체 문장의 동사는 doctor(단수)에 맞춰 was를 써요.");
s("I like people who are honest.", "나는 정직한 사람들을 좋아해요.",
 ["I like people who is honest.", "I like people which are honest.", "I like people who they are honest."],
 "I like people who ___ honest.", "are", ["is", "be", "am"],
 "관계대명사절의 동사는 선행사 people(복수)에 맞춰 are를 써요.");
s("The pen with which she wrote is mine.", "그녀가 그것으로 글씨를 쓴 펜은 내 거예요.",
 ["The pen with that she wrote is mine.", "The pen which with she wrote is mine.", "The pen with who she wrote is mine."],
 "The pen with ___ she wrote is mine.", "which", ["that", "who", "what"],
 "전치사 뒤의 관계대명사는 사물이면 which예요. that과 what은 쓸 수 없어요.");
s("He is the man about whom everyone is talking.", "그는 모두가 이야기하고 있는 사람이에요.",
 ["He is the man about who everyone is talking.", "He is the man about that everyone is talking.", "He is the man whom about everyone is talking."],
 "He is the man about ___ everyone is talking.", "whom", ["who", "that", "which"],
 "전치사 뒤에 사람 목적격이 오면 whom을 써요.");
s("The village where she was born is very small.", "그녀가 태어난 마을은 아주 작아요.",
 ["The village which she was born is very small.", "The village where she was born in is very small.", "The village who she was born is very small."],
 "The village ___ she was born is very small.", "where", ["which", "who", "whose"],
 "‘in the village’의 뜻을 대신하면 where를 써요. which를 쓰려면 in이 필요해요.");
s("My grandmother lives in a house which has a big garden.", "할머니는 큰 정원이 있는 집에 살고 계세요.",
 ["My grandmother lives in a house who has a big garden.", "My grandmother lives in a house whose has a big garden.", "My grandmother lives in a house what has a big garden."],
 "My grandmother lives in a house ___ has a big garden.", "which", ["who", "whose", "what"],
 "사물 선행사의 주격 관계대명사는 which예요.");
s("The teacher told us a story that made us laugh.", "선생님은 우리를 웃게 한 이야기를 해 주셨어요.",
 ["The teacher told us a story who made us laugh.", "The teacher told us a story that it made us laugh.", "The teacher told us a story what made us laugh."],
 "The teacher told us a story ___ made us laugh.", "that", ["who", "what", "whose"],
 "주격 관계대명사 that은 사람과 사물에 모두 쓸 수 있어요. what은 선행사 뒤에 쓰지 않아요.");
s("The woman I met yesterday works at the library.", "내가 어제 만난 여자는 도서관에서 일해요.",
 ["The woman I met her yesterday works at the library.", "The woman met I yesterday works at the library.", "The woman I met yesterday work at the library."],
 "The woman I met yesterday ___ at the library.", "works", ["work", "working", "to work"],
 "목적격 관계대명사는 생략할 수 있어요. 생략되어도 전체 문장의 동사는 woman(단수)에 맞춰 works로 써요.");
s("The movie we saw last night was scary.", "우리가 어젯밤에 본 영화는 무서웠어요.",
 ["The movie we saw it last night was scary.", "The movie saw we last night was scary.", "The movie we saw last night were scary."],
 "The movie we saw last night ___ scary.", "was", ["were", "be", "being"],
 "생략된 목적격 관계대명사 뒤에서도 관계절 안에 목적어를 다시 쓰지 않아요. 주절의 동사는 movie에 맞춰 was예요.");
s("Everything I own is in this box.", "내가 가진 모든 것이 이 상자 안에 있어요.",
 ["Everything I own are in this box.", "Everything I own it is in this box.", "Everything own I is in this box."],
 "Everything I own ___ in this box.", "is", ["are", "were", "be"],
 "everything은 단수 취급해요. 목적격 관계대명사 that이 생략된 문장이에요.");
s("I have a dog that likes swimming.", "나는 수영을 좋아하는 개를 키워요.",
 ["I have a dog it likes swimming.", "I have a dog that like swimming.", "I have a dog what likes swimming."],
 "I have a dog ___ likes swimming.", "that", ["who", "what", "whose"],
 "두 문장을 이을 때 관계대명사가 주어 it을 대신해요. 선행사가 dog(단수)이므로 likes로 써요.");
s("My sister, who is a nurse, works at night.", "간호사인 내 언니는 밤에 일해요.",
 ["My sister, that is a nurse, works at night.", "My sister, which is a nurse, works at night.", "My sister, who are a nurse, works at night."],
 "My sister, ___ is a nurse, works at night.", "who", ["which", "that", "whose"],
 "쉼표를 쓰는 관계절에는 that을 쓰지 않고, 사람이므로 which도 쓰지 않아요.");
s("The mountains which we climbed were covered with snow.", "우리가 오른 산들은 눈으로 덮여 있었어요.",
 ["The mountains which we climbed was covered with snow.", "The mountains who we climbed were covered with snow.", "The mountains which we climbed them were covered with snow."],
 "The mountains which we climbed ___ covered with snow.", "were", ["was", "is", "be"],
 "주절의 동사는 선행사 mountains(복수)에 맞춰요.");
s("This is the museum that opened last month.", "이곳이 지난달에 문을 연 박물관이에요.",
 ["This is the museum who opened last month.", "This is the museum that it opened last month.", "This is the museum what opened last month."],
 "This is the museum ___ opened last month.", "that", ["who", "what", "whose"],
 "사물 선행사의 주격 관계대명사로 that을 쓸 수 있어요.");
s("Is there a shop near here where I can buy a bike?", "이 근처에 자전거를 살 수 있는 가게가 있나요?",
 ["Is there a shop near here which I can buy a bike?", "Is there a shop near here who I can buy a bike?", "Is there a shop near here when I can buy a bike?"],
 "Is there a shop near here ___ I can buy a bike?", "where", ["which", "who", "when"],
 "‘그 가게에서’의 뜻을 대신하는 장소의 관계부사는 where예요.");
s("Mina has a cousin who studies in London.", "미나에게는 런던에서 공부하는 사촌이 있어요.",
 ["Mina has a cousin which studies in London.", "Mina has a cousin who study in London.", "Mina has a cousin whose studies in London."],
 "Mina has a cousin ___ studies in London.", "who", ["which", "whose", "whom"],
 "사람 선행사의 주격 관계대명사는 who이고, 동사는 선행사 cousin(단수)에 맞춰요.");
s("The students who were late missed the bus.", "지각한 학생들은 버스를 놓쳤어요.",
 ["The students which were late missed the bus.", "The students who was late missed the bus.", "The students who were late missed the bus it."],
 "The students ___ were late missed the bus.", "who", ["which", "whose", "what"],
 "복수 선행사 the students 뒤에서도 사람이면 who를 써요.");
s("The bag that she bought is expensive.", "그녀가 산 가방은 비싸요.",
 ["The bag that she bought it is expensive.", "The bag who she bought is expensive.", "The bag what she bought is expensive."],
 "The bag ___ she bought is expensive.", "that", ["who", "what", "whose"],
 "사물 선행사의 목적격 관계대명사로 that을 쓸 수 있고, 관계절 안에 it을 또 쓰지 않아요.");
