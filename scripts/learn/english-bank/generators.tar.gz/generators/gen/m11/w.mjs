export const W = [
 { k: "w", en: "describe", pos: "v", ko: "묘사하다", ex: "Can you describe the person who took your bag?", exko: "네 가방을 가져간 사람을 묘사해 줄 수 있니?", z: ["arrive", "sleep", "laugh"], syn: [], sp: ["discribe", "descirbe", "descrybe"] },
 { k: "w", en: "reason", pos: "n", ko: "이유", ex: "That is the reason why I called you.", exko: "그게 내가 너에게 전화한 이유야.", z: ["window", "bridge", "pencil"], syn: ["cause"], sp: ["reasen", "resaon", "reeson"] },
 { k: "w", en: "tool", pos: "n", ko: "도구", ex: "A hammer is a tool that people use to hit nails.", exko: "망치는 사람들이 못을 박을 때 쓰는 도구예요.", z: ["river", "season", "island"], syn: ["instrument"], sp: ["tul", "toole", "tooll"] }
];
