import json,sys
sys.path.insert(0,'.')
from k10_a import headline,article,idiom_body,idiom_action
from k10_b import proverbs,sino
from k10_c import logic
from k10_d import culture
from k10_e import review
sk={"k.k10.media_headline":headline,"k.k10.media_article":article,"k.k10.idioms_body":idiom_body,"k.k10.idioms_action":idiom_action,"k.k10.proverbs_life":proverbs,"k.k10.sino_four":sino,"k.k10.logic_debate":logic,"k.k10.culture_deep":culture,"k.k10.review_k10":review}
import re
errs=0
allnotes=set()
for sid,v in sk.items():
    es=v["entries"]; print(sid,len(es))
    kos=[e["ko"] for e in es]
    assert len(set(kos))==len(kos),sid
    for k,t in v["notes"].items():
        assert len(t)<=160 and not re.search('[가-힣]',t),(k,t)
        assert k not in allnotes,k; allnotes.add(k)
    for e in es:
        if e.get("note"): assert e["note"] in v["notes"],e
        assert not re.search('[가-힣]',e["g"]+e.get("s","")),e
        if "cloze" in e:
            c=e["cloze"]
            assert c["blank"].count("____")==1 and c["blank"].replace("____",c["ans"])==e["ko"],e["ko"]
            assert len(c["w"])==3 and e["ko"] not in [c["blank"].replace("____",x) for x in c["w"]] and c["ans"] not in c["w"],e["ko"]
        if "choose" in e:
            assert len(e["choose"]["w"])==3 and e["ko"] not in e["choose"]["w"] and len(set(e["choose"]["w"]))==3,e["ko"]
        if e["cat"] in("sentence","expr"): assert e["ko"][-1] in ".?!",e["ko"]
        if e["cat"] in("word","phrase"): assert e["ko"][-1] not in ".?!",e["ko"]
    assert len(es)>=22
out={"level":"K10","skills":sk}
json.dump(out,open('/tmp/claude-0/-home-user-life-help/a7bec9ed-1aa3-5639-a0ea-18d3dd534476/scratchpad/kb/pool_K10.json','w',encoding='utf8'),ensure_ascii=False,indent=1)
print("written")
