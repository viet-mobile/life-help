from k10_a import P,S
def E(ko,g,s,note=None):
    d={"cat":"expr","ko":ko,"g":g,"s":s}
    if note: d["note"]=note
    return d
def W(ko,g,note=None):
    d={"cat":"word","ko":ko,"g":g}
    if note: d["note"]=note
    return d

proverbs={"notes":{
 "proverb":"Proverbs are fixed sayings whose figurative meaning is a general lesson, so they are used as wholes and rarely changed.",
 "nounEndP":"Many proverbs end on a noun phrase with no verb, and they are quoted exactly as they stand."},
 "entries":[
 E("가는 말이 고와야 오는 말이 곱다.","If you speak kindly to others, they will speak kindly to you.","A friend snaps at everyone and then complains that people are rude to him.","proverb"),
 E("낮말은 새가 듣고 밤말은 쥐가 듣는다.","Be careful what you say, because someone may always be listening.","You are about to gossip about a coworker in a quiet corner of the office."),
 E("호랑이도 제 말 하면 온다.","Speak of the devil, and he will appear.","You were just talking about a friend and he walks through the door."),
 E("고래 싸움에 새우 등 터진다.","When powerful parties fight, innocent bystanders get hurt.","Two big companies are in a price war and the small suppliers are suffering."),
 E("원숭이도 나무에서 떨어진다.","Even experts make mistakes.","A famous chef burned the dish and the staff are surprised."),
 E("세 살 버릇 여든까지 간다.","Habits formed in childhood last a lifetime.","You tell a parent why it is important to teach manners to a small child early."),
 P("티끌 모아 태산","Many small amounts add up to something big.","nounEndP"),
 E("되로 주고 말로 받는다.","You give a little and get back much more, usually in trouble.","You made a small joke about a colleague and received a harsh scolding in return."),
 E("윗물이 맑아야 아랫물이 맑다.","Those below follow the example set by those in charge.","A manager who is often late complains that the team is careless about time."),
 E("백지장도 맞들면 낫다.","Even a simple task is easier with help.","You offer to help a neighbor carry a heavy box."),
 E("하늘이 무너져도 솟아날 구멍이 있다.","There is always a way out, even in the worst situation.","A friend has lost his job and thinks everything is over, and you reassure him."),
 P("우물 안 개구리","a person with a narrow view who knows nothing of the wider world","nounEndP"),
 E("등잔 밑이 어둡다.","The thing closest to you is often the hardest to notice.","You searched everywhere for your keys and found them in your own bag."),
 E("가재는 게 편이다.","People side with those who are similar to themselves.","The two coworkers who are both from the same hometown keep taking each other's side."),
 P("빛 좋은 개살구","something that looks appealing but has no real substance","nounEndP"),
 P("누워서 떡 먹기","something that is extremely easy","nounEndP"),
 E("아니 땐 굴뚝에 연기 날까?","There is no smoke without fire; a rumor usually has some basis.","People say there must be some truth behind the rumor about the celebrity."),
 E("사공이 많으면 배가 산으로 간다.","Too many people in charge ruins the outcome.","Ten people are giving orders on a project and nothing gets done."),
 P("천 리 길도 한 걸음부터","Even the longest journey begins with a single step.","nounEndP"),
 E("믿는 도끼에 발등 찍힌다.","You can be hurt by someone you trusted completely.","Your closest partner secretly took your clients and left."),
 P("갈수록 태산","Things keep getting harder as time goes on.","nounEndP"),
 E("말 한마디에 천 냥 빚도 갚는다.","Well-chosen words can resolve even a big problem.","A polite apology calmed down an angry customer."),
 E("열 번 찍어 안 넘어가는 나무 없다.","Persistence will eventually win over anyone or anything.","You keep asking a shy colleague to join the club, and finally she says yes."),
 E("사촌이 땅을 사면 배가 아프다.","People tend to feel envious when someone close to them succeeds.","A cousin bought a big house and you feel a pang of jealousy."),
 E("개구리 올챙이 적 생각 못 한다.","People forget their humble beginnings once they succeed.","A man who rose from poverty now looks down on poor people."),
 E("바늘 도둑이 소 도둑 된다.","A small bad habit can grow into a serious crime.","A child who took a pencil from a friend begins taking bigger things."),
 P("같은 값이면 다홍치마","If the price is the same, choose the nicer one.","nounEndP"),
 E("서당 개 삼 년이면 풍월을 읊는다.","Long exposure to something teaches you a bit about it.","A man who has worked at a bakery for years can explain how bread is made."),
]}

sino={"notes":{
 "fourChar":"Four-character idioms come from Chinese characters; each syllable carries one meaning, and the whole phrase is used like a noun or an adjective.",
 "usage":"Such idioms can serve as a predicate with the copula or as a modifier before a noun when a suffix is added."},
 "entries":[
 W("고진감래","Joy comes after hardship.","fourChar"),
 W("새옹지마","Fortune and misfortune are unpredictable, so do not rejoice or despair too soon."),
 W("설상가상","One misfortune piled on top of another"),
 W("유비무환","Being prepared means having nothing to worry about."),
 W("자업자득","Suffering the consequences of one's own actions"),
 W("이심전심","Communicating without words, heart to heart"),
 W("동문서답","An answer that has nothing to do with the question"),
 W("오리무중","Being completely in the dark, with no clue about the situation"),
 W("역지사지","Putting yourself in the other person's shoes"),
 W("막상막하","Being so evenly matched that it is hard to say which is better"),
 W("우유부단","Being indecisive and unable to make up one's mind"),
 W("안하무인","Being arrogant and treating others as if they did not exist"),
 W("자화자찬","Praising oneself"),
 W("천생연분","A match made in heaven"),
 W("부전자전","Like father, like son"),
 W("십중팔구","Eight or nine times out of ten; almost certainly"),
 W("금상첨화","Something good made even better; icing on the cake"),
 W("일편단심","Single-hearted, unwavering devotion"),
 W("조삼모사","Being fooled by a trick that changes the form but not the substance"),
 W("주객전도","Reversal of what is primary and secondary"),
 W("호시탐탐","Watching eagerly for a chance to strike"),
 W("천차만별","Countless differences; everyone and everything being different"),
 W("박학다식","Being widely learned and knowledgeable"),
 W("임기응변","Adapting quickly to the situation at hand"),
 W("속수무책","Being helpless, with no way to deal with the situation"),
 W("용두사미","A grand start with a weak finish"),
 W("대기만성","Great talent that matures late"),
 W("표리부동","Being two-faced; one's outside differs from one's inside"),
]}
