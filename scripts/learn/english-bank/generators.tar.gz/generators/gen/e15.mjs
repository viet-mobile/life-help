import fs from "node:fs";
const S=(good,ko,bad,st,ok,wr,rule,extra={})=>({k:"s",good,ko,bad,cz:{st,ok,wr},rule,...extra});
const M=(q,o,a,why,extra={})=>({k:"m",q,o,a,why,...extra});
const R=(title,text,qs,ko)=>({k:"r",title,text,std:["6영01-04","6영01-05"],qs:qs.map(([q,key,wr,a,why])=>{const o=[...wr];o.splice(a,0,key);return{q,o,a,why};})});
const W=(en,pos,ko,ex,exko,z,sp)=>({k:"w",en,pos,ko,ex,exko,z,syn:[],sp});

const fut=[
S("I will visit my grandmother tomorrow.","나는 내일 할머니를 찾아뵐 거예요.",["I will visits my grandmother tomorrow.","I will visiting my grandmother tomorrow.","I will to visit my grandmother tomorrow."],"I will ___ my grandmother tomorrow.","visit",["visits","visiting","visited"],"will 뒤에는 항상 동사원형이 와요. 주어가 3인칭이어도 -s를 붙이지 않아요.",{ord:false,std:["6영02-06"],hint:"will 뒤에 오는 동사의 모양을 생각해 보세요."}),
S("She is going to buy a new bag.","그녀는 새 가방을 살 거예요.",["She going to buy a new bag.","She is going to buys a new bag.","She are going to buy a new bag."],"She ___ going to buy a new bag.","is",["am","are","be"],"be going to는 be동사(am/is/are)와 함께 써요. 주어가 She이므로 is를 써요.",{std:["6영02-06"]}),
S("They are going to play soccer after school.","그들은 방과 후에 축구를 할 거예요.",["They is going to play soccer after school.","They are going play soccer after school.","They are going to playing soccer after school."],"They are going to ___ soccer after school.","play",["plays","playing","played"],"be going to 뒤에는 동사원형이 와요.",{ord:false}),
S("He will not come to the party.","그는 파티에 오지 않을 거예요.",["He will not comes to the party.","He not will come to the party.","He will not to come to the party."],"He will not ___ to the party.","come",["comes","coming","came"],"will 부정문은 will not + 동사원형이에요. not은 will 바로 뒤에 써요."),
S("We aren't going to watch TV tonight.","우리는 오늘 밤 TV를 보지 않을 거예요.",["We aren't going to watching TV tonight.","We isn't going to watch TV tonight.","We don't going to watch TV tonight."],"We aren't going to ___ TV tonight.","watch",["watches","watching","watched"],"be going to의 부정문은 be동사 뒤에 not을 붙여요. 그 뒤에는 동사원형이 와요.",{ord:false}),
S("Will you help me with my homework?","내 숙제를 도와줄래요?",["Will you helps me with my homework?","Do you will help me with my homework?","Will you to help me with my homework?"],"Will you ___ me with my homework?","help",["helps","helping","helped"],"will 의문문은 Will + 주어 + 동사원형 ~?의 순서예요."),
S("Is it going to rain this afternoon?","오늘 오후에 비가 올까요?",["Is it going to raining this afternoon?","Does it going to rain this afternoon?","Is it going rain this afternoon?"],"___ it going to rain this afternoon?","Is",["Are","Do","Does"],"be going to 의문문은 be동사를 주어 앞으로 보내요. it에는 Is를 써요."),
S("Are you going to join the art club?","너는 미술 동아리에 들어갈 거니?",["Are you going join the art club?","Do you going to join the art club?","Are you go to join the art club?"],"Are you ___ to join the art club?","going",["go","goes","went"],"be going to를 쓸 때는 going to를 빠뜨리지 않아야 해요. 앞에는 be동사가 와요."),
S("What are you going to eat for lunch?","너는 점심으로 뭘 먹을 거니?",["What you are going to eat for lunch?","What are you going to eating for lunch?","What do you going to eat for lunch?"],"What ___ you going to eat for lunch?","are",["do","is","will"],"의문사 뒤에도 be going to 의문문의 순서(be동사 + 주어 + going to)를 그대로 써요."),
S("I think it will be sunny tomorrow.","내일은 맑을 것 같아요.",["I think it will is sunny tomorrow.","I think it will being sunny tomorrow.","I think it will to be sunny tomorrow."],"I think it will ___ sunny tomorrow.","be",["is","being","was"],"will 뒤에는 be동사도 원형인 be를 써요.",{ord:false}),
S("My brother will be ten years old next month.","내 남동생은 다음 달에 열 살이 될 거예요.",["My brother will is ten years old next month.","My brother will be ten years old yesterday.","My brother is will be ten years old next month."],"My brother ___ be ten years old next month.","will",["is","was","does"],"next month 같은 미래 시간 표현은 will과 함께 써요. 과거를 나타내는 yesterday와는 쓸 수 없어요.",{ord:false}),
S("Dad is going to pick me up at five.","아빠가 5시에 나를 데리러 오실 거예요.",["Dad going to pick me up at five.","Dad is going to picks me up at five.","Dad is going pick me up at five."],"Dad is going to ___ me up at five.","pick",["picks","picking","picked"],"be going to 뒤에는 동사원형이 와요. 주어가 3인칭 단수여도 동사에는 -s를 붙이지 않아요."),
S("Be careful! You are going to fall.","조심해! 너 넘어지겠다.",["Be careful! You going to fall.","Be careful! You are going to falls.","Be careful! You is going to fall."],"Be careful! You are going to ___.","fall",["falls","falling","fell"],"눈앞의 상황으로 곧 일어날 일을 예상할 때도 be going to를 써요."),
S("I'll call you tonight.","오늘 밤에 전화할게요.",["I'll calls you tonight.","I'll to call you tonight.","I'll calling you tonight."],"I'll ___ you tonight.","call",["calls","calling","called"],"I'll은 I will의 줄임말이에요. 그 뒤에도 동사원형이 와요.",{ord:false}),
S("She won't be late for school.","그녀는 학교에 늦지 않을 거예요.",["She won't is late for school.","She won't being late for school.","She doesn't will be late for school."],"She won't ___ late for school.","be",["is","being","was"],"won't는 will not의 줄임말이에요. 뒤에는 동사원형 be가 와요."),
S("When will the movie start?","그 영화는 언제 시작해요?",["When the movie will start?","When will the movie starts?","When does the movie will start?"],"When will the movie ___?","start",["starts","starting","started"],"의문사 + will + 주어 + 동사원형 순서로 써요."),
S("If it rains tomorrow, we will stay home.","내일 비가 오면 우리는 집에 있을 거예요.",["If it will rain tomorrow, we will stay home.","If it rains tomorrow, we will stays home.","If it rains tomorrow, we will to stay home."],"If it ___ tomorrow, we will stay home.","rains",["will rain","rained","raining"],"if가 이끄는 조건절에서는 미래의 일이어도 will을 쓰지 않고 현재형으로 말해요.",{ord:false}),
S("Tom is going to be a doctor someday.","톰은 언젠가 의사가 될 거예요.",["Tom is going to being a doctor someday.","Tom is going to is a doctor someday.","Tom going to be a doctor someday."],"Tom is going to ___ a doctor someday.","be",["being","is","are"],"be going to 뒤에는 동사원형이 오므로 be동사도 be로 써요.",{ord:false,std:["6영02-06"]}),
S("Are they going to travel by train?","그들은 기차로 여행할 거니?",["Are they going travel by train?","Do they going to travel by train?","Are they going to travelling by train?"],"Are they going to ___ by train?","travel",["travels","travelling","traveled"],"be going to 의문문에서도 going to 뒤에는 동사원형을 써요."),
S("I will not forget your birthday.","나는 네 생일을 잊지 않을 거야.",["I will not forgets your birthday.","I not will forget your birthday.","I will not forgot your birthday."],"I will not ___ your birthday.","forget",["forgets","forgot","forgetting"],"will not 뒤에는 동사원형을 써요."),
S("Will Mina bring her umbrella?","미나는 우산을 가져올까요?",["Will Mina brings her umbrella?","Does Mina will bring her umbrella?","Will Mina to bring her umbrella?"],"Will Mina ___ her umbrella?","bring",["brings","brought","bringing"],"Will + 주어 + 동사원형 ~? 로 물어요. 주어가 Mina여도 동사는 원형이에요."),
];
const futM=[
M("I will see you ___.",["last week","tomorrow","two days ago","yesterday"],1,"will은 앞으로 일어날 일에 쓰므로 미래를 나타내는 tomorrow(내일)와 어울려요.",{cat:"time words"}),
M("‘나는 내일 수영하러 갈 거예요.’를 영어로 바르게 옮긴 것은?",["I went swimming tomorrow.","I go swimming yesterday.","I will go swimming tomorrow.","I will went swimming tomorrow."],2,"미래는 will + 동사원형으로 말해요. went는 과거형이라 will 뒤에 쓸 수 없어요."),
M("We ___ visit the science museum next Friday.",["will","did","has","are"],0,"next Friday는 미래이고, 빈칸 뒤에 동사원형 visit이 있으므로 will이 알맞아요. are visit은 틀린 형태예요."),
M("‘will not’의 줄임말은 무엇일까요?",["don't","willn't","won't","wouldn't"],2,"will not은 won't로 줄여 써요. willn't라는 말은 없어요."),
M("I'm going to study English tonight. 여기서 I'm은 무엇의 줄임말일까요?",["I have","I was","I would","I am"],3,"I'm은 I am의 줄임말이고, am going to는 ‘~할 예정이다’라는 뜻이에요."),
M("A: Will you come to my party? B: Yes, ___.",["I do","I am","I will","I did"],2,"Will ~?로 물으면 will을 이용해 Yes, I will.로 대답해요."),
M("A: Are you going to see a movie today? B: No, ___.",["I don't","I'm not","I didn't","I wasn't"],1,"be going to 의문문에는 be동사로 대답해요. No, I'm not.이 알맞아요."),
M("다음 중 계획을 묻는 질문은 무엇일까요?",["What did you do last weekend?","What were you doing at that time?","What was your best day?","What are you going to do this weekend?"],3,"be going to는 앞으로의 계획을 물을 때 써요. 나머지 문장은 과거의 일을 물어요."),
M("다음 중 미래의 일을 말하는 문장은 무엇일까요?",["I cleaned my room after dinner.","I clean my room every Sunday.","I am cleaning my room now.","I will clean my room after dinner."],3,"will + 동사원형은 앞으로의 일을 나타내요. 나머지는 과거, 습관, 현재 진행이에요."),
M("Mom ___ going to cook dinner tonight.",["are","be","is","am"],2,"주어 Mom은 3인칭 단수이므로 is going to를 써요."),
M("They ___ going to move to a new house in May.",["is","are","am","does"],1,"주어 They에는 be동사 are를 써서 are going to로 말해요."),
M("다음 문장에서 틀린 부분은 어디일까요?\nShe will goes to the library after lunch.",["will","after lunch","goes","to the library"],2,"will 뒤에는 동사원형이 와야 해요. goes를 go로 고쳐야 해요."),
M("‘내일 비가 올 거예요.’에 맞는 영어 문장은 무엇일까요?",["It rain will tomorrow.","It is will rain tomorrow.","It will rain tomorrow.","It will rains tomorrow."],2,"will은 주어 바로 뒤에 오고 그 뒤에 동사원형이 와요."),
M("I ___ be late. I promise!",["won't","didn't","wasn't","isn't"],0,"약속하며 ‘늦지 않을게’라고 할 때 will not의 줄임말 won't를 써요. 나머지는 be 앞에 쓸 수 없어요."),
M("A: The phone is ringing. B: I ___ answer it.",["have","did","am","will"],3,"그 자리에서 정한 일을 말할 때 will을 써요. I will answer it.이 자연스러워요."),
M("will 바로 뒤에 올 수 없는 것은 무엇일까요?",["be","eat","going","go"],2,"will 뒤에는 동사원형만 와요. going은 -ing형이라 쓸 수 없어요."),
M("‘He will win.’을 의문문으로 바꾼 것은 무엇일까요?",["Does he will win?","Will he win?","Is he will win?","Will he wins?"],1,"will 의문문은 will을 주어 앞으로 보내고 동사는 원형으로 써요."),
M("다음 중 모두 미래를 나타내는 표현끼리 짝지은 것은 무엇일까요?",["last year, tomorrow","yesterday, soon","ago, last night","next month, tonight"],3,"next month(다음 달)와 tonight(오늘 밤)은 앞으로의 때를 나타내요. 다른 짝에는 과거 표현이 섞여 있어요."),
M("A: What are you going to do this summer? B: ___",["I visited my cousins last summer.","I'm going to visit my cousins.","I was at home yesterday.","I visit my cousin yesterday."],1,"계획을 묻는 질문에는 be going to로 대답해요. 나머지는 과거를 나타내요."),
M("A: Will it be cold tomorrow? B: Yes, it ___.",["does","is","was","will"],3,"Will it ~?에는 Yes, it will.로 대답해요."),
M("다음 중 문법적으로 틀린 문장은 무엇일까요?",["I will meet my friends tomorrow.","She is going to study tonight.","He won't eat the cake.","We will to go camping."],3,"will 뒤에는 to 없이 동사원형이 와야 해요. We will go camping.이 맞아요."),
M("Mina ___ her grandparents this weekend.",["is going to visit","is going to visits","are going to visit","going to visit"],0,"주어 Mina에는 is가 필요하고, going to 뒤에는 동사원형 visit이 와요."),
M("We will have a picnic ___ Saturday.",["last","next","ago","yesterday"],1,"will은 앞으로의 일에 쓰므로 미래를 나타내는 next Saturday(다음 토요일)가 알맞아요. last는 과거를 나타내요."),
M("What's he going to do? 에서 What's는 무엇의 줄임말일까요?",["What has","What does","What was","What is"],3,"What's he going to do?의 What's는 What is예요. be going to 의문문이기 때문이에요."),
M("A: Is Jack going to join us? B: Yes, ___.",["he has","he is","he did","he does"],1,"be going to 의문문에는 be동사로 대답해요. Yes, he is.가 알맞아요."),
M("A: When ___ you going to finish your homework? B: After dinner.",["did","will","do","are"],3,"going to 앞에는 be동사가 필요해요. 주어 you에는 are를 써요."),
];
const fr=[
R("A Surprise for Dad","Next Saturday is my father's birthday. My sister and I are going to make a cake for him. Mom will buy the eggs and milk at the market this afternoon. We are going to hide the cake in the kitchen until evening. After dinner, we will sing a song together. I think Dad will be very happy.",[
["What is the passage mainly about?","A family's plan for a birthday",["A trip to a big market","A song contest at school","A lesson about baking bread"],0,"글 전체가 아버지 생신을 위한 가족의 계획을 이야기해요."],
["Who will buy the eggs and milk?","Mom",["The writer","Dad","The sister"],2,"세 번째 문장에서 Mom will buy the eggs and milk라고 했어요."],
["Where will the cake stay until evening?","In the kitchen",["Under the bed","At the market","In the garage"],1,"We are going to hide the cake in the kitchen until evening.이라고 했어요."],
["When will the family sing a song?","After dinner",["Before breakfast","On Friday night","At the market"],0,"After dinner, we will sing a song together.라고 했어요."],
["How does the writer feel about the plan?","Hopeful that Dad will enjoy it",["Worried that the cake will burn","Sad that Dad is busy","Angry that Mom is late"],0,"글쓴이는 아빠가 매우 기뻐할 거라고 생각해요(I think Dad will be very happy)."]]),
R("Tomorrow's Weather","Here is tomorrow's weather. In the morning, it will be cloudy, but it will not rain. In the afternoon, the sun will come out and the temperature will go up to twenty-five degrees. In the evening, strong winds are going to blow from the sea. Take a jacket if you plan to walk outside tonight.",[
["Why was this text written?","To tell people what the weather will be",["To teach people how to swim","To sell jackets at a shop","To describe last week's trip"],0,"내일 날씨를 알려 주는 글이에요."],
["What will the morning be like?","Cloudy without rain",["Sunny and hot","Rainy and cold","Windy and cloudy"],0,"In the morning, it will be cloudy, but it will not rain.이라고 했어요."],
["What will happen to the temperature in the afternoon?","It will go up.",["It will stay the same.","It will go down.","It will freeze."],0,"the temperature will go up이라고 했어요."],
["What are the evening winds going to do?","Blow from the sea",["Stop at night","Bring snow","Come from the mountain"],0,"strong winds are going to blow from the sea라고 했어요."]]),
R("Mina's Summer Camp","Mina is going to go to a summer camp in July. She will stay there for five days. At the camp, she is going to swim in a lake, climb a small mountain, and make new friends. She will not bring her phone because the camp has a no-phone rule. Instead, she is going to write a diary every night. After the camp, she will show it to her mother.",[
["How long will Mina stay at the camp?","Five days",["Two weeks","One night","Ten days"],2,"She will stay there for five days.라고 했어요."],
["Why won't Mina bring her phone?","The camp does not allow phones.",["It is too heavy to carry.","Her mother lost it.","It will break in the lake."],0,"the camp has a no-phone rule이라고 했어요."],
["What is Mina going to do every night?","Write in a diary",["Climb a mountain","Call her mother","Swim in the lake"],0,"she is going to write a diary every night라고 했어요."],
["In the last sentence, ‘it’ means ___.","the diary",["the lake","the camp","the phone"],0,"앞 문장에서 쓴 일기(diary)를 어머니께 보여 준다는 뜻이에요."],
["Which of these will Mina do at the camp?","Make new friends",["Watch videos","Visit her cousins","Learn to cook"],1,"At the camp, she is going to ... make new friends라고 했어요."]]),
R("Robot Helpers","In the future, robots will help us at home. A robot will wash the dishes, water the plants, and carry heavy bags. Some people think robots will take care of old people too. But a robot will not understand our feelings like a friend does. So I believe humans and robots are going to work together. What do you think?",[
["What does the writer believe?","People and robots will work together.",["Robots will replace all friends.","Robots will never come home.","Homes will not need any help."],0,"So I believe humans and robots are going to work together.라고 했어요."],
["What will a robot not understand?","Our feelings",["Heavy bags","Simple jobs","The dishes"],2,"a robot will not understand our feelings like a friend does라고 했어요."],
["In this text, ‘carry’ means ___.","hold something and take it somewhere",["throw something away","wash something with water","make something smaller"],0,"carry heavy bags는 무거운 가방을 들고 옮긴다는 뜻이에요."],
["Why does the writer end with ‘What do you think?’","To ask readers for their ideas",["To say that the writer is lost","To finish a story about a friend","To give the readers homework"],0,"독자도 자기 생각을 해 보도록 묻는 마무리예요."]]),
];
const fw=[
W("tomorrow","adv","내일","I will go to the park tomorrow.","나는 내일 공원에 갈 거예요.",["yesterday","ago","never"],["tomorow","tommorow","tomarrow"]),
W("promise","v","약속하다","I promise to call you tonight.","오늘 밤에 전화하겠다고 약속할게.",["eat","wash","open"],["promis","promiss","prommise"]),
];

const tr=[
S("I am not hungry now.","나는 지금 배고프지 않아요.",["I not am hungry now.","I am no hungry now.","I don't am hungry now."],"I am ___ hungry now.","not",["no","don't","isn't"],"be동사의 부정문은 be동사 바로 뒤에 not을 붙여요.",{ord:false}),
S("Are you ready for the test?","너는 시험 볼 준비가 됐니?",["Do you ready for the test?","Are you are ready for the test?","Is you ready for the test?"],"___ you ready for the test?","Are",["Do","Is","Does"],"be동사 문장의 의문문은 be동사를 주어 앞으로 보내요. you에는 Are를 써요."),
S("She doesn't like spicy food.","그녀는 매운 음식을 좋아하지 않아요.",["She don't like spicy food.","She doesn't likes spicy food.","She not like spicy food."],"She ___ like spicy food.","doesn't",["don't","isn't","not"],"주어가 3인칭 단수일 때 일반동사의 부정문은 doesn't + 동사원형이에요."),
S("Does your brother play the piano?","네 오빠(형)는 피아노를 치니?",["Do your brother play the piano?","Does your brother plays the piano?","Is your brother play the piano?"],"___ your brother play the piano?","Does",["Do","Is","Are"],"주어가 3인칭 단수인 일반동사 의문문은 Does + 주어 + 동사원형 ~?이에요."),
S("We didn't watch TV last night.","우리는 어젯밤에 TV를 보지 않았어요.",["We didn't watched TV last night.","We not watched TV last night.","We don't watched TV last night."],"We didn't ___ TV last night.","watch",["watched","watches","watching"],"과거 부정문은 didn't + 동사원형이에요. didn't에 이미 과거의 뜻이 있어요.",{ord:false}),
S("Did you finish your homework?","너는 숙제를 끝냈니?",["Did you finished your homework?","Do you finished your homework?","Were you finish your homework?"],"Did you ___ your homework?","finish",["finished","finishes","finishing"],"과거 의문문은 Did + 주어 + 동사원형 ~?이에요."),
S("They are not at the park.","그들은 공원에 있지 않아요.",["They not are at the park.","They don't at the park.","They are no at the park."],"They are ___ at the park.","not",["no","don't","doesn't"],"be동사가 있는 문장은 don't 없이 be동사 + not으로 부정해요."),
S("Is there a bank near here?","이 근처에 은행이 있나요?",["Are there a bank near here?","Is there have a bank near here?","Do there a bank near here?"],"___ there a bank near here?","Is",["Are","Do","Does"],"There is ~의 의문문은 Is there ~?예요. 뒤에 오는 명사가 단수(a bank)라서 Is를 써요."),
S("Tom can't swim very well.","톰은 수영을 잘 못해요.",["Tom can't swims very well.","Tom doesn't can swim very well.","Tom not can swim very well."],"Tom can't ___ very well.","swim",["swims","swam","swimming"],"can의 부정은 can't(cannot) + 동사원형이에요. can 뒤에서는 주어가 3인칭 단수여도 -s를 붙이지 않아요."),
S("Can you open the window?","창문을 열어 줄래요?",["Do you can open the window?","Can you opens the window?","Can you to open the window?"],"Can you ___ the window?","open",["opens","opening","to open"],"조동사 can의 의문문은 Can + 주어 + 동사원형 ~?이에요."),
S("He wasn't at home yesterday.","그는 어제 집에 없었어요.",["He not was at home yesterday.","He didn't was at home yesterday.","He weren't at home yesterday."],"He ___ at home yesterday.","wasn't",["weren't","isn't","don't"],"be동사의 과거 부정문은 was/were + not이에요. He에는 was를 써요.",{ord:false}),
S("Were they late for class?","그들은 수업에 늦었나요?",["Was they late for class?","Did they late for class?","Were they be late for class?"],"___ they late for class?","Were",["Was","Did","Do"],"be동사 과거 의문문은 Was/Were를 주어 앞에 써요. they에는 Were를 써요."),
S("What does she want for her birthday?","그녀는 생일에 무엇을 갖고 싶어 하나요?",["What she wants for her birthday?","What does she wants for her birthday?","What do she want for her birthday?"],"What ___ she want for her birthday?","does",["do","is","are"],"의문사 뒤에도 does + 주어 + 동사원형 순서를 지켜요."),
S("Where did you go yesterday?","너는 어제 어디에 갔니?",["Where you did go yesterday?","Where did you went yesterday?","Where do you went yesterday?"],"Where did you ___ yesterday?","go",["went","goes","going"],"과거 의문문에서는 did 때문에 동사가 원형이에요. went로 쓰면 틀려요."),
S("I don't have any pencils.","나는 연필이 하나도 없어요.",["I not have any pencils.","I doesn't have any pencils.","I don't has any pencils."],"I ___ have any pencils.","don't",["doesn't","not","am not"],"주어가 I일 때 일반동사 부정문은 don't + 동사원형이에요."),
S("There aren't any eggs in the fridge.","냉장고에 달걀이 하나도 없어요.",["There not are any eggs in the fridge.","There don't any eggs in the fridge.","There aren't any egg in the fridge."],"There ___ any eggs in the fridge.","aren't",["don't","doesn't","not"],"There are ~의 부정문은 There aren't ~예요. 부정문의 any 뒤에는 복수명사를 써요."),
S("Is she watching TV now?","그녀는 지금 TV를 보고 있니?",["Is she watch TV now?","Is she watches TV now?","Does she watching TV now?"],"Is she ___ TV now?","watching",["watch","watches","watched"],"현재진행 의문문은 Is/Are + 주어 + 동사-ing ~?이에요.",{ord:false}),
S("He isn't running in the hallway.","그는 복도에서 뛰고 있지 않아요.",["He isn't run in the hallway.","He doesn't running in the hallway.","He not running in the hallway."],"He isn't ___ in the hallway.","running",["run","runs","ran"],"현재진행 부정문은 be동사 + not + 동사-ing예요.",{ord:false}),
S("How many books do you have?","너는 책이 몇 권 있니?",["How many books you have?","How many books does you have?","How many book do you have?"],"How many books ___ you have?","do",["does","are","is"],"How many 뒤에는 복수명사가 오고, 이어서 do + 주어 + 동사원형 순서로 써요."),
S("Do they eat lunch at school?","그들은 학교에서 점심을 먹나요?",["Does they eat lunch at school?","Do they eats lunch at school?","Are they eat lunch at school?"],"___ they eat lunch at school?","Do",["Does","Are","Is"],"주어가 they이면 일반동사 의문문은 Do + 주어 + 동사원형 ~?이에요."),
S("She didn't go to the party because she was sick.","그녀는 아파서 파티에 가지 않았어요.",["She didn't went to the party because she was sick.","She not go to the party because she was sick.","She didn't goes to the party because she was sick."],"She didn't ___ to the party because she was sick.","go",["went","goes","going"],"didn't 뒤에는 동사원형이 와요. because 뒤의 절은 따로 과거 형태를 써요.",{ord:false}),
];
const trM=[
M("‘I like fish.’를 부정문으로 바꾼 것은 무엇일까요?",["I not like fish.","I doesn't like fish.","I don't like fish.","I am not like fish."],2,"일반동사 문장은 don't(doesn't, didn't)를 이용해 부정문을 만들어요. 주어가 I이므로 don't를 써요."),
M("‘She plays tennis.’를 의문문으로 바꾼 것은 무엇일까요?",["Do she play tennis?","Does she play tennis?","Is she play tennis?","Does she plays tennis?"],1,"주어가 3인칭 단수이므로 Does를 쓰고, 동사는 원형 play로 바꿔요."),
M("‘He is a doctor.’를 부정문으로 바꾼 것은 무엇일까요?",["He not is a doctor.","He don't a doctor.","He is not a doctor.","He doesn't is a doctor."],2,"be동사의 부정문은 be동사 뒤에 not을 붙여요."),
M("‘We eat pizza.’를 과거 부정문으로 바꾼 것은 무엇일까요?",["We don't ate pizza.","We didn't eat pizza.","We not ate pizza.","We didn't ate pizza."],1,"과거 부정문은 didn't + 동사원형이에요."),
M("‘They can swim.’을 의문문으로 바꾼 것은 무엇일까요?",["Do they can swim?","Are they can swim?","Can they swims?","Can they swim?"],3,"can이 있는 문장은 can을 주어 앞으로 보내서 의문문을 만들어요."),
M("‘There are two cats in the garden.’을 의문문으로 바꾼 것은 무엇일까요?",["Is there two cats in the garden?","Do there are two cats in the garden?","Are there two cats in the garden?","Are two cats there in the garden?"],2,"There are ~는 are를 there 앞으로 보내 Are there ~?로 물어요."),
M("‘She lives in Busan.’에서 장소를 묻는 의문문은 무엇일까요?",["Where she lives?","Where does she lives?","Where do she live?","Where does she live?"],3,"Where + does + 주어 + 동사원형 ~? 순서로 써요."),
M("‘I am happy.’의 부정문을 줄임말로 바르게 쓴 것은 무엇일까요?",["I'm not happy.","I amn't happy.","I aren't happy.","I'm no happy."],0,"am not은 amn't로 줄이지 않고 I'm not으로 써요."),
M("다음 중 의문문인 것은 무엇일까요?",["You like music.","Do you like music?","Please like music.","I like music."],1,"Do로 시작하고 물음표로 끝나는 문장이 의문문이에요."),
M("A: Does Jane have a pet? B: No, ___.",["she isn't","she don't","she didn't","she doesn't"],3,"Does로 묻는 질문에는 does를 이용해 대답해요. No, she doesn't.가 알맞아요."),
M("‘This is a book.’의 부정문은 무엇일까요?",["This not is a book.","This is not a book.","This doesn't a book.","This isn't not a book."],1,"be동사 문장은 be동사 뒤에 not을 붙여요."),
M("‘You cleaned your room.’을 의문문으로 바꾼 것은 무엇일까요?",["Do you cleaned your room?","Were you clean your room?","Did you cleaned your room?","Did you clean your room?"],3,"과거 의문문은 Did + 주어 + 동사원형이에요."),
M("다음 문장에서 틀린 부분은 무엇일까요?\nDoes he likes pizza?",["Does","he","likes","pizza"],2,"Does 뒤에는 동사원형이 와야 해요. likes를 like로 고쳐요."),
M("___ she go to school by bus?",["Do","Is","Does","Are"],2,"주어가 she인 일반동사 의문문이므로 Does를 쓰고 go는 원형으로 둬요."),
M("‘I have a brother.’의 부정문은 무엇일까요?",["I not have a brother.","I don't have a brother.","I doesn't have a brother.","I am not have a brother."],1,"일반동사 have의 부정문은 don't have예요."),
M("‘Open the door.’를 ‘문을 열지 마세요’라는 뜻으로 바꾼 것은 무엇일까요?",["Not open the door.","Doesn't open the door.","Don't opens the door.","Don't open the door."],3,"명령문의 부정은 동사원형 앞에 Don't를 붙여요."),
M("‘He was sleepy.’를 의문문으로 바꾼 것은 무엇일까요?",["Did he sleepy?","Was he sleepy?","Does he sleepy?","Is he was sleepy?"],1,"be동사 과거 의문문은 Was를 주어 앞으로 보내요."),
M("다음 중 어순이 바른 의문문은 무엇일까요?",["Where he does live?","Does where he live?","Where does he live?","He does where live?"],2,"의문사 + does + 주어 + 동사원형 순서로 써요. 의문사가 맨 앞에 와요."),
M("‘She likes dogs.’에서 dogs를 묻는 질문은 무엇일까요?",["What do she like?","What does she like?","What she likes?","What does she likes?"],1,"무엇을 좋아하는지 묻는 What does she like?가 알맞아요."),
M("‘There are five apples.’에서 수를 묻는 질문은 무엇일까요?",["How many apples is there?","How many apple are there?","How much apples are there?","How many apples are there?"],3,"How many 뒤에는 복수명사가 오고, are there가 이어져요."),
M("‘Tom broke the window.’에서 Tom을 묻는 질문은 무엇일까요?",["Who did broke the window?","Who is broke the window?","Who broke the window?","Who does the window break?"],2,"주어를 묻는 Who 질문은 do/did 없이 Who + 동사 ~?로 써요."),
M("‘I am tired.’를 과거 부정문으로 바꾼 것은 무엇일까요?",["I didn't tired.","I wasn't tired.","I weren't tired.","I amn't tired."],1,"am의 과거형은 was이므로 I wasn't tired.가 돼요."),
M("A: Do you walk to school? B: ___",["Yes, I am.","Yes, I does.","Yes, I walk do.","Yes, I do."],3,"Do로 묻는 질문에는 Yes, I do.로 대답해요."),
M("‘I can run fast.’의 부정문은 무엇일까요?",["I don't can run fast.","I can't run fast.","I can't runs fast.","I not can run fast."],1,"can의 부정문은 can't + 동사원형이에요."),
M("‘너는 어제 뭐 했니?’를 영어로 바르게 옮긴 것은 무엇일까요?",["What you did yesterday?","What did you did yesterday?","What do you do yesterday?","What did you do yesterday?"],3,"과거 질문은 What did you do ~?이고, did 뒤의 do는 원형이에요."),
M("‘isn't’를 풀어 쓴 것은 무엇일까요?",["is not","does not","is no","are not"],0,"isn't는 is not의 줄임말이에요."),
];
const tw=[
W("question","n","질문","She asked me a question.","그녀는 나에게 질문을 하나 했어요.",["bag","shoe","spoon"],["questoin","qestion","quesstion"]),
W("change","v","바꾸다","Please change the sentence to a question.","그 문장을 질문으로 바꿔 보세요.",["sing","sleep","wash"],["chnage","chaenge","changge"]),
];
const tr_r=[
R("A New Classmate","Today a new student came to our class. His name is Jun. He isn't shy, and he likes to talk. At lunch, I asked him, \"Do you like soccer?\" He said, \"Yes, I do. Do you play too?\" I answered, \"I don't play, but I watch every game.\" Then we both laughed. I think we will be good friends.",[
["What is the passage mainly about?","Meeting a new classmate",["Winning a soccer game","Cooking lunch at school","Changing to a new class"],2,"새로 온 친구 준과 처음 대화하는 이야기예요."],
["In the passage, ‘shy’ means ___.","afraid to talk to new people",["good at playing sports","very hungry at noon","tired after a long day"],0,"shy는 낯선 사람과 이야기하기를 부끄러워하는 것을 뜻해요. 준은 말하기를 좋아한다고 했어요."],
["What does the writer do about soccer?","Watches it but does not play",["Plays it every day","Hates it","Teaches it to Jun"],0,"I don't play, but I watch every game.이라고 했어요."],
["In ‘Yes, I do,’ the word ‘do’ stands for ___.","like soccer",["play with me","talk to Jun","watch every game"],0,"앞의 질문 Do you like soccer?에서 like soccer를 대신해요."],
["How does the writer feel at the end?","Hopeful about a new friendship",["Nervous about a test","Sorry about a mistake","Bored with the lesson"],0,"글쓴이는 둘이 좋은 친구가 될 것 같다고 생각해요."]]),
R("Library Rules","Welcome to our school library! Please follow these rules. Don't eat or drink inside. Don't talk loudly. You can borrow three books for two weeks. Do you want to keep a book longer? Ask the librarian. Don't forget to return your books on time. Thank you!",[
["Why was this notice written?","To explain how to use the library",["To advertise a book sale","To say sorry for a noise","To announce a new teacher"],0,"도서관에서 지켜야 할 규칙을 알려 주는 안내문이에요."],
["How many books can a student borrow?","Three",["Two","Five","One"],0,"You can borrow three books for two weeks.라고 했어요."],
["What should you do to keep a book longer?","Ask the librarian",["Return it and leave","Talk loudly in the room","Eat a snack inside"],0,"Do you want to keep a book longer? Ask the librarian.이라고 했어요."],
["In this notice, ‘borrow’ means ___.","take something for a short time",["give something to a friend","buy something at a shop","break something by mistake"],0,"borrow는 잠시 빌려서 쓰고 돌려주는 것을 뜻해요."],
["Which thing is NOT allowed in the library?","Eating food",["Reading a book","Returning a book","Asking the librarian"],2,"Don't eat or drink inside.라고 했어요."]]),
R("Grandpa's Childhood","I interviewed my grandfather for a school project. \"Did you have a computer when you were young?\" I asked. \"No, we didn't,\" he said. \"We didn't have phones or TVs either. We played outside all day.\" \"Was it boring?\" \"Not at all! We were always busy.\" I was surprised. Life was very different then.",[
["What is the passage mainly about?","How the grandfather's childhood was different",["A new computer game","A school sports day","A trip to see old friends"],1,"할아버지의 어린 시절이 오늘날과 어떻게 달랐는지를 이야기하는 글이에요."],
["Why did the writer talk to the grandfather?","For a school project",["For a birthday gift","For a TV show","For a family trip"],0,"I interviewed my grandfather for a school project.라고 했어요."],
["What did the grandfather NOT have when he was young?","A computer",["A game to play outside","Friends nearby","Time to play"],0,"No, we didn't라고 답해 컴퓨터가 없었음을 알 수 있어요. 바깥에서 하루 종일 놀았다고 했어요."],
["What does the grandfather think about his childhood?","It was not boring.",["It was too quiet.","It was very lonely.","It was too short."],0,"Not at all! We were always busy.라고 대답했어요."],
["In this passage, ‘busy’ means ___.","having a lot to do",["feeling very sleepy","going to bed early","waiting for a bus"],0,"busy는 할 일이 많아 바쁘다는 뜻이에요. 놀 거리가 많았다는 의미예요."]]),
R("Where Is My Umbrella?","Hi Eun, are you at home? I can't find my umbrella. Did I leave it at your house yesterday? It isn't in my bag, and it isn't in my room. It is blue with white dots. Please check the hall. I don't need it today, but I will need it tomorrow because it is going to rain. Thanks! From Sora",[
["Why did Sora write this message?","To ask Eun to look for her umbrella",["To invite Eun to a party","To thank Eun for a gift","To tell Eun about a trip"],0,"소라는 우산을 어제 은의 집에 두고 온 것 같아 찾아봐 달라고 부탁해요."],
["Where has Sora already looked?","In her bag and her room",["In the hall","At the school gate","In the kitchen"],0,"It isn't in my bag, and it isn't in my room.이라고 했어요."],
["What does the umbrella look like?","Blue with white dots",["Red with a long handle","White with blue stripes","Yellow and small"],0,"It is blue with white dots.라고 했어요."],
["Why will Sora need the umbrella tomorrow?","The weather will be rainy.",["She is going to a party.","Her old one is broken.","Her mother wants it."],0,"it is going to rain 때문에 내일 필요하다고 했어요."],
["In this message, ‘check’ means ___.","look carefully to see if it is there",["write down in a book","wash with soap","give to a friend"],0,"check the hall은 현관을 살펴보라는 뜻이에요."]]),
];
const out={packet:"E15-e5",sections:[{skill:"e.e5.future",items:[...fut,...futM,...fr,...fw]},{skill:"e.e5.transform",items:[...tr,...trM,...tr_r,...tw]}]};
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E15-e5.json",JSON.stringify(out,null,1));
