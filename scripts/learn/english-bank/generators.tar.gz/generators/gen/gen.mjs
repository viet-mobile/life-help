import fs from "node:fs";
import { S } from "./h01s.mjs"; import { M } from "./h01m.mjs"; import { R, W } from "./h01r.mjs";
const items = [];
for (const [good, ko, bad, st, ok, wr, rule, hint, ord] of S) items.push({ k:"s", good, ko, bad, cz:{st, ok, wr}, rule, ...(hint?{hint}:{}), ...(ord?{}:{ord:false}), d:3 });
M.forEach(([q,key,wrong,why],i)=>{ const pos=(i*3+(i>>2))%4; const o=[...wrong]; o.splice(pos,0,key); items.push({k:"m",q,o,a:pos,why,cat:"tense"}); });
for (const r of R) items.push({k:"r",title:r.title,text:r.text,std:r.std,d:3,qs:r.qs.map(([q,o,why],i)=>{ const pos=(i*3+r.title.length)%4; const key=o[0]; const w=o.slice(1); w.splice(pos,0,key); return {q,o:w,a:pos,why}; })});
for (const w of W) items.push({...w,d:3});
const cnt={}; for(const i of items) cnt[i.k]=(cnt[i.k]||0)+1; console.log(cnt);
const top=(a,b)=>a; // sections
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H01-h1-tense.json", JSON.stringify({packet:"H01-h1-tense",sections:[{skill:"e.h1.tense",items}]},null,1)+"\n");
