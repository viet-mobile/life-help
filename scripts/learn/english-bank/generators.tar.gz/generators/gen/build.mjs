import fs from "node:fs";
import { sItems } from "./s.mjs";
import { mItems } from "./m.mjs";
import { rItems } from "./r.mjs";
const W = (en, pos, ko, ex, exko, z, syn, sp) => ({ k: "w", en, pos, ko, ex, exko, z, syn, sp });
const wItems = [
  W("exhausted", "adj", "기진맥진한", "After the long trip, Lena was exhausted and fell asleep on the sofa.", "긴 여행 뒤에 레나는 지쳐서 소파에서 잠들었어요.", ["spacious", "edible", "ancient"], ["tired"], ["exausted", "exhaustid", "exhosted"]),
  W("glance", "v", "흘끗 보다", "I glance at the clock every few minutes during class.", "나는 수업 중에 몇 분마다 시계를 흘끗 봐요.", ["mend", "bake", "invent"], ["peek", "look"], ["glanse", "glence", "glanc"]),
  W("reluctant", "adj", "내키지 않는", "Jun was reluctant to speak in front of the class.", "준은 반 친구들 앞에서 말하기를 내켜 하지 않았어요.", ["fond", "capable", "aware"], ["unwilling", "hesitant"], ["reluctent", "relucktant", "reluctan"]),
  W("mumble", "v", "중얼거리다", "Please don't mumble; I can't hear you.", "중얼거리지 마세요. 잘 안 들려요.", ["sharpen", "freeze", "borrow"], ["murmur"], ["mumbel", "mumbble", "mummble"])
];
const items = [...sItems, ...mItems, ...rItems, ...wItems];
console.log({ s: sItems.length, m: mItems.length, r: rItems.length, w: wItems.length });
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H03-h1-partc.json", JSON.stringify({ packet: "H03-h1-partc", sections: [{ skill: "e.h1.partc", items }] }, null, 1) + "\n");
