import fs from "node:fs";
const S = (good, ko, bad, st, ok, wr, rule, hint, ord = true) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...(hint ? { hint } : {}), ...(ord ? {} : { ord: false }) });
const ins = (key, wrongs, pos) => { const o = [...wrongs]; o.splice(pos, 0, key); return o; };
const M = (q, key, wrongs, pos, why, cat = "grammar") => ({ k: "m", q, o: ins(key, wrongs, pos), a: pos, why, cat });
const Q = (q, key, wrongs, pos, why) => ({ q, o: ins(key, wrongs, pos), a: pos, why });
const W = (en, pos, ko, ex, exko, z, sp, syn = []) => ({ k: "w", en, pos, ko, ex, exko, z, syn, sp });
const R = (k, title, text, std, qs) => ({ k, title, text, std, qs });

const tenseS = [
 S("Tom is reading a book now.","톰은 지금 책을 읽고 있어요.",["Tom reads a book now.","Tom read a book now.","Tom will reading a book now."],"Tom ___ a book now.","is reading",["reads","read","will read"],"now(지금)가 있으면 지금 하고 있는 일이므로 현재진행형 be + -ing를 써요.","시간을 나타내는 말을 먼저 보세요.",false),
 S("We played soccer yesterday.","우리는 어제 축구를 했어요.",["We play soccer yesterday.","We are playing soccer yesterday.","We will play soccer yesterday."],"We ___ soccer yesterday.","played",["play","are playing","will play"],"yesterday(어제)는 지난 일이므로 동사의 과거형(-ed)을 써요.","어제 있었던 일이에요.",false),
 S("I will visit my grandmother tomorrow.","나는 내일 할머니를 찾아뵐 거예요.",["I visited my grandmother tomorrow.","I am visit my grandmother tomorrow.","I visiting my grandmother tomorrow."],"I ___ my grandmother tomorrow.","will visit",["visited","visiting","am visit"],"tomorrow(내일)는 앞으로 할 일이므로 will + 동사원형을 써요.","내일 일어날 일이에요.",false),
 S("She goes to the library every Saturday.","그녀는 토요일마다 도서관에 가요.",["She go to the library every Saturday.","She goes to the library every Saturdays.","She will goes to the library every Saturday."],"She ___ to the library every Saturday.","goes",["go","going","will goes"],"every Saturday처럼 늘 반복되는 일은 현재형으로 말하고, 주어가 she이면 동사에 -(e)s를 붙여요.","반복되는 습관을 말하고 있어요."),
 S("Look! It is raining outside.","보세요! 밖에 비가 오고 있어요.",["Look! It rain outside.","Look! It is rain outside.","Look! It will raining outside."],"Look! It ___ outside.","is raining",["rain","is rain","has rain"],"눈앞에서 지금 일어나는 일은 be + -ing(현재진행형)로 말해요.","Look!은 지금 보고 있다는 뜻이에요."),
 S("My brother was sick last week.","내 남동생은 지난주에 아팠어요.",["My brother is sick last week.","My brother were sick last week.","My brother will be sick last week."],"My brother ___ sick last week.","was",["is","were","will be"],"be동사의 과거형은 주어가 I, he, she, it이면 was, you, we, they이면 were예요.","last week는 지난 시간이에요.",false),
 S("I am going to make a cake for her birthday.","나는 그녀의 생일을 위해 케이크를 만들 거예요.",["I going to make a cake for her birthday.","I am going to making a cake for her birthday.","I am go to make a cake for her birthday."],"I am going to ___ a cake for her birthday.","make",["made","makes","making"],"be going to 뒤에는 동사원형이 와요. 앞으로의 계획을 말할 때 써요.","계획을 말하는 표현이에요."),
 S("Did you watch TV last night?","너는 어젯밤에 텔레비전을 봤니?",["Do you watched TV last night?","Did you watched TV last night?","Are you watch TV last night?"],"___ you watch TV last night?","Did",["Do","Are","Will"],"과거의 일을 묻는 일반동사 의문문은 Did + 주어 + 동사원형으로 만들어요.","last night는 이미 지난 시간이에요.",false),
 S("What are you doing now?","너는 지금 무엇을 하고 있니?",["What do you doing now?","What you are doing now?","What are you do now?"],"What ___ you doing now?","are",["do","is","does"],"지금 하고 있는 일을 묻는 말은 What + be동사 + 주어 + -ing ~?로 만들어요.","doing이 힌트예요.",false),
 S("Will it be sunny tomorrow?","내일은 날씨가 맑을까요?",["Will it is sunny tomorrow?","Does it be sunny tomorrow?","Will it sunny tomorrow?"],"Will it ___ sunny tomorrow?","be",["is","being","been"],"will이 있는 의문문에서는 Will + 주어 + 동사원형 순서로 쓰고, be동사도 원형 be가 와요.","will 뒤에는 동사의 기본 모양을 써요.",false),
 S("He didn't go to school yesterday.","그는 어제 학교에 가지 않았어요.",["He didn't went to school yesterday.","He doesn't went to school yesterday.","He not go to school yesterday."],"He didn't ___ to school yesterday.","go",["went","goes","going"],"과거의 부정문은 didn't + 동사원형이에요. didn't가 이미 과거를 나타내므로 동사는 과거형으로 쓰지 않아요.","didn't 뒤의 동사 모양에 주의하세요.",false),
 S("They are going to see a movie this Sunday.","그들은 이번 일요일에 영화를 볼 거예요.",["They going to see a movie this Sunday.","They are going to saw a movie this Sunday.","They is going to see a movie this Sunday."],"They are going to ___ a movie this Sunday.","see",["saw","sees","seeing"],"be going to 뒤에는 항상 동사원형이 와요. be동사는 주어에 맞게 써요(they - are).","going to 뒤를 살펴보세요.",false),
 S("The sun rises in the east.","해는 동쪽에서 떠요.",["The sun rise in the east.","The sun rised in the east.","The sun will rises in the east."],"The sun ___ in the east.","rises",["rise","rised","rising"],"변하지 않는 사실은 현재형으로 말해요. 주어가 the sun(3인칭 단수)이므로 -s를 붙여요.","늘 그런 사실이에요."),
 S("I wake up at seven every morning.","나는 매일 아침 일곱 시에 일어나요.",["I am wake up at seven every morning.","I wakes up at seven every morning.","I will waking up at seven every morning."],"I ___ up at seven every morning.","wake",["wakes","waking","am wake"],"매일 반복되는 습관은 현재형으로 써요. 주어가 I이면 동사에 -s를 붙이지 않아요.","every morning을 보세요.",false),
 S("Last summer, we visited Jeju Island.","지난여름에 우리는 제주도를 방문했어요.",["Last summer, we visit Jeju Island.","Last summer, we will visit Jeju Island.","Last summer, we are visiting Jeju Island."],"Last summer, we ___ Jeju Island.","visited",["visit","will visit","are visiting"],"Last summer(지난여름)는 과거 시간이므로 과거형 visited를 써요.","지난여름 이야기예요.",false),
 S("Minho is not playing games now.","민호는 지금 게임을 하고 있지 않아요.",["Minho not is playing games now.","Minho is not play games now.","Minho does not playing games now."],"Minho is not ___ games now.","playing",["play","played","plays"],"현재진행형의 부정문은 be동사 뒤에 not을 넣고 동사원형 + -ing를 써요.","is not 다음 모양을 보세요.",false),
 S("Look at the dark clouds! It is going to rain.","먹구름을 보세요! 곧 비가 올 것 같아요.",["Look at the dark clouds! It is going to rains.","Look at the dark clouds! It going to rain.","Look at the dark clouds! It is go to rain."],"Look at the dark clouds! It ___ to rain.","is going",["going","is go","goes"],"눈앞의 증거로 곧 일어날 일을 예상할 때는 be going to를 써요.","먹구름이 단서예요."),
 S("My sister studied English for an hour last night.","내 여동생은 어젯밤에 한 시간 동안 영어를 공부했어요.",["My sister studies English for an hour last night.","My sister studyed English for an hour last night.","My sister will study English for an hour last night."],"My sister ___ English for an hour last night.","studied",["studies","studying","will study"],"study처럼 「자음 + y」로 끝나는 동사는 y를 i로 바꾸고 -ed를 붙여 과거형을 만들어요.","last night를 보세요.",false),
 S("Does your dad drive to work every day?","너희 아빠는 매일 운전해서 출근하시니?",["Do your dad drive to work every day?","Does your dad drives to work every day?","Is your dad drive to work every day?"],"___ your dad drive to work every day?","Does",["Do","Is","Are"],"현재형 일반동사 의문문은 Do/Does로 시작하고 동사는 원형을 써요. 주어가 3인칭 단수이면 Does를 써요.","주어가 한 사람이에요.",false),
 S("I will not forget your birthday.","나는 네 생일을 잊지 않을 거예요.",["I will not forgot your birthday.","I not will forget your birthday.","I will not forgets your birthday."],"I will not ___ your birthday.","forget",["forgot","forgets","forgetting"],"will의 부정문은 will not(won't) + 동사원형이에요.","will not 뒤를 보세요."),
 S("When I was young, I lived in Busan.","나는 어릴 때 부산에 살았어요.",["When I was young, I live in Busan.","When I am young, I lived in Busan.","When I was young, I will live in Busan."],"When I was young, I ___ in Busan.","lived",["live","will live","am living"],"어릴 때처럼 이미 지나간 때의 일은 과거형으로 말해요.","어릴 때는 지난 일이에요."),
];

const tenseM = [
 M("빈칸에 알맞은 말은?\nMy dad ___ breakfast right now.","is making",["made","will make","makes"],2,"right now(바로 지금)는 현재진행형을 써요. is making이 알맞아요."),
 M("빈칸에 알맞은 말은?\nYesterday, Sora ___ her grandparents.","called",["calls","is calling","will call"],0,"yesterday는 과거를 나타내므로 과거형 called를 써요."),
 M("빈칸에 알맞은 말은?\nNext weekend, we ___ go camping.","are going to",["is going to","are go to","went to"],3,"주어가 we이므로 are going to + 동사원형으로 앞으로의 계획을 말해요."),
 M("'last month(지난달)'와 함께 쓸 수 있는 문장은?","I visited a museum last month.",["I visit a museum last month.","I will visit a museum last month.","I am visiting a museum last month."],1,"last month는 과거를 나타내는 말이므로 과거형 visited를 써요."),
 M("앞으로 할 일을 말하는 문장은?","I am going to clean my room.",["I cleaned my room.","I clean my room every day.","I am cleaning my room now."],2,"be going to는 앞으로의 계획을 나타내요. 나머지는 과거, 습관, 지금 하는 일이에요."),
 M("다음 문장에서 틀린 부분은?\nShe is play the piano now.","play",["is","the","now"],3,"지금 하고 있는 일은 be + -ing이므로 play를 playing으로 고쳐야 해요."),
 M("다음 문장에서 틀린 부분은?\nWe will visited the zoo next Friday.","visited",["will","the","next"],0,"will 뒤에는 동사원형이 와요. visited를 visit으로 고쳐야 해요."),
 M("buy의 과거형은?","bought",["buyed","boughted","buys"],1,"buy는 불규칙 동사로 과거형은 bought예요."),
 M("run에 -ing를 붙인 바른 형태는?","running",["runing","runeing","runnig"],2,"run처럼 「짧은 모음 + 자음 하나」로 끝나는 동사는 마지막 자음을 한 번 더 쓰고 -ing를 붙여요."),
 M("study의 과거형으로 알맞은 것은?","studied",["studyed","studys","studing"],0,"「자음 + y」로 끝나는 동사는 y를 i로 바꾸고 -ed를 붙여요."),
 M("빈칸에 알맞은 말은?\nYesterday, Mina ___ eat lunch because she was busy.","didn't",["doesn't","isn't","won't"],3,"yesterday의 일을 부정할 때는 didn't + 동사원형을 써요."),
 M("빈칸에 알맞은 말은?\n___ you going to join the music club next month?","Are",["Do","Is","Did"],1,"be going to 의문문은 be동사로 시작해요. 주어가 you이므로 Are를 써요."),
 M("대화에 알맞은 대답은?\nA: What did you do last Sunday?\nB: ___","I went to the park.",["I am going to the park.","I will go to the park.","I go to the park."],2,"last Sunday에 한 일을 물었으므로 과거형으로 대답해요."),
 M("대화에 알맞은 대답은?\nA: What will you do this summer?\nB: ___","I will go swimming at the beach.",["I went swimming at the beach.","I swim at the beach yesterday.","I am swam at the beach."],0,"앞으로 할 일을 묻는 질문에는 will + 동사원형으로 대답해요."),
 M("'나는 어제 영화를 봤어요.'를 영어로 바르게 옮긴 것은?","I saw a movie yesterday.",["I see a movie yesterday.","I will see a movie yesterday.","I seen a movie yesterday."],3,"see의 과거형은 saw예요. yesterday가 있으니 과거형을 써요."),
 M("'우리는 내일 소풍을 갈 거예요.'에 알맞은 문장은?","We will have a picnic tomorrow.",["We will had a picnic tomorrow.","We have a picnic yesterday.","We had a picnic tomorrow."],1,"내일 일은 will + 동사원형으로 말해요. will 뒤에는 had가 아니라 have가 와요."),
 M("빈칸에 알맞은 말은?\nMia is ___ a letter at the moment.","writing",["wrote","write","writes"],2,"at the moment(지금 이 순간)는 현재진행형이에요. write는 e를 빼고 -ing를 붙여 writing이 돼요."),
 M("빈칸에 알맞은 말은?\nI will go to the beach ___.","next Saturday",["last Saturday","yesterday","two days ago"],0,"will은 미래를 나타내므로 next Saturday처럼 앞으로의 시간을 써요."),
 M("빈칸에 알맞은 말은?\nMy uncle called me ___.","two hours ago",["tomorrow","next week","right now"],3,"called는 과거형이므로 ago처럼 지난 시간을 나타내는 말과 함께 써요."),
 M("빈칸에 알맞은 말은?\nMy grandfather ___ a walk every morning.","takes",["take","taken","will takes"],1,"every morning은 반복되는 일이고, 주어가 3인칭 단수이므로 takes를 써요."),
 M("빈칸에 알맞은 말은?\nDad ___ going to wash the car this afternoon.","is",["are","am","be"],2,"be going to에서 be동사는 주어에 맞게 써요. Dad는 3인칭 단수이므로 is예요."),
 M("빈칸에 알맞은 말은?\nWhat time will the movie ___?","start",["starts","started","starting"],0,"will 뒤에는 동사원형이 와요."),
 M("빈칸에 알맞은 말은?\nI ___ my homework before dinner yesterday.","finished",["finish","will finish","am finishing"],3,"yesterday의 일이므로 과거형 finished를 써요."),
 M("빈칸에 알맞은 말은?\nBe quiet! Dad ___ on the phone.","is talking",["talked","will talk","talk"],1,"지금 통화 중이라는 뜻이므로 현재진행형 is talking이 알맞아요."),
 M("'He plays the violin well.'는 어떤 때를 말하는 문장일까요?","현재의 습관이나 사실",["지난 일","앞으로의 계획","지금 막 하고 있는 일"],2,"plays는 현재형으로, 평소에 하는 일이나 사실을 말해요. 지금 이 순간의 일은 is playing이라고 해요."),
 M("was는 어떤 말의 과거형일까요?","am, is",["are만","do","have"],0,"was는 am과 is의 과거형이고, are의 과거형은 were예요."),
];

const modalS = [
 S("She can swim very fast.","그녀는 아주 빠르게 수영할 수 있어요.",["She cans swim very fast.","She can swims very fast.","She can to swim very fast."],"She can ___ very fast.","swim",["swims","to swim","swimming"],"can 뒤에는 주어와 상관없이 항상 동사원형이 와요."),
 S("You must wear a helmet when you ride a bike.","자전거를 탈 때는 헬멧을 써야 해요.",["You must wearing a helmet when you ride a bike.","You must to wear a helmet when you ride a bike.","You musts wear a helmet when you ride a bike."],"You must ___ a helmet when you ride a bike.","wear",["wearing","wore","wears"],"must는 '~해야 한다'는 뜻이고 뒤에는 동사원형이 와요.","must 뒤의 동사 모양을 보세요."),
 S("Children should eat more vegetables.","어린이들은 채소를 더 먹는 게 좋아요.",["Children should eats more vegetables.","Children should to eat more vegetables.","Children should eating more vegetables."],"Children should ___ more vegetables.","eat",["eats","ate","eating"],"should는 '~하는 게 좋다'는 충고의 뜻이고 뒤에 동사원형이 와요."),
 S("May I use your pencil?","네 연필을 써도 될까요?",["May I using your pencil?","May I to use your pencil?","May I uses your pencil?"],"May I ___ your pencil?","use",["using","uses","to use"],"May I ~?는 허락을 구하는 말이에요. may 뒤에도 동사원형이 와요."),
 S("Can you help me with this box?","이 상자 옮기는 것을 도와줄 수 있니?",["Can you helps me with this box?","Can you to help me with this box?","Do can you help me with this box?"],"___ you help me with this box?","Can",["Cans","Are","Is"],"can 의문문은 Can + 주어 + 동사원형 ~?의 순서이고, can은 모양이 변하지 않아요.","질문 맨 앞의 말을 보세요."),
 S("You must not run in the hallway.","복도에서 뛰면 안 돼요.",["You not must run in the hallway.","You must not to run in the hallway.","You don't must run in the hallway."],"You must ___ run in the hallway.","not",["no","don't","isn't"],"must not은 '~하면 안 된다'는 금지의 뜻이에요. not은 must 바로 뒤에 써요.","금지하는 말이에요."),
 S("He can't ride a bike yet.","그는 아직 자전거를 탈 수 없어요.",["He can't rides a bike yet.","He doesn't can ride a bike yet.","He can't to ride a bike yet."],"He ___ ride a bike yet.","can't",["doesn't can","don't can","not can"],"can의 부정형은 can't(cannot)이에요. do/does와 함께 쓰지 않아요.","할 수 없다는 뜻이에요.",false),
 S("Students should not talk during the test.","학생들은 시험 시간에 이야기하지 않는 게 좋아요.",["Students should not talking during the test.","Students not should talk during the test.","Students should not to talk during the test."],"Students should not ___ during the test.","talk",["talks","talking","talked"],"should not은 '~하지 않는 게 좋다'는 뜻이고, 뒤에는 동사원형이 와요.","should not 다음을 보세요.",false),
 S("Where can I buy a train ticket?","기차표는 어디에서 살 수 있나요?",["Where I can buy a train ticket?","Where can I buying a train ticket?","Where can I buys a train ticket?"],"Where can I ___ a train ticket?","buy",["buys","buying","bought"],"의문사가 있는 의문문은 의문사 + can + 주어 + 동사원형 ~? 순서로 써요."),
 S("What should I bring to the picnic?","소풍에 무엇을 가져가야 할까요?",["What should I to bring to the picnic?","What I should bring to the picnic?","What should I brings to the picnic?"],"What ___ I bring to the picnic?","should",["shoulds","does","are"],"What should I + 동사원형 ~?은 '무엇을 ~해야 할까요?'라고 조언을 구하는 말이에요."),
 S("You may leave your bag here.","여기에 가방을 두고 가도 돼요.",["You may leaves your bag here.","You may to leave your bag here.","You mays leave your bag here."],"You may ___ your bag here.","leave",["leaves","leaving","left"],"may는 '~해도 좋다'는 허락의 뜻이고 뒤에 동사원형이 와요.","허락하는 말이에요.",false),
 S("It may rain this afternoon.","오늘 오후에 비가 올지도 몰라요.",["It may be rain this afternoon.","It may raining this afternoon.","It is may rain this afternoon."],"It may ___ this afternoon.","rain",["rains","raining","rained"],"may는 '~일지도 모른다'는 가능성도 나타내요. 이때도 may 뒤에 동사원형이 와요.","확실하지 않은 일을 말해요.",false),
 S("Birds can fly, but fish can't.","새는 날 수 있지만 물고기는 날 수 없어요.",["Birds can flies, but fish can't.","Birds can to fly, but fish can't.","Birds cans fly, but fish can't."],"Birds can fly, but fish ___.","can't",["cans","don't can","not can"],"can의 부정형은 can't예요. 앞의 동사가 반복되면 생략할 수 있어요.","",false),
 S("We must keep the park clean.","우리는 공원을 깨끗하게 지켜야 해요.",["We must to keep the park clean.","We musts keep the park clean.","We must keeps the park clean."],"We ___ keep the park clean.","must",["musts","are must","do must"],"must는 주어가 달라져도 모양이 변하지 않아요. must + 동사원형으로 써요."),
 S("Visitors must not touch the paintings.","관람객은 그림을 만지면 안 돼요.",["Visitors not must touch the paintings.","Visitors must not touching the paintings.","Visitors must not touches the paintings."],"Visitors ___ touch the paintings.","must not",["not must","must no","do must not"],"금지는 must not + 동사원형으로 표현해요."),
 S("It is very dark. I can't see anything.","너무 어두워요. 아무것도 보이지 않아요.",["It is very dark. I can't sees anything.","It is very dark. I can't to see anything.","It is very dark. I don't can see anything."],"It is very dark. I ___ see anything.","can't",["don't can","cans not","not can"],"can't + 동사원형은 '~할 수 없다'는 뜻이에요. can 앞에 do를 쓰지 않아요.","할 수 없는 상황이에요."),
 S("May I come in?","들어가도 될까요?",["May I coming in?","May I comes in?","Do I may come in?"],"May I ___ in?","come",["comes","coming","came"],"허락을 구하는 May I ~?에서 may 뒤에는 동사원형을 써요.","May I 뒤의 모양을 보세요."),
 S("I have a test tomorrow, so I must study tonight.","나는 내일 시험이 있어서 오늘 밤 공부해야 해요.",["I have a test tomorrow, so I must studying tonight.","I have a test tomorrow, so I must studies tonight.","I have a test tomorrow, so I must to study tonight."],"I have a test tomorrow, so I ___ study tonight.","must",["musts","to must","am must"],"must는 '반드시 ~해야 한다'는 뜻이에요. 해야 하는 이유가 분명할 때 써요.","해야만 하는 이유가 있어요.",false),
 S("Should we take an umbrella?","우리 우산을 가져가야 할까요?",["Shoulds we take an umbrella?","Should we to take an umbrella?","Do we should take an umbrella?"],"___ we take an umbrella?","Should",["Shoulds","Does","Are"],"should 의문문은 Should + 주어 + 동사원형 ~?으로 써요."),
 S("You must be quiet in the library.","도서관에서는 조용히 해야 해요.",["You must is quiet in the library.","You must are quiet in the library.","You must to be quiet in the library."],"You must ___ quiet in the library.","be",["is","are","being"],"조동사 뒤에는 be동사도 원형 be를 써요."),
 S("We can have lunch outside because the weather is nice.","날씨가 좋아서 우리는 밖에서 점심을 먹을 수 있어요.",["We can has lunch outside because the weather is nice.","We can having lunch outside because the weather is nice.","We can to have lunch outside because the weather is nice.","x"].slice(0,3),"We ___ have lunch outside because the weather is nice.","can",["cans","are can","do can"],"can은 '~할 수 있다'는 뜻으로, 상황이 허락할 때도 써요. 뒤에는 동사원형이 와요.","",false),
];

const modalM = [
 M("신호등이 빨간색이면 반드시 멈춰야 해요.\nYou ___ stop at a red light.","must",["can","may","are"],1,"반드시 해야 하는 일에는 must를 써요."),
 M("허락을 구하는 질문이에요. 빈칸에 알맞은 말은?\n___ I open the window?","May",["Am","Does","Are"],3,"May I ~?는 '~해도 될까요?'라고 허락을 구하는 말이에요."),
 M("매우 더운 날이에요. 충고하는 말에 알맞은 것은?\nIt's very hot outside. You ___ drink a lot of water.","should",["are","does","mustn't"],0,"'~하는 게 좋다'는 충고에는 should를 써요."),
 M("'You must be quiet here.'의 뜻으로 알맞은 것은?","여기서는 조용히 해야 해요.",["조용히 해도 돼요.","조용히 할 수 있어요.","조용히 하지 않아도 돼요."],2,"must는 '~해야 한다'는 뜻이에요."),
 M("'You may use my pen.'의 뜻으로 알맞은 것은?","내 펜을 써도 좋아요.",["내 펜을 써야 해요.","내 펜을 쓸 수 없어요.","내 펜을 쓰지 않는 게 좋아요."],1,"may는 '~해도 좋다'는 허락의 뜻이에요."),
 M("can이 '능력'을 나타내는 문장은?","My sister can ride a horse.",["You can go home now.","Can I use your phone?","It can be cold at night."],3,"My sister can ride a horse.는 '말을 탈 수 있다'는 능력이에요. 나머지는 허락, 허락 요청, 가능성이에요."),
 M("금지를 나타내는 문장은?","You must not touch the stove.",["You should drink water.","You may sit here.","You can swim well."],2,"must not은 '~하면 안 된다'는 금지의 뜻이에요."),
 M("다음 문장에서 틀린 부분은?\nMy sister can sings very well.","sings",["sister","can","well"],0,"can 뒤에는 동사원형이 와요. sings를 sing으로 고쳐야 해요."),
 M("다음 문장에서 틀린 부분은?\nWe should to clean the room.","to",["We","should","clean"],1,"should 뒤에는 to 없이 동사원형을 써요."),
 M("다음 문장에서 틀린 부분은?\nDoes he can swim?","Does",["he","can","swim"],2,"can이 있는 질문은 Can he swim?처럼 can을 맨 앞으로 보내요. Does를 쓰지 않아요."),
 M("대화에 알맞은 대답은?\nA: May I borrow your umbrella?\nB: ___","Sure, here you are.",["Yes, I must.","No, I am.","Yes, you does."],3,"허락을 구하는 질문에는 'Sure.' 'Yes, you may.' 등으로 대답해요."),
 M("대화의 빈칸에 알맞은 말은?\nA: I have a bad cold.\nB: You ___ stay home and rest.","should",["are","does","mustn't"],0,"'~하는 게 좋겠다'고 충고할 때는 should를 써요."),
 M("대화에 알맞은 대답은?\nA: Can Jinho swim?\nB: Yes, ___.","he can",["he does","he is","he must"],1,"can으로 물으면 can으로 대답해요."),
 M("빈칸에 알맞은 말은?\n아이들은 밤 10시 이후에 게임을 하면 안 돼요.\nChildren ___ play games after 10 p.m.","must not",["don't must","must no","not must"],2,"금지는 must not + 동사원형으로 표현해요."),
 M("빈칸에 알맞은 말은?\nI ___ open this jar. It is too tight.","can't",["must","may","should"],3,"뚜껑이 너무 꽉 조여 있어서 '열 수 없다'는 뜻이므로 can't가 알맞아요."),
 M("must와 may의 차이로 알맞은 것은?","must는 '해야 한다', may는 '해도 된다'는 뜻이다.",["must는 '해도 된다', may는 '해야 한다'는 뜻이다.","must와 may는 둘 다 과거를 나타낸다.","must와 may 뒤에는 -ing 형태가 온다."],1,"must는 의무, may는 허락을 나타내요. 둘 다 뒤에 동사원형이 와요."),
 M("빈칸에 알맞은 형태는?\nHe should ___ his room.","clean",["cleans","cleaning","to clean"],2,"should 뒤에는 동사원형이 와요."),
 M("어순이 알맞은 문장은?","Where should we meet?",["Where we should meet?","Where should we meeting?","Where do should we meet?"],0,"의문사 + should + 주어 + 동사원형 순서로 써요."),
 M("'Penguins can't fly.'의 뜻으로 알맞은 것은?","펭귄은 날 수 없어요.",["펭귄은 날아야 해요.","펭귄은 날아도 돼요.","펭귄은 나는 게 좋아요."],3,"can't는 '~할 수 없다'는 뜻이에요."),
 M("낯선 사람에게 문을 열어 달라고 정중히 부탁하는 말은?","Can you open the door, please?",["You must open the door.","Open the door, you should.","Do you can open the door?"],1,"Can you ~, please?는 부탁할 때 쓰는 말이에요."),
 M("빈칸에 알맞은 말은?\nThe sky is cloudy. It ___ rain later.","may",["will to","is","does"],2,"하늘이 흐리면 비가 올지도 모른다고 말할 수 있어요. may 뒤에는 동사원형이 와요."),
 M("can의 부정형을 줄여 쓴 바른 형태는?","can't",["cann't","ca'nt","can'nt"],0,"can not은 줄여서 can't라고 써요. 줄임표(')는 n과 t 사이에 들어가요.","punctuation"),
 M("'여기에 앉아도 되나요?'를 영어로 바르게 옮긴 것은?","May I sit here?",["Must I sit here?","Do I may sit here?","Should I sits here?"],1,"허락을 구할 때는 May I + 동사원형 ~?을 써요."),
 M("'너는 숙제를 먼저 하는 게 좋겠어.'를 영어로 바르게 옮긴 것은?","You should do your homework first.",["You do should your homework first.","You should does your homework first.","You should to do your homework first."],3,"충고는 should + 동사원형으로 말해요."),
 M("빈칸에 알맞은 말은?\nI'm sorry, I ___ come to your party. I have a piano lesson.","can't",["must","may","should"],2,"피아노 수업이 있어서 갈 수 없다는 뜻이므로 can't가 알맞아요."),
 M("표지판에 'Wet Floor(젖은 바닥)'라고 쓰여 있어요. 알맞은 경고 문장은?\nYou ___ walk carefully here.","should",["can't","may not","are"],0,"젖은 바닥에서는 조심해서 걷는 게 좋다고 충고할 때 should를 써요."),
];

const P = (k,t,s,q)=>R(k,t,s,["6영01-04","6영01-05"],q);
const tenseR = [
 P("r","A Busy Weekend","On Saturday morning, Jisu cleaned her room and washed her dog. In the afternoon, she played badminton with her cousin in the park. Now it is Sunday evening, and she is writing a letter to her friend in Canada. Tomorrow is Monday, so she is going to get up early. She will take the letter to the post office after school.",[
  Q("What did Jisu do on Saturday morning?","She cleaned her room and washed her dog.",["She played badminton with her cousin outside.","She wrote a letter to her friend in Canada.","She went to the post office after school."],2,"첫 문장에 토요일 아침에 방을 청소하고 개를 씻겼다고 나와요."),
  Q("What is Jisu doing now?","Writing a letter",["Playing badminton","Washing her dog","Going to school"],0,"Now it is Sunday evening, and she is writing a letter에서 지금 편지를 쓰고 있어요."),
  Q("What is Jisu going to do tomorrow morning?","Get up early",["Visit her cousin","Wash her dog again","Play in the park"],3,"Tomorrow is Monday, so she is going to get up early.에서 알 수 있어요."),
  Q("When will Jisu take the letter to the post office?","After school on Monday",["On Saturday afternoon","Tonight, before bed","On Sunday morning"],1,"내일(월요일) 방과 후에 우체국에 가져갈 거예요."),
  Q("What is the passage mainly about?","Jisu's weekend and her plans",["How to write a letter to Canada","Jisu's favorite sports at school","A dog that needs a bath"],0,"토요일에 한 일, 지금 하는 일, 내일 할 일을 차례로 말하고 있어요."),
 ]),
 P("r","Sports Day Notice","Our school sports day is next Friday. Last year it rained, so we stayed inside the gym. This year the weather report says it will be sunny. Students are practicing the relay race every afternoon this week. Parents are going to cheer from the stands. Please bring a water bottle and a hat.",[
  Q("When is the school sports day?","Next Friday",["This Monday","Last Friday","Tomorrow morning"],1,"첫 문장에 sports day is next Friday라고 나와요."),
  Q("What happened last year?","They stayed in the gym because of rain.",["The relay race was held outside.","Parents cheered from the stands.","Students practiced every afternoon."],3,"Last year it rained, so we stayed inside the gym."),
  Q("What are students doing this week?","Practicing the relay race",["Cleaning the gym","Buying water bottles","Watching the weather report"],2,"Students are practicing the relay race every afternoon this week."),
  Q("What will the weather be like on sports day?","Sunny",["Rainy","Cloudy and cold","Windy and wet"],0,"the weather report says it will be sunny."),
  Q("Why was this notice written?","To tell people about sports day",["To report last year's winners","To ask parents to join the race","To sell hats and bottles"],1,"운동회 일정과 준비물을 알리는 안내문이에요."),
 ]),
 P("d","Plans for Summer","A: Hi, Ben! What are you doing?\nB: I'm packing my bag. I'm going to visit my uncle in Busan tomorrow.\nA: That sounds fun! What did you do last summer?\nB: I stayed at home and played computer games. It was boring.\nA: This summer will be better. Are you going to swim in the sea?\nB: Yes, I am! I'll bring my swimsuit.\nA: Take lots of pictures, okay?\nB: I will. See you in two weeks!",[
  Q("What is Ben doing now?","Packing his bag",["Swimming in the sea","Playing computer games","Taking pictures"],2,"I'm packing my bag.에서 지금 가방을 싸고 있어요."),
  Q("Who is Ben going to visit?","His uncle",["His cousin","His teacher","His neighbor"],1,"I'm going to visit my uncle in Busan tomorrow."),
  Q("What did Ben do last summer?","He stayed home and played games.",["He visited Busan and swam.","He took lots of pictures.","He packed his bag for a trip."],0,"I stayed at home and played computer games."),
  Q("How did Ben feel about last summer?","It was boring for him.",["It was exciting for him.","It was too hot for him.","It was too short for him."],3,"It was boring.이라고 했으므로 지루했어요."),
  Q("What will Ben bring to Busan?","A swimsuit",["A tent","A camera bag","A sleeping bag"],1,"I'll bring my swimsuit."),
 ]),
 P("d","A Phone Call","A: Hello, Mina. Are you at home?\nB: No, I'm at the supermarket now. I'm buying some fruit.\nA: Oh, I called you twice this morning.\nB: Sorry, I was at the dentist. My phone was in my bag.\nA: No problem. Will you come to my house later?\nB: Yes, I'll be there at five.\nA: Great! We're going to make pizza.\nB: Wonderful. I'll bring the cheese.",[
  Q("Where is Mina now?","At the supermarket",["At the dentist","At home","At A's house"],1,"I'm at the supermarket now."),
  Q("Why did Mina miss the calls this morning?","She was at the dentist and her phone was in her bag.",["She was cooking and her phone was broken.","She was sleeping and her phone was off.","She was shopping and her phone was at home."],0,"I was at the dentist. My phone was in my bag."),
  Q("What time will Mina arrive at A's house?","At five",["At four","At six","At noon"],3,"I'll be there at five."),
  Q("What are they going to make?","Pizza",["Fruit salad","Sandwiches","Cheese cake"],2,"We're going to make pizza."),
  Q("What will Mina bring?","Some cheese",["Some fruit","Some pizza dough","Some drinks"],1,"I'll bring the cheese. fruit는 슈퍼마켓에서 사고 있는 물건이에요."),
 ]),
];

const modalR = [
 P("r","Pool Rules","Welcome to Sunny Pool! Please follow these rules. You must take a shower before you swim. You must not run on the wet floor. Children under seven can swim only with an adult. You may bring a snack, but you should eat it outside the pool area. If you feel tired, you should rest on a bench.",[
  Q("What must swimmers do before they swim?","Take a shower",["Eat a snack","Rest on a bench","Wait for an adult"],1,"You must take a shower before you swim."),
  Q("Who can swim only with an adult?","Children under seven",["Children under ten","Everyone who feels tired","Visitors with a snack"],2,"Children under seven can swim only with an adult."),
  Q("Where should visitors eat their snacks?","Outside the pool area",["On the wet floor","In the water","Next to the shower"],0,"you should eat it outside the pool area."),
  Q("Which action is not allowed?","Running on the wet floor",["Bringing a snack","Resting on a bench","Swimming with an adult"],3,"You must not run on the wet floor."),
  Q("Why was this text written?","To explain how to use the pool safely",["To advertise a swimming class","To tell a story about a swimmer","To ask people to buy snacks"],1,"수영장 이용 규칙을 알려 주는 안내문이에요."),
 ]),
 P("d","Hiking Day","A: Tomorrow we're going hiking. What should I bring?\nB: You should bring water and a hat. It may be very sunny.\nA: Can I bring my dog?\nB: I'm sorry, you can't. Dogs aren't allowed on the trail.\nA: OK. Can I take photos?\nB: Of course! But you must not leave the trail. It's dangerous.\nA: I understand. Should I wear boots?\nB: Yes, you should. Sneakers can be slippery.",[
  Q("What should A bring on the hike?","Water and a hat",["A dog and a camera","Boots and a map","Photos and a hat"],2,"You should bring water and a hat."),
  Q("Why can't A bring the dog?","Dogs are not allowed on the trail.",["The dog is too small to walk far.","The weather will be too sunny.","A needs to carry too many photos."],0,"Dogs aren't allowed on the trail."),
  Q("What must A not do?","Leave the trail",["Take photos","Wear boots","Bring water"],1,"you must not leave the trail. It's dangerous."),
  Q("What does B say about the weather?","It may be very sunny.",["It will rain all day.","It is going to snow.","It must be windy and cold."],3,"It may be very sunny."),
  Q("Why should A wear boots?","Sneakers can be slippery.",["Boots are cheaper than sneakers.","The trail is covered with snow.","Boots help dogs walk safely."],2,"Sneakers can be slippery."),
 ]),
 P("r","Grandpa's Advice","My grandfather is eighty years old, but he can still climb the mountain behind our house. Every morning he says, \"You should walk a little every day.\" He also tells me that I must not skip breakfast. When I ask, \"May I play games after dinner?\", he smiles and says, \"Yes, you may, but only for thirty minutes.\" I think his rules are strict, but they are good for me.",[
  Q("What can the writer's grandfather still do?","Climb the mountain",["Run a marathon","Play computer games","Cook dinner"],1,"he can still climb the mountain behind our house."),
  Q("What does the grandfather say about breakfast?","The writer must not skip it.",["The writer should cook it.","The writer may eat it late.","The writer can have it outside."],0,"he tells me that I must not skip breakfast."),
  Q("How long may the writer play games after dinner?","Thirty minutes",["One hour","Ten minutes","All evening"],2,"Yes, you may, but only for thirty minutes."),
  Q("What does the writer think of the rules?","They are strict but good.",["They are easy and boring.","They are silly and unfair.","They are new and confusing."],3,"his rules are strict, but they are good for me."),
  Q("In the passage, what does \"skip\" mean?","Not have",["Jump over","Cook well","Eat quickly"],1,"must not skip breakfast는 아침을 거르지 말라는 뜻이므로 skip은 '거르다'예요."),
 ]),
 P("d","At the Library","A: Excuse me. May I borrow three books?\nB: Sorry, you can borrow only two books at a time.\nA: Oh, I see. How long can I keep them?\nB: You can keep them for two weeks. You must return them on time.\nA: What happens if I'm late?\nB: You must pay a small fee. You should check the date on your card.\nA: Thank you. Can I use the computers here?\nB: Yes, you may. But you must be quiet.",[
  Q("How many books can A borrow at a time?","Two",["One","Three","Five"],3,"you can borrow only two books at a time."),
  Q("How long can A keep the books?","For two weeks",["For two days","For one month","For one night"],0,"You can keep them for two weeks."),
  Q("What must A do if the books are late?","Pay a small fee",["Buy new books","Write a letter","Clean the library"],2,"You must pay a small fee."),
  Q("What should A check?","The date on the card",["The number on the computer","The name of the book","The time on the clock"],1,"You should check the date on your card."),
  Q("Which is true about the computers?","A may use them but must be quiet.",["A cannot use them at all.","A can use them only with a teacher.","A must bring a computer."],0,"Yes, you may. But you must be quiet."),
 ]),
];

const sec = (skill, S_, M_, R_, W_) => ({ skill, items: [...S_, ...M_, ...R_, ...W_] });
const tenseW = [
 W("tomorrow","adv","내일","We will go hiking tomorrow.","우리는 내일 하이킹을 갈 거예요.",["yesterday","usually","always"],["tomorow","tommorow","tomarrow"]),
 W("usually","adv","보통, 대개","I usually walk to school.","나는 보통 걸어서 학교에 가요.",["yesterday","tomorrow","tonight"],["usualy","usully","usaully"],["often","normally"]),
];
const modalW = [
 W("rule","n","규칙","One rule in our class is to be kind.","우리 반의 규칙 하나는 친절하게 대하는 거예요.",["window","pencil","season"],["rool","rulle","ruel"]),
 W("allowed","adj","허용된, 허락된","You are not allowed to run here.","여기서는 뛰면 안 돼요.",["sunny","round","yellow"],["alowed","allowd","allowedd"]),
];
const out = { packet: "E17-e6", sections: [sec("e.e6.tense", tenseS, tenseM, tenseR, tenseW), sec("e.e6.modal", modalS, modalM, modalR, modalW)] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E17-e6.json", JSON.stringify(out, null, 1) + "\n");
console.log(tenseS.length, tenseM.length, tenseR.length, modalS.length, modalM.length, modalR.length);
