const S = ["9영01-03", "9영02-07"], D = ["9영01-02"], I = ["9영01-04"], P = ["9영01-06"], V = ["9영01-07"], E = ["9영01-05"];
export default [
["Life in the Desert",
"A desert looks empty, but many animals have found clever ways to live there. The fennec fox has huge ears that give off heat, so its body stays cool. Camels can drink a great deal of water at once and then travel for days without drinking. Many small animals sleep in cool holes during the hot day and come out only at night to look for food. These habits do not make life easy, but they help the animals survive where water is rare.",
[
["Which sentence is the best summary of the passage?", "Desert animals have special habits and body parts that help them survive with little water.", ["Fennec foxes have big ears, and camels can walk for days without any water.", "Deserts are the hottest places on Earth, and no plants can grow there.", "Small animals leave their holes only at night because they are afraid of camels."], "중심 내용은 사막 동물들이 물이 적은 곳에서 살아남는 방법이에요.", S],
["Why do fennec foxes have large ears?", "To let body heat escape", ["To hear sounds from far away", "To dig holes in hot sand", "To store water for later"], "큰 귀가 열을 내보내 몸을 시원하게 해 줘요.", D],
["When do many small desert animals look for food?", "At night", ["At noon", "In the early afternoon", "Just after the rain"], "더운 낮에는 구멍에서 자고 밤에 나와요.", D],
["The word \"rare\" is closest in meaning to", "hard to find", ["easy to carry", "good to drink", "far from home"], "rare는 '드문'이라는 뜻이에요.", V]
]],
["Staying Safe Online",
"The internet is a wonderful place to learn and play, but it also has risks. First, never share your password with anyone except your parents. Second, think before you post a photo, because once it is online, it can be copied by others. Third, if a stranger sends you a message that makes you feel uncomfortable, do not answer; tell an adult at once. Finally, remember that not everything you read online is true. Checking more than one website can help you find the facts.",
[
["Which is the best summary of the passage?", "Internet users should follow a few simple rules to protect themselves and find true information.", ["Passwords are the most important thing to protect, and parents can always see them.", "Photos should never be posted online because other people always copy them.", "The internet is a dangerous place where children must stay away from strangers."], "여러 가지 안전 수칙을 모아 온라인에서 자신을 보호하라는 것이 중심이에요.", S],
["According to the passage, who may know your password?", "Your parents", ["Your best friends", "Your teachers", "Anyone who asks nicely"], "비밀번호는 부모님 외에는 공유하지 말라고 해요.", D],
["What should you do if a stranger's message makes you uncomfortable?", "Tell an adult right away.", ["Reply and ask who the person is.", "Block your parents' account.", "Delete your photos online."], "대답하지 말고 즉시 어른에게 알리라고 해요.", D],
["Why does the writer suggest checking more than one website?", "Some information online may not be true.", ["Many websites are too slow.", "Parents like to read many pages.", "Different sites have different passwords."], "온라인의 모든 내용이 사실은 아니기 때문이에요.", I]
]],
["The Lost Dog",
"On Tuesday afternoon, Min-ho saw a small brown dog sitting alone near the bus stop. It had no collar, and it was shaking in the cold. Min-ho gave it half of his sandwich and called his mother. Together they took the dog to the animal clinic, where a doctor checked it and found a tiny tag under its fur. The tag had a phone number. That evening, a girl came to the clinic with tears in her eyes and hugged her dog tightly. Min-ho smiled all the way home.",
[
["What is the best summary of the story?", "Min-ho helped a lost dog get back to its owner.", ["Min-ho found a sandwich while he was waiting at a bus stop.", "A doctor at an animal clinic took care of many dogs in the cold.", "A girl was crying because she could not find the way home."], "민호가 길 잃은 개를 주인에게 돌려보내 준 이야기예요.", S],
["How did the clinic find the owner?", "A phone number was on a tag.", ["The dog barked at the girl.", "Min-ho looked at the collar.", "A neighbor knew the dog."], "수의사가 털 속에서 전화번호가 적힌 작은 태그를 발견했어요.", D],
["How did the girl feel when she saw her dog?", "Relieved and happy", ["Surprised and angry", "Bored and sleepy", "Shy and nervous"], "눈물을 글썽이며 강아지를 꼭 안았으니 안도하고 기뻤어요.", E],
["Why did Min-ho smile all the way home?", "He felt good about helping.", ["He was going to keep the dog.", "He had won a school prize.", "He was glad to be warm again."], "도움을 줬다는 뿌듯함 때문이라고 추론할 수 있어요.", I]
]],
["Spring Festival Announcement",
"Our school will hold its Spring Festival on the first Friday of May. Classes will end after lunch, and the festival will begin at one o'clock on the main playground. Each class will run a booth, such as a food stand, a game corner, or a small art show. The music club will play on the stage at three. Parents and neighbors are welcome, and the money from the booths will be used to buy new books for the library. Please send your ideas for booths to your homeroom teacher by next Wednesday.",
[
["Which sentence summarizes the announcement best?", "The school will hold a spring festival to raise money for books.", ["The music club will perform on the school stage at three o'clock.", "Every class must run a food stand on the first Friday of May.", "Parents and neighbors must pay to enter the school playground."], "봄 축제 안내이고 수익금이 도서관 책 구입에 쓰인다는 점이 핵심이에요.", S],
["What will the money from the booths be used for?", "Buying new books", ["Paying the music club", "Fixing the playground", "Making school posters"], "부스 수익금은 도서관의 새 책을 사는 데 쓰여요.", D],
["What should students do by next Wednesday?", "Give booth ideas to their homeroom teacher", ["Bring food for the festival", "Practice with the music club", "Invite their neighbors"], "다음 주 수요일까지 담임 선생님께 부스 아이디어를 보내야 해요.", D],
["What is the purpose of the announcement?", "To give information and ask for ideas", ["To change the school rules", "To close the school early", "To praise the music club"], "축제 정보를 알리고 아이디어를 요청해요.", P]
]],
["Why Drink Water?",
"Your body is about sixty percent water. Water carries food energy to your cells, keeps your temperature steady, and helps your body get rid of waste. When you do not drink enough, you may feel tired or get a headache. Many people wait until they feel thirsty, but thirst is a late signal. A better habit is to take small sips throughout the day. If plain water seems boring, you can add a slice of lemon or cucumber for flavor.",
[
["What is the passage mainly about?", "Why and how to drink water regularly", ["How to make lemon and cucumber drinks", "Why tired people should sleep more", "Which sports drinks give the most energy"], "물이 몸에 하는 일과 규칙적으로 마시는 방법이 중심이에요.", S],
["Which sentence should be left out of a short summary?", "You can add a slice of lemon or cucumber for flavor.", ["Water does important jobs inside the body.", "Not drinking enough water can make you tired.", "It is better to sip water through the whole day."], "레몬이나 오이를 넣는 것은 부수적인 세부 정보예요.", S],
["According to the passage, what is thirst?", "A late signal from the body", ["A sure sign of good health", "A habit that can be learned", "A way to cool the cells"], "목마름은 늦게 오는 신호라고 해요.", D],
["What can happen when you drink too little water?", "You may feel tired or get a headache.", ["Your body will grow warmer.", "Your food will taste better.", "You will sleep for many hours."], "수분이 부족하면 피곤하거나 두통이 생길 수 있어요.", D]
]],
["A Day at the Animal Shelter",
"Last Saturday, I volunteered at an animal shelter for the first time. My job was to clean the cages, fill the water bowls, and walk the dogs. At first I felt nervous because some dogs were big and loud. A worker named Ms. Han showed me how to speak softly and give each dog time to sniff my hand. By the afternoon, a shy gray puppy was following me everywhere. When I said goodbye, I promised to return. Helping animals was tiring, but it made me feel useful.",
[
["Which is the best summary of the passage?", "A first-time volunteer felt nervous but enjoyed helping animals at a shelter.", ["A shy gray puppy followed a worker named Ms. Han all afternoon.", "Animal shelters need volunteers because big dogs are loud and scary.", "The writer decided never to go back because the work was too tiring."], "처음 봉사한 사람이 긴장했지만 보람을 느꼈다는 것이 중심이에요.", S],
["How did the writer feel at first?", "Nervous", ["Bored", "Proud", "Angry"], "처음에는 큰 개들 때문에 긴장했어요.", E],
["What did Ms. Han teach the writer?", "To speak softly to the dogs", ["To train puppies to sit", "To wash big dogs quickly", "To open the cages safely"], "부드럽게 말하고 개가 손 냄새를 맡게 하는 법을 알려 줬어요.", D],
["What does the ending suggest about the writer?", "The writer wants to volunteer again.", ["The writer wants to adopt every dog.", "The writer dislikes the shelter workers.", "The writer plans to stop helping animals."], "다시 오겠다고 약속했으니 또 봉사하고 싶어 해요.", I]
]],
["The Slow Train",
"My father likes trains more than planes. He says a train ride is a trip in itself, not just a way to arrive. Last winter we took a slow train across the mountains to visit my uncle. Through the window we saw frozen lakes, small villages, and farmers walking with their cows. We played cards, ate rice balls, and talked more than we do at home. The trip took eight hours, which is much longer than a plane, but I did not feel bored for one minute.",
[
["What is the passage mainly about?", "Enjoying the journey on a long train trip", ["The reasons why planes are dangerous", "How to visit an uncle in the mountains", "What farmers do in the winter"], "기차 여행 자체를 즐긴다는 것이 중심이에요.", S],
["Which sentence is too broad to be a good summary?", "Traveling is a good way to spend time with family.", ["A slow train ride was a fun trip for the writer's family.", "The writer enjoyed seeing the views and talking during a train trip.", "A long trip by train felt interesting rather than boring."], "여행 일반에 관한 문장은 이 글만의 내용을 담지 못해 너무 넓어요.", S],
["How long did the trip take?", "Eight hours", ["Eighteen hours", "Two days", "Three hours"], "여행은 8시간 걸렸다고 해요.", D],
["What does the father mean by \"a trip in itself\"?", "The ride is an enjoyable part of the journey.", ["The train is cheaper than other ways.", "Trains always arrive on time.", "Only long trips are worth taking."], "도착뿐 아니라 이동 자체가 여행의 일부라는 뜻이에요.", V]
]],
["Giving Bottles a Second Life",
"Every year, people throw away millions of plastic bottles. Instead of tossing them in the trash, you can find new uses for them. A bottle with the top cut off can become a pen holder or a small pot for seeds. Two bottles taped together make a bird feeder if you cut a few holes for the seeds. Some schools even use hundreds of bottles to build a greenhouse wall. These ideas save money, cut down on trash, and show that old things can still be useful.",
[
["Which sentence is the best summary of the passage?", "Used plastic bottles can be turned into useful things, which reduces trash.", ["A pen holder is the simplest thing that can be made from a plastic bottle.", "Schools build greenhouses because they cannot buy glass for the walls.", "People throw away too many bottles, and the government should stop them."], "버려지는 병을 다시 쓰는 아이디어로 쓰레기를 줄인다는 것이 중심이에요.", S],
["What can two bottles taped together become?", "A bird feeder", ["A pen holder", "A greenhouse", "A seed pot"], "병 두 개를 붙이고 구멍을 내면 새 모이통이 돼요.", D],
["What is the writer's purpose?", "To suggest ways to reuse bottles", ["To ask schools for money", "To sell plastic products", "To explain how bottles are made"], "병을 재사용하는 방법을 제안하는 글이에요.", P],
["Which is NOT mentioned as a benefit?", "It makes the bottles taste better.", ["It saves money.", "It reduces the amount of trash.", "It shows old things can be useful."], "맛에 관한 이야기는 없어요. 나머지 세 가지는 마지막 문장에 나와요.", D]
]],
["The Moving Sea",
"If you spend a day at the beach, you will notice that the water goes up and down twice a day. These changes are called tides. They are caused mainly by the pull of the moon, which tugs gently on the ocean. When the water is high, waves reach far up the sand; when it is low, the beach becomes wide and you can find shells and small crabs. Fishers and sailors check a tide table before they go out, because the depth of the water affects their boats.",
[
["What is the best summary of the passage?", "Tides are daily rises and falls of sea water caused mostly by the moon.", ["Fishers use tide tables to find small crabs and shells on the sand.", "The moon is a large ball of rock that pulls on every beach in the world.", "Waves always reach far up the sand when people want to swim."], "조수의 개념과 원인이 중심 내용이에요.", S],
["According to the passage, what mainly causes tides?", "The pull of the moon", ["The strength of the wind", "The heat of the sun", "The shape of the beach"], "달의 인력이 주된 원인이에요.", D],
["Why do sailors check a tide table?", "The water depth affects their boats.", ["They want to find shells and crabs.", "They need to know the weather.", "They want to avoid the moon."], "물의 깊이가 배에 영향을 주기 때문이에요.", I],
["When can you find shells and small crabs?", "When the tide is low", ["When the tide is high", "When the waves are very big", "When the moon is bright"], "물이 빠지면 해변이 넓어져 조개와 작은 게를 찾을 수 있어요.", D]
]],
["My First Guitar Lessons",
"Learning the guitar is harder than I expected. In my first week, my fingers hurt from pressing the strings, and every chord sounded like a cat in trouble. I almost quit. Then my teacher told me to practice for just ten minutes a day instead of one long hour once a week. I tried it, and after a month I could play three chords. Last night I played a simple song for my family, and my mother clapped so loudly that the neighbors may have heard her.",
[
["Which sentence summarizes the passage best?", "The writer improved at the guitar by practicing a little every day.", ["The writer's mother loves loud music and often claps for her neighbors.", "The writer stopped the lessons because the strings hurt his fingers.", "Guitar is the most difficult instrument that any student can learn."], "매일 조금씩 연습해 실력이 늘었다는 것이 핵심이에요.", S],
["What did the teacher advise?", "Practice ten minutes every day.", ["Practice one hour on the weekend.", "Change to an easier instrument.", "Play only for the family."], "하루 10분씩 연습하라고 조언했어요.", D],
["What does \"like a cat in trouble\" suggest about the sound?", "It sounded bad.", ["It sounded sleepy.", "It sounded very quiet.", "It sounded beautiful."], "고양이가 곤경에 빠졌을 때의 소리 같다는 건 듣기 안 좋았다는 뜻이에요.", V],
["How does the writer feel at the end?", "Proud and happy", ["Tired and bored", "Angry and worried", "Shy and sad"], "가족 앞에서 연주하고 박수를 받아 뿌듯하고 기뻐요.", E]
]],
["Gardens in the Sky",
"In crowded cities, there is little room for parks, so some people are turning rooftops into gardens. On top of tall buildings, they grow vegetables, herbs, and flowers in boxes of soil. These green roofs have many benefits. Plants keep the building cooler in summer, so less air conditioning is needed. Rain soaks into the soil instead of rushing into the streets. Rooftop gardens also give workers a quiet place to rest. Some even have beehives, which provide honey for the neighborhood.",
[
["What is the passage mainly about?", "How rooftop gardens help cities and people", ["Why tall buildings are good for bees", "Which vegetables grow best in boxes", "How workers can relax at lunchtime"], "옥상 정원의 여러 이점이 중심 내용이에요.", S],
["Which is the best summary?", "Rooftop gardens use unused space and bring cooling, water control, and rest.", ["Rooftop gardens are a place where bees make honey for the whole city.", "Cities should build parks on the ground and not on top of buildings.", "Workers use boxes of soil to grow herbs for their lunch."], "여러 이점을 아우르는 문장이 좋은 요약이에요.", S],
["How do green roofs help in summer?", "They keep buildings cooler.", ["They make rain heavier.", "They catch more sunlight.", "They stop all the noise."], "식물이 건물을 시원하게 해 에어컨 사용이 줄어요.", D],
["What happens to rain on a green roof?", "It soaks into the soil.", ["It flows to the bees.", "It stays in the boxes forever.", "It rushes into the streets."], "빗물이 흙에 스며들어 거리로 쏟아지지 않아요.", D]
]],
["Better Homework Habits",
"Many students feel stressed by homework, but a few habits can make it easier. First, choose a quiet place and put away anything that might distract you. Second, make a list of tasks and begin with the hardest one while your mind is fresh. Third, take a short break every forty minutes to stretch or drink water. Finally, check your work before you pack your bag. Students who follow these steps often finish earlier and have more free time in the evening.",
[
["Which sentence is the best summary of the passage?", "Simple study habits can help students finish homework with less stress.", ["Students should always begin with the hardest task and then go to bed.", "Teachers give too much homework, so students feel stressed all evening.", "A quiet room is the only thing a student needs for good homework."], "간단한 공부 습관이 숙제 스트레스를 줄여 준다는 것이 중심이에요.", S],
["According to the passage, when should students start the hardest task?", "At the beginning, while the mind is fresh", ["Near the end of the evening", "After a long break", "Right before checking the work"], "머리가 맑을 때 가장 어려운 것부터 시작하라고 해요.", D],
["How often does the writer suggest taking a short break?", "Every forty minutes", ["Every ten minutes", "Once a day", "After each task"], "40분마다 짧게 쉬라고 해요.", D],
["What is the likely result of these habits?", "Students finish earlier and have more free time.", ["Students need less sleep.", "Teachers give them more homework.", "Students forget the hard parts."], "일찍 끝내고 저녁 시간이 늘어난다고 해요.", I]
]]
];
