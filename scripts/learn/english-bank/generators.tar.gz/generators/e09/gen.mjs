import fs from "node:fs";
// Q(stem, key, [w1,w2,w3], pos, why)
const Q = (q, key, w, pos, why) => { const o = [...w]; o.splice(pos, 0, key); return { q, o, a: pos, why }; };
const R = (title, text, ko, qs, k = "r") => ({ k, title, text, ko, std: ["4영01-05", "4영01-06"], qs });
const M = (q, key, w, pos, why, extra = {}) => { const o = [...w]; o.splice(pos, 0, key); return { k: "m", q, o, a: pos, why, ...extra }; };
const S = (good, ko, bad, st, ok, wr, rule, extra = {}) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...extra });

const read = [];
read.push(R("Jin's Morning", "Jin gets up at seven. He washes his face and eats breakfast with his mom. Then he walks to school with his friend Sora. School starts at nine.",
 "진은 일곱 시에 일어나요. 세수를 하고 엄마와 아침을 먹어요. 그다음 친구 소라와 학교에 걸어가요. 수업은 아홉 시에 시작해요.", [
 Q("When does Jin get up?", "At seven.", ["At six.", "At eight.", "At nine."], 2, "첫 문장에 Jin gets up at seven.이라고 나와요."),
 Q("Who eats breakfast with Jin?", "His mom", ["His dad", "Sora", "His teacher"], 0, "He ... eats breakfast with his mom.이라고 했어요."),
 Q("What time does school start?", "At nine.", ["At seven.", "At eight.", "At ten."], 3, "마지막 문장 School starts at nine.에서 알 수 있어요."),
 Q("Who is Sora?", "Jin's friend", ["Jin's sister", "Jin's teacher", "Jin's neighbor"], 1, "his friend Sora라고 했으므로 Sora는 진의 친구예요.")]));
read.push(R("My Cat Momo", "I have a cat. Her name is Momo. She is white and small. Momo likes milk and fish. Every afternoon she sleeps on my bed. I love Momo very much.",
 "나는 고양이가 있어요. 이름은 모모예요. 모모는 하얗고 작아요. 우유와 생선을 좋아해요. 매일 오후에 내 침대에서 자요. 나는 모모를 아주 많이 사랑해요.", [
 Q("What color is Momo?", "White", ["Black", "Brown", "Gray"], 1, "She is white and small.이라고 했어요."),
 Q("What does Momo like?", "Milk and fish", ["Rice and eggs", "Bread and jam", "Apples and cake"], 3, "Momo likes milk and fish.가 정답의 근거예요."),
 Q("Where does Momo sleep in the afternoon?", "On the bed", ["On the sofa", "In a box", "Under the table"], 0, "Every afternoon she sleeps on my bed."),
 Q("In the passage, which word means 'little'?", "small", ["white", "every", "very"], 2, "small은 '작은'이라는 뜻으로 little과 비슷해요.")]));
read.push(R("At the Park", "It is sunny today. Dad, Mina and I go to the park. Mina rides her bike. Dad and I play badminton. After that, we eat sandwiches under a big tree. It is a happy day.",
 "오늘은 맑아요. 아빠, 미나, 나는 공원에 가요. 미나는 자전거를 타요. 아빠와 나는 배드민턴을 쳐요. 그 후에 큰 나무 아래에서 샌드위치를 먹어요. 행복한 하루예요.", [
 Q("What is the weather like?", "Sunny", ["Rainy", "Cloudy", "Snowy"], 2, "첫 문장 It is sunny today.에서 알 수 있어요."),
 Q("Who rides a bike?", "Mina", ["Dad", "The writer", "A friend"], 1, "Mina rides her bike."),
 Q("Where do they eat sandwiches?", "Under a big tree", ["On a bench", "In the car", "At home"], 0, "we eat sandwiches under a big tree."),
 Q("What is the passage mainly about?", "A fun day at the park", ["A rainy day at home", "A new bike", "A birthday party"], 3, "가족이 공원에서 즐겁게 보낸 하루에 대한 글이에요.")]));
read.push(R("Fruit Shop", "Mr. Kim has a fruit shop. He sells apples, grapes and melons. One apple is one thousand won. Today Sue buys two apples and one melon. They are for her grandma.",
 "김 씨는 과일 가게를 해요. 사과, 포도, 멜론을 팔아요. 사과 한 개는 천 원이에요. 오늘 수는 사과 두 개와 멜론 한 개를 사요. 그것들은 할머니께 드릴 거예요.", [
 Q("What does Mr. Kim do?", "He sells fruit.", ["He teaches music.", "He drives a bus.", "He cooks dinner."], 1, "Mr. Kim has a fruit shop. He sells ...라고 했어요."),
 Q("How much is one apple?", "One thousand won", ["Two thousand won", "Three thousand won", "Five hundred won"], 3, "One apple is one thousand won."),
 Q("What does Sue buy?", "Two apples and a melon", ["One apple and grapes", "Two melons", "Grapes and a melon"], 0, "Sue buys two apples and one melon."),
 Q("In the passage, who are 'they' for?", "Sue's grandma", ["Mr. Kim", "Sue's friend", "Sue's mom"], 2, "They are for her grandma.에서 her는 Sue를 가리켜요.")]));
read.push(R("My Body", "I have two eyes, two ears and one nose. I see with my eyes. I hear with my ears. I smell flowers with my nose. I use my mouth to eat and talk.",
 "나는 눈이 두 개, 귀가 두 개, 코가 한 개 있어요. 눈으로 봐요. 귀로 들어요. 코로 꽃 냄새를 맡아요. 입으로 먹고 말해요.", [
 Q("What do we do with our ears?", "We hear.", ["We see.", "We smell.", "We talk."], 2, "I hear with my ears."),
 Q("How many noses does the writer have?", "One", ["Two", "Three", "Four"], 0, "one nose라고 했어요."),
 Q("What does the writer do with the mouth?", "Eat and talk", ["Run and jump", "See and hear", "Smell and touch"], 1, "I use my mouth to eat and talk."),
 Q("What is the passage mainly about?", "Parts of the face", ["Favorite foods", "A trip to a park", "Colors of flowers"], 3, "눈, 귀, 코, 입 같은 얼굴 부분과 하는 일을 설명해요.")]));
read.push(R("A Rainy Day", "It rains today, so Ben cannot play soccer outside. He stays home. He draws a robot and reads a funny book. Then his sister plays a board game with him. Ben has fun at home.",
 "오늘은 비가 와서 벤은 밖에서 축구를 할 수 없어요. 그는 집에 있어요. 로봇을 그리고 재미있는 책을 읽어요. 그다음 누나가 보드게임을 같이 해요. 벤은 집에서 즐거워요.", [
 Q("Why can't Ben play soccer?", "It is raining.", ["He is tired.", "He has no ball.", "He is at school."], 1, "It rains today, so Ben cannot play soccer outside."),
 Q("What does Ben draw?", "A robot", ["A house", "A flower", "A ball"], 3, "He draws a robot."),
 Q("Who plays a board game with Ben?", "His sister", ["His friend", "His dad", "His teacher"], 0, "his sister plays a board game with him."),
 Q("How does Ben probably feel at the end?", "Happy", ["Angry", "Afraid", "Bored"], 2, "Ben has fun at home.이므로 즐거운 기분이에요.")]));
read.push(R("School Lunch", "At noon, we eat lunch in the lunch room. Today we have rice, soup, kimchi and a banana. My friend Hana does not like soup, so she eats more rice. After lunch, we play on the playground.",
 "정오에 우리는 급식실에서 점심을 먹어요. 오늘은 밥, 국, 김치, 바나나가 나와요. 친구 하나는 국을 좋아하지 않아서 밥을 더 먹어요. 점심 후에는 운동장에서 놀아요.", [
 Q("Where do they eat lunch?", "In the lunch room", ["In the library", "On the playground", "At home"], 2, "we eat lunch in the lunch room."),
 Q("Which fruit do they have today?", "A banana", ["An apple", "A grape", "A melon"], 0, "rice, soup, kimchi and a banana 중 과일은 banana예요."),
 Q("Why does Hana eat more rice?", "She doesn't like soup.", ["She is very hungry.", "She likes kimchi.", "She has no spoon."], 3, "Hana does not like soup, so she eats more rice."),
 Q("What do they do after lunch?", "They play outside.", ["They sleep.", "They go home.", "They study math."], 1, "After lunch, we play on the playground.")]));
read.push(R("Grandpa's Garden", "My grandpa has a small garden behind his house. He grows tomatoes, carrots and flowers. In summer, I visit him and water the plants. The red tomatoes are sweet. Grandpa says, \"Good job!\"",
 "할아버지는 집 뒤에 작은 텃밭이 있어요. 토마토, 당근, 꽃을 길러요. 여름에 나는 할아버지를 찾아가 식물에 물을 줘요. 빨간 토마토는 달아요. 할아버지는 \"잘했다!\"라고 말해요.", [
 Q("Where is the garden?", "Behind his house", ["In front of his house", "Near a school", "On a mountain"], 1, "a small garden behind his house."),
 Q("When does the writer visit?", "In summer", ["In winter", "In spring", "In fall"], 3, "In summer, I visit him ..."),
 Q("What does the writer do in the garden?", "Waters the plants", ["Picks flowers for sale", "Plants carrots", "Cooks tomatoes"], 0, "I ... water the plants."),
 Q("In the second sentence, who does 'He' mean?", "Grandpa", ["The writer", "A neighbor", "A teacher"], 2, "앞 문장의 my grandpa를 가리켜요.")]));
read.push(R("The Library", "Our school library is on the second floor. It opens at eight and closes at four. We can borrow three books for one week. Please be quiet in the library. Do not eat or drink there.",
 "우리 학교 도서관은 2층에 있어요. 여덟 시에 열고 네 시에 닫아요. 책은 일주일 동안 세 권 빌릴 수 있어요. 도서관에서는 조용히 해 주세요. 거기에서 먹거나 마시지 마세요.", [
 Q("Where is the library?", "On the second floor", ["On the first floor", "Next to the gym", "Outside the school"], 3, "on the second floor라고 했어요."),
 Q("How many books can students borrow?", "Three", ["One", "Two", "Five"], 0, "We can borrow three books for one week."),
 Q("Which is a library rule?", "Do not eat or drink.", ["Talk loudly.", "Run fast.", "Sleep on the desk."], 1, "Do not eat or drink there."),
 Q("Why was this text written?", "To tell the library rules", ["To sell some books", "To ask for help", "To tell a funny story"], 2, "도서관 이용 시간과 규칙을 알려 주는 글이에요.")]));
read.push(R("Eun's Birthday", "Today is Eun's birthday. She is nine years old. Her friends come to her house at three. They sing a birthday song and eat chocolate cake. Tom gives her a new notebook. Eun says, \"Thank you!\"",
 "오늘은 은의 생일이에요. 은은 아홉 살이에요. 친구들이 세 시에 집에 와요. 생일 노래를 부르고 초콜릿 케이크를 먹어요. 톰이 새 공책을 선물해요. 은은 \"고마워!\"라고 말해요.", [
 Q("How old is Eun?", "Nine", ["Seven", "Eight", "Ten"], 1, "She is nine years old."),
 Q("When do her friends come?", "At three", ["At two", "At four", "At five"], 2, "Her friends come to her house at three."),
 Q("What does Tom give Eun?", "A notebook", ["A cake", "A bag", "A song"], 0, "Tom gives her a new notebook."),
 Q("How does Eun probably feel?", "Happy and thankful", ["Sad and tired", "Angry and loud", "Shy and sick"], 3, "생일을 즐기고 선물에 고맙다고 했으므로 기쁘고 고마운 마음이에요.")]));
read.push(R("My Favorite Season", "My favorite season is fall. The weather is cool, and the leaves turn red and yellow. My family goes to the mountain in October. We walk, take pictures and eat gimbap. I like fall because it is so pretty.",
 "내가 가장 좋아하는 계절은 가을이에요. 날씨가 시원하고 나뭇잎이 빨갛고 노랗게 변해요. 우리 가족은 10월에 산에 가요. 걷고, 사진을 찍고, 김밥을 먹어요. 가을은 아주 예뻐서 좋아요.", [
 Q("What is the writer's favorite season?", "Fall", ["Spring", "Summer", "Winter"], 2, "My favorite season is fall."),
 Q("What color are the leaves?", "Red and yellow", ["Blue and white", "Pink and green", "Black and brown"], 0, "the leaves turn red and yellow."),
 Q("Why does the writer like fall?", "It is pretty.", ["It is very hot.", "It has no school.", "It has snow."], 3, "I like fall because it is so pretty."),
 Q("When does the family go to the mountain?", "In October", ["In May", "In July", "In January"], 1, "My family goes to the mountain in October.")]));
read.push(R("A Trip to the Zoo", "Tom visits the zoo on Saturday. He sees a tall giraffe and a big elephant. The monkeys are funny. They jump and eat bananas. Tom takes many pictures. He wants to come again next week.",
 "톰은 토요일에 동물원에 가요. 키 큰 기린과 큰 코끼리를 봐요. 원숭이들은 재미있어요. 뛰어다니고 바나나를 먹어요. 톰은 사진을 많이 찍어요. 그는 다음 주에 또 오고 싶어요.", [
 Q("When does Tom visit the zoo?", "On Saturday", ["On Monday", "On Friday", "On Sunday"], 3, "Tom visits the zoo on Saturday."),
 Q("Which animal is tall?", "The giraffe", ["The elephant", "The monkey", "The rabbit"], 0, "a tall giraffe라고 했어요."),
 Q("What do the monkeys do?", "Jump and eat bananas", ["Sleep and swim", "Sing and dance", "Run and drink milk"], 1, "They jump and eat bananas."),
 Q("What can we guess about Tom?", "He had a good time.", ["He was lost.", "He did not like animals.", "He was afraid of monkeys."], 2, "또 오고 싶어 하므로 즐거운 시간을 보냈다고 짐작할 수 있어요.")]));
read.push(R("A Note from Mom", "Dear Jun, I am at the market. I will be home at five. Your snack is on the table. Please do your homework first. Then you can play games for thirty minutes. Love, Mom",
 "준에게. 엄마는 시장에 있어. 다섯 시에 집에 올 거야. 간식은 식탁 위에 있어. 먼저 숙제를 해 주렴. 그다음에 삼십 분 동안 게임을 해도 돼. 사랑해, 엄마가", [
 Q("Where is Mom now?", "At the market", ["At school", "At home", "At the park"], 1, "I am at the market."),
 Q("What should Jun do first?", "Do his homework", ["Play games", "Eat dinner", "Go shopping"], 0, "Please do your homework first."),
 Q("How long can Jun play games?", "For thirty minutes", ["For ten minutes", "For one hour", "All day"], 2, "you can play games for thirty minutes."),
 Q("Why did Mom write this note?", "To tell Jun what to do", ["To say sorry for being late", "To invite Jun to a party", "To ask Jun a question"], 3, "집에 없는 엄마가 준이 할 일을 알려 주려고 쓴 쪽지예요.")]));
read.push(R("Sports Day", "Our school Sports Day is on Friday. We run, jump rope and pull a big rope. Class 3 wins the rope game. My team is red, and we lose. But we smile and shake hands. I enjoy the day very much.",
 "우리 학교 운동회는 금요일이에요. 달리기, 줄넘기, 줄다리기를 해요. 3반이 줄다리기에서 이겨요. 우리 팀은 빨간 팀이고 져요. 하지만 우리는 웃으며 악수해요. 나는 그날이 아주 즐거워요.", [
 Q("When is Sports Day?", "On Friday", ["On Monday", "On Thursday", "On Saturday"], 0, "Our school Sports Day is on Friday."),
 Q("Which class wins the rope game?", "Class 3", ["Class 1", "Class 2", "Class 4"], 2, "Class 3 wins the rope game."),
 Q("What does 'lose' mean here?", "Not win", ["Find", "Run fast", "Give a gift"], 1, "we lose는 '지다', 즉 이기지 못했다는 뜻이에요."),
 Q("How does the writer feel about the day?", "Happy", ["Sad", "Angry", "Afraid"], 3, "I enjoy the day very much.라고 했으므로 즐거워해요.")]));
read.push(R("Making a Sandwich", "First, put two pieces of bread on a plate. Next, put cheese and a tomato on one piece. Then put the other piece on top. Last, cut the sandwich in half. Now you can eat it!",
 "먼저 접시에 빵 두 장을 놓으세요. 다음으로 한 장 위에 치즈와 토마토를 올리세요. 그다음 나머지 한 장을 위에 올리세요. 마지막으로 샌드위치를 반으로 자르세요. 이제 먹을 수 있어요!", [
 Q("What do you do first?", "Put bread on a plate", ["Cut the sandwich", "Eat the cheese", "Wash the tomato"], 2, "First, put two pieces of bread on a plate."),
 Q("What goes on one piece of bread?", "Cheese and a tomato", ["Jam and butter", "Eggs and ham", "Milk and sugar"], 0, "put cheese and a tomato on one piece."),
 Q("What do you do last?", "Cut it in half", ["Put cheese on it", "Put bread on top", "Buy bread"], 1, "Last, cut the sandwich in half."),
 Q("What is the text mainly about?", "How to make a sandwich", ["Why bread is good", "A shop that sells cheese", "A picnic in the park"], 3, "샌드위치를 만드는 순서를 설명하는 글이에요.")]));
read.push(R("My New Tablet", "Dad gives me a tablet for my birthday. I use it to read e-books and draw pictures. I also talk to my cousin in Canada on video calls. Dad says I can use it for only one hour a day. I follow the rule.",
 "아빠가 생일 선물로 태블릿을 주셨어요. 나는 전자책을 읽고 그림을 그려요. 캐나다에 있는 사촌과 화상 통화도 해요. 아빠는 하루에 한 시간만 써도 된다고 하세요. 나는 그 규칙을 지켜요.", [
 Q("Who gives the writer a tablet?", "Dad", ["Mom", "A cousin", "A teacher"], 1, "Dad gives me a tablet for my birthday."),
 Q("Who does the writer talk to on video calls?", "A cousin in Canada", ["A friend at school", "A teacher", "Grandma in Korea"], 3, "my cousin in Canada라고 했어요."),
 Q("How long can the writer use the tablet?", "One hour a day", ["All day", "Two hours a day", "One hour a week"], 0, "for only one hour a day."),
 Q("What does 'follow the rule' mean?", "Do what the rule says", ["Break the rule", "Forget the rule", "Write a new rule"], 2, "follow the rule은 규칙을 지킨다는 뜻이에요.")]));
read.push(R("Healthy Habits", "To stay healthy, Jina eats vegetables every day. She drinks water, not soda. She goes to bed at nine. On weekends, she rides her bike with her family. Jina feels strong and happy.",
 "건강을 지키려고 지나는 매일 채소를 먹어요. 탄산음료 대신 물을 마셔요. 아홉 시에 자러 가요. 주말에는 가족과 자전거를 타요. 지나는 튼튼하고 행복해요.", [
 Q("What does Jina drink?", "Water", ["Soda", "Juice", "Milk"], 2, "She drinks water, not soda."),
 Q("When does Jina go to bed?", "At nine", ["At eight", "At ten", "At eleven"], 0, "She goes to bed at nine."),
 Q("What does Jina do on weekends?", "She rides a bike.", ["She plays computer games.", "She goes shopping.", "She visits a doctor."], 1, "On weekends, she rides her bike with her family."),
 Q("What is the passage mainly about?", "Jina's healthy habits", ["Jina's school day", "Jina's new bike", "Jina's favorite food"], 3, "지나가 건강을 위해 하는 좋은 습관들을 소개해요.")]));
if (read.length !== 17) throw new Error("read " + read.length);

const dial = [];
dial.push(R("At the Shop", "Clerk: Hello! Can I help you?\nTom: Yes, please. I want two cookies.\nClerk: Sure. Anything else?\nTom: One bottle of milk, please.\nClerk: That is four dollars.\nTom: Here you are.\nClerk: Thank you. Have a nice day!\nTom: You too. Bye!",
 "점원: 안녕하세요! 도와드릴까요?\n톰: 네. 쿠키 두 개 주세요.\n점원: 그럼요. 더 필요한 건요?\n톰: 우유 한 병 주세요.\n점원: 4달러예요.\n톰: 여기 있어요.\n점원: 감사합니다. 좋은 하루 보내세요!\n톰: 그쪽도요. 안녕히 계세요!", [
 Q("What does Tom buy?", "Two cookies and milk", ["Two cakes and juice", "One cookie and bread", "Milk and an apple"], 2, "I want two cookies. / One bottle of milk."),
 Q("How much is it?", "Four dollars", ["Two dollars", "Three dollars", "Five dollars"], 0, "That is four dollars."),
 Q("Where are they?", "In a store", ["In a school", "In a hospital", "In a library"], 1, "점원과 손님이 물건을 사고파는 대화이므로 가게예요."),
 Q("What does 'Here you are' mean?", "Tom gives the money.", ["Tom asks where the clerk is.", "Tom says goodbye.", "Tom says he is hungry."], 3, "Here you are.는 무언가를 건네주며 하는 말이에요.")], "d"));
dial.push(R("Asking the Way", "Mina: Excuse me. Where is the post office?\nMan: Go straight for two blocks.\nMina: Two blocks. Then?\nMan: Turn left at the bank.\nMina: Is it far?\nMan: No. It is next to the bookstore.\nMina: Thank you very much.\nMan: You are welcome.",
 "미나: 실례합니다. 우체국이 어디예요?\n남자: 두 블록 곧장 가세요.\n미나: 두 블록이요. 그다음은요?\n남자: 은행에서 왼쪽으로 도세요.\n미나: 먼가요?\n남자: 아니요. 서점 옆에 있어요.\n미나: 정말 고맙습니다.\n남자: 천만에요.", [
 Q("What is Mina looking for?", "The post office", ["The bank", "The bookstore", "The school"], 1, "Where is the post office?"),
 Q("How far should she go straight?", "Two blocks", ["One block", "Three blocks", "Ten blocks"], 3, "Go straight for two blocks."),
 Q("Where should she turn left?", "At the bank", ["At the bookstore", "At the park", "At the post office"], 0, "Turn left at the bank."),
 Q("Where is the post office?", "Next to the bookstore", ["Behind the bank", "In front of the school", "Across the river"], 2, "It is next to the bookstore.")], "d"));

const mRead = [
 M("Read the sign: \"Please be quiet. Students are reading.\" Where is this sign probably?", "In a library", ["In a gym", "At a market", "At a bus stop"], 1, "조용히 하고 읽고 있다는 표지판이므로 도서관이에요."),
 M("Read the note: \"Tom, I am at the park. Back at five. Jim\" Who wrote the note?", "Jim", ["Tom", "The park", "Five"], 2, "쪽지 끝에 쓴 사람의 이름이 있어요. 받는 사람은 Tom이에요."),
 M("The movie starts at 3:30 and ends at 5:00. What time does it start?", "3:30", ["5:00", "3:00", "4:30"], 0, "starts at 3:30이라고 했어요."),
 M("Menu: Pizza $8, Salad $5, Juice $2. Which costs the most?", "Pizza", ["Salad", "Juice", "They cost the same."], 3, "8달러로 가장 비싼 것은 Pizza예요."),
 M("Monday: sunny. Tuesday: rainy. Wednesday: cloudy. Thursday: snowy. Which day is rainy?", "Tuesday", ["Monday", "Wednesday", "Thursday"], 1, "Tuesday: rainy예요."),
 M("Sue: Do you want to play badminton? Ann: Yes! See you at four. What will they do?", "Play badminton at four", ["Watch a movie at four", "Eat lunch at noon", "Do homework together"], 2, "배드민턴을 치자고 했고 네 시에 만나기로 했어요."),
 M("Label on a box: \"Milk. Keep in the refrigerator.\" Where should you keep it?", "In the refrigerator", ["In the sun", "On the floor", "In a school bag"], 0, "Keep in the refrigerator.는 냉장고에 보관하라는 뜻이에요."),
 M("Mina has a dog. She walks it every morning. What does 'it' mean?", "The dog", ["The morning", "Mina", "A walk"], 3, "it은 앞에 나온 a dog를 가리켜요."),
 M("\"The soup is very hot. Be careful!\" What does 'careful' mean?", "Pay attention to stay safe", ["Eat it quickly", "Ask for more", "Put it in the sun"], 1, "careful은 다치지 않게 조심한다는 뜻이에요."),
 M("First, Ann wakes up. Then she brushes her teeth. Last, she goes to school. What does Ann do after she wakes up?", "She brushes her teeth.", ["She goes to school.", "She eats lunch.", "She goes to bed."], 2, "Then(그다음)에 양치를 한다고 했어요."),
 M("Birds fly. Fish swim. Rabbits jump. What are these sentences about?", "What animals do", ["Colors of animals", "Homes of animals", "Food for animals"], 0, "동물들이 하는 행동을 말하고 있어요."),
 M("Dan has two brothers and one sister. Which sentence is true?", "Dan has three brothers and sisters.", ["Dan has one brother.", "Dan has two sisters.", "Dan has no brothers or sisters."], 3, "형제 둘과 자매 하나를 합쳐 모두 세 명이에요."),
 M("Sam has piano class on Monday and Wednesday. Today is Tuesday. Does Sam have piano class today?", "No, he does not.", ["Yes, he does.", "Yes, he has it every day.", "Yes, it starts on Tuesday."], 1, "피아노 수업은 월요일과 수요일이라서 화요일에는 없어요."),
 M("Invitation: \"Come to my party! Day: Saturday. Time: 2 p.m. Place: My house.\" Where is the party?", "At the writer's house", ["At a park", "At school", "At a restaurant"], 2, "Place: My house라고 했어요."),
 M("It is yellow. It is long. Monkeys like it. What is it?", "A banana", ["An apple", "A carrot", "A grape"], 0, "노랗고 길며 원숭이가 좋아하는 것은 바나나예요."),
 M("I have four legs and a flat top. You eat dinner on me. What am I?", "A table", ["A chair", "A bed", "A spoon"], 3, "다리가 네 개이고 위가 평평하며 그 위에서 저녁을 먹는 것은 식탁이에요."),
 M("Ben puts on a coat, a hat and gloves. What is the weather probably like?", "It is cold.", ["It is hot.", "It is sunny and warm.", "It is a beach day."], 1, "코트, 모자, 장갑을 입는 것은 추운 날씨라는 단서예요."),
 M("Sign: \"Please turn off the lights when you leave.\" Why is this sign there?", "To save electricity", ["To clean the room", "To open the windows", "To find lost things"], 2, "불을 끄면 전기를 아낄 수 있어요."),
].map((x) => ({ ...x, std: ["4영01-05"] }));

const sRead = [
 S("Jin gets up at seven.", "진은 일곱 시에 일어나요.", ["Jin get up at seven.", "Jin gets up on seven.", "Jin getting up at seven."], "Jin ___ up at seven.", "gets", ["get", "getting", "to get"], "주어가 3인칭 단수(Jin)이면 동사에 -s를 붙이고, 시각 앞에는 at을 써요.", { hint: "주어가 한 사람일 때 동사의 모양을 생각해 보세요." }),
 S("My brother plays soccer after school.", "내 형은 방과 후에 축구를 해요.", ["My brother play soccer after school.", "My brother plays a soccer after school.", "My brother playing soccer after school."], "My brother ___ soccer after school.", "plays", ["play", "playing", "to play"], "주어가 3인칭 단수이면 plays처럼 -s를 붙여요. 운동 이름 앞에는 a를 쓰지 않아요."),
 S("Mina eats lunch at twelve.", "미나는 열두 시에 점심을 먹어요.", ["Mina eat lunch at twelve.", "Mina eats lunch in twelve.", "Mina is eats lunch at twelve."], "Mina eats lunch ___ twelve.", "at", ["on", "in", "to"], "정확한 시각 앞에는 전치사 at을 써요. 일반동사 앞에는 is를 함께 쓰지 않아요."),
 S("The cat is under the table.", "고양이가 식탁 아래에 있어요.", ["The cat are under the table.", "The cat is under table.", "The cat is the table under."], "The cat ___ under the table.", "is", ["are", "am", "be"], "주어가 단수(The cat)이면 be동사는 is를 써요. table 앞에는 the가 필요해요."),
 S("They like pizza on Fridays.", "그들은 금요일마다 피자를 좋아해요.", ["They likes pizza on Fridays.", "They like pizza in Fridays.", "They liking pizza on Fridays."], "They ___ pizza on Fridays.", "like", ["likes", "liking", "to like"], "주어가 They(복수)이면 동사 원형 like를 써요. 요일 앞에는 on을 써요."),
 S("Sam reads a book every night.", "샘은 매일 밤 책을 읽어요.", ["Sam reading a book every night.", "Sam reads book every night.", "Sam reads a book every nights."], "Sam reads a book every ___.", "night", ["nights", "a night", "the night"], "every 뒤에는 단수 명사를 써요. 책 한 권은 a book이라고 해요."),
];

const abc = [];
const A = (...a) => abc.push(M(...a));
// case pairs
A("대문자 G의 소문자로 알맞은 것은?", "g", ["q", "j", "y"], 2, "G의 소문자는 g예요. q와 모양이 비슷하니 조심하세요.", { std: ["4영01-02"] });
A("소문자 r의 대문자는?", "R", ["P", "B", "K"], 0, "r의 대문자는 R이에요.", { std: ["4영01-02"] });
A("다음 중 대문자와 소문자의 짝이 맞는 것은?", "D – d", ["B – p", "G – q", "N – m"], 1, "D의 소문자는 d예요. B의 소문자는 b, G의 소문자는 g, N의 소문자는 n이에요.", { std: ["4영01-02"] });
A("다음 중 대문자와 소문자의 짝이 맞지 않는 것은?", "M – n", ["A – a", "E – e", "H – h"], 3, "M의 소문자는 m이에요. n은 N의 소문자예요.", { std: ["4영01-02"] });
A("대문자와 소문자의 모양이 크기만 다르고 거의 같은 글자는?", "Oo", ["Dd", "Gg", "Bb"], 0, "O와 o는 크기만 다르고 모양이 같아요. 나머지는 모양이 확연히 달라요.", { std: ["4영01-02"] });
A("대문자 F의 소문자로 알맞은 것은?", "f", ["t", "l", "h"], 3, "F의 소문자는 f예요.", { std: ["4영01-02"] });
A("소문자 n의 대문자는?", "N", ["M", "H", "U"], 1, "n의 대문자는 N이에요. M은 m의 대문자예요.", { std: ["4영01-02"] });
A("Which word is written in capital letters only?", "BOOK", ["bag", "pen", "Sun"], 2, "BOOK은 모든 글자가 대문자예요. Sun은 첫 글자만 대문자예요.", { std: ["4영01-02"] });
A("Which word is written in small letters only?", "apple", ["Dog", "CAT", "Bird"], 1, "apple은 모든 글자가 소문자예요.", { std: ["4영01-02"] });
A("Which word needs a capital letter even in the middle of a sentence?", "monday", ["table", "green", "happy"], 0, "요일 이름은 문장 중간에서도 첫 글자를 대문자로 써요.", { std: ["4영01-02"] });
A("문장의 첫 글자를 대문자로 바르게 쓴 것은?", "We like bananas.", ["our dog is big.", "my pen is blue.", "they run fast."], 3, "문장은 첫 글자를 대문자로 시작해요.", { std: ["4영01-02"] });
A("'나'를 뜻하는 영어 I는 문장 가운데에서도 어떻게 쓰나요?", "늘 대문자로 써요", ["늘 소문자로 써요", "밑줄을 그어요", "두 번 겹쳐 써요"], 2, "I는 문장의 어디에 있어도 대문자로 써요.", { std: ["4영01-02"] });
A("소문자 b를 거울에 비춘 것처럼 보이는 글자는?", "d", ["m", "t", "k"], 0, "b의 막대와 동그라미 위치를 좌우로 바꾸면 d가 돼요.", { std: ["4영01-02"] });
// b d p q
A("소문자 b의 모양을 바르게 설명한 것은?", "막대가 왼쪽에 있고 동그라미가 오른쪽에 있어요.", ["막대가 오른쪽에 있고 동그라미가 왼쪽에 있어요.", "막대가 아래로 내려가고 동그라미가 오른쪽에 있어요.", "막대가 아래로 내려가고 동그라미가 왼쪽에 있어요."], 3, "b는 막대(ㅣ)가 왼쪽, 동그라미가 오른쪽이에요. d는 반대, p와 q는 막대가 아래로 내려가요.", { std: ["4영01-02"] });
A("단어 dad는 첫 글자와 마지막 글자가 같아요. 이 글자는?", "d", ["b", "p", "q"], 0, "dad는 d–a–d로 써요.", { std: ["4영01-02"] });
A("Which word has the letter p in it?", "pig", ["bird", "duck", "bus"], 2, "pig에는 p가 있어요.", { std: ["4영01-02"] });
A("Which word has the letter q in it?", "queen", ["pen", "dog", "bed"], 1, "queen은 q로 시작해요.", { std: ["4영01-02"] });
A("The animal says quack. Which word is it?", "duck", ["buck", "puck", "quck"], 0, "오리는 duck이에요. 첫 글자 d의 방향에 주의하세요.", { std: ["4영01-02"] });
A("You sleep on it. Which spelling is right?", "bed", ["ded", "bep", "beb"], 3, "침대는 bed예요. b와 d를 헷갈리지 마세요.", { std: ["4영02-03"] });
A("소문자 p와 q의 차이로 알맞은 것은?", "p는 동그라미가 오른쪽, q는 왼쪽에 있어요.", ["p는 동그라미가 왼쪽, q는 오른쪽에 있어요.", "p는 막대가 위로 올라가요.", "p와 q는 모양이 똑같아요."], 1, "둘 다 막대가 아래로 내려가는데, p는 동그라미가 오른쪽, q는 왼쪽이에요.", { std: ["4영01-02"] });
// order
A("What letter comes after C in the alphabet?", "D", ["B", "E", "F"], 0, "알파벳 순서는 A, B, C, D, E 순서예요.", { std: ["4영01-02"] });
A("What letter comes before M?", "L", ["K", "N", "O"], 2, "L 다음이 M이에요.", { std: ["4영01-02"] });
A("Which letter comes between P and R?", "Q", ["O", "S", "T"], 1, "P, Q, R 순서예요.", { std: ["4영01-02"] });
A("알파벳의 첫 번째 글자는?", "A", ["B", "Z", "I"], 3, "알파벳은 A로 시작해요.", { std: ["4영01-02"] });
A("알파벳의 마지막 글자는?", "Z", ["X", "Y", "W"], 0, "알파벳은 Z로 끝나요. Y는 그 바로 앞 글자예요.", { std: ["4영01-02"] });
A("Which letter is missing? g, h, ___, j, k", "i", ["l", "f", "m"], 2, "g, h, i, j, k 순서예요.", { std: ["4영01-02"] });
A("Which letter is missing? R, S, ___, U, V", "T", ["Q", "W", "P"], 1, "R, S, T, U, V 순서예요.", { std: ["4영01-02"] });
A("알파벳은 모두 몇 글자인가요?", "26", ["24", "28", "30"], 3, "알파벳은 A부터 Z까지 모두 26글자예요.", { std: ["4영01-02"] });
A("Which word comes first in ABC order?", "apple", ["banana", "cherry", "grape"], 0, "첫 글자 a가 가장 앞서므로 apple이 가장 먼저 나와요.", { std: ["4영01-02"] });
A("Which word comes last in ABC order?", "tiger", ["lion", "mouse", "pig"], 2, "첫 글자를 비교하면 t가 가장 뒤에 있어요.", { std: ["4영01-02"] });
A("Which letter is the fifth letter of the alphabet?", "E", ["D", "F", "G"], 0, "A, B, C, D, E 순서이니 다섯 번째는 E예요.", { std: ["4영01-02"] });
A("Which letter comes right after W?", "X", ["V", "Y", "Z"], 0, "W 다음이 X, 그다음이 Y, Z예요.", { std: ["4영01-02"] });
// vowels
A("Which letter is a vowel?", "E", ["B", "T", "M"], 2, "모음은 a, e, i, o, u 다섯 글자예요.", { std: ["4영01-01"] });
A("Which letter is NOT a vowel?", "S", ["A", "I", "O"], 0, "S는 자음이에요. A, I, O는 모음이에요.", { std: ["4영01-01"] });
A("Which group has only vowels?", "a, e, i, o, u", ["a, b, c, d, e", "e, f, g, h, i", "o, p, q, r, u"], 1, "모음은 a, e, i, o, u예요.", { std: ["4영01-01"] });
A("Which word starts with a vowel letter?", "egg", ["pen", "sun", "hat"], 3, "egg는 모음 e로 시작해요.", { std: ["4영01-01"] });
A("Which letter is a consonant?", "K", ["A", "E", "O"], 0, "K는 자음이에요. A, E, O는 모음이에요.", { std: ["4영01-01"] });
A("How many vowel letters are in the word 'cat'?", "1", ["0", "2", "3"], 2, "cat에는 모음 a 하나만 있어요.", { std: ["4영01-01"] });
A("Which word has the vowel letter o in it?", "dog", ["cat", "sit", "bus"], 1, "dog에는 모음 o가 있어요.", { std: ["4영01-01"] });
// counting / positions
A("How many letters are in the word 'apple'?", "5", ["4", "6", "7"], 0, "a–p–p–l–e로 모두 5글자예요.", { std: ["4영01-02"] });
A("How many letters are in the word 'elephant'?", "8", ["7", "9", "10"], 3, "e–l–e–p–h–a–n–t로 모두 8글자예요.", { std: ["4영01-02"] });
A("What is the first letter of 'monkey'?", "m", ["n", "w", "y"], 1, "monkey는 m으로 시작해요.", { std: ["4영01-02"] });
A("What is the last letter of 'fish'?", "h", ["f", "s", "i"], 2, "fish는 f–i–s–h로, 마지막 글자는 h예요.", { std: ["4영01-02"] });
A("Which word has the letter x in it?", "box", ["bus", "bag", "bed"], 0, "box는 b–o–x로 써요.", { std: ["4영01-02"] });
A("Which word has two of the same letter side by side?", "book", ["bike", "fish", "star"], 3, "book에는 o가 두 번 연달아 나와요.", { std: ["4영01-02"] });
A("Which word ends with the letter e?", "name", ["pig", "sun", "dog"], 1, "name은 n–a–m–e로 e로 끝나요.", { std: ["4영01-02"] });
// sounds
A("Which word begins with the same letter as 'sun'?", "sock", ["tree", "milk", "pen"], 2, "sun과 sock은 둘 다 s로 시작해요.", { std: ["4영01-01"] });
A("Which word begins with the sound /m/?", "moon", ["sun", "dog", "hat"], 0, "moon은 /m/ 소리로 시작해요.", { std: ["4영01-01"] });
A("Which word begins with the sound /f/?", "fish", ["pig", "bus", "hat"], 1, "fish는 /f/ 소리로 시작해요.", { std: ["4영01-01"] });
A("Which word ends with the sound /t/?", "cat", ["dog", "pig", "sun"], 3, "cat은 /t/ 소리로 끝나요.", { std: ["4영01-01"] });
A("Which word does not begin with the letter s?", "tree", ["sun", "star", "soap"], 0, "tree는 t로 시작해요. 나머지는 모두 s로 시작해요.", { std: ["4영01-01"] });
A("Which word rhymes with 'hat'?", "bat", ["dog", "pen", "sun"], 2, "hat과 bat은 -at 소리로 끝나서 운이 맞아요.", { std: ["4영01-03"] });
A("Which word begins with the letter u?", "umbrella", ["apple", "orange", "egg"], 0, "umbrella는 u로 시작해요.", { std: ["4영01-01"] });
// letter names
A("Which letter sounds like the English word 'sea'?", "C", ["D", "T", "P"], 1, "알파벳 C의 이름은 sea와 소리가 같아요.", { std: ["4영01-01"] });
A("Which letter sounds like the word 'eye'?", "I", ["A", "E", "O"], 0, "알파벳 I의 이름은 eye와 소리가 같아요.", { std: ["4영01-01"] });
A("Which letter sounds like the word 'you'?", "U", ["W", "V", "Y"], 3, "알파벳 U의 이름은 you와 소리가 같아요.", { std: ["4영01-01"] });
A("Which letter sounds like the word 'why'?", "Y", ["X", "Z", "W"], 0, "알파벳 Y의 이름은 why와 소리가 비슷해요.", { std: ["4영01-01"] });
// shapes
A("Which capital letter has only straight lines?", "E", ["S", "O", "C"], 1, "E는 직선으로만 이루어져 있고, S, O, C는 곡선이 있어요.", { std: ["4영01-02"] });
A("Which small letter has a dot above it?", "i", ["l", "t", "f"], 0, "i에는 위에 점이 있어요.", { std: ["4영01-02"] });
A("Which small letter goes below the line?", "g", ["a", "e", "o"], 2, "g는 꼬리가 줄 아래로 내려가요.", { std: ["4영01-02"] });
A("Which small letter is tall?", "b", ["a", "c", "e"], 1, "b는 키가 큰 글자예요. a, c, e는 작은 글자예요.", { std: ["4영01-02"] });
A("Which capital letter looks like a cross, ×?", "X", ["T", "H", "K"], 3, "X는 두 선이 × 모양으로 엇갈려요.", { std: ["4영01-02"] });
A("A road sign says STOP. Which letter does the word begin with?", "S", ["T", "O", "P"], 0, "STOP은 S로 시작해요.", { std: ["4영01-02"] });
A("Which pair of letters is a vowel and a consonant?", "A and B", ["E and I", "B and C", "O and U"], 0, "A는 모음, B는 자음이에요.", { std: ["4영01-01"] });
A("Which letter is NOT in the word 'dog'?", "t", ["d", "o", "g"], 0, "dog는 d–o–g로 이루어져 있어요.", { std: ["4영01-02"] });
console.error("abc m count", abc.length);

const W = (en, pos, ko, ex, exko, z, sp, extra = {}) => ({ k: "w", en, pos, ko, ex, exko, z, syn: [], sp, ...extra });
const abcW = [
 W("letter", "n", "글자", "The first letter of my name is S.", "내 이름의 첫 글자는 S예요.", ["fruit", "table", "window"], ["leter", "lettar", "letterr"]),
 W("alphabet", "n", "알파벳", "I can sing the alphabet song.", "나는 알파벳 노래를 부를 수 있어요.", ["dinner", "window", "kitchen"], ["alfabet", "alphabat", "alphabett"]),
 W("word", "n", "단어", "Write a new word in your notebook.", "새 단어를 공책에 쓰세요.", ["shoe", "tree", "bus"], ["werd", "wrod", "wordd"]),
 W("vowel", "n", "모음", "The letter A is a vowel.", "글자 A는 모음이에요.", ["color", "animal", "drink"], ["vowal", "vowwel", "voewl"]),
 W("capital", "adj", "대문자의", "Names start with a capital letter.", "이름은 대문자로 시작해요.", ["hungry", "sleepy", "rainy"], ["capitel", "capitle", "captal"], { syn: ["uppercase"] }),
 W("small", "adj", "작은", "I have a small bag.", "나는 작은 가방이 있어요.", ["sunny", "rainy", "hungry"], ["smal", "smaall", "smaul"], { syn: ["little", "tiny"] }),
 W("same", "adj", "같은", "Bob and Ben start with the same letter.", "밥과 벤은 같은 글자로 시작해요.", ["hungry", "sleepy", "happy"], ["saem", "sayme", "samme"]),
 W("different", "adj", "다른", "These two letters are different.", "이 두 글자는 서로 달라요.", ["sleepy", "hungry", "cloudy"], ["diferent", "diffrent", "differant"]),
 W("write", "v", "쓰다", "I write my name on the paper.", "나는 종이에 내 이름을 써요.", ["eat", "wash", "carry"], ["wrigt", "wirte", "writte"]),
 W("spell", "v", "철자를 말하다", "Can you spell your name?", "네 이름의 철자를 말할 수 있니?", ["wash", "carry", "open"], ["spel", "spil", "spelle"]),
 W("read", "v", "읽다", "I can read this word.", "나는 이 단어를 읽을 수 있어요.", ["eat", "wash", "jump"], ["reid", "raed", "reaad"]),
];
for (const w of abcW) w.std = ["4영01-05"];
const sAbc = [
 S("I have an egg.", "나는 달걀이 하나 있어요.", ["I have a egg.", "I has an egg.", "I have an eggs."], "I have ___ egg.", "an", ["a", "two", "many"], "모음 소리로 시작하는 단수 명사 앞에는 a 대신 an을 써요.", { hint: "egg의 첫 소리가 모음인지 살펴보세요." }),
 S("An elephant is big.", "코끼리는 커요.", ["A elephant is big.", "An elephant are big.", "An elephant is bigs."], "___ elephant is big.", "An", ["A", "Two", "Many"], "elephant는 모음 소리로 시작하므로 an을 써요. 주어가 단수이면 be동사는 is예요."),
 S("The alphabet has twenty-six letters.", "알파벳은 스물여섯 글자예요.", ["The alphabet have twenty-six letters.", "The alphabet has twenty-six letter.", "The alphabet has twenty-six of letters."], "The alphabet has twenty-six ___.", "letters", ["letter", "a letter", "the letter"], "숫자가 2 이상이면 명사에 -s를 붙여요. 주어 alphabet은 단수이므로 has를 써요."),
 S("Tom and Tim start with the same letter.", "톰과 팀은 같은 글자로 시작해요.", ["Tom and Tim starts with the same letter.", "Tom and Tim is start with the same letter.", "Tom and Tim start with the letter same."], "Tom and Tim ___ with the same letter.", "start", ["starts", "starting", "to start"], "Tom and Tim은 두 명이므로 복수 주어예요. 동사는 -s 없이 start를 써요."),
 S("B comes before C.", "B는 C 앞에 와요.", ["B come before C.", "B comes before to C.", "B comes C before."], "B comes ___ C.", "before", ["at", "in", "with"], "'~ 앞에'는 before를 써요. 한 글자(B)는 3인칭 단수이므로 comes예요."),
 S("Write your name with a capital letter.", "이름을 대문자로 쓰세요.", ["Writes your name with a capital letter.", "Write you name with a capital letter.", "Write your name with capital a letter."], "Write your name with a capital ___.", "letter", ["letters", "a letter", "the letters"], "'대문자'는 capital letter예요. 앞에 a가 있으므로 단수 letter를 써요.", { hint: "'a' 뒤에 오는 명사의 모양을 생각해 보세요." }),
];
const out = {
 packet: "E09-e3",
 sections: [
  { skill: "e.e3.read", items: [...read, ...dial, ...mRead, ...sRead] },
  { skill: "e.e3.abc1", items: [...abc, ...abcW, ...sAbc] },
 ],
};
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E09-e3.json", JSON.stringify(out, null, 1));
