// {k,title,text,qs:[[q,key,[d1,d2,d3],why,std?]]}
export const R = [
{k:"r",title:"My New School",text:"Today is my first day at a new school. I am nervous, but my classmates are very friendly. My homeroom teacher, Ms. Oh, is kind and funny. She is also our English teacher. The classroom is big and bright, and there are thirty desks in it. My desk is next to the window. At lunch, I am with two girls named Yuri and Soyeon. They are in the cooking club, and they are happy to see a new face. I am not worried now. I think this school is going to be great.",
qs:[
["What is the passage mainly about?","A student's first day at a new school",["A teacher who joins the cooking club","A big classroom with thirty desks","A girl who changes her homeroom class"],"처음 학교에 간 날의 경험과 기분을 이야기하는 글이에요.",["9영01-03"]],
["Who is the English teacher?","Ms. Oh",["Yuri","Soyeon","The principal"],"'She is also our English teacher.'에서 She는 Ms. Oh예요.",["9영01-02"]],
["Where is the writer's desk?","Next to the window",["Near the front door","In the back row","Beside the teacher's desk"],"'My desk is next to the window.'라고 했어요.",["9영01-02"]],
["How does the writer feel at the end?","Hopeful about the school",["Angry at the classmates","Bored with the lessons","Sad about leaving"],"마지막에 걱정하지 않고 학교가 멋질 것이라고 생각해요.",["9영01-05"]],
["In the passage, who does \"they\" in \"they are happy to see a new face\" refer to?","Yuri and Soyeon",["All the classmates","Ms. Oh and the writer","The writer's old friends"],"앞 문장에서 cooking club에 있는 두 소녀를 말해요."]]},
{k:"d",title:"Lost and Found",text:"Ben: Excuse me. Is this the lost and found?\nClerk: Yes, it is. Can I help you?\nBen: I think my jacket is here. It was on a bench in the park yesterday.\nClerk: What color is it?\nBen: It's dark green, and there are two big pockets.\nClerk: Hmm. Here are three jackets. Are they yours?\nBen: No, the first one is blue, and the other two are too small. Wait, that one on the chair is mine!\nClerk: Great. Is your name inside?\nBen: Yes, it is. Look, Ben Park.\nClerk: Perfect. Here you are.",
qs:[
["Where does this conversation take place?","At a lost and found office",["In a city park","At a clothing shop","In a school classroom"],"Ben이 'Is this the lost and found?'라고 물어요.",["9영01-02"]],
["Where was Ben's jacket yesterday?","On a bench in the park",["Under a chair at school","On a bus to the city","At a friend's house"],"'It was on a bench in the park yesterday.'라고 말해요.",["9영01-02"]],
["What color is Ben's jacket?","Dark green",["Light blue","Dark gray","Pale yellow"],"Ben이 'It's dark green'이라고 말해요.",["9영01-02"]],
["How does Ben show that the jacket is his?","His name is written inside it",["The clerk remembers his face","He shows a photo of the jacket","He tells the clerk his address"],"이름이 안쪽에 있다고 확인하고 Ben Park을 보여 줘요.",["9영01-04"]]]},
{k:"r",title:"A Rainy Saturday",text:"Last Saturday was rainy, so my brother and I were at home all day. At first we were bored. The TV was broken, and our books were at school. Then our grandmother was in the kitchen, and she said, \"Let's make dumplings!\" Soon the kitchen was full of flour and laughter. My brother was terrible at folding them, but he was the best at eating them. By evening, the rain was gone. The dumplings were delicious, and we were not bored anymore.",
qs:[
["Why were the children at home last Saturday?","The weather was bad",["They were sick","They had too much homework","They were waiting for guests"],"첫 문장에서 토요일에 비가 와서 집에 있었다고 해요.",["9영01-04"]],
["What does \"bored\" most likely mean in the passage?","Tired of having nothing to do",["Afraid of the rain","Angry at each other","Happy with the day"],"TV가 고장 나고 책도 없어서 할 일이 없는 상태예요.",["9영01-07"]],
["Who was the best at eating dumplings?","The writer's brother",["The writer","The grandmother","The writer's mother"],"'he was the best at eating them'에서 he는 형제예요.",["9영01-02"]],
["What happened after the grandmother suggested making dumplings?","The kitchen became busy and messy",["The rain stopped at once","The brother went to bed","The TV was fixed"],"곧 부엌이 밀가루와 웃음으로 가득 찼다고 해요.",["9영01-04"]],
["Which statement is true?","The dumplings tasted good",["The brother was good at folding","The TV worked well all day","The writer stayed bored until night"],"마지막 문장에서 dumplings were delicious라고 해요.",["9영01-02"]]]},
{k:"r",title:"Join the Science Club",text:"Join the Science Club! Our club meets in Room 204 every Wednesday after school. The room is next to the library, so it is easy to find. Our teacher, Mr. Han, is an expert on volcanoes, and he is very patient with beginners. You are not required to be good at science. Everyone is welcome! Please bring a notebook and a pen. The first meeting is free, but the materials for later meetings are 2,000 won each. Are you curious? Come and see us on Wednesday!",
qs:[
["Why was this notice written?","To invite students to join a club",["To announce a science test","To ask for money for a trip","To introduce a new school building"],"Join the Science Club!으로 시작하며 가입을 권하는 글이에요.",["9영01-06"]],
["When does the club meet?","Every Wednesday after school",["Every Monday after school","Every Wednesday before school","Every Friday after lunch"],"every Wednesday after school이라고 해요.",["9영01-02"]],
["How can students find the room?","It is next to the library",["It is on the roof","It is across from the gym","It is behind the cafeteria"],"'The room is next to the library'라고 해요.",["9영01-02"]],
["Which is true about the first meeting?","It does not cost anything",["Students must be good at science","Students pay 2,000 won","It is held in the library"],"첫 모임은 free(무료)라고 해요.",["9영01-02"]],
["What kind of teacher is Mr. Han?","Patient with new members",["Strict about test scores","Often late to class","Tired of beginners"],"he is very patient with beginners라고 해요.",["9영01-07"]]]},
{k:"r",title:"My Pet Hamster",text:"I have a pet hamster. His name is Mochi. He is small and round, and his fur is soft and brown. Mochi is awake at night, so he is very sleepy in the morning. His favorite foods are sunflower seeds and carrots. His cage is in my room, next to my desk. There are two wheels and a little house in it. My mom is not a big fan of hamsters, but she is kind to Mochi. I am very happy with my small friend.",
qs:[
["When is Mochi active?","During the night",["In the early morning","In the afternoon","At lunchtime"],"Mochi is awake at night라고 해요.",["9영01-02"]],
["Where is Mochi's cage?","In the writer's room",["In the kitchen","In the living room","Next to the front door"],"His cage is in my room이라고 해요.",["9영01-02"]],
["What does \"awake\" mean in the passage?","Not sleeping",["Very hungry","Very quiet","Hiding"],"밤에 깨어 있어서 아침에 졸리다는 흐름이에요.",["9영01-07"]],
["How does the writer's mom feel about hamsters?","She is not very fond of them",["She wants to get another one","She is afraid of all pets","She likes them more than the writer does"],"not a big fan은 '별로 좋아하지 않는다'는 뜻이에요.",["9영01-07"]],
["What is the best title for the passage?","Meet My Pet Hamster",["How to Clean a Cage","A Hamster's Long Night Walk","Foods That Hamsters Hate"],"글 전체가 햄스터를 소개하고 있어요.",["9영01-03"]]]},
{k:"r",title:"Grandpa's Village",text:"Last summer, my family was in my grandfather's village for two weeks. The village is small and quiet. There are only about forty houses, and the mountains are all around it. Every morning, the air was cool and fresh. Grandpa's garden was full of tomatoes and corn. My cousins were there too, so we were never bored. We were in the river almost every afternoon. The water was cold, but it was fun. I am sad now because summer is over, but my memories are very happy.",
qs:[
["How long was the writer's family in the village?","For two weeks",["For one week","For a month","For the whole summer"],"for two weeks라고 해요.",["9영01-02"]],
["What was in Grandpa's garden?","Tomatoes and corn",["Peppers and beans","Apples and pears","Potatoes and onions"],"garden was full of tomatoes and corn이라고 해요.",["9영01-02"]],
["Why does the writer feel sad now?","The summer holiday has ended",["The village is too noisy","The cousins were unkind","The river water is cold"],"because summer is over라고 해요.",["9영01-05"]],
["Which sentence is NOT true about the village?","It is large and crowded",["It is small and quiet","It has mountains around it","It has about forty houses"],"마을은 작고 조용하다고 했어요.",["9영01-02"]]]},
{k:"d",title:"Planning a Party",text:"Jisu: Hi, Tom. Is your birthday this Friday?\nTom: No, it isn't. It's next Friday.\nJisu: Oh, I'm sorry. Are you free that afternoon?\nTom: Yes, I am. My parents are at work, so the house is empty.\nJisu: Great! We can have a small party. Who is coming?\nTom: Minho and Sara are coming. They're my best friends.\nJisu: Is Sara allergic to nuts? Her cake can't have any.\nTom: Yes, she is. Good question! Let's make a plain chocolate cake.\nJisu: OK. I'm good at baking, so I can make it.",
qs:[
["When is Tom's birthday?","Next Friday",["This Friday","Next Monday","This Sunday"],"Tom이 'It's next Friday.'라고 말해요.",["9영01-02"]],
["Why is Tom's house empty that afternoon?","His parents are at work",["His family is on a trip","The house is being repaired","His parents are at a party"],"My parents are at work, so the house is empty라고 해요.",["9영01-04"]],
["Why does Jisu ask about nuts?","She wants the cake to be safe for Sara",["She dislikes nuts herself","Tom asks for a nut cake","The shop has no nuts today"],"Sara가 견과류 알레르기가 있는지 확인하고 있어요.",["9영01-06"]],
["What will Jisu do for the party?","Make a chocolate cake",["Buy some balloons","Invite Minho","Clean the house"],"I'm good at baking, so I can make it이라고 해요.",["9영01-02"]]]},
{k:"r",title:"Our Town Library",text:"Our town library is on Maple Street. It is open from nine to six, and it is closed on Sundays. There are three floors. The first floor is for children, and there are many picture books and soft cushions. The second floor is quiet, and there are long tables for studying. The third floor is a small cafe, but it is not open in the morning. Last month, there was a book festival, and many families were there. The library is a great place for everyone.",
qs:[
["What is the passage mainly about?","A description of a town library",["A story about a book festival","Rules for studying at a cafe","A guide to children's books"],"도서관의 위치, 시간, 층별 모습을 소개하는 글이에요.",["9영01-03"]],
["On which floor are the long study tables?","The second floor",["The first floor","The third floor","The basement"],"The second floor ... long tables for studying이라고 해요.",["9영01-02"]],
["When is the library closed?","On Sundays",["On Saturdays","On Mondays","In the evening"],"closed on Sundays라고 해요.",["9영01-02"]],
["What was held at the library last month?","A book festival",["A cooking class","A music show","A movie night"],"Last month, there was a book festival이라고 해요.",["9영01-02"]],
["Who would most likely enjoy the first floor?","A young child who likes stories",["A student preparing for a test","A person who wants some coffee","A worker who needs silence"],"1층은 어린이를 위한 그림책 공간이에요.",["9영01-07"]]]},
{k:"r",title:"An Email to Emma",text:"Hi Emma,\nHow are you? I am fine, but I am very busy these days. School is hard this term, and the tests are every week. Yesterday I was late for science class because the bus was slow. My teacher was not angry, but I felt bad about it. My weekend is free, so I am ready to relax. Are you free on Saturday? The new park is open, and the lake there is beautiful. Please write back soon!\nYour friend,\nDana",
qs:[
["Why does Dana write this email?","To ask Emma about weekend plans",["To say sorry for missing a test","To tell Emma about a new school","To ask for help with homework"],"토요일에 시간이 되는지 묻고 답장을 부탁해요.",["9영01-06"]],
["Why was Dana late for science class?","The bus was slow",["She was sick","She forgot her book","Her teacher was late"],"because the bus was slow라고 해요.",["9영01-02"]],
["How did Dana feel about being late?","She felt bad about it",["She felt proud of it","She felt very sleepy","She felt angry at the teacher"],"I felt bad about it라고 해요.",["9영01-05"]],
["What new place does Dana mention?","A park with a lake",["A school with a pool","A shop with a cafe","A zoo with a river"],"The new park is open, and the lake there is beautiful이라고 해요.",["9영01-02"]],
["Which is true about Dana's weekend?","It is free",["It is full of tests","It is busy with classes","It is spent at the lake"],"My weekend is free라고 해요.",["9영01-02"]]]},
{k:"r",title:"The Twins Next Door",text:"Hana and Dani are twins, but they are very different. Hana is tall and quiet. She is a member of the library club, and her favorite place is the reading room. Dani is short and loud. He is on the school soccer team, and he is always on the field after class. They are both good students, but their hobbies are not the same. Their mother is a nurse, and their father is a bus driver. On weekends, they are together at their grandmother's house. There, they are both happy.",
qs:[
["What is the passage mainly about?","Two twins with different interests",["A school soccer game","The jobs of two parents","A visit to a library"],"쌍둥이의 성격과 취미가 서로 다르다는 내용이에요.",["9영01-03"]],
["What does Dani do after class?","He spends time on the soccer field",["He studies in the reading room","He helps at the library club","He visits his grandmother"],"he is always on the field after class라고 해요.",["9영01-02"]],
["In the passage, \"loud\" describes Dani as someone who is ___.","noisy and full of energy",["afraid of loud sounds","taller than his sister","always sad and tired"],"Hana가 조용하다는 것과 대비되어 '시끄럽고 활발한' 사람을 말해요.",["9영01-07"]],
["What is the twins' father's job?","Bus driver",["Nurse","Teacher","Cook"],"their father is a bus driver라고 해요.",["9영01-02"]],
["Where are the twins together on weekends?","At their grandmother's house",["At the school library","On the soccer field","At their mother's hospital"],"On weekends, they are together at their grandmother's house라고 해요.",["9영01-02"]]]},
];
export const W = [
{k:"w",en:"absent",pos:"adj",ko:"결석한",ex:"Minho is absent from school today.",exko:"민호는 오늘 학교에 결석했어요.",z:["tall","happy","angry"],syn:[],sp:["absant","abcent","apsent"]},
{k:"w",en:"nervous",pos:"adj",ko:"긴장한",ex:"I was nervous before my first piano show.",exko:"나는 첫 피아노 공연 전에 긴장했어요.",z:["wooden","sunny","square"],syn:["anxious","worried"],sp:["nervus","nerveous","nurvous"]},
{k:"w",en:"polite",pos:"adj",ko:"예의 바른",ex:"My neighbors are always polite to children.",exko:"우리 이웃들은 아이들에게 항상 예의 바르게 대해요.",z:["round","empty","sleepy"],syn:[],sp:["polight","pollite","polit"]},
];
