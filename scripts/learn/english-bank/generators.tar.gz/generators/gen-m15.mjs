import fs from "node:fs";
let ctr = 0;
// q(question, key, [3 distractors], why, std)
const q = (qq, key, ds, why, std) => {
  const pos = (ctr++ * 3 + 1) % 4;
  const o = [...ds]; o.splice(pos, 0, key);
  return { q: qq, o, a: pos, why, ...(std ? { std } : {}) };
};
const R = (title, text, qs, d) => ({ k: "r", title, text, qs, ...(d ? { d } : {}) });
const D = (title, lines, qs, d) => ({ k: "d", title, text: lines.join("\n"), qs, ...(d ? { d } : {}) });
const M = (qq, key, ds, why, std, cat) => { const x = q(qq, key, ds, why, std); return { k: "m", ...x, cat: cat ?? "reading" }; };

const r = [];
r.push(R("Beach Clean-up", "Dear members, I am writing about next Saturday's beach clean-up. Last month only twelve people came, and the shore was still covered with plastic bottles and bags. We hope more of you can join us this time. Gloves and bags will be provided, but please bring your own water and a hat, because there is little shade. If it rains, we will move the event to the following Saturday. Please reply by Wednesday so that we can order enough supplies. Thank you for caring about our town. Mina, Green Club", [
  q("Why did Mina write this email?", "To ask members to join an event and reply", ["To report the result of last month's event", "To explain how to recycle plastic at home", "To announce that the club will be closed"], "참여를 부탁하고 수요일까지 답장해 달라고 요청하는 글이에요.", ["9영01-06"]),
  q("Why does Mina mention that only twelve people came last month?", "Because more helpers are needed this time", ["Because the beach was already clean", "Because the weather was too hot then", "Because twelve is the number of gloves"], "지난달 참가자가 적어 해변이 여전히 지저분했다는 점에서 더 많은 도움이 필요하다는 것을 추론할 수 있어요.", ["9영01-06"]),
  q("The word \"provided\" is closest in meaning to", "supplied", ["borrowed", "washed", "counted"], "provided는 '제공된'이라는 뜻으로 supplied와 가까워요.", ["9영01-07"]),
  q("What can we infer about the beach?", "There is not much place to stay out of the sun", ["It is closed on rainy days only", "It is far from the town center", "It has a lot of tall trees"], "little shade라고 했으므로 그늘이 별로 없다고 추론할 수 있어요.", ["9영01-07"]),
  q("What will happen if it rains next Saturday?", "The clean-up will be held a week later", ["The members will stay and wait for the sun", "The club will order more supplies", "Only twelve people will be asked to come"], "비가 오면 그다음 토요일로 옮긴다고 했어요.", ["9영01-02"]),
]));
r.push(R("Library Notice", "Attention, students. The school library will close at 3:00 p.m. every day this week because workers are repairing the roof. The noise during the repair is too loud for reading, and some shelves must be covered. Books can still be returned through the box beside the main door, and no late fees will be charged until Monday. If you need a book for your project, please ask Ms. Park in the office before noon. We are sorry for the trouble and thank you for your patience.", [
  q("What is the main purpose of this notice?", "To tell students about a temporary change", ["To ask students to buy new books", "To praise the workers for their effort", "To introduce a new library teacher"], "도서관이 일시적으로 일찍 닫는다는 변경 사항을 알리는 글이에요.", ["9영01-06"]),
  q("Why will late fees not be charged until Monday?", "Because returning books is harder this week", ["Because the library will have no books", "Because Ms. Park is on vacation", "Because the roof was fixed last Friday"], "수리 때문에 반납이 불편하므로 연체료를 면제해 주는 거예요.", ["9영01-04"]),
  q("The phrase \"thank you for your patience\" shows that the writer", "expects students to feel a little upset", ["wants students to hurry up", "is angry at the students", "is planning a surprise party"], "불편을 끼쳐 미안하다는 뜻이며, 학생들이 조금 불편해할 것을 예상해요.", ["9영01-06"]),
  q("What should a student do to get a book for a project?", "Talk to Ms. Park before twelve", ["Use the box beside the main door", "Wait until the roof is repaired", "Visit the library after 3:00 p.m."], "정오 전에 사무실의 Ms. Park에게 요청하라고 했어요.", ["9영01-02"]),
]));
r.push(R("Before the Recital", "Saturday, October 3. I could not eat breakfast today. My hands felt cold, and I kept playing the same four bars again and again. Mom said, \"You know this piece better than anyone.\" I smiled, but my stomach did not agree. In the hall, I looked at the big black piano and wished I could walk home. Then Mr. Han gave me a thumbs-up from the first row. My fingers were still shaking when I sat down, but when the first note came out clean, I finally took a breath.", [
  q("How did the writer feel before the recital?", "Anxious", ["Bored", "Proud", "Jealous"], "아침도 못 먹고 손이 차갑다고 했으므로 긴장한 상태예요.", ["9영01-05"]),
  q("What does \"my stomach did not agree\" mean?", "The writer was still nervous inside", ["The writer was feeling hungry", "The writer disagreed with Mom", "The writer had a serious illness"], "웃었지만 속으로는 여전히 긴장하고 있다는 함축적 표현이에요.", ["9영01-07"]),
  q("Why did the writer feel better at the end?", "The opening note was played well", ["Mom sat in the first row", "The piano was smaller than expected", "The hall was almost empty"], "첫 음을 깔끔하게 치자 마침내 숨을 쉬었다고 했어요.", ["9영01-04"]),
  q("Who is Mr. Han most likely to be?", "The writer's piano teacher", ["The writer's older brother", "The hall's cleaning worker", "A reporter from a newspaper"], "객석에서 엄지를 들어 격려한 것으로 보아 선생님일 가능성이 가장 커요.", ["9영01-07"]),
]));
r.push(R("Cooking for Beginners", "Have you ever burned toast? Don't worry! Our Saturday morning cooking class is made for people who have never held a knife. In four weeks, you will learn to cook six simple meals, from vegetable soup to fried rice. Each class has only eight students, so the teacher can help everyone. All food is shared at the end of class, and you can take the recipes home. The first lesson is free. Sign up at the front desk of Hillside Community Center before the end of this month.", [
  q("What is the writer's main purpose?", "To get people to join a class", ["To teach how to make soup", "To warn people about kitchen knives", "To report a cooking contest result"], "광고의 목적은 수업 등록을 유도하는 거예요.", ["9영01-06"]),
  q("Why does the writer ask, \"Have you ever burned toast?\"", "To show the class is friendly to beginners", ["To complain about a broken toaster", "To sell a new kind of bread", "To test the readers' cooking skills"], "서툰 사람도 환영한다는 분위기를 만들기 위한 질문이에요.", ["9영01-06"]),
  q("Why does the class have only eight students?", "So that each person can get help", ["So that the food can be sold", "Because the kitchen has no tables", "Because the teacher is a beginner"], "선생님이 모두를 도울 수 있도록 인원을 제한한 거예요.", ["9영01-04"]),
  q("Which is true about the first lesson?", "It costs nothing", ["It teaches fried rice only", "It is held on a Sunday", "It lasts four weeks"], "첫 수업은 무료(free)라고 했어요.", ["9영01-02"]),
]));
r.push(R("A Week Without Phones", "Last month my family tried an experiment: no phones at dinner. At first, it felt strange. My brother kept looking at the empty place beside his plate, and Dad did not know what to do with his hands. By the third night, though, we were talking about everything: school, Grandma's garden, even our silly dreams. I am not saying phones are bad. But I realized that I had not heard my father laugh like that in a long time. Maybe the best conversations start when nothing is buzzing.", [
  q("What is the writer's opinion?", "Putting phones away can improve family time", ["Phones should be thrown away", "Dinner should be eaten quickly", "Grandma's garden is the best topic"], "휴대폰을 치우면 대화가 풍부해진다는 것이 필자의 생각이에요.", ["9영01-06"]),
  q("Why did Dad \"not know what to do with his hands\"?", "He was used to holding his phone", ["He had burned his fingers", "He wanted to leave the table", "He was too tired to eat"], "평소 휴대폰을 들고 있던 습관 때문에 손이 어색했던 거예요.", ["9영01-07"]),
  q("What can we infer from \"I am not saying phones are bad\"?", "The writer wants to avoid a one-sided view", ["The writer bought a new phone", "The writer lost a phone recently", "The writer dislikes his brother"], "휴대폰을 무조건 비난하지 않으려는 균형 잡힌 태도예요.", ["9영01-07"]),
  q("What does the last sentence suggest?", "Quiet moments help people connect", ["Noise makes people tired", "Buzzing is a type of music", "Dinner should start earlier"], "아무것도 울리지 않을 때 좋은 대화가 시작된다는 의미예요.", ["9영01-03"]),
]));
r.push(R("A Cold Bowl of Soup", "To the manager of Blue Door Restaurant, I visited your restaurant last Friday for my mother's birthday. We waited forty minutes for our food, and the soup arrived cold. When we told the waiter, he only said, \"The kitchen is busy.\" I understand that Fridays are hard, and the dessert was delicious. However, a birthday dinner should not feel like a test of patience. I hope you will train your staff to respond more kindly. I would like to visit again, and I hope the next experience will be better. Sincerely, Hana Kim", [
  q("Why did Hana write this letter?", "To complain about the service she received", ["To book a table for her mother", "To ask for a job at the restaurant", "To thank the manager for dessert"], "서비스에 대한 불만을 전달하는 항의 편지예요.", ["9영01-06"]),
  q("How would you describe the tone of the letter?", "Polite but disappointed", ["Cheerful and silly", "Angry and rude", "Scared and nervous"], "공손하지만 실망한 어조가 드러나요.", ["9영01-06"]),
  q("What does the writer mean by \"a test of patience\"?", "The waiting was too long to enjoy", ["The restaurant gave a quiz", "The soup was too spicy", "The dessert was hard to eat"], "오래 기다리는 것이 인내심 시험 같았다는 비유예요.", ["9영01-07"]),
  q("What can be inferred about Hana?", "She may come back if things improve", ["She will never visit the place again", "She often eats there on Fridays", "She works in the kitchen herself"], "다음에는 더 좋기를 바라며 다시 방문하고 싶다고 했어요.", ["9영01-07"]),
]));
r.push(R("Biscuit Comes Home", "When Biscuit did not come home for dinner, Ben's chest felt tight. He walked up and down the street, calling the dog's name until his voice was rough. Mrs. Lopez from next door opened her window. \"I heard a noise in my garden shed this afternoon,\" she said. Ben ran there, pulled the door open, and found Biscuit asleep on a pile of old blankets, with a half-eaten bone beside him. Ben laughed so hard that he sat down on the grass. Then he hugged the dog and said, \"Next time, please tell me where you are going.\"", [
  q("How did Ben feel at the beginning?", "Worried", ["Relaxed", "Embarrassed", "Curious"], "가슴이 조이는 느낌이라고 했으므로 걱정스러운 상태예요.", ["9영01-05"]),
  q("Why did Ben laugh when he found Biscuit?", "He felt relieved and amused", ["He thought the shed was funny", "He was angry at Mrs. Lopez", "He forgot about dinner"], "안심되고 우스꽝스러운 상황이라 웃음이 터진 거예요.", ["9영01-05"]),
  q("What can we infer about Biscuit?", "He had been eating and sleeping in the shed", ["He ran away from home forever", "He was hurt by a loud noise", "He belonged to Mrs. Lopez"], "뼈다귀를 먹다 만 채 담요 위에서 자고 있었어요.", ["9영01-07"]),
  q("The expression \"his voice was rough\" suggests that Ben", "had called out for a long time", ["had a cold in winter", "was singing a song", "was whispering to the dog"], "오래 불러서 목소리가 쉬었다는 뜻이에요.", ["9영01-07"]),
]));
r.push(R("Later School Mornings", "Many teenagers feel tired at school because their bodies naturally want to sleep later at night and wake up later in the morning. Researchers say this change in the body clock is normal at this age. In one town, a school moved its first class from 8:00 to 9:00. After a year, students were late less often, and many said they paid more attention in class. Of course, a later start also means a later finish, which may be difficult for sports teams. Still, the results suggest that a small change can make a big difference.", [
  q("What is the main idea of the passage?", "A later start time may help students", ["Teenagers should sleep during class", "Sports teams need more practice", "Schools should have no first class"], "등교 시간이 늦춰지면 학생들에게 도움이 될 수 있다는 내용이에요.", ["9영01-03"]),
  q("Why do teenagers feel sleepy in the morning?", "Their body clocks shift later", ["They study too many subjects", "They wake up for sports teams", "They do not like breakfast"], "청소년기에는 체내 시계가 늦어진다고 했어요.", ["9영01-04"]),
  q("The phrase \"a small change can make a big difference\" refers to", "moving the class start by one hour", ["buying new school desks", "taking a year off from school", "adding a sports team"], "한 시간 늦춘 것이 큰 차이를 만들었다는 뜻이에요.", ["9영01-07"]),
  q("What is mentioned as a possible problem?", "Sports teams may have trouble with time", ["Students might be late more often", "Teachers will lose their classrooms", "Parents will have to drive more"], "늦게 끝나면 운동부에 어려움이 있을 수 있다고 했어요.", ["9영01-02"]),
]));
r.push(R("Not What I Expected", "I almost did not go to see the new animated film. The poster looked childish, and my friends said it was only about a talking turtle. I expected to check my watch every ten minutes. Instead, I found myself holding my breath during the storm scene, and I was surprised to feel sad when the turtle said goodbye to his friends. The jokes are clever enough for adults, too. The only weak part is the ending, which feels a little rushed. If you like stories about friendship, give this one a chance.", [
  q("What is the writer's overall opinion of the film?", "Better than expected, with a small weakness", ["Boring from start to finish", "Perfect without any problems", "Too scary for most viewers"], "기대보다 훨씬 좋았지만 결말이 서두른 느낌이라고 했어요.", ["9영01-06"]),
  q("Why did the writer expect to \"check my watch every ten minutes\"?", "He thought the film would be dull", ["He had to catch a bus soon", "He was waiting for a friend", "He liked to count the minutes"], "지루할 거라 예상했다는 뜻이에요.", ["9영01-07"]),
  q("Which scene made the writer hold his breath?", "The storm scene", ["The goodbye scene", "The final scene", "The opening joke scene"], "폭풍 장면에서 숨을 죽였다고 했어요.", ["9영01-02"]),
  q("Who is the passage mainly written for?", "People who enjoy friendship stories", ["People who work with turtles", "People who make animated films", "People who dislike jokes"], "마지막 문장이 우정 이야기를 좋아하는 사람에게 권하고 있어요.", ["9영01-06"]),
]));
r.push(R("Vote for Daniel", "Hello, everyone. My name is Daniel, and I want to be your student council president. Some people ask, \"What can one student change?\" Last spring, I asked for a bike rack near the gate, and now thirty bikes are parked there every day. If I win, I will ask the school to open the gym for free play on rainy lunch breaks, and I will start a book swap on the first Friday of each month. I cannot promise that everything will be easy. But I promise to listen, and I promise to try. Thank you.", [
  q("What is the speaker's main purpose?", "To persuade students to vote for him", ["To ask for new bicycles", "To say goodbye to his classmates", "To report on a school event"], "학생회장 선거 연설로, 표를 얻기 위한 글이에요.", ["9영01-06"]),
  q("Why does Daniel mention the bike rack?", "To prove that he can make real changes", ["To complain about parked bikes", "To show he is good at sports", "To ask for another rack"], "자전거 보관대 사례는 자신의 실행력을 보여 주는 근거예요.", ["9영01-06"]),
  q("What does \"I cannot promise that everything will be easy\" suggest?", "Daniel is honest about the challenges", ["Daniel plans to quit soon", "Daniel dislikes hard work", "Daniel has lost the election"], "쉽지 않을 것을 인정하는 솔직한 태도를 보여 줘요.", ["9영01-07"]),
  q("When will the book swap take place?", "Once a month", ["Every rainy day", "At each lunch break", "Only in spring"], "매월 첫 금요일이라고 했으므로 한 달에 한 번이에요.", ["9영01-02"]),
]));
r.push(R("Caring for a Cactus", "Many people believe a cactus needs almost no care, but this idea can actually kill the plant. First, put it by a bright window, because it needs at least four hours of sunlight. Second, water it only when the soil is completely dry, usually every two or three weeks. Too much water makes the roots rot, which is the most common reason cacti die. Finally, use a pot with holes in the bottom so that extra water can escape. Follow these steps, and your cactus may live for many years.", [
  q("What is the main purpose of the passage?", "To explain how to keep a cactus healthy", ["To argue that cacti are dangerous", "To sell pots with holes", "To describe a desert trip"], "선인장 관리 방법을 설명하는 글이에요.", ["9영01-03"]),
  q("What can we infer about watering a cactus?", "Giving it too much water is harmful", ["It needs water every single day", "It never needs any water", "Cold water is worse than warm water"], "과습이 뿌리를 썩게 해 가장 흔한 사망 원인이라고 했어요.", ["9영01-07"]),
  q("Why should the pot have holes in the bottom?", "To let extra water drain out", ["To give the roots more sunlight", "To keep insects out of the soil", "To make the pot lighter"], "남는 물이 빠져나가도록 하기 위해서예요.", ["9영01-04"]),
  q("The word \"rot\" is closest in meaning to", "decay", ["grow", "dry", "shine"], "rot은 '썩다'라는 뜻으로 decay와 가까워요.", ["9영01-07"]),
]));
r.push(R("Where Have the Bees Gone?", "In some parts of the world, farmers have noticed that fewer bees are visiting their fields. This matters because bees carry pollen from flower to flower, and many fruits and vegetables cannot grow without it. Scientists believe that several things are to blame, including strong chemicals, disease, and the loss of wild flowers. Some towns have begun planting gardens for bees along roads and on roofs. One researcher said, \"If we help the bees, we are really helping ourselves.\" It is a reminder that small animals can have a huge effect on our meals.", [
  q("What is the passage mainly about?", "Why bees matter to human food", ["How to build a honey farm", "Which flowers smell the best", "Where roof gardens are sold"], "벌이 줄어드는 문제와 그것이 식량에 주는 영향을 다뤄요.", ["9영01-03"]),
  q("What does the researcher mean by \"we are really helping ourselves\"?", "Protecting bees also protects our food", ["Bees will give us free honey", "Researchers need more money", "Farmers should keep pets"], "벌을 돕는 것이 곧 우리의 식량을 지키는 일이라는 뜻이에요.", ["9영01-07"]),
  q("Which is NOT given as a cause of the problem?", "Too many farmers planting wild flowers", ["Strong chemicals", "Disease among bees", "The loss of wild flowers"], "야생화 감소가 원인이지 야생화를 심는 것이 원인은 아니에요.", ["9영01-02"]),
  q("What does the writer want readers to realize?", "Small animals can greatly affect daily life", ["Bees are more important than fruit", "Scientists cannot solve problems", "Roads should be closed to cars"], "작은 동물이 우리 식탁에 큰 영향을 준다는 점이에요.", ["9영01-03"]),
]));
r.push(R("The Missed Train", "Yuri watched the last train leave the platform just as she reached the stairs. It was already nine o'clock, her phone battery was at two percent, and she had never been in this city alone. A young man in a blue jacket noticed her worried face. \"Where do you need to go?\" he asked. After she explained, he showed her the way to a night bus and even waited with her until it came. When she tried to thank him, he only shrugged and said, \"Someone did the same for me once.\" On the bus, Yuri decided she would pass that kindness on.", [
  q("What problem did Yuri have at the start?", "She had missed the final train", ["She had lost her phone", "She had forgotten the city's name", "She had no money for a ticket"], "막차를 놓쳤어요.", ["9영01-02"]),
  q("What does \"Someone did the same for me once\" suggest about the young man?", "He once received similar help himself", ["He works for the train company", "He is a friend of Yuri's family", "He often misses trains"], "예전에 누군가 자신을 도와준 적이 있다는 뜻이에요.", ["9영01-07"]),
  q("How did Yuri most likely feel at the end?", "Thankful and inspired", ["Bored and sleepy", "Jealous and upset", "Afraid and angry"], "친절을 다른 사람에게도 전하겠다고 결심했으므로 감사하며 감동한 상태예요.", ["9영01-05"]),
  q("Why is her phone battery mentioned?", "It shows how hard it was to get help", ["It explains why the bus was late", "It proves the man was rich", "It tells us the train's price"], "배터리가 거의 없어서 혼자 해결하기 어려운 상황이었음을 강조해요.", ["9영01-04"]),
]));
r.push(R("A Request for More Time", "Dear Mr. Kim, I am sorry to bother you. I am writing about the science report due this Friday. I have finished the experiment, but last week I had a bad flu and missed three days of school, so I have not been able to write the conclusion. I think I need two more days to do it properly. I understand that this is a lot to ask, and I will accept a lower score if you think it is fair. I would be very grateful for your understanding. Thank you for your time. Sincerely, Jiho Park", [
  q("Why did Jiho write this email?", "To ask for an extension on a report", ["To complain about a low score", "To report that he is sick today", "To invite Mr. Kim to his lab"], "마감 연장을 부탁하는 이메일이에요.", ["9영01-06"]),
  q("What is the reason for his request?", "Illness caused him to miss school", ["The experiment failed completely", "He forgot about the report", "The teacher changed the topic"], "독감으로 사흘 결석했다고 했어요.", ["9영01-04"]),
  q("What does the sentence \"I will accept a lower score\" show about Jiho?", "He is willing to take responsibility", ["He does not care about science", "He wants to quit the class", "He thinks the teacher is unfair"], "더 낮은 점수도 받아들이겠다는 것은 책임을 지려는 태도예요.", ["9영01-06"]),
  q("What is the tone of the email?", "Respectful and apologetic", ["Humorous and relaxed", "Demanding and impatient", "Excited and proud"], "정중하고 미안해하는 어조예요.", ["9영01-06"]),
]));
r.push(R("Flea Market for Paws", "Come to the Oakwood Flea Market this Sunday from 10 a.m. to 4 p.m.! Neighbors will sell books, toys, plants, and homemade snacks. Every dollar earned at the red tables goes to Safe Paws, a small shelter that takes care of stray dogs and cats. Last year, our market paid for winter blankets for forty animals. If you have items to donate, drop them off at the school gym on Saturday morning. Bring a bag, bring a friend, and, if you cannot find anything to buy, you can still help by saying hello to the volunteers.", [
  q("What is the purpose of this poster?", "To invite people to a charity event", ["To advertise a new pet shop", "To announce a school holiday", "To warn people about stray dogs"], "동물 보호소를 돕는 자선 행사에 초대하는 포스터예요.", ["9영01-06"]),
  q("What happens to the money from the red tables?", "It supports a shelter for animals", ["It pays for the school gym", "It is divided among the sellers", "It buys snacks for the volunteers"], "빨간 테이블의 수익은 Safe Paws에 기부돼요.", ["9영01-02"]),
  q("Why does the poster mention last year's blankets?", "To show how the money was used", ["To ask for warmer clothes", "To say winter has started", "To advertise a blanket sale"], "지난해 수익이 어떻게 쓰였는지 보여 주는 예시예요.", ["9영01-04"]),
  q("What can we infer from the last sentence?", "Visitors are welcome even if they buy nothing", ["Everyone must bring a friend", "The market will close if no one buys", "Volunteers are paid for chatting"], "아무것도 사지 않아도 인사만으로 도울 수 있다고 하니 방문 자체가 환영받아요.", ["9영01-07"]),
]));
r.push(R("Grandma's Sewing Machine", "In the corner of Grandma's room sits an old sewing machine with a black body and a gold flower on its side. When I was small, I thought it was a sleeping animal. Grandma used it to make every school bag I ever carried. Last winter, her hands became too weak to sew, and the machine fell silent. Yesterday I found a piece of cloth in the drawer and asked her to show me how to start. She laughed, put her wrinkled hand over mine, and said, \"Slowly, slowly. The machine will tell you what it wants.\"", [
  q("What does the sentence \"the machine fell silent\" mean?", "Grandma stopped sewing with it", ["The machine was thrown away", "The machine made a strange noise", "The writer broke the machine"], "할머니가 더 이상 재봉틀을 쓰지 않게 되었다는 뜻이에요.", ["9영01-07"]),
  q("Why did the writer think it was a \"sleeping animal\"?", "The writer was a small child then", ["It made a snoring sound", "It was kept in the garden", "Grandma named it after a pet"], "어렸을 때의 상상이었다는 것이 맥락이에요.", ["9영01-04"]),
  q("What does the scene at the end suggest?", "A skill is being passed to a new generation", ["Grandma wants to sell the machine", "The writer dislikes old things", "The cloth in the drawer was brand new"], "할머니가 손녀 손을 잡고 가르치며 기술이 이어지는 장면이에요.", ["9영01-07"]),
  q("What feeling is shown between the two people?", "Warm affection", ["Deep anger", "Sudden fear", "Cold distance"], "웃으며 손을 포개는 모습에서 따뜻한 애정이 느껴져요.", ["9영01-05"]),
]));
r.push(R("Bike Sharing Comes to Town", "Since spring, red bicycles have appeared at forty stations around our city. You scan a code with your phone, ride for as long as you like, and leave the bike at any station. The first thirty minutes cost nothing, and after that, a small fee is charged. The city says that more than ten thousand trips are taken each week. Not everyone is happy, though. Some shop owners complain that bikes are left on the sidewalk, and older residents say the roads are not safe enough. The city has promised to add bike lanes next year.", [
  q("What is the passage mainly about?", "A new bike program and reactions to it", ["How to repair a red bicycle", "Why shops are closing downtown", "A race held in the city center"], "자전거 공유 서비스와 그에 대한 반응을 다뤄요.", ["9영01-03"]),
  q("What can be inferred from \"The city has promised to add bike lanes next year\"?", "Safety concerns are being taken seriously", ["Bike sharing will end soon", "Cars will be banned from roads", "The fee will be removed"], "시가 안전 우려에 대응하려 한다는 것을 알 수 있어요.", ["9영01-07"]),
  q("When must a rider pay?", "After using a bike for half an hour", ["Before scanning the code", "When leaving the bike at a station", "Only on weekends"], "처음 30분은 무료이고 이후에 요금이 부과돼요.", ["9영01-02"]),
  q("Who is unhappy with the program?", "Some shop owners and older residents", ["Most of the riders", "The city's mayor", "The children in the city"], "상점 주인과 노인 주민들이 불만을 제기했어요.", ["9영01-02"]),
]));
r.push(R("After the Final Whistle", "The match ended 3-1, and our team had lost its first game of the season. Nobody spoke in the locker room. Coach Reyes waited until everyone had taken off their shoes. \"I am not going to say that losing is fine,\" she began. \"But I watched the second half, and I saw ten players running for each other. That is what I came here to see.\" She smiled for the first time that day. \"Tonight, rest. Tomorrow, we begin to fix the passing. Understood?\" A few of us laughed, and the room felt a little lighter.", [
  q("What is the coach's purpose in speaking to the team?", "To encourage the players after a loss", ["To blame them for the defeat", "To announce a change of schedule", "To introduce a new teammate"], "패배한 선수들을 격려하기 위한 말이에요.", ["9영01-06"]),
  q("Why did the coach wait before she spoke?", "She wanted the players to settle down first", ["She forgot what to say", "She was waiting for the referee", "She had lost her voice"], "신발을 벗고 진정할 때까지 기다린 거예요.", ["9영01-04"]),
  q("What does \"the room felt a little lighter\" mean?", "The mood became less heavy", ["The lights were turned on", "The players left the room", "The room became larger"], "분위기가 한결 가벼워졌다는 뜻이에요.", ["9영01-07"]),
  q("What does the coach want to improve next?", "The team's passing", ["The players' running", "The locker room", "The referee's decisions"], "내일 패스를 고치기 시작하겠다고 했어요.", ["9영01-02"]),
]));
r.push(R("Burnt Pancakes", "My first attempt at making pancakes for the family ended in smoke. I turned the heat too high, and the outsides turned black while the insides were still wet. My sister took one bite, made a face, and politely said, \"Interesting.\" Dad, however, ate two and called them \"crunchy.\" The second time, I used a lower heat and a timer, and the pancakes came out golden. I have learned that cooking is a lot like many other things: you rarely get it right the first time, and a good laugh helps you try again.", [
  q("What is the tone of the passage?", "Humorous and positive", ["Serious and angry", "Sad and hopeless", "Formal and cold"], "실패를 웃음으로 넘기는 유쾌하고 긍정적인 글이에요.", ["9영01-06"]),
  q("What did the sister's word \"Interesting\" really mean?", "She did not enjoy the taste", ["She wanted to make more", "She was learning to cook", "She liked the black color"], "표정을 찌푸리며 예의상 한 말이므로 맛이 없었다는 뜻이에요.", ["9영01-07"]),
  q("Why were the first pancakes ruined?", "The heat was set too high", ["The timer was broken", "There was too little flour", "Dad ate them too fast"], "불이 너무 세서 겉만 타고 속은 덜 익었어요.", ["9영01-04"]),
  q("What lesson does the writer draw?", "Mistakes are a normal part of learning", ["Pancakes should be crunchy", "Timers are never needed", "Cooking is easy for everyone"], "처음부터 잘하기 어렵고 웃으며 다시 시도하는 게 중요하다는 교훈이에요.", ["9영01-03"]),
]));
r.push(R("Parking Rules", "Notice to all residents of Maple Court: Beginning on the first of next month, cars may be parked only in marked spaces. Vehicles left in front of the fire exits or in the playground area will be removed at the owner's cost. Each household may register two cars. Visitors can use the blue spaces near the gate for up to four hours. We know that parking has become difficult since the new shop opened, but safety must come first. Please read the new map outside the management office, and contact us if you have any questions.", [
  q("What is the main purpose of this notice?", "To explain new parking rules", ["To advertise the new shop", "To ask for help in the playground", "To invite neighbors to a meeting"], "새 주차 규정을 알리는 공지예요.", ["9영01-06"]),
  q("Why are cars not allowed in front of fire exits?", "Because safety is the first concern", ["Because shops need more space", "Because visitors prefer blue spaces", "Because the map is outside the office"], "안전이 최우선이라는 말에서 이유를 알 수 있어요.", ["9영01-04"]),
  q("What can we infer from \"parking has become difficult since the new shop opened\"?", "More cars are coming into the area", ["The shop has closed already", "The residents moved away", "The playground was removed"], "새 가게가 생긴 뒤 차가 많아졌음을 짐작할 수 있어요.", ["9영01-07"]),
  q("How long can a visitor use a blue space?", "For up to four hours", ["For two days", "Only for one hour", "As long as they like"], "방문객은 최대 4시간까지 쓸 수 있어요.", ["9영01-02"]),
]));
r.push(R("Letter from a Pen Pal", "Dear Sam, Winter has finally arrived here in Sapporo, and the whole town is white. Last weekend, my class went to the snow festival. Teams from every school built huge snow statues, and at night, lights made them glow like glass. My favorite one was a dragon almost as tall as a house. We drank hot corn soup to keep warm, and my fingers were so cold that I could not hold my pen to take notes! I wish you could see it for yourself. Please write soon and tell me about winter in your country. Your friend, Aiko", [
  q("Why did Aiko write this letter?", "To share her experience and invite a reply", ["To ask Sam for a loan", "To complain about the cold", "To announce a trip to Sam's country"], "경험을 나누고 답장을 요청하는 편지예요.", ["9영01-06"]),
  q("What does \"the whole town is white\" mean?", "Snow covers the town", ["The houses were painted", "The town lost its power", "It is foggy every day"], "눈이 마을을 덮었다는 뜻이에요.", ["9영01-07"]),
  q("Why could Aiko not take notes at the festival?", "Her fingers were too cold to hold a pen", ["She forgot to bring a notebook", "The statues were too far away", "The lights were too bright"], "손가락이 너무 시려 펜을 잡을 수 없었어요.", ["9영01-04"]),
  q("What does \"I wish you could see it for yourself\" show?", "Aiko wants to share the moment with Sam", ["Aiko plans to visit Sam soon", "Aiko is sad about the festival", "Sam has seen the festival before"], "그 광경을 함께 보고 싶은 마음을 표현해요.", ["9영01-05"]),
]));
r.push(R("Paper or Screen?", "Many students now read on tablets and phones, but some studies suggest that paper may be better for deep reading. In one experiment, students who read a long story on paper remembered the order of events more clearly than those who read it on a screen. Researchers think this is because it is easier to feel the length of a book and to flip back to earlier pages. However, the same studies found that screens are useful for short texts and quick searches. The best choice probably depends on what you are reading and why you are reading it.", [
  q("Which sentence best expresses the writer's view?", "Each type of reading has its own best use", ["Paper should replace all screens", "Tablets are better than books", "Reading is no longer important"], "읽는 목적과 종류에 따라 최선이 달라진다는 결론이에요.", ["9영01-03"]),
  q("The word \"suggest\" in the first sentence is closest to", "indicate", ["order", "forget", "refuse"], "suggest는 '시사하다'로 indicate와 가까워요.", ["9영01-07"]),
  q("What is one reason paper may help memory?", "Readers can feel how far they are in the book", ["Paper makes pages louder", "Screens use less light", "Books have more pictures"], "분량을 몸으로 느끼고 앞 페이지로 쉽게 넘길 수 있기 때문이에요.", ["9영01-04"]),
  q("When are screens described as useful?", "For quick searches and short texts", ["For long stories only", "For reading in a bright garden", "For remembering numbers"], "짧은 글과 빠른 검색에는 화면이 유용하다고 했어요.", ["9영01-02"]),
]));
r.push(R("The Volcano That Would Not Erupt", "Nari had worked on her science fair volcano for two weeks. She had painted the sides brown and gray and made a tiny village at the bottom. When the judges arrived, she poured in the baking soda and vinegar, but only a few bubbles crept out. Her face turned hot. Then one of the judges smiled and said, \"I like that you put a village there. Tell me, what do you think went wrong?\" Nari took a breath and explained that she had measured the baking soda by eye. Afterward, she wrote in her notebook: \"Measure first, wonder later.\"", [
  q("How did Nari feel when the volcano failed?", "Embarrassed", ["Excited", "Sleepy", "Satisfied"], "얼굴이 화끈거린다는 표현에서 당황한 마음을 알 수 있어요.", ["9영01-05"]),
  q("Why did the judge ask what went wrong?", "To see if Nari could learn from the mistake", ["To make Nari feel worse", "To end the contest early", "To decide who made the village"], "실패 원인을 스스로 설명하게 하는 것은 배움을 확인하려는 의도예요.", ["9영01-06"]),
  q("What was the real cause of the problem?", "The baking soda was not measured exactly", ["The vinegar was too cold", "The village was too heavy", "The judges came too early"], "눈대중으로 재서 양이 정확하지 않았어요.", ["9영01-02"]),
  q("What does Nari's note suggest she learned?", "Careful preparation matters in experiments", ["Volcanoes should be smaller", "Judges prefer simple models", "Vinegar is better than water"], "먼저 정확히 재라는 교훈이에요.", ["9영01-03"]),
]));
r.push(R("A Thank-You Note", "Dear volunteers, On behalf of the whole Riverside Care Home, I want to thank all twenty of you for last Saturday. When you arrived with your guitars and board games, I saw faces that I had not seen smile in weeks. Mr. Oh, who rarely speaks, even taught one of you to play a card game from his childhood. Your visit did more than fill an afternoon; it reminded our residents that they are not forgotten. We hope you will come again in the spring. With warm regards, Ms. Evans, Activities Manager", [
  q("What is the main purpose of this letter?", "To express thanks for a visit", ["To ask for money", "To announce new rules", "To invite people to work full-time"], "방문 봉사에 대한 감사 편지예요.", ["9영01-06"]),
  q("What does \"they are not forgotten\" suggest about the residents?", "They sometimes feel lonely", ["They have lost their memory", "They enjoy being alone", "They are planning to leave"], "잊히지 않았다고 상기시켜 주었다는 말은 외로움을 느낄 수 있음을 뜻해요.", ["9영01-07"]),
  q("Why is the story about Mr. Oh included?", "It shows how much the visit meant", ["It explains why cards are banned", "It proves he plays guitar", "It lists the volunteers' names"], "평소 말이 적은 분이 먼저 나선 사례는 방문의 의미를 보여 줘요.", ["9영01-04"]),
  q("What does the writer hope will happen?", "The volunteers will come back", ["The care home will be larger", "The games will be sold", "Mr. Oh will move away"], "봄에 다시 오기를 바란다고 했어요.", ["9영01-02"]),
]));
r.push(R("The Quiet Kettle", "Introducing the Calm Kettle, the first electric kettle that boils water without a single whistle. Its soft blue light slowly fades from bright to dark as the water heats, so you can read, study, or simply think while you wait. A safety switch turns the kettle off by itself when the water is ready, and the handle stays cool to the touch. Whether you are a student studying late at night or a parent with a sleeping baby, you will never have to say \"shh\" to your tea again. Available in white, gray, and green.", [
  q("What is the main purpose of this text?", "To persuade readers to buy a product", ["To teach how to make tea", "To compare two kettles", "To report a safety accident"], "제품을 소개해 구매를 유도하는 광고예요.", ["9영01-06"]),
  q("Who would be the most likely customer?", "Someone who needs a quiet room", ["Someone who loves loud music", "Someone who never drinks tea", "Someone who sells kettles"], "소음이 없다는 점이 강조된 광고예요.", ["9영01-07"]),
  q("What does \"you will never have to say 'shh' to your tea\" mean?", "The kettle will not make disturbing noise", ["The tea will be too hot to drink", "Tea must be kept in silence", "The kettle talks to the user"], "주전자 소리가 방해되지 않는다는 재치 있는 표현이에요.", ["9영01-07"]),
  q("What does the safety switch do?", "It turns the kettle off when water is ready", ["It makes the light brighter", "It cools the water quickly", "It locks the handle at night"], "물이 끓으면 스스로 꺼져요.", ["9영01-02"]),
]));
r.push(R("Sleep and the Teenage Brain", "Many teenagers believe that staying up late to study will help them do well on a test. In fact, the opposite is often true. During sleep, the brain moves new information from short-term memory to long-term memory, so skipping sleep can make it harder to remember what you learned. A tired mind is also slower at solving problems and quicker to get upset. Experts recommend eight to ten hours of sleep for teenagers. Turning off screens an hour before bed and keeping the room dark are two easy ways to start.", [
  q("What is the writer's main message?", "Enough sleep is important for learning", ["Studying at night is the best way", "Screens help the brain relax", "Tests should be held at night"], "충분한 수면이 학습에 중요하다는 글이에요.", ["9영01-03"]),
  q("What does \"the opposite is often true\" mean here?", "Staying up late often hurts test results", ["Late studying always gives high scores", "Tests are easier at night", "Sleeping makes students upset"], "밤샘이 오히려 시험에 도움이 되지 않는다는 뜻이에요.", ["9영01-07"]),
  q("According to the passage, what happens during sleep?", "The brain stores new information for later", ["The brain stops working", "The body grows taller at once", "Tests are copied into memory"], "수면 중 단기 기억이 장기 기억으로 옮겨져요.", ["9영01-02"]),
  q("Which tip is given for better sleep?", "Keep the bedroom dark", ["Drink hot coffee at night", "Study until midnight", "Sleep with the lights on"], "방을 어둡게 하라는 팁이 있어요.", ["9영01-02"]),
]));
r.push(R("The Man with the Bread", "Every afternoon at four o'clock, an old man sat on the same bench and opened a paper bag full of bread crumbs. Pigeons landed at his feet as if they had received an invitation. Eli, who passed the park on his way home, began to notice that the man never looked at his watch and never seemed to be waiting for anyone. One day, Eli stopped and said hello. The old man's face lit up. \"I used to come here with my wife,\" he said, tossing a crumb. \"Now these fellows keep me company.\"", [
  q("What can we infer about the old man?", "He misses his wife and feels lonely", ["He sells bread to pigeons", "He is afraid of birds", "He works at the park office"], "아내와 함께 오곤 했고 지금은 새들이 동무라는 말에서 외로움을 알 수 있어요.", ["9영01-07"]),
  q("What does \"as if they had received an invitation\" suggest about the pigeons?", "They came without any fear", ["They were forced to leave", "They were angry at the man", "They could read a letter"], "초대받은 듯 자연스럽게 모여든다는 뜻이에요.", ["9영01-07"]),
  q("Why did the man's face \"light up\" when Eli spoke?", "He was glad to have someone to talk to", ["He wanted to sell the bench", "He thought Eli was his son", "He had finished the bread"], "말 걸어 주는 사람이 있어 기뻤다는 뜻이에요.", ["9영01-05"]),
  q("What is the meaning of \"keep me company\" in the last line?", "stay with me so I am not alone", ["follow me to my house", "work for my company", "eat all my bread"], "keep company는 '곁에 있어 주다'라는 뜻이에요.", ["9영01-07"]),
]));
r.push(R("You Are Invited", "Hi everyone! Mr. Lee is retiring after thirty-two years of teaching, and we are planning a party for him on Friday, June 12, at 4 p.m. in room 204. Please keep this a secret, because he thinks it will be a normal staff meeting! We are collecting messages and old photographs for a memory book, so please give yours to Sora by Wednesday. If you can bring a snack to share, that would be wonderful, but it is not required. Come with a big smile and a few good stories. See you there!", [
  q("Why is the writer sending this message?", "To invite people to a surprise party", ["To announce a staff meeting", "To ask Mr. Lee to retire", "To sell a memory book"], "깜짝 파티 초대 글이에요.", ["9영01-06"]),
  q("Why should people keep the party secret?", "Mr. Lee does not know about it", ["The room is too small", "Sora has lost the photographs", "The party is on a school night"], "Mr. Lee는 평범한 직원 회의로 알고 있어요.", ["9영01-04"]),
  q("What does \"it is not required\" mean about the snacks?", "Guests may choose whether to bring them", ["Snacks are forbidden", "Only Sora must bring snacks", "Snacks will be bought later"], "필수는 아니고 선택이라는 뜻이에요.", ["9영01-07"]),
  q("What should people give to Sora?", "Messages and old photographs", ["Snacks and drinks", "Tickets and money", "Homework and books"], "추억 책을 위한 메시지와 사진을 Sora에게 주라고 했어요.", ["9영01-02"]),
]));
r.push(R("Water at Our School", "Last month, the Green Team measured how much water our school used each day. The biggest surprise was the school yard: sprinklers ran for an hour every morning, even on rainy days. The team also found three taps in the restrooms that dripped all day, wasting about 20 liters. Together, these two problems used more water than the cafeteria. The team recommends adding a rain sensor to the sprinklers and fixing the taps this month. If both changes are made, the school could save enough water to fill an entire swimming pool every year.", [
  q("What is the purpose of this report?", "To suggest ways to save water", ["To praise the cafeteria workers", "To sell rain sensors", "To plan a swimming contest"], "물 사용을 조사하고 절약 방안을 제안하는 보고서예요.", ["9영01-06"]),
  q("What can we infer about the sprinklers?", "They do not respond to the weather", ["They are controlled by students", "They are used only on dry days", "They are broken in every season"], "비 오는 날에도 켜진다고 했으므로 날씨에 반응하지 않아요.", ["9영01-07"]),
  q("Which place used the most water, according to the passage?", "The yard and restroom taps together", ["The cafeteria alone", "The swimming pool", "The teachers' room"], "스프링클러와 수도꼭지 두 문제가 급식실보다 더 많이 썼어요.", ["9영01-02"]),
  q("What is the writer's attitude to the problem?", "Practical and hopeful", ["Hopeless and tired", "Careless and rude", "Frightened and shocked"], "해결책을 제시하며 기대하는 현실적이고 희망적인 태도예요.", ["9영01-06"]),
]));
r.push(R("My First Week at a New School", "On Monday, I walked into a hallway full of strangers, and I felt like a fish in the wrong pond. Nobody was unkind, but nobody knew my name either. At lunch, I sat alone and pretended to be interested in my rice. On Wednesday, a girl named Hyeri asked if I liked drawing, because she had noticed the sketchbook in my bag. By Friday, we were sharing pencils and jokes. I still miss my old friends, but this school no longer feels like somebody else's home.", [
  q("What does \"a fish in the wrong pond\" mean?", "The writer felt out of place", ["The writer was fond of swimming", "The writer was lost in a park", "The writer wanted to catch a fish"], "낯선 곳에서 어울리지 못하는 기분을 비유한 표현이에요.", ["9영01-07"]),
  q("Why did the writer pretend to be interested in the rice?", "To avoid showing loneliness", ["To finish eating quickly", "To get more food", "To hide the sketchbook"], "혼자 있는 모습을 숨기려는 행동이에요.", ["9영01-05"]),
  q("How did Hyeri start the conversation?", "She noticed the writer's sketchbook", ["She shared her pencils", "She introduced the teacher", "She asked about the rice"], "가방 속 스케치북을 보고 그림을 좋아하느냐고 물었어요.", ["9영01-02"]),
  q("How does the writer feel by the end?", "More comfortable at the new school", ["Ready to go back to the old school", "Angry at Hyeri", "Bored with drawing"], "더 이상 남의 집 같지 않다고 했어요.", ["9영01-05"]),
]));
r.push(R("The Baker's Day", "Min-ho the baker gets up at 3 a.m. every day, long before the sun is up. By the time most people eat breakfast, he has already made two hundred loaves. \"The first hour is the hardest,\" he says, wiping flour from his face. \"After that, the smell of fresh bread wakes me up better than any coffee.\" He closes the shop at two in the afternoon, but his work does not end there; he must prepare the dough for tomorrow. When asked whether he gets tired, he laughs and says, \"Only when the oven is cold.\"", [
  q("What is the passage mainly about?", "A baker's early and busy daily routine", ["How to make a perfect loaf", "Why coffee is unhealthy", "A bakery that is closing down"], "제빵사의 이른 하루 일과를 소개해요.", ["9영01-03"]),
  q("What does the baker mean by \"Only when the oven is cold\"?", "He feels energetic when he is busy baking", ["He cannot work in winter", "He hates warm places", "He wants a new oven"], "오븐이 따뜻하게 돌아갈 때, 즉 일할 때는 피곤하지 않다는 재치 있는 말이에요.", ["9영01-07"]),
  q("When does Min-ho finish his work for the day?", "After preparing dough for the next day", ["At two o'clock exactly", "Before the sun rises", "As soon as breakfast ends"], "문을 닫은 후에도 내일 반죽을 준비해야 하므로 그때 끝나요.", ["9영01-02"]),
  q("What can we infer about Min-ho?", "He takes pleasure in his job", ["He wants to change jobs", "He drinks coffee all day", "He sleeps in the shop"], "빵 냄새가 커피보다 낫다며 웃는 모습에서 일을 즐긴다고 추론할 수 있어요.", ["9영01-07"]),
]));
r.push(R("Robots in the Hospital", "In one hospital, a small robot now delivers medicine and meals to the rooms of patients. It rolls through the halls, stops politely at elevators, and says, \"Excuse me,\" when people block its way. Nurses say that the robot saves them about two hours every day, which they can spend talking with patients. Some patients, however, miss seeing a human face at mealtime. The hospital plans to keep the robot but also ask nurses to say hello at each door. The goal is not to replace people but to give them more time to care.", [
  q("What is the main idea?", "Robots can free nurses to spend time with people", ["Robots will replace all nurses", "Patients prefer eating alone", "Elevators in hospitals are too slow"], "로봇이 간호사의 시간을 아껴 환자 돌봄에 쓰게 한다는 내용이에요.", ["9영01-03"]),
  q("Why do some patients feel uncomfortable?", "They miss seeing a person during meals", ["The robot is too loud", "The robot drops the medicine", "The food is always cold"], "식사 때 사람 얼굴을 보지 못해 아쉬워한다고 했어요.", ["9영01-04"]),
  q("What does the last sentence suggest about the hospital's attitude?", "People should remain the center of care", ["Machines are better than nurses", "Care costs too much money", "Robots should talk more"], "목표가 사람을 대체하는 것이 아니라 더 돌볼 시간을 주는 것이라는 뜻이에요.", ["9영01-06"]),
  q("The word \"deliver\" is closest in meaning to", "bring", ["break", "borrow", "build"], "deliver는 '배달하다'로 bring과 가까워요.", ["9영01-07"]),
]));
r.push(R("More Benches, Please", "To the editor: I walk through Central Park every morning, and I have noticed something worrying. There are only six benches along the main path, which is nearly two kilometers long. Last week, an elderly woman had to sit on a low stone wall to catch her breath. Parks are for everyone, not only for fast runners. I urge the city to add at least ten more benches, especially near the playground and the pond. Such a small investment would make a large difference to older visitors and to parents with small children. Yours truly, Henry Ross", [
  q("What is the writer's purpose?", "To ask the city to take action", ["To praise the park's cleanliness", "To advertise a running club", "To report an accident"], "벤치를 더 설치해 달라고 시에 요구하는 글이에요.", ["9영01-06"]),
  q("Why does he mention the elderly woman?", "To give a real example of the problem", ["To describe a popular sport", "To complain about stone walls", "To introduce a friend"], "구체적 사례로 문제를 보여 주는 거예요.", ["9영01-06"]),
  q("What does \"Parks are for everyone, not only for fast runners\" imply?", "Slower visitors need support too", ["Runners should leave the park", "Parks need a faster path", "Stone walls are for sitting"], "빠르지 않은 사람도 공원을 이용할 수 있어야 한다는 뜻이에요.", ["9영01-07"]),
  q("The phrase \"a small investment\" refers to", "building more benches", ["buying a playground", "paying for runners", "digging a new pond"], "벤치를 늘리는 비용이 작은 투자라는 뜻이에요.", ["9영01-07"]),
]));
r.push(R("The Night of the Storm", "The wind began to howl at dusk, and by midnight the little fishing village was shaking. Old Captain Roh checked the ropes on his boat for the third time and then went to the harbor bell. He rang it hard, again and again, so that everyone on the cliffs could hear. One by one, lights came on, and men and women hurried down to help move the boats. By dawn, the sea was calm. Not a single boat was lost. \"A bell is just a piece of metal,\" the captain said with a tired smile. \"It is the people who answer it.\"", [
  q("Why did Captain Roh ring the bell?", "To wake the village so people could help", ["To announce the end of the storm", "To call fish into the harbor", "To celebrate a birthday"], "마을 사람들을 깨워 도움을 요청하려는 거예요.", ["9영01-04"]),
  q("What does the captain's last sentence mean?", "Cooperation matters more than the tool itself", ["Metal is difficult to find", "Bells should be replaced", "The storm was not serious"], "종이 아니라 응답하는 사람들이 중요하다는 뜻이에요.", ["9영01-03"]),
  q("What can we infer about the village?", "Its people care for one another", ["Its boats are all very old", "Its captain is a stranger", "Its harbor is in a big city"], "종소리에 사람들이 모여 함께 배를 옮겼어요.", ["9영01-07"]),
  q("What happened by dawn?", "The sea became calm", ["The bell broke", "The boats sank", "The cliffs fell"], "새벽에는 바다가 잔잔해졌다고 했어요.", ["9영01-02"]),
]));
r.push(R("What Failure Teaches", "Many people think of failure as the opposite of success, but it is often a step toward it. A gardener who grows nothing in the first year learns which soil is too dry. A runner who stops halfway learns how to pace herself. Even a scientist whose experiment fails gains useful information, because now she knows one more thing that does not work. Of course, failure is never fun. It stings, and it can make us want to quit. Yet those who keep trying and think carefully about each mistake are the ones who finally find a way forward.", [
  q("What is the main idea of the passage?", "Failure can be a useful part of learning", ["Failure is always avoidable", "Gardeners cannot become scientists", "Runners should never stop"], "실패가 배움의 일부라는 내용이에요.", ["9영01-03"]),
  q("Why does the writer say the scientist \"gains useful information\"?", "She finds out one thing that does not work", ["She earns money from the test", "She wins a science prize", "She meets other scientists"], "실패한 방법 하나를 알게 되는 것도 정보라는 뜻이에요.", ["9영01-04"]),
  q("The word \"stings\" is used to show that failure", "causes a sharp feeling of pain", ["costs a lot of money", "makes a loud sound", "needs a doctor"], "stings는 마음이 따끔하게 아픈 느낌을 나타내요.", ["9영01-07"]),
  q("What is the writer's attitude toward failure?", "Realistic but encouraging", ["Fearful and strict", "Careless and funny", "Angry and hopeless"], "실패가 아프다는 것을 인정하면서도 격려해요.", ["9영01-06"]),
]));

// ---------- dialogues
const d = [];
d.push(D("Returning a Jacket", [
  "Clerk: Hello. How can I help you?",
  "Jin: Hi. I bought this jacket yesterday, but the zipper is stuck.",
  "Clerk: I see. Do you have your receipt with you?",
  "Jin: Yes, here it is. I'd like a refund, if possible.",
  "Clerk: I'm afraid we can only give a refund within seven days, but that is no problem. It's only been one day.",
  "Jin: Oh, good. Actually, I would prefer a different jacket in the same size.",
  "Clerk: Of course. The blue one over there is the same price. Would you like to try it on?",
  "Jin: Sure. And could you check that the zipper works before I leave?",
], [
  q("Why did Jin go to the shop?", "To deal with a faulty jacket", ["To buy a present for a friend", "To ask for a job", "To pay for a receipt"], "지퍼가 고장 난 재킷 문제를 해결하러 갔어요.", ["9영01-06"]),
  q("What does the clerk mean by \"that is no problem\"?", "The refund time limit is not an issue here", ["The shop is too busy today", "The jacket cannot be returned", "The clerk will not help"], "하루밖에 안 지나 7일 기한 내이므로 문제 없다는 뜻이에요.", ["9영01-07"]),
  q("What does Jin decide to do?", "Exchange the jacket for another one", ["Take the money and leave", "Keep the broken jacket", "Wait for the manager"], "환불 대신 같은 사이즈의 다른 재킷을 원했어요.", ["9영01-02"]),
  q("What can be inferred from Jin's last question?", "Jin is careful not to make the same mistake", ["Jin does not like the blue color", "Jin has no time to try it on", "Jin wants a lower price"], "새 재킷의 지퍼를 확인해 달라는 것은 같은 문제를 피하려는 신중함이에요.", ["9영01-07"]),
]));
d.push(D("Planning the Trip", [
  "Eun: Have you decided where to go for our class trip?",
  "Tom: Not yet. I like the science museum, but it is a bit expensive.",
  "Eun: How about the mountain park? We could walk, and it's cheap.",
  "Tom: That sounds nice, but the forecast says rain on Friday.",
  "Eun: Oh, I didn't check. Then maybe the museum is a safer choice.",
  "Tom: Right. If we ask everyone to bring a lunch, we can save money.",
  "Eun: Good idea. I'll write a note for the class tonight.",
], [
  q("What problem do Eun and Tom face?", "They must choose a place that suits the weather and budget", ["They have lost the class list", "They cannot find the science museum", "They disagree about lunch"], "비와 비용 때문에 장소를 고민하고 있어요.", ["9영01-04"]),
  q("Why does Tom reject the mountain park?", "Rain is expected on the day", ["It is too far from school", "It costs too much", "He dislikes walking"], "금요일에 비 예보가 있기 때문이에요.", ["9영01-04"]),
  q("What does Eun mean by \"a safer choice\"?", "Less likely to be spoiled by the weather", ["Cheaper than every other place", "Closer to her house", "Better for sports"], "비가 와도 영향이 적다는 의미예요.", ["9영01-07"]),
  q("What will Eun probably do next?", "Write a note about bringing lunch", ["Call the museum tonight", "Cancel the class trip", "Check the park's map"], "오늘 밤 학급에 알릴 쪽지를 쓰겠다고 했어요.", ["9영01-02"]),
]));
d.push(D("Asking for Advice", [
  "Ms. Cho: Come in, Sara. You look worried.",
  "Sara: I have been trying to write my essay, but I can't think of an ending.",
  "Ms. Cho: Can you tell me what the essay is about?",
  "Sara: It's about how my grandfather taught me to fish.",
  "Ms. Cho: That's lovely. What did you learn from him besides fishing?",
  "Sara: Well, patience, I suppose. He never got angry when I lost a fish.",
  "Ms. Cho: There's your ending. Finish with what he really taught you.",
  "Sara: Oh! I had been looking at the wrong part of the story. Thank you.",
], [
  q("Why did Sara visit Ms. Cho?", "She needed help finishing her essay", ["She wanted to learn how to fish", "She planned to change her topic", "She lost her grandfather's letter"], "에세이 결말을 짓지 못해 조언을 구하러 갔어요.", ["9영01-06"]),
  q("What is Ms. Cho's advice?", "End the essay with the lesson Sara learned", ["Add more fishing facts", "Write about a different person", "Start the essay again"], "할아버지에게 배운 진짜 교훈으로 끝맺으라는 조언이에요.", ["9영01-03"]),
  q("What does Sara mean by \"the wrong part of the story\"?", "She was focusing on the wrong thing", ["She misplaced a page", "She wrote the story backward", "She forgot the story's title"], "결말을 엉뚱한 곳에서 찾고 있었다는 뜻이에요.", ["9영01-07"]),
  q("How does Sara feel at the end?", "Relieved and thankful", ["Confused and upset", "Bored and tired", "Proud and jealous"], "해결책을 찾아 안도하고 감사해요.", ["9영01-05"]),
]));
d.push(D("The Messy Room", [
  "Mina: Joon, did you borrow my headphones again?",
  "Joon: No. Why would I do that?",
  "Mina: Because last week, you said you'd take them for a minute and kept them all weekend.",
  "Joon: That was different. I gave them back, didn't I?",
  "Mina: Only after I found them under your bed, next to a sock.",
  "Joon: Okay, okay. Let me check my room.",
  "Joon: Found them! They were behind the desk.",
  "Mina: So you did borrow them.",
  "Joon: Fine. Sorry. I'll ask next time.",
], [
  q("Why did Mina suspect Joon?", "He had taken her headphones before", ["He had broken them last week", "He was wearing them at home", "He never cleaned his room"], "지난주에 빌린 뒤 주말 내내 가져갔던 일이 있어서예요.", ["9영01-04"]),
  q("What is the meaning of \"That was different\" in Joon's line?", "He is trying to defend himself", ["He agrees with Mina", "He has changed his room", "He wants to buy new ones"], "자신을 변호하려는 말이에요.", ["9영01-07"]),
  q("What can be inferred from the end of the conversation?", "Joon did take the headphones this time", ["Mina found the headphones herself", "The headphones were never lost", "Joon bought new headphones"], "책상 뒤에서 찾았다는 것은 그가 가져간 것이라는 뜻이에요.", ["9영01-07"]),
  q("What does Joon promise?", "To ask before borrowing", ["To clean his room daily", "To give Mina a gift", "To stop listening to music"], "다음에는 먼저 묻겠다고 했어요.", ["9영01-02"]),
]));
d.push(D("A Lost Bag", [
  "Staff: Airport lost-and-found. How can I help?",
  "Ken: Hello, I flew in from Busan this morning, and I think I left my bag on the plane.",
  "Staff: Can you describe it?",
  "Ken: It's a small gray backpack with a red tag. There is a laptop inside.",
  "Staff: Do you remember your seat number?",
  "Ken: Yes, 14C. I put the bag under the seat in front of me.",
  "Staff: Please hold on. I'll check with the cleaning crew.",
  "Ken: Thank you. I have a presentation tomorrow, so this is really important.",
  "Staff: A gray backpack with a red tag has just been found. You can pick it up at Gate 5 in thirty minutes.",
], [
  q("What is the purpose of Ken's call?", "To find a bag he left behind", ["To book a flight to Busan", "To ask about plane tickets", "To complain about the cleaning crew"], "비행기에 두고 내린 가방을 찾으려는 전화예요.", ["9영01-06"]),
  q("Why does Ken say \"this is really important\"?", "He needs the laptop for tomorrow", ["He wants to sell the backpack", "He is angry at the staff", "He loves the red tag"], "내일 발표가 있기 때문이에요.", ["9영01-04"]),
  q("Why does the staff member ask for a seat number?", "To help the cleaning crew look in the right place", ["To decide the price of the bag", "To check if Ken paid", "To change Ken's seat"], "좌석 번호는 청소 팀이 정확한 위치를 찾게 도와줘요.", ["9영01-04"]),
  q("What will Ken probably do next?", "Go to Gate 5 and collect the bag", ["Fly back to Busan", "Call the cleaning crew", "Buy a new laptop"], "30분 뒤 5번 게이트에서 찾아가라고 안내받았어요.", ["9영01-02"]),
]));
d.push(D("Choosing a Club", [
  "Hana: Are you going to join the drama club?",
  "Leo: I'm not sure. I like acting, but I'm afraid of forgetting my lines.",
  "Hana: Everyone forgets them sometimes. Last year I froze on stage for ten seconds.",
  "Leo: Really? What did you do?",
  "Hana: I waited, smiled, and the other actor helped me. Nobody cared in the end.",
  "Leo: That's comforting. I'll come to the first meeting, at least.",
  "Hana: Great. If you hate it, you can leave. It costs nothing to try.",
], [
  q("What is Leo's concern?", "He might forget his lines on stage", ["He dislikes meeting new people", "He has no time after school", "He cannot afford the fee"], "대사를 잊을까 봐 걱정해요.", ["9영01-05"]),
  q("Why does Hana tell the story about last year?", "To make Leo feel less worried", ["To show that she is a better actor", "To explain why she left the club", "To ask for help with lines"], "자신의 실수를 들려주며 레오를 안심시키려는 의도예요.", ["9영01-06"]),
  q("What does \"It costs nothing to try\" mean?", "Leo has nothing to lose by joining once", ["The club is free for all students", "Trying costs ten dollars", "Leo should pay the next day"], "한 번 해보는 데 손해가 없다는 뜻이에요.", ["9영01-07"]),
  q("What will Leo do?", "Go to the first meeting", ["Leave the club right away", "Write a new play", "Talk to the teacher"], "첫 모임에 가 보겠다고 했어요.", ["9영01-02"]),
]));

// ---------- standalone m
const m = [];
m.push(M("Read the message.\n\n\"Sorry, my bus broke down. Start dinner without me!\"\n\nWhat can we infer about the writer?", "The writer will arrive late", ["The writer is cooking dinner", "The writer will skip the trip", "The writer has bought a bus"], "버스가 고장 나서 먼저 먹으라고 했으므로 늦게 도착할 것이에요.", ["9영01-07"]));
m.push(M("Read the sign.\n\n\"Please keep your voice down. Others are studying.\"\n\nWhere is this sign most likely found?", "In a reading room", ["On a football field", "In a shopping mall", "At a bus stop"], "조용히 하라는 안내이므로 열람실 같은 곳이에요.", ["9영01-07"]));
m.push(M("Read the text.\n\n\"The film starts at 7:30. Don't be late. I'm saving you a seat.\"\n\nWhat is the writer's purpose?", "To remind a friend about the time", ["To cancel the movie plans", "To thank the friend for tickets", "To review the film"], "시간을 상기시키고 자리를 맡아 두겠다는 메시지예요.", ["9영01-06"]));
m.push(M("Read the sentence.\n\n\"It's raining cats and dogs, so I'm staying in.\"\n\nWhat does \"raining cats and dogs\" mean?", "raining very hard", ["raining softly", "making animal noises", "clearing up"], "숙어로 비가 매우 세게 온다는 뜻이에요.", ["9영01-07"]));
m.push(M("Read the note.\n\n\"Mom, I fed the dog and took out the trash. Can I go to Dae's house now?\"\n\nWhat does the writer want?", "Permission to go out", ["Help with the homework", "Money for a new dog", "A ride to school"], "할 일을 했으니 친구 집에 가도 되는지 허락을 구하고 있어요.", ["9영01-06"]));
m.push(M("Read the sentence.\n\n\"Wow, you've been waiting an hour? You must be freezing.\"\n\nWhat does the speaker assume?", "The listener is very cold", ["The listener has just arrived", "The listener is hungry", "The weather is hot"], "must be는 강한 추측으로, 오래 기다려 추울 것이라고 짐작해요.", ["9영01-07"]));
m.push(M("Read the ad.\n\n\"Lost: a brown wallet near the library. Contains a student card. Reward offered.\"\n\nWhat does the writer want readers to do?", "Return the wallet if they find it", ["Buy a new wallet", "Visit the library at night", "Apply for a student card"], "분실물을 돌려 달라고 부탁하며 사례를 제안했어요.", ["9영01-06"]));
m.push(M("Read the dialogue.\n\nA: \"Could you tell me where the post office is?\"\n\nWhat is the speaker doing?", "Asking for directions", ["Giving an order", "Telling a story", "Refusing a request"], "Could you tell me ...?는 공손한 질문(문의)이에요.", ["9영01-06"]));
m.push(M("Read the post.\n\n\"Finally! After six months of practice, I ran 5 km without stopping. My legs hurt, but I'm smiling.\"\n\nHow does the writer feel?", "Proud and happy", ["Worried and lonely", "Bored and sleepy", "Angry and tired"], "연습 끝에 해낸 성취감과 기쁨이 드러나요.", ["9영01-05"]));
m.push(M("Read the sentence.\n\n\"Their offer sounds too good to be true.\"\n\nWhat does the speaker suggest?", "The offer may not be honest", ["The offer is the best ever", "The offer has expired", "The offer is free"], "지나치게 좋은 조건은 의심스럽다는 표현이에요.", ["9영01-07"]));
m.push(M("Read the text.\n\n\"Dear neighbors, the elevator will be out of order on Tuesday morning. We apologize for the trouble.\"\n\nWhat is the main purpose of this text?", "To announce a temporary inconvenience", ["To invite people to a party", "To ask for a new elevator", "To sell apartments"], "엘리베이터 사용이 잠시 불가함을 알려요.", ["9영01-06"]));
m.push(M("Read the conversation.\n\nA: \"I got the highest score in the class!\"\nB: \"I'm not surprised. You studied day and night.\"\n\nWhat does B imply?", "A has earned the result by working hard", ["A copied from other students", "A did not study at all", "A is lucky as usual"], "밤낮으로 공부했으니 놀랍지 않다는 말은 노력의 결과라는 뜻이에요.", ["9영01-07"]));
m.push(M("Read the sentence.\n\n\"He said he would call me back, but it's been a week.\"\n\nWhat does the speaker probably feel?", "Disappointed", ["Thrilled", "Sleepy", "Curious"], "일주일이 지나도록 전화가 없어 실망한 마음이에요.", ["9영01-05"]));
m.push(M("Read the label.\n\n\"Keep in a cool, dry place. Do not freeze.\"\n\nWhat can we infer about the product?", "Heat or ice could spoil it", ["It must be eaten hot", "It is sold only in summer", "It glows in the dark"], "너무 덥거나 얼어서는 안 된다는 보관 지침이에요.", ["9영01-07"]));
m.push(M("Read the text message.\n\n\"Running late! Can you tell the teacher I'll be there in ten minutes?\"\n\nWhat is the sender asking for?", "A message to be passed on", ["A ride to school", "A longer lunch break", "A copy of the homework"], "선생님께 늦는다고 대신 전해 달라는 부탁이에요.", ["9영01-06"]));
m.push(M("Read the sentence.\n\n\"She gave me a cold look when I sat in her seat.\"\n\nWhat does \"a cold look\" suggest?", "She was unhappy with the writer", ["She was feeling ill", "She wanted to say hello", "She was waiting for ice"], "cold look은 차갑고 불쾌한 시선을 뜻해요.", ["9영01-07"]));
m.push(M("Read the sentence.\n\n\"The shop windows were dark, and the door was locked. The sign on it said 'Back soon'.\"\n\nWhat can we infer?", "The owner has gone out for a while", ["The shop has closed forever", "The shop is open all night", "The shop is being painted"], "'곧 돌아옴'이라는 표지판은 잠시 자리를 비웠다는 뜻이에요.", ["9영01-07"]));
m.push(M("Read the review.\n\n\"The food was fine, but we waited an hour for our table. I would not go on a weekend.\"\n\nWhat is the writer advising?", "Avoid going at busy times", ["Order only desserts", "Bring your own food", "Book a hotel nearby"], "주말의 긴 대기를 피하라는 조언이에요.", ["9영01-06"]));
m.push(M("Read the text.\n\n\"Mr. Ahn is a man of few words, but when he speaks, everyone listens.\"\n\nWhat does \"a man of few words\" mean?", "someone who does not talk much", ["someone who cannot speak", "someone who writes books", "someone who talks all day"], "말수가 적은 사람을 뜻하는 표현이에요.", ["9영01-07"]));
m.push(M("Read the announcement.\n\n\"Passengers are asked to stay in their seats until the plane has come to a complete stop.\"\n\nWhy is this announcement made?", "For the passengers' safety", ["To sell more tickets", "To delay the flight", "To serve the meal"], "완전히 멈추기 전 일어나면 위험하기 때문이에요.", ["9영01-04"]));
m.push(M("Read the sentence.\n\n\"Hana studied all night, yet she looked fresh the next morning.\"\n\nWhat does \"yet\" show?", "A surprising contrast", ["A cause and result", "A time order", "An example"], "yet은 예상과 다른 대조를 나타내요.", ["9영01-04"]));
m.push(M("Read the sentences.\n\n\"The path was steep. Joon stopped twice to catch his breath, but he did not turn back.\"\n\nWhat does this tell us about Joon?", "He is determined", ["He is lazy", "He is lost", "He is angry"], "숨이 차도 돌아가지 않았으므로 의지가 강한 사람이에요.", ["9영01-07"]));
m.push(M("Read the sentence.\n\n\"If you have any trouble with the app, please contact our help desk.\"\n\nWhat kind of text is this most likely from?", "A user guide", ["A poem", "A weather report", "A diary"], "앱 문제 시 고객 지원에 연락하라는 안내문이에요.", ["9영01-06"]));
m.push(M("Read the message.\n\n\"Thanks for the book, but I already have a copy. I'll give it to my cousin, who loves mysteries.\"\n\nWhat is the writer's attitude?", "Grateful but practical", ["Furious and rude", "Nervous and shy", "Sad and lonely"], "고마워하면서도 이미 갖고 있음을 솔직히 말하고 활용 방안을 제시해요.", ["9영01-06"]));
m.push(M("Read the dialogue.\n\nA: \"Do you want to come to the movie?\"\nB: \"I'd love to, but I have a test tomorrow.\"\n\nWhat does B mean?", "B will probably not go", ["B will go gladly", "B has seen the movie", "B has no friends"], "I'd love to, but ...는 정중한 거절이에요.", ["9영01-07"]));
m.push(M("Read the sentence.\n\n\"The streets were empty, and every shop was closed. It must be a holiday.\"\n\nWhat clue leads to this idea?", "No people or open shops were seen", ["A loud parade passed by", "The speaker saw a calendar", "Many cars were parked"], "텅 빈 거리와 닫은 가게가 단서가 되어 휴일이라 추측해요.", ["9영01-07"]));
m.push(M("Read the sentence.\n\n\"The new rule was announced on Monday, and by Friday, almost everyone had stopped using plastic bags.\"\n\nWhat does this suggest about the rule?", "It was effective", ["It was ignored", "It was confusing", "It was removed"], "일주일 만에 대부분이 비닐봉지를 쓰지 않게 되었으므로 효과적이에요.", ["9영01-07"]));
m.push(M("Read the text.\n\n\"Please do not feed the animals. Human food can make them sick.\"\n\nWhat reason is given for the rule?", "Human food can harm the animals", ["The animals are shy", "The zoo needs more money", "Feeding takes too much time"], "사람 음식이 동물을 아프게 할 수 있다고 이유를 밝혔어요.", ["9영01-04"]));
m.push(M("Read the sentence.\n\n\"I'll believe it when I see it.\"\n\nWhat is the speaker's attitude?", "Doubtful", ["Delighted", "Frightened", "Grateful"], "직접 보기 전에는 믿지 못하겠다는 회의적인 태도예요.", ["9영01-07"]));
m.push(M("Read the notice.\n\n\"Entry is free for children under six. Adults pay five dollars.\"\n\nWho would NOT need to pay?", "A five-year-old child", ["A teacher", "A mother", "A ten-year-old"], "6세 미만은 무료이므로 5세 아이는 내지 않아요.", ["9영01-02"]));
m.push(M("Read the sentence.\n\n\"Sora packed an umbrella, a raincoat, and boots, even though the sky was clear.\"\n\nWhat can we say about Sora?", "She likes to be prepared", ["She dislikes rain", "She forgot the date", "She is going swimming"], "맑은 날에도 우비를 챙겼으므로 대비하는 성격이에요.", ["9영01-07"]));
m.push(M("Read the note.\n\n\"Dear Ms. Lee, I'm sorry I forgot the key. It won't happen again. I'll bring it tomorrow.\"\n\nWhat is the writer's purpose?", "To apologize and promise to improve", ["To ask for a new key", "To blame Ms. Lee", "To thank Ms. Lee"], "사과와 앞으로의 약속이 담긴 쪽지예요.", ["9영01-06"]));
m.push(M("Read the sentence.\n\n\"He answered the question so quickly that the teacher was surprised.\"\n\nWhat does the sentence show?", "The result of how fast he answered", ["A wish about the future", "A rule of the class", "A past habit"], "so ... that 구문으로 빠른 대답이 낳은 결과를 나타내요.", ["9영01-04"]));
m.push(M("Read the sentence.\n\n\"The coach praised the team not for winning, but for playing fairly.\"\n\nWhat does the coach value most?", "Fair play", ["Winning at any cost", "Being famous", "Practicing less"], "승리가 아니라 정정당당한 경기를 칭찬했어요.", ["9영01-03"]));
m.push(M("Read the text.\n\n\"Our robot vacuum cleans your floors while you are out, so you can come home to a tidy house.\"\n\nWhat is the writer trying to do?", "Make the product sound useful", ["Warn about dust", "Teach cleaning skills", "Report a robot problem"], "제품의 장점을 강조해 구매를 유도하는 광고 문구예요.", ["9영01-06"]));
m.push(M("Read the sentence.\n\n\"Dae-ho put his phone away and looked his grandmother in the eye.\"\n\nWhat does this action suggest?", "He wanted to give her full attention", ["He was about to leave", "He was feeling shy", "He lost his phone"], "휴대폰을 치우고 눈을 맞추는 행동은 집중해서 듣겠다는 태도예요.", ["9영01-07"]));
m.push(M("Read the sentences.\n\n\"The lights went out during the test. For a moment, no one moved. Then the teacher said, 'Stay calm.'\"\n\nWhy did the teacher say this?", "To keep students from panicking", ["To end the test", "To turn on the lights", "To start a game"], "정전이 일어나 학생들을 진정시키려는 말이에요.", ["9영01-06"]));
m.push(M("Read the sentence.\n\n\"My grandfather's garden is small, but it gives us enough tomatoes for the whole summer.\"\n\nWhat does \"but\" show here?", "The garden is better than its size suggests", ["The garden is too big", "The tomatoes are not red", "Summer is too short"], "작지만 충분하다는 대조를 나타내요.", ["9영01-04"]));

// ---------- sentences (s)
const S = (good, ko, bad, cz, rule, extra) => ({ k: "s", good, ko, bad, cz, rule, ...extra });
const s = [];
s.push(S("He must be tired after the long trip.", "긴 여행 뒤라 그는 피곤할 거야.", ["He must tired after the long trip.", "He must is tired after the long trip.", "He must to be tired after the long trip."], { st: "He ___ tired after the long trip.", ok: "must be", wr: ["must", "must to be", "must is"] }, "must + be는 현재 사실에 대한 강한 추측('~임에 틀림없다')이에요. must 뒤에는 동사원형이 와요.", { hint: "확신하는 추측을 나타내는 조동사를 생각해 보세요." }));
s.push(S("That can't be Jina's bag because hers is red.", "그건 지나의 가방일 리 없어. 그녀의 것은 빨간색이거든.", ["That can't being Jina's bag because hers is red.", "That can't is Jina's bag because hers is red.", "That can't to be Jina's bag because hers is red."], { st: "That ___ Jina's bag because hers is red.", ok: "can't be", wr: ["can't being", "can't is", "can't to be"] }, "can't be는 '~일 리가 없다'는 강한 부정 추측이에요. 뒤에는 동사원형 be를 써요.", { hint: "'~일 리 없다'를 나타내는 표현이에요." }));
s.push(S("She may have missed the bus, so she is late.", "그녀는 버스를 놓쳤을지도 몰라서 늦은 거야.", ["She may missed the bus, so she is late.", "She may has missed the bus, so she is late.", "She may have miss the bus, so she is late."], { st: "She ___ the bus, so she is late.", ok: "may have missed", wr: ["may missed", "may has missed", "may have miss"] }, "may have + 과거분사는 과거에 대한 약한 추측('~했을지도 모른다')이에요.", { hint: "과거 일에 대한 추측이에요." }));
s.push(S("You should have called me before you left.", "떠나기 전에 내게 전화했어야 했어.", ["You should called me before you left.", "You should has called me before you left.", "You should have call me before you left."], { st: "You ___ me before you left.", ok: "should have called", wr: ["should called", "should has called", "should have call"] }, "should have + 과거분사는 과거에 하지 않은 일에 대한 후회나 비판을 나타내요.", { hint: "과거에 하지 않은 일에 대한 아쉬움을 나타내요." }));
s.push(S("Could you tell me where the station is?", "역이 어디에 있는지 알려 주시겠어요?", ["Could you tell me where is the station?", "Could you tell me where does the station is?", "Could you tell me where the station be?"], { st: "Could you tell me ___?", ok: "where the station is", wr: ["where is the station", "where does the station is", "where the station be"] }, "간접의문문에서는 의문사 뒤에 '주어 + 동사' 순서를 써요. 질문의 어순(is the station)이 아니에요.", { hint: "의문사 뒤의 어순에 주의하세요.", ord: true }));
s.push(S("I wonder if she will join our team.", "그녀가 우리 팀에 들어올지 궁금해.", ["I wonder if will she join our team.", "I wonder if she joins will our team.", "I wonder whether will she join our team."], { st: "I wonder ___ join our team.", ok: "if she will", wr: ["if will she", "whether will she", "if does she"] }, "wonder 뒤의 if는 '~인지 아닌지'를 뜻하며, 이어지는 절은 '주어 + 동사' 어순이에요.", { hint: "'~인지'라는 뜻의 접속사를 생각하세요." }));
s.push(S("The movie was so boring that I fell asleep.", "그 영화는 너무 지루해서 나는 잠이 들었어.", ["The movie was so boring what I fell asleep.", "The movie was such boring that I fell asleep.", "The movie was so boring for I fell asleep."], { st: "The movie was ___ I fell asleep.", ok: "so boring that", wr: ["so boring what", "such boring that", "so boring for"] }, "so + 형용사 + that ...은 '너무 ~해서 ...하다'라는 결과를 나타내요. such는 뒤에 명사가 와야 해요.", { hint: "결과를 나타내는 구문이에요." }));
s.push(S("The test was not only hard but also very long.", "시험은 어려울 뿐만 아니라 매우 길었어.", ["The test was not only hard but also very long.".replace("not only hard but also", "not only hard and also"), "The test was not only hard but very also long.", "The test was only not hard but also very long."], { st: "The test was ___ very long.", ok: "not only hard but also", wr: ["not only hard and also", "not only hard but too", "only not hard but also"] }, "not only A but also B는 'A뿐만 아니라 B도'를 뜻하고, A와 B는 같은 형태로 맞춰요.", { hint: "'A뿐만 아니라 B도'를 나타내는 짝 표현이에요." }));
s.push(S("You had better take an umbrella because it looks like rain.", "비가 올 것 같으니 우산을 가져가는 게 좋겠어.", ["You had better to take an umbrella because it looks like rain.", "You had better took an umbrella because it looks like rain.", "You had better taking an umbrella because it looks like rain."], { st: "You ___ an umbrella because it looks like rain.", ok: "had better take", wr: ["had better to take", "had better took", "had better taking"] }, "had better 뒤에는 to 없이 동사원형이 와요.", { hint: "충고하는 표현 뒤의 동사 형태를 확인하세요." }));
s.push(S("It seems that he has already finished his homework.", "그는 숙제를 벌써 끝낸 것 같아.", ["It seems that he already has finish his homework.", "It seems that he have already finished his homework.", "It seems what he has already finished his homework."], { st: "It seems ___ his homework.", ok: "that he has already finished", wr: ["that he have already finished", "what he has already finished", "that he has already finish"] }, "It seems that + 주어 + 동사는 '~인 것 같다'는 추측이에요. 주어가 3인칭 단수이므로 has finished로 써요.", { hint: "접속사와 현재완료 형태를 함께 확인하세요." }));
s.push(S("I would rather stay home than go out in this cold.", "이렇게 추운데 나가느니 집에 있겠어.", ["I would rather to stay home than go out in this cold.", "I would rather staying home than go out in this cold.", "I would rather stay home that go out in this cold."], { st: "I ___ home than go out in this cold.", ok: "would rather stay", wr: ["would rather to stay", "would rather staying", "would rather stayed"] }, "would rather + 동사원형 (+ than + 동사원형)은 '차라리 ~하겠다'는 선호를 나타내요.", { hint: "선호를 나타내는 표현 뒤의 동사 형태를 보세요." }));

// fix: the s bad for notOnly built via replace -> ensure fine
const items = [...r, ...d, ...m, ...s];
// std for s and clean 'cat' on m
for (const it of items) if (it.k === "m") delete it.cat;
import { P } from "./patches.mjs";
{ let c = 0;
  for (const [i, k, o, n] of P) {
    const it = items[i]; const qq = it.qs ? it.qs[k] : it;
    const j = qq.o.indexOf(o); if (j < 0) { console.log("PATCH MISS", i, k, o); continue; }
    if ((c++) % 3 === 2) continue;
    qq.o[j] = n;
  }
}
const out = { packet: "M15-m3-read", sections: [{ skill: "e.m3.read", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M15-m3-read.json", JSON.stringify(out, null, 1) + "\n");
console.log(r.length, d.length, m.length, s.length);
