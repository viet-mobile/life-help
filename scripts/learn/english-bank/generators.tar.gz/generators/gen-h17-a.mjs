let c = 0;
const POS = [2, 0, 3, 1, 1, 3, 0, 2, 3, 1, 0, 2];
export const Q = (q, key, ds, why, std) => {
  const a = POS[c++ % POS.length];
  const o = [...ds]; o.splice(a, 0, key);
  return { q, o, a, why, ...(std ? { std } : {}) };
};
export const R = (title, text, qs, k = "r") => ({ k, title, text, qs });

export const rs1 = [
R("Junior Designer Wanted",
`Brightside Studio, a small design company in Daegu, is looking for a junior graphic designer to join its creative team. The successful candidate will create posters, social media images, and packaging for local businesses. Applicants should have a basic knowledge of design software, although previous work experience is not required. What matters more is a strong portfolio and the ability to accept feedback calmly. The position is full-time, with flexible starting hours between eight and ten in the morning. Candidates who are shortlisted will be asked to complete a short design task before the interview. Please send your portfolio and a one-page cover letter to the hiring manager by March 15. Late applications will not be considered.`,
[
Q("What is the main purpose of the text?", "To invite people to apply for a design job", ["To advertise a new line of packaging for shops", "To explain how to use design software at work", "To announce that a studio is hiring a manager"], "채용 공고로, 주니어 디자이너 지원을 권유하는 글이에요.", ["12직영01-01"]),
Q("According to the text, what is NOT required of applicants?", "Experience in a similar job", ["A portfolio of their own designs", "A cover letter of about one page", "A calm attitude toward feedback"], "previous work experience is not required라고 했어요.", ["12직영01-01"]),
Q("What must shortlisted candidates do before the interview?", "Finish a short design assignment", ["Visit the studio for a tour of the office", "Send two letters from former employers", "Present their portfolio to the whole team"], "complete a short design task라고 했어요.", ["12직영01-03"]),
Q("In the text, the word “shortlisted” is closest in meaning to", "chosen for the next stage", ["refused after a quick review", "asked to start work at once", "placed on a list for next year"], "shortlisted는 최종 후보로 추려졌다는 뜻이에요.", ["12직영01-01"]),
Q("What can be inferred about an application sent on March 16?", "It will probably be ignored", ["It will be read after the others are done", "It will receive a reply within a week", "It will be accepted if the portfolio is good"], "Late applications will not be considered에서 알 수 있어요.", ["12직영01-01"]),
]),
R("An Apology for the Delay",
`Dear Ms. Han,

Thank you for contacting us about your order, number 40871. I am very sorry that your desk lamp has not arrived on the promised date. Unfortunately, a storm closed the main road to our warehouse for two days, and several deliveries were affected. Your parcel left our warehouse this morning and should reach you by Friday, as we have asked the carrier to treat it as a priority. As a small apology, we have refunded the delivery fee to your card. If the lamp does not arrive by Saturday, please reply to this message and we will send a replacement at no cost.

Thank you for your patience and understanding.

Sincerely,
Joon-ho Park
Customer Care, Lumen Home`,
[
Q("Why did Mr. Park write this email?", "To apologize for a late delivery and offer a fix", ["To ask a customer to pay a missing delivery fee", "To thank a customer for choosing a new lamp", "To report that the warehouse has moved elsewhere"], "배송 지연에 대한 사과와 해결책을 알리는 이메일이에요.", ["12직영01-01"]),
Q("What caused the delay?", "A storm blocked the road to the warehouse", ["The lamp was damaged while it was packed", "The customer gave an address that was wrong", "The delivery company went on a two-day strike"], "a storm closed the main road라고 했어요.", ["12직영01-01"]),
Q("What has the company already done for Ms. Han?", "Returned the money for delivery", ["Sent a second lamp in the same box", "Given her a discount on her next order", "Changed her order to a different product"], "refunded the delivery fee라고 했어요.", ["12직영01-01"]),
Q("What will happen if the lamp has not arrived by Saturday?", "The company will send a new one for free", ["Ms. Han will be asked to visit the shop", "The order will be cancelled automatically", "Ms. Han will pay half the price again"], "replacement at no cost라고 했어요.", ["12직영01-03"]),
]),
R("Minutes of the Weekly Meeting",
`Marketing Team Meeting, Tuesday, 10:00. Present: Seo-yeon (chair), Daniel, Priya, Minho.

1. Social media report. Daniel reported that followers grew by eight percent last month, mainly because of the short videos. The team agreed to post three videos a week instead of two.

2. Spring campaign. Priya presented two slogans. After a short discussion, the team chose the second one, which was simpler and easier to remember. Priya will ask the design team for sample posters by Friday.

3. Budget. Minho warned that the printing budget is almost spent. Seo-yeon decided that new posters will be shared online first and printed only if necessary.

Next meeting: Tuesday, 10:00. Action: Minho to send a revised budget before then.`,
[
Q("What is the main purpose of these minutes?", "To record what was discussed and decided", ["To invite staff to a party for the spring campaign", "To ask the design team for new poster ideas", "To praise the team for growing so fast online"], "회의록은 논의와 결정 사항을 기록하는 글이에요.", ["12직영01-01"]),
Q("Why did the team choose the second slogan?", "It was easier to remember", ["It was cheaper to print on posters", "It had been suggested by the chair", "It matched last year's campaign well"], "simpler and easier to remember라고 했어요.", ["12직영01-01"]),
Q("What can be inferred about the printing budget?", "Printed posters must be kept to a minimum", ["The team plans to buy a new printer soon", "Posters will no longer be shown online", "The design team will pay for the printing"], "예산이 거의 소진되어 온라인 공유가 먼저이고 인쇄는 필요할 때만 해요.", ["12직영01-01"]),
Q("Who must do something before the next meeting?", "Minho", ["Daniel", "Priya", "Seo-yeon"], "Action: Minho to send a revised budget이라고 했어요.", ["12직영01-03"]),
Q("In item 1, what does “mainly because of” show?", "The main reason for the growth", ["A plan the team made for next month", "A problem that the videos caused", "An example of a short social media post"], "mainly because of는 주된 원인을 나타내요.", ["12직영01-01"]),
]),
R("Kitchen Safety Notice",
`ATTENTION ALL KITCHEN STAFF

Over the past month, three small accidents have happened in our kitchen. To protect everyone, the following rules start on Monday.

First, wipe up any spilled water or oil immediately, and place a yellow warning sign on the wet floor. Second, carry knives with the blade pointing down and never leave them in a sink full of water. Third, closed, non-slip shoes must be worn at all times; sandals are not allowed, even during the break.

If you see a hazard that you cannot fix yourself, tell the head chef right away. Staff who follow the rules will help us keep a safe workplace, and the restaurant will return to its normal schedule without delays.

Thank you for your cooperation.
Chef Kwon`,
[
Q("What is the purpose of this notice?", "To introduce new safety rules for staff", ["To announce a change in the restaurant's menu", "To warn customers about a wet floor", "To thank the staff for fixing three accidents"], "주방 직원들에게 새 안전 규칙을 알리는 공지예요.", ["12직영01-01"]),
Q("Which rule is mentioned in the notice?", "Wearing closed shoes with a non-slip sole", ["Washing every knife twice after each meal", "Putting a red sign beside every hot oven", "Taking a break after two hours of cooking"], "closed, non-slip shoes must be worn이라고 했어요.", ["12직영01-08"]),
Q("What should a worker do about a hazard he cannot fix?", "Report it to the head chef", ["Leave a warning sign and go home", "Ask a customer to stay away from it", "Wait until the next Monday meeting"], "tell the head chef right away라고 했어요.", ["12직영01-03"]),
Q("What does the word “hazard” mean here?", "Something that could cause harm", ["A tool that is used for cutting food", "A rule that was written by the chef", "A customer who is waiting for a meal"], "hazard는 위험 요소를 뜻해요.", ["12직영01-01"]),
]),
R("A Cover Letter Opening",
`Dear Mr. Alvarez,

I am writing to apply for the position of library assistant that was advertised on your website. I am currently a third-year student at Hanbit High School, and I have volunteered at my local library every Saturday for the past two years. During that time, I helped younger children choose books, repaired damaged covers, and organized a monthly reading club that now has twenty regular members.

What attracts me to this position is the chance to work with a team that values community learning. I am patient, reliable, and comfortable with basic computer systems. I would welcome the opportunity to discuss how my experience could support your library. My résumé is attached, and I can be reached at any time by email.

Yours sincerely,
Eun-ji Lee`,
[
Q("Why is Eun-ji writing the letter?", "To apply for a position at a library", ["To ask Mr. Alvarez for some library books", "To report a problem with the library website", "To invite students to a monthly reading club"], "도서관 보조 직책에 지원하는 자기소개서예요.", ["12직영01-06"]),
Q("What did Eun-ji do at the library?", "She started a regular reading group", ["She trained new volunteers on computers", "She designed the library's new website", "She wrote reviews of books for the paper"], "organized a monthly reading club이라고 했어요.", ["12직영01-06"]),
Q("What can be inferred about Eun-ji?", "She has some practical experience already", ["She has never worked with other people", "She is applying for her very first job ever", "She would prefer to work alone at night"], "2년간의 봉사 경험이 있으므로 어느 정도 실무 경험이 있어요.", ["12직영01-06"]),
Q("The phrase “reached at any time” is closest in meaning to", "contacted whenever needed", ["found in a library each day", "visited without an appointment", "paid on a regular schedule"], "reached는 연락이 닿는다는 뜻이에요.", ["12직영01-06"]),
]),
R("Working from Home Securely",
`Many companies now allow employees to work from home, but this freedom comes with responsibilities. When you work outside the office, you are still handling information that belongs to your employer and its customers. Experts therefore recommend a few simple habits. Use a strong password that is different for every account, and never share it, even with a colleague you trust. Avoid public Wi-Fi when you open private files, because other users on the same network may be able to see your activity. Lock your screen whenever you leave your desk, even at home, and do not discuss confidential matters where visitors can overhear you. Finally, report any suspicious email to your IT team instead of opening the attachment. A single careless click can put thousands of people's data at risk.`,
[
Q("What is the passage mainly about?", "Habits that protect company information at home", ["Reasons why companies stopped using their offices", "Ways to make home Wi-Fi faster and cheaper", "Tips for talking with trusted colleagues"], "재택근무 시 정보를 보호하는 습관에 관한 글이에요.", ["12직영01-08"]),
Q("Why does the writer advise against public Wi-Fi?", "Other users might see what you are doing", ["It usually costs more than home Wi-Fi", "It cannot be used for opening any private file", "It slows the computer down in a cafe"], "other users on the same network may be able to see your activity라고 했어요.", ["12직영01-08"]),
Q("What should a worker do with a suspicious email?", "Tell the IT team about it", ["Open the attachment to check it", "Send it on to a trusted colleague", "Delete it and say nothing to anyone"], "report any suspicious email to your IT team이라고 했어요.", ["12직영01-08"]),
Q("The word “confidential” is closest in meaning to", "private and not for sharing", ["old and no longer important", "interesting for many readers", "difficult to understand easily"], "confidential은 비밀로 해야 하는 것을 뜻해요.", ["12직영01-08"]),
Q("What is the writer's attitude toward careless clicking?", "Serious concern about the danger", ["Mild amusement at a common habit", "Strong support for faster work", "Complete lack of any interest"], "수천 명의 데이터가 위험해질 수 있다고 경고하는 태도예요.", ["12직영01-08"]),
]),
R("My Internship at a Clinic",
`Last summer, I spent four weeks as an intern at a children's dental clinic. I was nervous on the first day because I had never worked in a medical setting. My supervisor, Dr. Moon, gave me a simple task: greet each family at the door and help them fill out a form. At first, my voice shook, but by the second week I was talking easily with parents and even making the children laugh.

I also learned that small details matter. A mistake in a patient's birth date, for example, can cause serious confusion later. So I started checking each form twice before handing it in. On my last day, Dr. Moon told me that this habit was the most useful thing I had shown. I did not expect such praise, and it made me think seriously about a career in healthcare.`,
[
Q("What is the writer's main point?", "The internship built her skills and interest in healthcare", ["Dentists should be kinder to small children", "Forms at clinics are too difficult for most interns to complete", "Summer jobs are easier than school courses"], "인턴 경험이 기술과 진로 관심을 키워 주었다는 글이에요.", ["12직영01-01"]),
Q("How did the writer feel on the first day?", "Worried because the work was new", ["Bored because the tasks were too easy", "Proud because Dr. Moon had praised her", "Angry because she had to work alone"], "I was nervous on the first day라고 했어요.", ["12직영01-01"]),
Q("What habit did the writer develop?", "Reading each form two times before submitting", ["Writing a daily diary about each patient", "Arriving at the clinic an hour before it opens", "Asking parents to sign every page twice"], "checking each form twice라고 했어요.", ["12직영01-01"]),
Q("What does “this habit” refer to in the last paragraph?", "Double-checking the forms", ["Talking with the children", "Greeting families at the door", "Working for four weeks"], "this habit은 앞서 말한 서식을 두 번 확인하는 것이에요.", ["12직영01-01"]),
Q("What can be inferred from the last sentence?", "The experience may influence her future plans", ["She has already decided to quit school", "She will return to the clinic next week", "She dislikes working with young patients in clinics"], "healthcare 진로에 대해 진지하게 생각하게 되었다고 했어요.", ["12직영01-01"]),
]),
R("Shadowing a Nurse for a Day",
`Job shadowing means following a worker through a normal day to see what the job is really like. Hyun-woo shadowed a hospital nurse named Ms. Cho for one day, and his notes show how different the real job was from his expectations.

He had imagined that nurses spend most of their time giving injections. In fact, Ms. Cho spent much of her morning listening to patients, updating records on a tablet, and explaining medicines in simple words. She also worked closely with doctors, sharing short reports at every change of shift so that nothing important was forgotten.

At the end of the day, Hyun-woo felt tired but impressed. "I realized that communication is just as important as medical knowledge," he wrote. He has decided to take a first-aid course this winter.`,
[
Q("What is job shadowing?", "Following a worker to learn about a job", ["Taking over a worker's duties for a month", "Watching videos about different careers", "Interviewing a doctor after an operation"], "본문 첫 문장이 정의를 설명해요.", ["12직영01-01"]),
Q("What surprised Hyun-woo about the nurse's work?", "Much of it involved communication and records", ["Most of her day was spent giving injections", "She rarely spoke to doctors or patients", "Her shifts lasted for several whole days in a row"], "그는 주사를 놓는 일이 대부분일 거라 상상했지만 실제는 달랐어요.", ["12직영01-01"]),
Q("Why do nurses share reports at each shift change?", "To make sure no key information is lost", ["To give doctors some time to rest", "To practise speaking in simple words to patients", "To decide who will use the tablet next"], "so that nothing important was forgotten이라고 했어요.", ["12직영01-03"]),
Q("What can be inferred about Hyun-woo after the day?", "He is still interested in healthcare", ["He wants to become a hospital doctor", "He plans to stop studying in winter", "He thinks nursing is an easy career"], "응급처치 강좌를 듣기로 한 것에서 계속 관심이 있음을 알 수 있어요.", ["12직영01-01"]),
]),
R("Business Customs Around the World",
`Doing business with people from other countries can be rewarding, but small cultural differences can cause misunderstanding. In some countries, arriving ten minutes early to a meeting shows respect. In others, the host may expect guests to arrive a little late, and starting exactly on time can feel rushed. Exchanging business cards is also treated differently. In several Asian countries, people offer and receive a card with both hands and read it carefully before putting it away. Writing on it or pushing it into a back pocket may seem impolite.

Experts advise that the best strategy is not to memorize every rule but to stay curious. Ask polite questions, watch how others behave, and be ready to adjust. Showing a sincere interest in other customs usually matters more than getting every detail right.`,
[
Q("What is the main message of the passage?", "Being open to other cultures helps in business", ["Business cards are required in every country", "Arriving late is always better than being early", "Foreign partners should learn the same rules"], "문화 차이에 열린 태도를 가지라는 내용이에요.", ["12직영01-07"]),
Q("According to the passage, what might offend a person in some Asian countries?", "Putting a received card in a back pocket", ["Reading a card with great care", "Offering a card with both hands", "Arriving at the meeting ten minutes early"], "pushing it into a back pocket may seem impolite라고 했어요.", ["12직영01-07"]),
Q("What does the writer suggest about arriving on time?", "The right habit depends on the country", ["Everyone should arrive thirty minutes early", "Guests should always wait outside first", "Starting late is rude in every culture"], "나라마다 시간 관념이 다르다고 했어요.", ["12직영01-07"]),
Q("The word “adjust” is closest in meaning to", "change a little to fit", ["stop and ask for help", "repeat what was said", "refuse to take part in it"], "adjust는 상황에 맞게 조금 바꾼다는 뜻이에요.", ["12직영01-07"]),
Q("What is the writer's attitude toward learning every rule?", "It is less important than showing interest", ["It is the only way to avoid mistakes", "It is impossible for young workers to manage", "It should be done before any meeting"], "모든 규칙을 외우기보다 호기심을 가지라고 해요.", ["12직영01-07"]),
]),
R("Feedback After Three Months",
`Dear Jin-ah,

Now that you have completed your first three months with us, I would like to share some feedback. First, your work with customers has been excellent. Several of them have mentioned how patiently you explain our products, and your satisfaction scores are among the highest on the team.

There is one area where I would like to see improvement: your weekly reports. They are often submitted on Friday evening, which leaves little time for me to review them. In the coming quarter, please aim to send them by Thursday noon. If you feel overloaded, tell me early, and we can adjust your schedule together.

Overall, you have made a very good start, and I am confident that you will grow quickly. Let's meet next Monday to talk about your goals.

Best regards,
Ms. Yoon`,
[
Q("What is the purpose of the letter?", "To give a new employee balanced feedback", ["To warn an employee that she will be dismissed", "To announce a promotion to the customer team", "To ask customers for scores on her service"], "칭찬과 개선점을 함께 전하는 피드백 편지예요.", ["12직영01-01"]),
Q("What does Ms. Yoon praise Jin-ah for?", "Explaining products with patience", ["Writing reports earlier than needed", "Working longer hours than colleagues", "Teaching other staff how to sell"], "patiently you explain our products라고 했어요.", ["12직영01-01"]),
Q("What does Ms. Yoon ask Jin-ah to change?", "The time her weekly reports are submitted", ["The products that she sells to customers", "The number of meetings she attends daily", "The way she greets customers at the door each morning"], "reports를 Thursday noon까지 보내 달라고 했어요.", ["12직영01-01"]),
Q("What can be inferred about Ms. Yoon's attitude?", "She wants to help Jin-ah succeed", ["She is angry about the late reports", "She thinks the team has too many staff", "She has no time to meet with Jin-ah"], "격려하고 면담을 제안하는 것으로 보아 도와주려는 태도예요.", ["12직영01-02"]),
]),
R("Setting Up the Smart Speaker",
`Welcome to the Aria Smart Speaker. Please follow these steps to set it up in about ten minutes.

First, place the speaker on a flat surface near a power outlet and plug it in. A blue light will appear and turn white after about thirty seconds. Next, download the Aria app on your phone and create an account. Once you have signed in, tap “Add device” and choose your speaker from the list. The app will then ask you to select your home Wi-Fi network and enter its password. After the speaker connects, it will say “Hello” to confirm that setup has been completed. Finally, open the settings menu and decide which voices the speaker may respond to. If the light turns red at any point, unplug the speaker and start again from the beginning.`,
[
Q("What is the purpose of this text?", "To explain how to set up a device", ["To compare two kinds of smart speakers", "To advertise a new music service", "To report a problem with a power outlet"], "기기 설정 절차를 안내하는 설명서예요.", ["12직영01-03"]),
Q("What should the user do right after signing in to the app?", "Tap “Add device” and pick the speaker", ["Choose a home Wi-Fi network from a list", "Plug the speaker into an outlet", "Decide which voices are allowed"], "sign in 다음에 Add device를 눌러요.", ["12직영01-03"]),
Q("How will the user know that the setup is finished?", "The speaker will say hello", ["The blue light will turn red", "The phone will make a loud sound", "The app will close by itself"], "it will say “Hello” to confirm이라고 했어요.", ["12직영01-03"]),
Q("What should the user do if the light turns red?", "Unplug the speaker and restart the setup", ["Wait thirty seconds for the light to change", "Download the app again on the phone", "Move the speaker closer to the outlet"], "unplug the speaker and start again이라고 했어요.", ["12직영01-03"]),
]),
R("Front Desk Training Guide",
`Welcome to your first week at Harbor Hotel. Guests form their first impression at the front desk, so your behaviour matters a great deal.

Always greet guests with a smile within ten seconds of their arrival, even if you are on the phone. Use their family name when you have it. When a guest has a complaint, listen without interrupting, apologize for the inconvenience, and say clearly what you will do about it. Never promise something you cannot deliver; if you are unsure, say that you will check with your manager and give a time when you will reply.

Remember, too, that guest information is private. Do not say a guest's room number aloud in the lobby. Write it down and hand it over instead.`,
[
Q("Who is the guide written for?", "New hotel employees", ["Guests who stay at the hotel", "Managers who plan a new lobby", "Travel agents who book rooms"], "첫 주를 맞은 신입 직원을 위한 안내서예요.", ["12직영01-02"]),
Q("What should an employee do first when a guest has a complaint?", "Listen without interrupting", ["Offer a free night at the hotel", "Call the manager to the front desk", "Explain why the guest is mistaken"], "listen without interrupting이라고 했어요.", ["12직영01-04"]),
Q("Why shouldn't staff say room numbers aloud in the lobby?", "Guest information must be kept private", ["The lobby is too noisy for numbers", "Guests prefer to be called by name", "Managers like written notes more than speech"], "guest information is private라고 했어요.", ["12직영01-08"]),
Q("What does the guide suggest if an employee is unsure about a request?", "Say that you will check and name a time", ["Promise the guest whatever is asked", "Ask the guest to come back again tomorrow", "Pass the problem to another guest"], "check with your manager and give a time이라고 했어요.", ["12직영01-04"]),
Q("The word “deliver” in “something you cannot deliver” means", "actually provide", ["carry to a room", "describe in detail", "forget about later"], "deliver는 약속한 것을 실제로 제공한다는 뜻이에요.", ["12직영01-04"]),
]),
R("Employee of the Month",
`Congratulations to Tae-min Oh, who has been named Employee of the Month for October! Tae-min works in our delivery department, where he is known for solving problems calmly. Last month, a heavy rainstorm damaged a van that was carrying forty urgent orders. Instead of waiting for repairs, Tae-min contacted nearby shops, borrowed two small vehicles, and arranged for every order to reach customers on the same day.

His manager, Ms. Baek, said, “Tae-min doesn't just follow instructions. He thinks about what the customer needs and finds a way.” Colleagues also praised him for training two new drivers without being asked.

As a reward, Tae-min will receive a gift card and an extra day of leave. The next winner will be announced on November 30, so keep up the good work, everyone!`,
[
Q("Why was Tae-min chosen?", "He handled a difficult situation well", ["He worked more hours than anyone else", "He drove more kilometres than his team", "He repaired a van by himself in a day"], "폭풍으로 차량이 손상됐을 때 침착하게 해결했어요.", ["12직영01-01"]),
Q("How did Tae-min get the orders delivered?", "He borrowed vehicles from nearby shops", ["He asked customers to collect them", "He waited until the van was repaired", "He delivered half of them the next day"], "borrowed two small vehicles라고 했어요.", ["12직영01-03"]),
Q("What does Ms. Baek's comment suggest about Tae-min?", "He takes the initiative to help customers", ["He often disagrees with instructions", "He prefers working alone every single day", "He has little interest in the customers"], "doesn't just follow instructions는 스스로 방법을 찾는다는 뜻이에요.", ["12직영01-01"]),
Q("What is the purpose of the last sentence?", "To encourage all employees", ["To announce a new delivery rule", "To warn staff about the storm", "To thank customers for waiting"], "keep up the good work는 모두를 격려하는 말이에요.", ["12직영01-01"]),
]),
R("Career Fair Announcement",
`The Seoul Youth Career Fair will take place on Saturday, April 12, from 10 a.m. to 4 p.m. at the Riverside Convention Center. Over sixty organizations, including hospitals, technology firms, and farms, will run booths where students can ask questions about daily work and training.

New this year are fifteen-minute “job chats,” in which professionals talk about their paths to their current positions and answer questions. Spaces are limited, so students must reserve a seat on the fair's website by April 8. In addition, a free workshop will help visitors write a one-page résumé. No tickets are required, but visitors under eighteen should bring a student ID.

Please note that parking at the center is not available. Visitors are encouraged to use public transport.`,
[
Q("What is the purpose of the announcement?", "To give details about a career event", ["To advertise jobs at a single company", "To request money for a convention center", "To report results from last year's fair"], "진로 박람회의 일정과 내용을 알리는 공지예요.", ["12직영01-01"]),
Q("What is new at this year's fair?", "Short talks with working professionals", ["A workshop for writing a résumé", "Booths run by hospitals, firms, and farms", "Free parking for all visitors"], "New this year are fifteen-minute “job chats”라고 했어요.", ["12직영01-01"]),
Q("What must students do by April 8?", "Reserve a place for a job chat", ["Buy a ticket for the convention center", "Send a résumé to sixty organizations", "Show a student ID at the entrance"], "reserve a seat on the fair's website by April 8이라고 했어요.", ["12직영01-03"]),
Q("What can be inferred about visitors who drive?", "They will need to find parking elsewhere", ["They will park for free near the booths", "They will be refused entry at the door", "They will be asked to pay at the entrance"], "주차가 불가능하니 대중교통을 권해요.", ["12직영01-01"]),
]),
];
