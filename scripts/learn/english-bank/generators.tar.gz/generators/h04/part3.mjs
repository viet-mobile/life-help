import { Q, R, D } from "./common.mjs";
const S2 = ["12영Ⅰ-01-04", "12영Ⅰ-01-02"];
export const readings = [
R("The Science of Kimchi",
`Kimchi has been part of Korean meals for centuries. [1] Its flavor comes from fermentation. [2] When vegetables are salted and stored, harmless bacteria begin to grow and produce lactic acid. [3] The acid gives kimchi its sour taste and also protects it from spoiling. [4] Today, scientists study these bacteria because they may be good for the stomach.`,
[
Q("Where would the following sentence best fit?\n\"That is why it can be kept for months in a cool place.\"", "[4]", "[1]", "[2]", "[3]", "That is why 앞에는 보존이 가능한 이유(산이 부패를 막음)가 와야 하므로 [4]가 알맞아요."),
Q("Which word could replace \"because\" in the last sentence without changing the meaning?", "since", "although", "unless", "but", "because는 이유를 나타내며 since로 바꿔 쓸 수 있어요."),
Q("What is the passage mainly about?", "How fermentation gives kimchi its taste and helps it last", "Why Koreans eat kimchi at every meal", "How to salt vegetables at home", "Which bacteria are harmful to the stomach", "발효가 김치의 맛과 보존에 미치는 영향을 설명해요."),
Q("What does lactic acid do to kimchi?", "It makes it sour and protects it from spoiling", "It makes it sweeter and softer", "It turns the vegetables red", "It stops the bacteria from growing", "산은 신맛을 내고 부패를 막아 줘요."),
], S2, 4),

R("A Letter of Inquiry",
`Dear Ms. Alvarez,

I am a first-year high school student, and I am writing to ask about volunteer opportunities at your science museum. I have been interested in astronomy since I joined my school's science club. (A), I am free on Saturday mornings and during the summer holidays. (B), I understand that most volunteers must be at least sixteen, and I will turn sixteen in November. (C), I would be grateful if you could let me know whether I may apply now or should wait.

Yours sincerely,
Hyun-woo Seo`,
[
Q("Which set best fills (A), (B), and (C)?", "(A) Moreover / (B) However / (C) Therefore", "(A) However / (B) Moreover / (C) Therefore", "(A) Therefore / (B) Moreover / (C) However", "(A) Moreover / (B) Therefore / (C) However", "시간 여유를 덧붙이는 Moreover, 나이 제한이라는 걸림돌을 말하는 However, 그래서 문의하는 Therefore예요."),
Q("Why did Hyun-woo write this letter?", "To ask whether he can volunteer at the museum", "To apply for a paid job as a guide", "To complain about a museum exhibit", "To invite the museum to his school", "박물관 봉사 기회에 대해 문의하는 편지예요."),
Q("When is Hyun-woo free to volunteer?", "On Saturday mornings and during summer holidays", "On weekday evenings only", "During the winter holidays", "Every day after school", "토요일 오전과 여름방학에 시간이 된다고 했어요."),
Q("Why does he mention November?", "He will reach the minimum age then", "The museum will open then", "His school club meets then", "The summer holidays will end then", "11월에 16세가 되어 최소 연령 조건을 충족해요."),
Q("What is the tone of the letter?", "Polite and formal", "Funny and casual", "Angry and demanding", "Sad and hopeless", "정중하고 격식 있는 어조예요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-02-05"], 4),

R("Why Noon Is Not the Same Everywhere",
`Imagine calling a friend overseas at noon your time, only to wake her at midnight. This happens because the Earth is divided into 24 time zones. As the Earth turns, the sun reaches different places at different moments, (A) noon in Seoul comes many hours before noon in London. Before the 1800s, every town set its own clock by the sun. (B), the invention of railways made this system confusing, since a train passenger had to adjust a watch at every station. Countries therefore agreed to share standard time zones.`,
[
Q("Which pair best fills (A) and (B)?", "(A) so / (B) However", "(A) because / (B) However", "(A) so / (B) For example", "(A) but / (B) Therefore", "해가 다른 시각에 도달한 결과가 so, 옛 방식이 철도 때문에 문제가 된 대조가 However예요."),
Q("What is the passage mainly about?", "Why time zones exist and how they came to be shared", "How to make a clock that uses the sun", "Why Seoul is ahead of every other city", "How railways were built in the 1800s", "시간대가 생긴 이유와 표준 시간대가 정해진 과정을 설명해요."),
Q("Why was the old system confusing for train passengers?", "They had to adjust their watch at every station", "Trains never left on time", "Stations used the same clock", "Tickets showed the wrong date", "역마다 시계를 맞춰야 했기 때문이에요."),
Q("In the passage, \"standard\" is closest in meaning to", "the same for everyone", "very expensive", "difficult to read", "popular with travelers", "standard time은 모두에게 같은 표준 시간을 뜻해요."),
], S2, 3),

R("Two Street Food Cultures",
`Street food markets in Southeast Asia and in Korea may look alike at first glance. Both offer cheap, freshly made dishes cooked in front of the customer, and both attract crowds in the evening. (A), the experience differs in several ways. In Bangkok, many vendors sell dishes with strong spices and fresh herbs. (B), in Seoul's traditional markets, the most popular items are often fried or grilled snacks eaten while standing. Despite these differences, both kinds of markets show how food can bring a community together.`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) By contrast", "(A) Likewise / (B) By contrast", "(A) However / (B) Likewise", "(A) Therefore / (B) For example", "닮은 점을 말한 뒤 차이를 말하므로 However, 두 도시의 대비는 By contrast예요."),
Q("What does the second sentence do?", "It describes ways the two kinds of markets are similar", "It explains why the markets are different", "It gives an example of a Bangkok dish", "It tells what happens in the morning", "Both ... and both ... 로 공통점을 설명해요."),
Q("What is the main idea of the passage?", "Street food markets in two regions are alike in some ways and different in others", "Bangkok has better street food than Seoul", "Street food is unhealthy for communities", "Markets in Korea only sell fried snacks", "두 시장의 공통점과 차이점을 비교하는 글이에요."),
Q("What does \"Despite these differences\" suggest about the writer's view?", "The markets share an important common value", "The differences are too big to compare", "One market should copy the other", "Tourists dislike both markets", "차이에도 불구하고 공동체를 모은다는 공통점을 강조해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-06"], 4),

R("Junk in Orbit",
`Since the first satellite was launched in 1957, thousands of objects have been sent into orbit. Most were meant to be temporary. (A), when satellites stop working, many stay in space as junk. Today more than 30,000 pieces larger than a tennis ball are tracked, and millions of smaller pieces cannot be tracked at all. Moving at about 28,000 kilometers per hour, even a tiny fragment can damage a spacecraft. (B), space agencies now plan satellites that can be pulled out of orbit once their work is done.`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) As a result", "(A) Therefore / (B) As a result", "(A) However / (B) In contrast", "(A) For example / (B) Otherwise", "임시용이었지만 실제로는 남는다는 대조(However), 위험의 결과로 계획을 세우는 As a result예요."),
Q("What is the passage mainly about?", "The growing problem of junk in space and efforts to deal with it", "The first satellite launched in 1957", "How to track objects larger than a tennis ball", "Why spacecraft travel at high speed", "우주 쓰레기 문제와 대응 노력을 다뤄요."),
Q("Why can a tiny fragment damage a spacecraft?", "It moves at an extremely high speed", "It is made of heavy metal", "It is always sharp", "It is hotter than the sun", "시속 약 28,000km로 움직이기 때문이에요."),
Q("What are space agencies planning?", "Satellites that can be removed from orbit after use", "A ban on all satellite launches", "Larger satellites that stay for longer", "A way to track the smallest pieces", "임무 후 궤도에서 제거할 수 있는 위성을 계획해요."),
], S2, 3),

R("What Makes a Good Friend?",
`What makes a good friend? Some people say it is someone who shares your interests. Others say it is someone who is always available. (A), I believe that the most important quality is honesty. A friend who tells you the truth kindly, even when it is uncomfortable, helps you to grow. (B), a friend who only says what you want to hear may be pleasant, but cannot be fully trusted. (C), true friendship depends less on fun times than on trust.`,
[
Q("Which set best fills (A), (B), and (C)?", "(A) However / (B) In contrast / (C) In short", "(A) In short / (B) However / (C) In contrast", "(A) For example / (B) In contrast / (C) However", "(A) However / (B) Therefore / (C) For example", "다른 견해와 대비되는 However, 정직한 친구와 대비되는 In contrast, 결론의 In short예요."),
Q("What is the purpose of the first three sentences?", "To present other views before stating the writer's own", "To list the writer's favorite friends", "To prove that honesty is unimportant", "To describe a recent argument", "다른 사람들의 의견을 먼저 제시한 뒤 자신의 의견을 말해요."),
Q("According to the writer, what is the most important quality of a friend?", "Honesty", "Having the same hobbies", "Always being available", "Being very funny", "필자는 정직을 가장 중요하게 봐요."),
Q("What does the writer say about a friend who only says what you want to hear?", "Such a friend is pleasant but not fully trustworthy", "Such a friend is the best kind of friend", "Such a friend always tells the truth", "Such a friend is difficult to find", "듣기 좋은 말만 하면 즐겁지만 완전히 믿을 수는 없다고 했어요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-02", "12영Ⅰ-01-06"], 3),

R("Visitor Information",
`VISITOR INFORMATION: Maple Science Museum

The museum is open from 9:00 a.m. to 5:00 p.m., Tuesday through Sunday. Admission is free for children under seven. In addition, students aged seven to eighteen pay half price if they show a valid school ID. Please note that the Space Hall will be closed for repairs until June 30. (A), the Ocean Gallery on the second floor is open as usual, and its new whale exhibit has been very popular. Photographs are welcome, (B) flash photography is not allowed near the display of old documents.`,
[
Q("Which pair best fills (A) and (B)?", "(A) On the other hand / (B) but", "(A) For example / (B) but", "(A) On the other hand / (B) so", "(A) Therefore / (B) because", "닫힌 전시관과 대비되는 열린 전시관은 On the other hand, 허용과 제한을 잇는 접속어는 but이에요."),
Q("What is the purpose of this notice?", "To give visitors useful information about the museum", "To advertise a new job at the museum", "To announce that the museum is closing forever", "To ask visitors to donate old documents", "방문객에게 박물관 이용 정보를 알려 줘요."),
Q("Who pays half price?", "Students aged seven to eighteen with a school ID", "All children under seven", "Visitors who bring a camera", "Adults visiting on Sundays", "7~18세 학생은 학생증이 있으면 반값이에요."),
Q("Which statement is true?", "The Space Hall will reopen after June 30", "The museum is open every day of the week", "The Ocean Gallery is on the first floor", "Photography is not allowed anywhere", "우주관은 6월 30일까지 수리로 닫혀요. 박물관은 화~일 개방, 해양관은 2층이에요."),
], ["12영Ⅰ-01-01", "12영Ⅰ-01-04"], 2),

R("Training for a Marathon",
`Training for a marathon takes months of careful planning. In the beginning, most coaches advise runners to build their weekly distance slowly. (A), a beginner who suddenly runs twenty kilometers is likely to be injured. After about two months, runners usually add a long run on weekends. Gradually the distance grows from ten kilometers to thirty. (B), the final weeks are different: runners cut their distance and rest so that their legs are fresh on race day. Many first-time runners are surprised that doing less can make them faster.`,
[
Q("Which pair best fills (A) and (B)?", "(A) Otherwise / (B) However", "(A) Otherwise / (B) Therefore", "(A) Similarly / (B) However", "(A) In contrast / (B) For example", "천천히 늘리지 않으면(Otherwise) 부상, 거리를 늘리는 단계와 대비되는 마지막 주(However)예요."),
Q("What is the passage mainly about?", "How runners should plan their training for a marathon", "Why marathons are held in the morning", "How to choose running shoes", "The history of long-distance racing", "마라톤 준비 훈련 계획을 설명하는 글이에요."),
Q("What do runners do in the final weeks?", "They run less and rest", "They run thirty kilometers every day", "They stop all exercise for a month", "They add a second long run", "마지막 몇 주에는 거리를 줄이고 쉬어요."),
Q("Which step comes right after building weekly distance slowly?", "Adding a long run on weekends", "Cutting the distance and resting", "Running twenty kilometers suddenly", "Running the actual race", "약 두 달 뒤 주말 장거리 달리기를 추가해요."),
], S2, 3),

R("Saving Water",
`Water seems unlimited when it flows from the tap, yet fresh water is scarce. Only about three percent of the world's water is fresh, and most of that is frozen. Households can reduce their use in simple ways. (A), turning off the tap while brushing your teeth saves around six liters a minute. (B), fixing a leaking faucet can save thousands of liters a year. Farms and factories use far more water than homes do, so individual effort alone is not enough. Governments and companies must also change how they use water.`,
[
Q("Which pair best fills (A) and (B)?", "(A) For example / (B) Similarly", "(A) However / (B) Similarly", "(A) For example / (B) In contrast", "(A) Therefore / (B) Otherwise", "간단한 방법의 예(For example)와 또 다른 비슷한 방법(Similarly)이에요."),
Q("What does \"so\" in the second-to-last sentence show?", "A result of farms and factories using more water", "A contrast with the idea of saving water", "An example of a household habit", "The order of two actions", "농장과 공장이 더 많이 쓰므로 개인의 노력만으로는 부족하다는 결과예요."),
Q("What is the writer's conclusion?", "Both individuals and large water users need to act", "Households alone can solve the problem", "Farms should stop using water", "Fresh water will never run out", "개인뿐 아니라 정부와 기업도 변해야 한다고 결론지어요."),
Q("About how much of the world's water is fresh?", "Three percent", "Thirty percent", "Half", "Almost all of it", "세계 물의 약 3퍼센트만 담수예요."),
], S2, 3),

R("A New Way to Read",
`Until the 1800s, blind people could read only with books printed in large raised letters. These books were huge, expensive, and slow to read, so very few were available. A young blind student found a better way. He used patterns of six dots, which fingertips can recognize much faster than letter shapes. (A), a page could be read quickly and written with a simple tool. (B), the system spread worldwide and is still used today.`,
[
Q("Which pair best fills (A) and (B)?", "(A) As a result / (B) Eventually", "(A) In contrast / (B) Eventually", "(A) As a result / (B) For example", "(A) Otherwise / (B) Meanwhile", "점자의 효과를 결과로 이어 주는 As a result, 시간이 지나 퍼졌다는 Eventually예요."),
Q("What is the passage mainly about?", "How a new system of dots made reading easier for blind people", "Why large books were popular in schools", "How to write with a simple tool", "Why blind students prefer listening to reading", "점자가 시각장애인의 읽기를 쉽게 만든 과정을 다뤄요."),
Q("Why were the old books hard to use?", "They were huge, expensive, and slow to read", "They were printed in many languages", "They had no raised letters", "They were only for children", "크고 비싸며 읽는 속도가 느렸어요."),
Q("In the passage, \"recognize\" is closest in meaning to", "identify", "destroy", "borrow", "ignore", "recognize는 알아보다, 식별하다라는 뜻이에요."),
], S2, 3),

R("Robots on the Hospital Floor",
`Hospitals around the world are beginning to use robots. Some carry medicine and meals through long corridors, while others help surgeons perform delicate operations with great accuracy. Supporters say that robots reduce mistakes and give nurses more time with patients. Nevertheless, there are concerns. A machine cannot comfort a frightened child, and it costs millions of dollars to buy and maintain. For these reasons, most experts believe that robots should assist medical staff, not replace them.`,
[
Q("What does \"Nevertheless\" signal?", "A contrast with the benefits just mentioned", "An example of the benefits", "A result of the robots' accuracy", "A time order of two events", "Nevertheless는 앞의 장점과 대비되는 우려를 이끌어요."),
Q("What is the function of the sentence \"A machine cannot comfort a frightened child\"?", "It gives an example of a limit of robots", "It explains how robots carry medicine", "It shows that nurses dislike robots", "It repeats the benefits for patients", "로봇의 한계를 보여 주는 예시 문장이에요."),
Q("What is the main idea of the passage?", "Robots are useful in hospitals but should support, not replace, staff", "Robots should perform all operations", "Hospitals cannot afford any machines", "Nurses prefer robots to doctors", "로봇은 도움이 되지만 의료진을 대체해서는 안 된다는 내용이에요."),
Q("Which is mentioned as a benefit of robots?", "They reduce mistakes and give nurses more time with patients", "They cost less than human staff", "They can comfort frightened patients", "They work without any maintenance", "실수를 줄이고 간호사가 환자와 보낼 시간을 늘려 줘요."),
], S2, 3),
];

export const dialogues = [
D("Planning the Class Trip",
`Mina: Have you decided where we should go for the class trip?
Joon: I like the science museum. It has a new space exhibition.
Mina: That sounds interesting. However, it's quite far from school, and the bus ride takes two hours.
Joon: True. On the other hand, the aquarium is only forty minutes away.
Mina: Besides, tickets for the aquarium are cheaper.
Joon: Then let's suggest the aquarium. We can visit the museum on our own later.
Mina: Good idea. I'll write the proposal tonight, and you can add the price list.
Joon: Deal.`,
[
Q("What does Mina's \"However\" show?", "She sees a problem with Joon's suggestion", "She agrees completely with Joon", "She gives an example of an exhibition", "She changes the subject", "However 뒤에서 박물관이 멀다는 문제점을 말해요."),
Q("What does \"Besides\" introduce?", "An additional reason in favor of the aquarium", "A reason to choose the museum", "A result of the long bus ride", "A new place to visit", "Besides는 수족관을 선택하는 또 하나의 이유(싼 입장권)를 덧붙여요."),
Q("What do they decide to do?", "Propose the aquarium for the class trip", "Visit the science museum first", "Cancel the class trip", "Ask the teacher to choose", "수족관을 제안하기로 해요."),
Q("What will Joon do for the proposal?", "Add the price list", "Write the whole proposal", "Call the aquarium", "Book the bus", "Mina가 제안서를 쓰고 Joon이 가격표를 추가해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 2),

D("Sharing the Poster Work",
`Sora: We only have three days left for the poster. Who is doing what?
Ethan: I'll draw the charts. After that, I can help with the layout.
Sora: Great. Meanwhile, I'll write the text, and Dahye will collect the photos.
Dahye: Actually, I haven't started yet. I was sick on Monday.
Sora: Oh, I'm sorry. In that case, I'll collect the photos myself. You can proofread everything at the end.
Dahye: That works. Otherwise, I'd be too stressed. Thanks!
Ethan: So we're set. Let's meet again on Thursday and check our progress.`,
[
Q("What does \"Meanwhile\" show about Sora's plan?", "She will write the text while Ethan draws the charts", "She will write the text after the photos are done", "She will not write any text", "She will draw the charts instead of Ethan", "Meanwhile은 같은 시간에 다른 일을 한다는 뜻이에요."),
Q("Why does Sora change the plan for the photos?", "Dahye was sick and has not started", "Dahye does not want to join the group", "The photos are already finished", "Ethan wants to collect them", "Dahye가 아파서 시작하지 못했기 때문이에요."),
Q("What does Dahye mean by \"Otherwise, I'd be too stressed\"?", "If she had to collect the photos too, she would be too stressed", "If Sora said thank you, she would be stressed", "If the poster were finished, she would be stressed", "If Ethan helped her, she would be stressed", "Otherwise는 '그렇지 않으면', 즉 사진까지 모아야 했다면 부담이 컸을 것이라는 뜻이에요."),
Q("What will Dahye do for the poster?", "Proofread everything at the end", "Draw the charts", "Write the text", "Design the layout", "마지막에 전체를 교정하기로 해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 3),

D("At the Restaurant",
`Waiter: Welcome. Are you ready to order?
Customer: Yes. I'd like the grilled salmon, please.
Waiter: I'm afraid the salmon is sold out. Instead, I can recommend the roast chicken.
Customer: Hmm. I'm allergic to nuts. Does the chicken come with a nut sauce?
Waiter: Actually, yes, it does. Still, we can serve it with plain gravy.
Customer: In that case, I'll have it with the gravy. And a side salad, too.
Waiter: Certainly. Would you like anything to drink as well?
Customer: Just water, thanks.`,
[
Q("What does \"Instead\" show?", "The waiter offers a substitute for the sold-out dish", "The waiter refuses to serve the customer", "The customer changes the restaurant", "The waiter repeats the customer's order", "Instead는 품절된 메뉴 대신 다른 메뉴를 제안해요."),
Q("Why does the customer ask about the sauce?", "The customer is allergic to nuts", "The customer dislikes chicken", "The customer wants a cheaper dish", "The customer is in a hurry", "견과류 알레르기가 있기 때문이에요."),
Q("What does \"Still\" show in the waiter's answer?", "He offers a solution despite the problem", "He agrees that the chicken is unsafe", "He asks the customer to leave", "He adds a new price", "문제가 있어도 해결책(plain gravy)을 제시해요."),
Q("What will the customer order?", "Roast chicken with plain gravy, a side salad, and water", "Grilled salmon with a side salad and water", "Roast chicken with nut sauce and water", "Grilled salmon with plain gravy", "일반 그레이비를 곁들인 로스트 치킨, 샐러드, 물을 주문해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 2),

D("A New Date for the Cleanup",
`Hana: Our park cleanup was canceled because of the rain.
Min: That's disappointing. We need a new date, then.
Hana: What about this Saturday? The forecast looks sunny.
Min: Unfortunately, I have a dentist appointment in the morning. But I'm free after lunch.
Hana: Fine. Moreover, more members can join in the afternoon since soccer practice ends at noon.
Min: That's true. As a result, we can clean a bigger area.
Hana: Exactly. I'll text everyone tonight.`,
[
Q("Why was the cleanup canceled?", "It rained", "The park was closed", "Few members could come", "Min was at the dentist", "비 때문에 취소되었어요."),
Q("Why does Min prefer the afternoon?", "He has a dentist appointment in the morning", "He wants to sleep late", "The forecast is bad in the morning", "Soccer practice is at noon", "오전에 치과 예약이 있기 때문이에요."),
Q("What does \"Moreover\" introduce?", "Another reason for choosing the afternoon", "A reason to cancel the cleanup again", "A problem with the forecast", "An example of soccer practice", "Moreover는 오후가 좋은 또 하나의 이유(더 많은 회원 참여)를 덧붙여요."),
Q("According to Min, what will happen if more members join?", "They can clean a bigger area", "They will finish before lunch", "They will skip soccer practice", "They will need a new park", "As a result 뒤에서 더 넓은 구역을 청소할 수 있다고 해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 2),

D("Was the Movie Too Long?",
`Jun: I thought the movie was too long. Nearly three hours!
Yuna: I see your point. Still, the story needed that time to develop the characters.
Jun: Maybe. But the middle part dragged on. For instance, the scene in the train station lasted twenty minutes.
Yuna: Okay, that scene was slow. Nevertheless, the ending made it worthwhile for me.
Jun: Honestly, the music was the best part. It was beautiful, so I could forgive the length.
Yuna: See? We agree on something after all!`,
[
Q("What example does Jun give of the middle part dragging on?", "A twenty-minute scene in a train station", "A long conversation about music", "The final scene of the movie", "A scene with too many characters", "For instance 뒤에 기차역 장면이 20분 이어졌다는 예가 나와요."),
Q("What does Yuna's \"Still\" show?", "She partly agrees but defends the movie's length", "She completely agrees with Jun", "She changes the topic to music", "She says she did not see the movie", "Still은 인정하면서도 반대 의견을 이어 줘요."),
Q("What does \"so\" show in Jun's last turn?", "A result: the music made him forgive the length", "A contrast between music and story", "An example of a long scene", "The order of two scenes", "아름다운 음악 때문에 길이를 용서할 수 있었다는 결과예요."),
Q("What can be inferred about the two speakers?", "They disagree on some points but share an opinion about the music", "They both hated the whole movie", "They both loved every scene", "They have not decided what to watch", "영화 길이에는 이견이 있지만 음악에는 의견이 같아요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-03"], 3),

D("A Better Study Plan",
`Teacher: You wanted to talk about your study plan?
Student: Yes. I study from 7 to 11 every night, but my grades are not improving.
Teacher: How about your sleep?
Student: I usually sleep five hours. In addition, I skip breakfast.
Teacher: I see. That may be the problem. Although you study a lot, your brain is tired.
Student: So you think I should study less?
Teacher: Not exactly. Rather, you should study smarter. For example, take a ten-minute break every hour and go to bed by eleven.
Student: I'll try that. Thank you!`,
[
Q("What problem does the student describe?", "Long study hours are not improving the grades", "The student has no time to study", "The student dislikes the teacher", "The student sleeps too much", "오래 공부해도 성적이 오르지 않는다고 말해요."),
Q("What does \"In addition\" add?", "Skipping breakfast as another poor habit", "A reason the student studies late", "An example of a good habit", "A result of sleeping five hours", "In addition은 수면 부족에 더해 아침을 거르는 습관을 덧붙여요."),
Q("What does the teacher mean by \"Rather, you should study smarter\"?", "Study more effectively instead of simply studying less", "Study more hours every night", "Stop studying completely", "Sleep during the study time", "Rather는 '오히려'로, 덜 하는 게 아니라 더 효과적으로 하라는 뜻이에요."),
Q("What does \"For example\" introduce?", "Specific ways to study smarter", "Reasons for the student's low grades", "A list of the student's subjects", "A comparison with other students", "For example 뒤에 휴식과 취침 시간 같은 구체적 방법이 나와요."),
Q("What does the teacher think is causing the problem?", "A tired brain from too little rest", "Too little time spent studying", "Poor handwriting", "A lack of interest in the subject", "공부를 많이 해도 뇌가 피곤하다고 말해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-02"], 3),
];
