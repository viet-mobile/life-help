import { Q, R } from "./common.mjs";
const S2 = ["12영Ⅰ-01-04", "12영Ⅰ-01-02"];
export default [
R("Bike Lanes in the City",
`More cities are building protected bike lanes. Cycling costs far less than driving. (A), it keeps commuters fit without any extra time at the gym. Safety, however, is still a worry for many families. (B), accidents have dropped sharply on streets where the lanes are separated from traffic by low walls. Planners therefore hope that more residents will leave their cars at home.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In addition / (B) Even so", "(A) In addition / (B) For example", "(A) As a result / (B) Similarly", "(A) Otherwise / (B) Even so", "(A)는 장점을 덧붙이는 In addition, (B)는 안전 걱정과 대비되는 사실을 말하므로 Even so가 알맞아요."),
Q("What is the passage mainly about?", "The benefits of bike lanes and how they address safety worries", "Why driving is better than cycling in big cities", "The history of bicycle design in Europe", "A plan to ban cars from every city center", "자전거 도로의 장점과 안전 문제 해결을 다루고 있어요."),
Q("According to the passage, what has helped reduce accidents?", "Lanes separated from traffic by low walls", "Lower prices for new bicycles", "New speed limits for cyclists", "Free helmets for all commuters", "낮은 벽으로 차도와 분리된 도로에서 사고가 줄었다고 했어요."),
Q("What does \"however\" in the fourth sentence signal?", "A contrast with the benefits just mentioned", "An example of the benefits just mentioned", "A result of the low cost of cycling", "The order in which events happened", "however는 앞의 장점과 대비되는 걱정(안전)을 이끌어요."),
], S2, 3),

R("Change of Plan for Friday",
`Subject: Change of plan for Friday

Hi everyone,

I'm sorry to say that Friday's photography club meeting cannot be held in Room 204. The room is being used for a make-up exam. (A), we will meet in the art room on the second floor at the same time. (B), please bring your cameras and the printed photos from last week. Mr. Han will bring extra memory cards, so nobody needs to buy their own.

See you then,
Jisoo`,
[
Q("Which pair best fills (A) and (B)?", "(A) Therefore / (B) In addition", "(A) For example / (B) In addition", "(A) Therefore / (B) In contrast", "(A) Similarly / (B) For example", "방을 쓸 수 없다는 원인 뒤에 결과(Therefore), 그리고 준비물을 덧붙이므로 In addition이에요."),
Q("Why did Jisoo write this email?", "To announce a change of meeting place", "To cancel the club for the rest of the year", "To ask students to join the club", "To report the results of an exam", "모임 장소가 바뀌었음을 알리는 이메일이에요."),
Q("What should the members bring on Friday?", "Their cameras and printed photos", "Extra memory cards for Mr. Han", "Art supplies and a pencil case", "Notes from the make-up exam", "카메라와 지난주에 인쇄한 사진을 가져오라고 했어요."),
Q("Why does Jisoo mention Mr. Han's memory cards?", "To explain that members do not have to buy their own", "To warn members that the cards are very expensive", "To ask members to return the cards on Friday", "To say that the cameras will be checked", "so 뒤에 이유가 나와요: 여분의 카드가 있으니 살 필요가 없어요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 2),

R("Sleep and Teenagers",
`Teenagers need about nine hours of sleep a night, yet most get far less. One reason is biology: during adolescence the body clock shifts, so teens feel sleepy later in the evening. (A), early school start times force many students to wake up while their brains still want to sleep. (B) the lack of sleep, students often struggle to concentrate and remember what they learned. Some schools have tried starting classes an hour later and reported better grades and fewer absences.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In addition / (B) Because of", "(A) In contrast / (B) Because of", "(A) In addition / (B) Although", "(A) For example / (B) Despite", "두 번째 이유를 덧붙이는 In addition, 원인을 나타내는 명사구 앞에는 Because of가 와요."),
Q("What is the passage mainly about?", "Teenagers sleep too little for both biological and social reasons", "Teenagers should go to bed earlier than adults do", "School start times have no effect on grades", "Nine hours of sleep is too much for teenagers", "생물학적 이유와 학교 시간표 때문에 청소년의 수면이 부족하다는 내용이에요."),
Q("Why do teens feel sleepy later in the evening?", "Their body clock shifts during adolescence", "They drink too much caffeine", "They study late at night", "Their schools finish late", "사춘기에 체내 시계가 바뀌기 때문이라고 했어요."),
Q("In the last sentence, \"absences\" is closest in meaning to", "times when students are not at school", "times when students receive awards", "mistakes students make on tests", "classes that are very short", "absences는 결석, 즉 학교에 없는 경우를 뜻해요."),
Q("How is the last sentence related to the sentences before it?", "It describes a possible solution to the problem", "It gives an example that disproves the problem", "It repeats the first sentence in other words", "It begins an unrelated topic", "수면 부족 문제에 대한 해결 시도를 소개해요."),
], S2, 3),

R("A Small Fee, a Big Change",
`When the town of Greenfield began charging ten cents for each plastic bag, shoppers were annoyed. (A), within a year the number of bags given out had fallen by almost 80 percent. Many people now carry cloth bags, (B) the beaches nearby are cleaner than before. Not everyone is satisfied, though. Small shop owners say they spend more time explaining the fee to customers. Still, most agree that the policy has done more good than harm.`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) so", "(A) Therefore / (B) so", "(A) However / (B) because", "(A) For example / (B) unless", "불만이 있었지만(However) 결과적으로 사용이 줄었고, 천 가방 사용의 결과로 해변이 깨끗해져 so가 알맞아요."),
Q("What is the passage mainly about?", "A small fee greatly reduced plastic bag use, although some complaints remain", "Shop owners want to raise the price of plastic bags", "Cloth bags are more expensive than plastic bags", "A town has stopped all beach cleaning programs", "작은 요금이 비닐봉지 사용을 크게 줄였지만 불만도 남았다는 내용이에요."),
Q("By how much did the number of bags fall in a year?", "By almost 80 percent", "By ten cents per bag", "By about half", "By nearly 20 percent", "1년 안에 거의 80퍼센트 줄었다고 했어요."),
Q("What do small shop owners complain about?", "Explaining the fee takes extra time", "Customers refuse to buy cloth bags", "The fee reduces their sales", "The beaches are too far away", "요금을 설명하느라 시간이 더 든다고 했어요."),
Q("What can be inferred about most shop owners?", "They still support the policy overall", "They plan to stop charging the fee", "They think customers should pay more", "They did not notice any change", "Still, most agree ... 에서 대체로 정책을 지지함을 알 수 있어요."),
], S2, 3),

R("Central Library Closure",
`NOTICE: Central Library Renovation

The Central Library will close from March 3 to April 14 so that the reading rooms can be repaired and new computers installed. (A) the main building will be closed, the book-return box at the front gate will stay open every day. Members who wish to borrow books during this period can use the mobile library van, which will visit the community center on Tuesdays and Saturdays. (B), all due dates will be extended until April 21, and no late fees will be charged. We apologize for the inconvenience.`,
[
Q("Which pair best fills (A) and (B)?", "(A) Although / (B) In addition", "(A) Because / (B) In addition", "(A) Although / (B) In contrast", "(A) Unless / (B) For example", "Although는 양보(건물은 닫지만 반납함은 열림), In addition은 정보를 덧붙여요."),
Q("What is the main purpose of the notice?", "To inform members of a closure and the services still available", "To ask members for money to buy new computers", "To announce a new library at the community center", "To invite members to join a book club", "휴관과 이용 가능한 서비스를 알리는 공지예요."),
Q("When will the mobile library van visit the community center?", "On Tuesdays and Saturdays", "Every day of the week", "On Mondays and Fridays", "Only on Sundays", "화요일과 토요일에 방문한다고 했어요."),
Q("What will happen if a member returns a book on April 20?", "No late fee will be charged", "A late fee will be charged", "The book will not be accepted", "The member cannot borrow books again", "반납 기한이 4월 21일까지 연장되고 연체료가 없어요."),
], ["12영Ⅰ-01-01", "12영Ⅰ-01-04"], 2),

R("My First Loaf",
`Last weekend I baked bread for the first time, and it was harder than I expected. (A), I mixed flour, water, yeast, and salt in a big bowl. Then I kneaded the dough for ten minutes until my arms ached. (B), I covered it with a cloth and waited for it to double in size. I got impatient and opened the oven too early, so the loaf came out flat and heavy. Still, it tasted wonderful with butter, and I plan to try again next Sunday.`,
[
Q("Which pair best fills (A) and (B)?", "(A) First / (B) After that", "(A) Finally / (B) After that", "(A) First / (B) However", "(A) For example / (B) Next time", "처음 단계는 First, 반죽을 치댄 다음 단계는 After that이 알맞아요."),
Q("What is the passage mainly about?", "The writer's first attempt at baking bread was hard but rewarding", "A simple recipe that anyone can follow perfectly", "Why fresh bread is better than store-bought bread", "How to choose the best oven for baking", "첫 빵 굽기가 어려웠지만 보람 있었다는 내용이에요."),
Q("Why did the loaf come out flat?", "The writer opened the oven too early", "Too much yeast was used", "The dough was not kneaded", "The oven was too cold", "성급하게 오븐을 일찍 열었기 때문이에요."),
Q("In the passage, \"ached\" is closest in meaning to", "felt sore", "became stronger", "felt cold", "moved quickly", "ached는 아프다, 쑤시다라는 뜻이에요."),
Q("How does the writer feel at the end?", "Hopeful despite the failure", "Angry about the result", "Bored with baking", "Ashamed in front of friends", "Still, ... 와 다음 일요일에 다시 해 보겠다는 말에서 희망적임을 알 수 있어요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-03"], 2),

R("Why Learn Another Language?",
`Learning a foreign language offers more than the ability to order food on holiday. It trains the brain to notice patterns and to switch between ideas quickly. (A), studies suggest that bilingual people often find it easier to focus on one task while ignoring distractions. A new language also opens doors to other cultures, since reading a novel in its original language lets you feel the humor and rhythm that translations often lose. (B) learning a language takes years of patience, the rewards are worth the effort.`,
[
Q("Which pair best fills (A) and (B)?", "(A) For instance / (B) Although", "(A) However / (B) Although", "(A) For instance / (B) Because", "(A) Therefore / (B) Unless", "뇌 훈련의 구체적 사례는 For instance, 오래 걸리지만 보람 있다는 양보는 Although예요."),
Q("What is the passage mainly about?", "Learning a language benefits both the mind and cultural understanding", "Translations are better than original novels", "Language learning is only useful when travelling", "Adults learn languages faster than children", "언어 학습이 두뇌와 문화 이해 모두에 도움이 된다는 내용이에요."),
Q("According to studies, what are bilingual people often better at?", "Focusing on one task despite distractions", "Remembering long lists of words", "Reading books very quickly", "Ordering food on holiday", "방해 요소를 무시하고 한 가지에 집중하는 것이라고 했어요."),
Q("What would the writer most likely agree with?", "Language learning is worth the long effort", "Learning a language is easy for adults", "Only young people should study languages", "Humor can be translated perfectly", "마지막 문장에서 노력할 가치가 있다고 했어요."),
Q("In the passage, \"lose\" is closest in meaning to", "fail to keep", "forget by accident", "win against", "send away", "번역에서 유머와 리듬을 잃는다는 뜻이므로 fail to keep이에요."),
], S2, 4),

R("The Clever Octopus",
`The octopus has no bones, no shell, and only a short life, yet it is one of the cleverest animals in the sea. In laboratory tests, octopuses have opened jars to reach food inside. (A), some have escaped from sealed tanks at night and returned before morning. Scientists were once unsure how an animal with such a short life could learn so much. (B), they now think that its large nervous system, which extends into its eight arms, gives the octopus an unusual way of thinking.`,
[
Q("Which pair best fills (A) and (B)?", "(A) Moreover / (B) However", "(A) Moreover / (B) Therefore", "(A) Otherwise / (B) However", "(A) In contrast / (B) For example", "(A)는 놀라운 행동을 덧붙이는 Moreover, (B)는 예전의 의문과 대비되는 현재의 생각이라 However예요."),
Q("What have some octopuses done at night?", "Escaped from sealed tanks and come back", "Opened jars for other animals", "Built shells around themselves", "Hunted together in groups", "밤에 밀폐된 수조에서 탈출했다가 돌아왔다고 했어요."),
Q("Why were scientists once unsure about the octopus?", "Its short life seemed too brief for so much learning", "It has no bones", "It refuses to take part in tests", "It lives too far from laboratories", "짧은 수명으로 많은 것을 배우는 것이 의문이었어요."),
Q("In the passage, \"extends\" is closest in meaning to", "reaches", "shrinks", "separates", "protects", "extends into는 ~까지 뻗어 있다는 뜻이에요."),
], S2, 4),

R("Hanbok in Everyday Life",
`For many years, the hanbok was worn mainly on holidays and at weddings. (A), today a growing number of young Koreans wear modern versions in everyday life. Designers have shortened the skirts and used lighter fabrics, so the clothes are easier to move in. Tourists have joined the trend, too. (B), visitors to old palaces in Seoul often rent hanbok to take photographs. Some critics argue that these changes make the clothes less traditional. Supporters answer that a tradition stays alive only when people keep using it.`,
[
Q("Which word best fills (A)?", "However", "For example", "Therefore", "Similarly", "과거(명절에만 입음)와 현재(일상에서 입음)가 대조되므로 However예요."),
Q("Which expression best fills (B)?", "For example", "In contrast", "Otherwise", "Nevertheless", "관광객이 한복을 빌려 입는 것은 유행의 구체적인 예이므로 For example이에요."),
Q("What is the main idea of the passage?", "The hanbok is changing and becoming part of daily life", "Tourists should not be allowed to wear the hanbok", "Traditional clothes are no longer made in Korea", "Designers prefer heavy fabrics for the hanbok", "한복이 현대화되어 일상에 들어오고 있다는 내용이에요."),
Q("What do critics worry about?", "Modern changes may make the clothes less traditional", "The hanbok has become too expensive", "Tourists rent too few hanbok", "Young people dislike lighter fabrics", "변화가 전통성을 떨어뜨린다고 비판한다고 했어요."),
Q("How do supporters answer the critics?", "A tradition survives only if it is still used", "Old palaces should close to visitors", "Only holidays can keep a tradition alive", "Fabrics should never be changed", "전통은 사람들이 계속 사용해야 살아남는다고 답해요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-02", "12영Ⅰ-01-08"], 3),

R("Phones in the Classroom",
`Should students be allowed to use smartphones in class? (A), supporters say that phones are powerful learning tools: students can look up unfamiliar words, record a teacher's explanation, or share notes with classmates. (B), opponents point out that a single notification can pull a student's attention away from the lesson for several minutes. Neither side is entirely wrong. (C), a growing number of schools take a middle path, allowing phones only for specific activities chosen by the teacher.`,
[
Q("Which pair best fills (A) and (B)?", "(A) On the one hand / (B) On the other hand", "(A) On the other hand / (B) On the one hand", "(A) For example / (B) Therefore", "(A) In addition / (B) In contrast", "두 입장을 비교할 때는 On the one hand ... On the other hand 순서로 써요."),
Q("Which word best fills (C)?", "Therefore", "In contrast", "Otherwise", "Likewise", "양쪽 모두 일리가 있다는 데서 절충안이 나오므로 결과를 나타내는 Therefore예요."),
Q("What is the passage mainly about?", "Arguments for and against phones in class, and a compromise", "A ban on phones in every school in the world", "How teachers can record their lessons on phones", "Why notifications are useful for learning", "찬반 양측 주장과 절충안을 소개하는 글이에요."),
Q("According to opponents, what can one notification do?", "Pull a student's attention away for several minutes", "Help students find unfamiliar words", "Remind teachers to start the lesson", "Tell students when the class ends", "알림 하나가 몇 분 동안 집중을 흐트러뜨린다고 했어요."),
Q("What does the writer think of the two sides?", "Each side has some good points", "Supporters are completely right", "Opponents are completely right", "Neither side cares about learning", "Neither side is entirely wrong 에서 양쪽 모두 일리가 있다고 봐요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-06", "12영Ⅰ-01-08"], 4),

R("Teamwork in the Hive",
`A honeybee colony depends on teamwork. Worker bees leave the hive to collect nectar, (A) others stay inside to care for the young. When a worker finds a good patch of flowers, it returns and performs a "waggle dance" that shows the direction and distance. (B), the other workers can fly straight to the food without searching. This system is so efficient that a hive can gather huge amounts of nectar in a single season.`,
[
Q("Which word best fills (A)?", "while", "because", "so", "unless", "일부는 꿀을 모으고 다른 일부는 안에 머무는 대조이므로 while이에요."),
Q("Which expression best fills (B)?", "As a result", "In contrast", "For example", "Otherwise", "춤이 방향과 거리를 알려 주므로 결과적으로 곧장 날아갈 수 있어요."),
Q("What is the passage mainly about?", "How honeybees work together to find and collect food", "Why honeybees build hives in trees", "How to protect a hive from storms", "Which flowers make the sweetest nectar", "꿀벌이 협력하여 먹이를 찾고 모으는 방법을 설명해요."),
Q("What does the waggle dance show?", "The direction and distance of the flowers", "The number of bees in the hive", "The best time to leave the hive", "The danger of nearby animals", "춤은 꽃밭의 방향과 거리를 알려 줘요."),
Q("In the passage, \"efficient\" is closest in meaning to", "working well without wasting time", "very noisy", "hard to see", "dangerous for the hive", "efficient는 효율적인, 낭비 없이 잘 작동하는이라는 뜻이에요."),
], S2, 3),

R("Recycling at Our School",
`Our school's new recycling program is already making a difference. Since September, students have separated paper, cans, and plastic bottles into three colored bins in every classroom. (A), the amount of general waste has dropped by a third. The student council has also started a competition between classes, and the class that recycles the most each month wins a pizza party. Not all students take part, however. Some still throw everything into the nearest bin, (B) the council plans to put up reminder posters.`,
[
Q("Which pair best fills (A) and (B)?", "(A) As a result / (B) so", "(A) However / (B) so", "(A) As a result / (B) although", "(A) For example / (B) unless", "분리배출의 결과로 일반 쓰레기가 줄었고(As a result), 일부가 지키지 않아서 포스터를 붙이려는 것이니 so예요."),
Q("What is the passage mainly about?", "A school recycling program and its results so far", "How to open a pizza restaurant at school", "Why students dislike colored bins", "A plan to close the student council", "학교 재활용 프로그램과 지금까지의 성과를 다뤄요."),
Q("How are the bins organized?", "Paper, cans, and plastic bottles go in three colored bins", "Each student has one personal bin", "Only plastic bottles are collected", "There is one bin for the whole school", "종이, 캔, 플라스틱을 세 가지 색 통에 분리한다고 했어요."),
Q("Why did the student council start the competition?", "To encourage classes to recycle more", "To lower the price of pizza", "To replace the colored bins", "To punish classes that recycle less", "경쟁으로 더 많이 재활용하게 하려는 의도예요."),
Q("What does the council plan to do about students who do not recycle?", "Put up reminder posters", "Remove the pizza party", "Close the classroom bins", "Ask teachers to sort the waste", "일부 학생들을 위해 안내 포스터를 붙일 계획이에요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 2),

R("A Late Delivery",
`Dear Customer Service,

I ordered a desk lamp from your website on May 2 and was told it would arrive within five days. (A), it is now May 16, and I have received neither the lamp nor an explanation. I have written to you twice before. (B), I have checked the tracking page every day, and it still says "preparing for shipment." I would like to know where my order is. If it cannot be delivered by Friday, I would prefer a full refund.

Sincerely,
Daniel Park`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) In addition", "(A) Therefore / (B) In addition", "(A) However / (B) Instead", "(A) For example / (B) Otherwise", "약속과 달리 늦은 상황은 However, 이미 한 노력을 덧붙이는 것은 In addition이에요."),
Q("Why did Daniel write this email?", "To complain about a late order and ask for action", "To cancel a refund he already received", "To ask for a different kind of lamp", "To thank the company for fast delivery", "늦은 주문에 대해 항의하고 조치를 요구하는 글이에요."),
Q("What does the tracking page say?", "\"Preparing for shipment\"", "\"Delivered\"", "\"Out for delivery\"", "\"Order cancelled\"", "추적 페이지에 아직 'preparing for shipment'라고 나와 있어요."),
Q("What will Daniel want if the lamp cannot arrive by Friday?", "A full refund", "A discount on his next order", "A different delivery address", "A replacement lamp", "금요일까지 배송이 안 되면 전액 환불을 원한다고 했어요."),
Q("How would you describe Daniel's attitude?", "Frustrated but polite", "Delighted and relaxed", "Angry and rude", "Confused and uninterested", "불만이 있지만 정중한 어조예요."),
], ["12영Ⅰ-01-03", "12영Ⅰ-01-04"], 3),
];
