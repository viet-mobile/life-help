import { Q, R } from "./common.mjs";
const S2 = ["12영Ⅰ-01-04", "12영Ⅰ-01-02"];
export default [
R("Hiking in the Rain",
`We arrived in Jeju on Saturday morning, and the forecast said rain all weekend. (A) the weather, we decided to follow our plan and hike Hallasan. The trail was muddy, and the top was hidden in clouds. (B), the forests along the way looked magical in the mist, and we met very few other hikers. By the afternoon our shoes were soaked, but we were laughing. The next day the sun finally came out, so we spent it on the beach.`,
[
Q("Which pair best fills (A) and (B)?", "(A) Despite / (B) Even so", "(A) Because of / (B) Even so", "(A) Despite / (B) Therefore", "(A) Although / (B) For example", "날씨에도 불구하고(Despite), 힘든 길에도 불구하고(Even so) 숲이 아름다웠다는 흐름이에요."),
Q("What is the passage mainly about?", "Bad weather did not spoil the writers' hike", "The best time of year to visit Jeju", "How to prepare for a long mountain climb", "A disagreement between two hikers", "비가 와도 즐거웠던 하이킹 경험을 이야기해요."),
Q("Where did the writers spend the second day?", "On the beach", "At the top of Hallasan", "In a hotel room", "In a muddy forest", "다음 날에는 해변에서 시간을 보냈다고 했어요."),
Q("Why were the writers laughing in the afternoon?", "They were enjoying the trip even though they were wet", "They had reached the top and seen the view", "They had met many other hikers", "They had found a dry place to rest", "신발이 젖었지만 웃고 있었다는 것은 여행을 즐기고 있었다는 뜻이에요."),
Q("In the passage, \"hidden\" is closest in meaning to", "not able to be seen", "very high", "covered with mud", "easy to find", "hidden은 보이지 않는, 가려진이라는 뜻이에요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-02", "12영Ⅰ-01-03"], 2),

R("Why Coral Turns White",
`Coral reefs cover less than one percent of the ocean floor, yet about a quarter of all sea creatures depend on them. When the water becomes too warm, corals push out the tiny algae that live inside them and give them color. (A), the corals turn white, and this process is called bleaching. Bleached corals are not dead, but they are weak. (B) the water cools quickly, they can recover; otherwise, they slowly starve. Because reefs shelter so many fish, the loss of corals can also reduce the fish that people catch for food.`,
[
Q("Which pair best fills (A) and (B)?", "(A) As a result / (B) If", "(A) For example / (B) If", "(A) As a result / (B) Unless", "(A) Instead / (B) Although", "algae가 빠져나간 결과로 하얗게 되고(As a result), 물이 빨리 식는다는 조건이므로 If예요."),
Q("What percent of the ocean floor do coral reefs cover?", "Less than one percent", "About a quarter", "Nearly half", "More than ten percent", "산호초는 해저의 1퍼센트 미만을 차지해요. 4분의 1은 산호초에 의존하는 해양 생물의 비율이에요."),
Q("In the passage, \"otherwise\" means", "if the water does not cool quickly", "if the corals have bright colors", "because the corals recover", "after the fish are caught", "otherwise는 '그렇지 않으면', 즉 물이 빨리 식지 않으면이라는 뜻이에요."),
Q("What does the last sentence suggest?", "Coral loss may affect people as well as sea life", "People should stop eating fish completely", "Reefs will soon recover without help", "Bleaching only happens in cold water", "산호가 사라지면 사람들이 잡는 물고기도 줄 수 있다는 뜻이에요."),
Q("What is the passage mainly about?", "Why corals bleach and what it may lead to", "How fish choose a place to live", "Which sea animals are the largest", "How algae are grown in laboratories", "산호 백화의 원인과 영향을 설명하는 글이에요."),
], S2, 4),

R("What Volunteers Gain",
`Many people think that volunteering means giving up free time for nothing in return. In fact, it often gives the volunteer as much as it gives others. (A), students who help at animal shelters often say they become more patient and confident. (B), working with a team teaches them how to listen and share responsibility. Of course, volunteering must be balanced with schoolwork. Even so, two hours a month can be meaningful.`,
[
Q("Which pair best fills (A) and (B)?", "(A) For example / (B) In addition", "(A) In contrast / (B) In addition", "(A) For example / (B) However", "(A) Therefore / (B) Otherwise", "구체적인 예(For example)와 또 다른 이점의 추가(In addition)로 이어져요."),
Q("What does \"In fact\" in the second sentence do?", "It introduces a surprising point against a common belief", "It gives an example of the common belief", "It shows the order of two events", "It adds another reason for the common belief", "In fact는 앞의 통념과 반대되는 사실을 강조해 소개해요."),
Q("What is the main idea of the passage?", "Volunteering benefits the helper as well as other people", "Students should quit their studies to volunteer", "Animal shelters need more money than teams", "Teamwork is difficult for most teenagers", "봉사가 도움을 받는 사람뿐 아니라 하는 사람에게도 이롭다는 내용이에요."),
Q("What do students who help at animal shelters often say?", "They become more patient and confident", "They no longer need any free time", "They prefer animals to people", "They finish schoolwork faster", "더 인내심 있고 자신감 있게 된다고 말해요."),
Q("What does the writer suggest in the last two sentences?", "A small amount of time can still make a difference", "Volunteering is only for people with free time", "Two hours is too short to be useful", "Schoolwork matters less than volunteering", "한 달에 두 시간이라도 의미가 있다는 뜻이에요."),
], S2, 3),

R("Gardens in the Sky and on the Ground",
`In many crowded cities, empty rooftops are being turned into vegetable gardens. A rooftop garden needs little space, and it produces fresh food close to the people who eat it. (A), it keeps the building cooler in summer because the plants absorb heat. Community gardens at ground level offer a different kind of benefit. (B) rooftop gardens, which are often managed by a few residents, community gardens bring neighbors of all ages together to share tools, seeds, and stories.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In addition / (B) Unlike", "(A) In addition / (B) Like", "(A) However / (B) Unlike", "(A) Therefore / (B) Like", "추가되는 장점은 In addition, 옥상 정원과 달리 공동체를 모으는 것은 Unlike예요."),
Q("What is the passage mainly about?", "Different kinds of city gardens and their benefits", "How to grow tomatoes on a rooftop", "Why gardens are banned in crowded cities", "The history of community tools", "도시 정원의 종류와 장점을 소개하는 글이에요."),
Q("Why does a rooftop garden keep a building cooler?", "The plants absorb heat", "The soil is always wet", "The garden blocks the wind", "The food is kept in the shade", "식물이 열을 흡수하기 때문이에요."),
Q("What makes community gardens different?", "They bring neighbors of all ages together", "They are managed by only a few residents", "They are built on the top of buildings", "They sell vegetables at high prices", "공동체 정원은 모든 연령의 이웃을 모아 준다는 점이 달라요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-01"], 3),

R("The Cost of Cheap Clothes",
`Fast fashion companies release new clothes almost every week, and the prices are low enough that shoppers can buy several items at a time. (A) consumers enjoy the variety, the system has serious costs. Factories use huge amounts of water, and cheap clothes are often thrown away after being worn only a few times. (B), millions of tons of textile waste end up in landfills each year. Some young people are responding by buying second-hand clothes or repairing what they already own.`,
[
Q("Which pair best fills (A) and (B)?", "(A) Although / (B) As a result", "(A) Because / (B) As a result", "(A) Although / (B) In contrast", "(A) Unless / (B) For example", "소비자는 좋아하지만(Although) 비용이 크고, 옷을 쉽게 버린 결과(As a result) 쓰레기가 쌓여요."),
Q("What is the writer's attitude toward fast fashion?", "Critical of its environmental costs", "Fully supportive of its low prices", "Uninterested and neutral", "Worried only about the quality of clothes", "환경 비용을 문제 삼는 비판적인 태도예요."),
Q("In the passage, \"landfills\" are", "places where garbage is buried", "factories that make textiles", "shops that sell second-hand clothes", "rivers polluted by dye", "landfill은 쓰레기 매립지예요."),
Q("What are some young people doing in response?", "Buying second-hand clothes or repairing their own", "Making new clothes every week", "Throwing away clothes after a few days", "Working in textile factories", "중고 옷을 사거나 가진 옷을 수선하고 있어요."),
], S2, 4),

R("School Festival: Volunteers Wanted",
`School Festival: Volunteers Wanted

The annual school festival will take place on October 24. We need volunteers to help in three areas: setting up the stage, selling snacks, and guiding visitors. Students who choose the stage team must be able to arrive at 7:30 a.m. (A), those on the snack team can come at 9:00. All volunteers will receive a free T-shirt and lunch. (B) you are interested, please sign up at the student council room by October 10. Spaces are limited, so early applicants will be given priority.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In contrast / (B) If", "(A) Therefore / (B) If", "(A) In contrast / (B) Unless", "(A) For example / (B) Although", "도착 시간이 대비되므로 In contrast, 관심이 있다면 조건 If예요."),
Q("What is the purpose of this notice?", "To ask students to help at the festival", "To announce the winners of a contest", "To cancel the festival on October 24", "To sell tickets for the festival", "축제를 도울 자원봉사자를 모집하는 공지예요."),
Q("What will all volunteers receive?", "A T-shirt and lunch", "A ticket and a snack", "A certificate and a gift card", "A bag and a bottle of water", "모든 자원봉사자는 티셔츠와 점심을 받아요."),
Q("Who is more likely to get a place?", "Students who sign up early", "Students who arrive at 9:00", "Students who choose the snack team", "Students who bring a friend", "자리가 한정되어 일찍 신청한 학생이 우선이에요."),
], ["12영Ⅰ-01-01", "12영Ⅰ-01-04"], 2),

R("From Bitter Drink to Sweet Bar",
`Chocolate began as a bitter drink. About 3,000 years ago, people in Central America made it by grinding cacao beans and mixing them with water and spices. (A), it was so valuable that the beans were sometimes used as money. When Europeans brought cacao home in the 1500s, they added sugar to make it sweeter. (B), it was still a luxury that only the rich could afford. It was not until the 1800s that machines made chocolate cheap enough, and solid enough, to eat as a bar.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In fact / (B) Even then", "(A) In fact / (B) Therefore", "(A) Otherwise / (B) Even then", "(A) Therefore / (B) As a result", "가치가 높았다는 사실을 강조하는 In fact, 달게 만든 뒤에도 여전히 비쌌다는 Even then이에요."),
Q("What is the passage mainly about?", "How chocolate changed from a bitter drink to a common treat", "Why cacao beans were used as money", "How to make a chocolate bar at home", "Why Europeans disliked sugar", "초콜릿이 쓴 음료에서 흔한 간식으로 바뀐 과정을 다뤄요."),
Q("What did Europeans do to cacao in the 1500s?", "They added sugar to it", "They used it as money", "They sold it as a medicine", "They mixed it with spices only", "유럽인들은 설탕을 넣어 더 달게 만들었어요."),
Q("Which happened last?", "Machines made chocolate cheap enough to eat as a bar", "Beans were used as money", "Europeans added sugar to cacao", "People ground cacao with water and spices", "시간 순서상 1800년대 기계 생산이 가장 나중이에요."),
Q("In the passage, \"luxury\" is closest in meaning to", "something expensive that is not necessary", "a kind of sweet drink", "a cheap everyday item", "a tool for grinding beans", "luxury는 사치품을 뜻해요."),
], S2, 3),

R("Music While You Study",
`Many students say they study better with music playing. Research, however, suggests a more complicated picture. In one experiment, students read a science text either in silence or with songs that had lyrics. Those in silence remembered about 15 percent more. (A), instrumental music without words seemed to cause far less harm. The researchers explain that lyrics compete with reading for the same part of the brain. (B), if you need background sound, choose music without words.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In contrast / (B) Therefore", "(A) Similarly / (B) Therefore", "(A) In contrast / (B) Otherwise", "(A) For example / (B) However", "가사 있는 음악과 대비되는 연주곡은 In contrast, 연구 결과에 따른 조언은 Therefore예요."),
Q("What is the passage mainly about?", "Songs with lyrics can make studying less effective", "Silence is always the best way to relax", "Instrumental music is more expensive than songs", "Students should never listen to music", "가사가 있는 음악이 공부를 방해할 수 있다는 내용이에요."),
Q("How much more did students in silence remember?", "About 15 percent", "About 50 percent", "About 5 percent", "Almost all of the text", "침묵 속에서 읽은 학생들이 약 15퍼센트 더 기억했어요."),
Q("Why do lyrics harm reading, according to the researchers?", "They compete with reading for the same part of the brain", "They make the music too loud", "They are usually in a foreign language", "They are hard to hear while reading", "가사와 읽기가 뇌의 같은 부분을 두고 경쟁하기 때문이에요."),
Q("What can be inferred about students' beliefs?", "Their belief may not match the research results", "Their belief is proved completely right", "They never study in silence", "They dislike instrumental music", "많은 학생이 음악이 도움이 된다고 믿지만 연구는 다른 모습을 보여 줘요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-02", "12영Ⅰ-01-05"], 4),

R("Click, Try, Return",
`Online shopping has changed how we buy almost everything. Shoppers can compare prices in seconds, read reviews from other customers, and have items delivered to their door. (A), they cannot touch, try on, or test the products before paying. (B), many returns are caused by clothes that look different on the screen than in real life. Stores have responded by offering free returns, so shoppers feel safer ordering items they are unsure about.`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) For example", "(A) Therefore / (B) For example", "(A) However / (B) Otherwise", "(A) Similarly / (B) In contrast", "장점 뒤에 단점이 오므로 However, 단점의 구체적 예는 For example이에요."),
Q("What can shoppers NOT do when buying online?", "Try on or test the products before paying", "Compare prices quickly", "Read other customers' reviews", "Have items delivered home", "온라인에서는 구입 전에 만지거나 입어 볼 수 없어요."),
Q("What does \"so\" in the last sentence show?", "A result: free returns make shoppers feel safer", "A contrast between stores and customers", "An example of an unsafe product", "The order of two events", "so는 결과를 나타내요: 무료 반품 덕분에 더 안심하고 주문해요."),
Q("What is the main idea of the passage?", "Online shopping is convenient but has some drawbacks", "Stores should stop selling clothes online", "Shoppers prefer paying in cash", "Reviews are always false", "온라인 쇼핑의 편리함과 단점을 함께 다뤄요."),
], S2, 3),

R("The Camel's Hump",
`Camels are well adapted to life in the desert. Their wide, flat feet spread out on the sand, which stops them from sinking. A camel can also go for days without drinking. (A), it does not store water in its hump, as many people believe. (B), the hump holds fat, which the animal can break down for energy when food is hard to find. In other words, the hump works like a food supply rather than a water tank.`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) Instead", "(A) Therefore / (B) Instead", "(A) However / (B) For example", "(A) Similarly / (B) In addition", "혹에 물이 없다는 반전은 However, 대신 지방이 있다는 것은 Instead예요."),
Q("What does the hump of a camel store?", "Fat", "Water", "Sand", "Air", "혹에는 지방이 저장되어 있어요."),
Q("What does the last sentence do?", "It restates the idea with a simple comparison", "It adds a new and unrelated fact", "It contradicts the previous sentence", "It describes the cause of a problem", "In other words는 앞 내용을 쉬운 비유로 다시 말해요."),
Q("Why are a camel's feet wide and flat?", "They stop the camel from sinking into the sand", "They help the camel store water", "They keep the camel's body cool", "They help the camel find food", "넓고 평평한 발은 모래에 빠지지 않게 해요."),
], S2, 3),

R("Slow Progress on the Guitar",
`I started learning the guitar six months ago, and my progress has been slower than I hoped. Although I practice for thirty minutes every day, my fingers still hurt, and some chords sound terrible. My teacher says this is normal. (A) of getting discouraged, she suggests that I record myself once a week. When I listen to old recordings, I can hear how much I have improved. That small habit has changed my attitude, and I now look forward to practice rather than dreading it.`,
[
Q("Which word best fills (A)?", "Instead", "Because", "In spite", "Besides", "낙담하는 대신 녹음을 해 보라는 뜻이므로 Instead (of)가 알맞아요."),
Q("What is the passage mainly about?", "How a simple habit helped the writer stay positive about learning", "Why the guitar is the hardest instrument", "How to choose a good guitar teacher", "The writer's plan to give up music", "녹음하는 작은 습관이 학습 태도를 바꿨다는 내용이에요."),
Q("What does the teacher suggest?", "Recording himself or herself once a week", "Practicing for two hours a day", "Changing to an easier instrument", "Stopping until the fingers heal", "일주일에 한 번 녹음해 보라고 했어요."),
Q("How has the writer's attitude changed?", "From dreading practice to looking forward to it", "From loving practice to avoiding it", "From teaching others to learning alone", "From using a guitar to using a piano", "연습이 두렵던 상태에서 기대하는 상태로 바뀌었어요."),
Q("In the passage, \"discouraged\" is closest in meaning to", "less confident and hopeful", "angry and loud", "tired from walking", "ready to teach", "discouraged는 낙담한, 의욕을 잃은이라는 뜻이에요."),
], ["12영Ⅰ-01-04", "12영Ⅰ-01-03"], 3),

R("More Than Books",
`Public libraries are no longer just places to borrow books. Many now lend tools, musical instruments, and even board games. (A), they run free classes in coding, cooking, and languages. (B) these services, a library card can be worth hundreds of dollars a year. Some people believe that the Internet makes libraries unnecessary. (C), librarians point out that millions of people still lack a fast connection or a quiet place to study at home.`,
[
Q("Which pair best fills (A) and (B)?", "(A) In addition / (B) Thanks to", "(A) In contrast / (B) Thanks to", "(A) In addition / (B) Despite", "(A) Otherwise / (B) Because", "대여 서비스에 수업을 덧붙이는 In addition, 서비스 덕분에는 Thanks to예요."),
Q("Which word best fills (C)?", "However", "Therefore", "For instance", "Similarly", "도서관이 불필요하다는 믿음과 반대되는 사실을 말하므로 However예요."),
Q("What is the passage mainly about?", "Modern libraries offer many services beyond books", "Libraries should only lend books", "Free classes are a waste of money", "The Internet has closed most libraries", "현대 도서관이 책 외에도 다양한 서비스를 제공한다는 내용이에요."),
Q("What do librarians say about the Internet?", "Many people still lack a fast connection or quiet place at home", "It is too slow for libraries to use", "It should be banned in public libraries", "It is cheaper than a library card", "수백만 명이 여전히 빠른 연결이나 조용한 공간이 없다고 말해요."),
Q("What can be inferred about libraries?", "They still serve people who lack resources at home", "They no longer need librarians", "They have replaced schools", "They only help children", "집에 자원이 없는 사람들에게 여전히 필요하다는 뜻이에요."),
], S2, 4),

R("Electric Cars: Promise and Problems",
`Electric cars produce no exhaust, so they keep city air cleaner. Their running costs are also low, since electricity is usually cheaper than gasoline. (A), buyers face some real problems. A new electric car often costs more than a similar gasoline model, and charging stations are still rare in rural areas. (B), governments in many countries offer money to help people buy one. Experts expect that as batteries become cheaper, these obstacles will gradually disappear.`,
[
Q("Which pair best fills (A) and (B)?", "(A) However / (B) For this reason", "(A) Moreover / (B) For this reason", "(A) However / (B) In contrast", "(A) For example / (B) Otherwise", "장점 뒤에 문제를 말하므로 However, 문제 때문에 지원금이 있으므로 For this reason이에요."),
Q("Why are the running costs of electric cars low?", "Electricity is usually cheaper than gasoline", "They never need any repairs", "Governments pay for the electricity", "They are much smaller than other cars", "전기가 보통 휘발유보다 싸기 때문이에요."),
Q("In the last sentence, \"these obstacles\" refers to", "high prices and a lack of charging stations", "exhaust and dirty air", "cheap electricity and low running costs", "government money and expert opinions", "these obstacles는 앞에서 말한 높은 가격과 부족한 충전소를 가리켜요."),
Q("What do experts expect?", "Cheaper batteries will make the problems smaller", "Charging stations will disappear", "Gasoline will become cheaper", "Governments will stop giving money", "배터리가 싸지면 장애물이 점차 사라질 것이라고 해요."),
], S2, 3),
];
