import fs from "node:fs";
import p1 from "./part1.mjs";
import p2 from "./part2.mjs";
import { readings, dialogues } from "./part3.mjs";
import { ms, ss } from "./part4.mjs";
const items = [...p1, ...p2, ...readings, ...dialogues, ...ms, ...ss];
const out = { packet: "H04-h1-conn", sections: [{ skill: "e.h1.conn", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H04-h1-conn.json", JSON.stringify(out, null, 1) + "\n");
const c = {}; for (const i of items) c[i.k] = (c[i.k] || 0) + 1; console.log(c);
