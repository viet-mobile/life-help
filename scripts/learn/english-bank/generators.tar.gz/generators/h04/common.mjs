// helpers: correct option first; rotated into a deterministic position
let n = 0;
export const Q = (q, ok, a, b, c, why) => {
  const wrong = [a, b, c];
  const pos = (n++ * 3 + 1) % 4;
  const o = [...wrong];
  o.splice(pos, 0, ok);
  return { q, o, a: pos, why };
};
export const R = (title, text, qs, std = ["12영Ⅰ-01-04"], d = 3) => ({ k: "r", title, text, qs, std, d });
export const D = (title, text, qs, std = ["12영Ⅰ-01-04"], d = 3) => ({ k: "d", title, text, qs, std, d });
export const M = (q, ok, a, b, c, why, cat = "connectives", d = 3) => {
  const x = Q(q, ok, a, b, c, why);
  return { k: "m", q, o: x.o, a: x.a, why, cat, std: ["12영Ⅰ-01-04"], d };
};
export const S = (good, ko, bad, st, ok, wr, rule, ord = true) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...(ord ? {} : { ord: false }) });
