import fs from "node:fs";
let t = fs.readFileSync("gen.mjs", "utf8");
const R = [
["when I was walking to the station with my friends.", "when I was walking to the station with my friends last Saturday afternoon."],
["Please help me, it is urgent and I have been worried for many days", "Please help me, it is urgent and I have been worried about everything for many days"],
["School uniforms are clothes that students put on before they go to their classes.", "School uniforms are the clothes that students put on at home before they walk to their classes each morning."],
["many students already like eating it at lunch.", "many students already like eating it at lunch with their friends in the cafeteria."],
["\"When they met, she was carrying a heavy bag.\"", "\"When the two girls met, she was carrying a heavy bag.\""],
["I think everybody should do it.\"", "I think everybody should do it at home and at school.\""],
["the best person you will ever interview.", "the best person you will ever interview this year."],
["Why would you invite me to that kind of party?", "Why would you invite me to that kind of boring party in the first place?"],
["\"catch\", \"fetch\"", "\"catch\", \"retrieve\""],
["during the summer holidays every year.", "during the summer holidays every year in most large cities across the country."],
["Meeting every Friday in the old gym after class.", "Meeting every Friday in the old gym after the lessons end."],
["Plastic is a material that is made in factories and used in many products.", "Plastic is a material that is made in large factories and used in a great many different products."],
["Quoting one sentence in quotation marks and naming the author\"", "Quoting one sentence in quotation marks and naming the author of the book\""],
["and it was a movie that many people watched.", "and it was a movie that many people watched in the city."],
["Bike use stayed about the same over the three years.", "Bike use stayed about the same over the three years that the graph covers."],
["I will never shop at your store again and I will tell everyone.", "I will never shop at your store again and I will tell everyone I know about this."],
["Choosing a topic together with other classmates\"", "Choosing a topic together with other classmates and the teacher\""],
["[\"A Day at School\", \"Why I Like Lunch\",", "[\"A Long and Happy Day at Our Local Middle School\", \"Why I Really Like Eating Lunch with My Friends\","],
["Therefore, the drawbacks of online classes are really advantages.", "Therefore, all of the drawbacks of online classes are really advantages."],
["to use cameras inside.", "to use cameras inside the reading area."],
["[\"in spite of\", \"as a representative of\", \"in front of\", \"in exchange for\"]", "[\"in spite of\", \"representing\", \"in front of\", \"in exchange for\"]"],
["Why people no longer borrow books from libraries", "Why people no longer borrow printed books from libraries"],
["Teaching newcomers the local language only", "Teaching newcomers the local language and nothing else"],
["\"By promising to buy many new novels\", \"By saying that reading is no longer important\", \"By pointing out that visitors attracted by activities may also borrow books\", \"By closing the meeting rooms during exam season\"", "\"By promising to buy many new novels for the main collection\", \"By saying that reading is no longer important to most visitors\", \"By noting that visitors drawn by activities often borrow books too\", \"By closing the meeting rooms during the busy exam season each year\""],
["The writer sees them as a natural and useful development.", "The writer sees them as natural and useful."],
["From curiosity to disappointment", "From curiosity to bitter disappointment and regret"],
["To record the people and moments that matter, as Grandma did", "To record people and moments that matter, as Grandma did"],
["To collect all of Grandma's recipes in one place", "To collect all of Grandma's recipes in one place before they are forgotten"],
["\"Bitter and resentful\", \"Cold and formal\", \"Affectionate and lightly humorous\", \"Serious and fearful\"", "\"Bitter and resentful toward her mother\", \"Cold and strictly formal throughout\", \"Affectionate and lightly humorous\", \"Serious and deeply fearful about it\""],
["A section of a university application essay", "Part of a college application essay"],
["They have made the writer more interested in cooking.", "They have made the writer more interested in cooking and gardening."],
["[\"carelessly\", \"carefully and strictly\", \"quickly and loudly\", \"secretly\"]", "[\"carelessly\", \"with great care\", \"quickly and loudly\", \"secretly\"]"],
["The first failure convinced the writer to quit the newspaper.", "The first failure convinced the writer to quit the newspaper and play sports instead."],
["The first complaint made the writer dislike interviewing teachers.", "The first complaint made the writer dislike interviewing teachers and other adults at school."],
["A principal has banned students from using the school roof.", "A principal has banned students from using the school roof for sports."],
["The garden is open to families every Saturday.", "The garden is open to families every Saturday throughout the whole year."],
["Students will record plant growth once a year.", "Students will record plant growth once a year in a shared school notebook."],
["The writer fully supports a complete ban on phones.", "The writer fully supports a complete ban on phones throughout the school day."],
["So that teachers have less work to do at lunch", "So that teachers have much less work to do during the long lunch break"],
["Benefits of green roofs, then drawbacks, then a recommendation", "Advantages, then drawbacks, then a recommendation"],
["A history of roofs from ancient times to today", "A history of roofs from ancient times to the modern day"],
["New buildings need fewer plants than old ones.", "New buildings need fewer plants than old ones do, so they cost less."],
// validation fixes
["[\"The test was difficult, however, most students passed.\", \"The test was difficult however, most students passed.\", \"The test was difficult; however most students, passed.\"]", "[\"The test was difficult, but however most students passed.\", \"The test was difficult; however, most students has passed.\", \"The test was difficult; however, passed most students.\"]"],
["Which sentence quotes the question correctly?\", [\"She asked where is the library?\", \"She asked, “Where is the library?”\", \"She asked “where is the library”?\", \"She asked: Where is the library”?\"], 1, \"직접 인용문은 따옴표 안에 넣고, 첫 글자를 대문자로 쓰며 물음표를 인용 안에 넣어요.\"", "Which sentence reports the question “Where is the library?” correctly?\", [\"She asked where was the library.\", \"She asked where the library was.\", \"She asked that where the library was.\", \"She asked where did the library be.\"], 1, \"간접화법에서는 의문사 뒤에 ‘주어 + 동사’ 순서를 쓰고 시제를 한 단계 과거로 바꿔요.\""],
["[\"The film was long, we enjoyed it.\", \"The film was long and, we enjoyed it.\", \"The film was long, but we enjoyed it.\", \"The film was long but we enjoyed, it.\"]", "[\"The film was long, we enjoyed it.\", \"The film was long and, we enjoyed it.\", \"The film was long, but we enjoyed it.\", \"The film was long, so but we enjoyed it.\"]"],
];
for (const [a, b] of R) { const n = t.split(a).length - 1; if (n !== 1) console.log("MISS/MULTI", n, a.slice(0, 60)); t = t.replace(a, () => b); }
// drop Children's s item
t = t.replace(/S\("Children's books[^\n]*\n/, "");
// add one m item
t = t.replace(/(M\("Which sentence best connects a paragraph[^\n]*\n)\];/, `$1M("Which word best completes “The writer's argument is persuasive ___ she supports each claim with evidence”?", ["although", "unless", "because", "until"], 2, "근거로 주장을 뒷받침하기 때문에 설득력이 있다는 인과 관계이므로 because가 알맞아요.", ["12영독02-08"]),\n];`);
fs.writeFileSync("gen.mjs", t);
