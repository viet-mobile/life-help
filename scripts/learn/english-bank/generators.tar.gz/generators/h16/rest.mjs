import { Q, D, M } from "./lib.mjs";
export const dialogues = [
D("Booking a Table by Phone", `Host: Good evening, Olive Garden Kitchen. How may I help you?
Customer: Hi, I'd like to reserve a table for six on Saturday evening, if you have one.
Host: Let me check. What time were you thinking?
Customer: Around seven would be ideal. It's for my father's retirement dinner.
Host: Congratulations to him! Unfortunately, seven is fully booked, but I can offer a table at six thirty or one at eight fifteen.
Customer: Hmm, my grandmother goes to bed early, so six thirty would be better. Is there a quiet corner?
Host: Yes, there's a round table near the window, away from the kitchen. May I have your name and number?
Customer: It's Kim, and my number is 555-0142.
Host: Thank you, Ms. Kim. One more thing: if you'd like a cake, you're welcome to bring one, and we will not charge a serving fee.
Customer: That's very thoughtful. Thank you so much.`, [
 Q("Why is the customer making the reservation?", "To celebrate her father's retirement", ["To hold a birthday party for her grandmother", "To meet a friend after work", "To thank the restaurant staff"], "아버지의 은퇴 기념 저녁 식사 때문이에요."),
 Q("Why does the customer choose six thirty?", "Her grandmother goes to bed early.", ["She prefers to eat before the restaurant gets crowded.", "The later table was too far from the kitchen.", "The host said that seven was cheaper."], "할머니가 일찍 주무시기 때문이에요."),
 Q("What does the host say about a cake?", "The family may bring one without an extra charge.", ["The restaurant will bake one for free.", "Cakes are not permitted inside the restaurant.", "A serving fee must be paid in advance."], "케이크를 가져와도 서빙 요금이 없다고 해요."),
 Q("What is the host's purpose in saying \"Congratulations to him!\"?", "To respond kindly to the personal news", ["To change the reservation date", "To ask for the father's name", "To end the call politely"], "고객이 알려 준 개인적인 소식에 친절히 반응한 거예요."),
 Q("Where is the table the host offers?", "Near the window and away from the kitchen", ["Next to the kitchen door", "In the center of the dining room", "Outside on the patio"], "창가의 둥근 테이블이고 주방과 떨어져 있다고 해요."),
], ["12실영01-01", "12실영01-07"]),

D("Can I Borrow Your Notes?", `Jina: Hey, Marcus, do you have a minute?
Marcus: Sure. What's up?
Jina: I was in the clinic yesterday and missed the history lecture. Would you mind lending me your notes?
Marcus: Of course, but my handwriting is awful. You might have trouble reading it.
Jina: That's fine. I'd just like to see the main points before the quiz on Friday.
Marcus: Then why don't I scan the pages and send them tonight? That way I can keep the originals in case I need them.
Jina: That would be perfect. Thank you! I'll buy you a drink next time.
Marcus: No need. Actually, the teacher mentioned that the quiz will focus on the last two chapters, so concentrate on those.
Jina: Really? You're a lifesaver. I'd have wasted hours on the early part.
Marcus: Anytime. Let me know if anything is hard to understand.`, [
 Q("Why does Jina need Marcus's notes?", "She missed a lecture because she was at the clinic.", ["She lost her own notebook.", "She wants to compare answers on the quiz.", "She forgot which chapter was assigned."], "어제 진료소에 가서 수업을 놓쳤어요."),
 Q("What does Marcus offer to do?", "Scan the pages and send them that night", ["Give her his notebook for a week", "Explain the lecture to her in person", "Write a new summary for the class"], "스캔해서 오늘 밤 보내 주겠다고 해요."),
 Q("What useful information does Marcus add?", "The quiz will mostly cover the last two chapters.", ["The quiz has been moved to a later week.", "The teacher will let students use notes.", "The lecture was recorded for absent students."], "퀴즈가 마지막 두 단원에 집중될 거라고 알려 줘요."),
 Q("What does \"You're a lifesaver\" express?", "Strong gratitude for very helpful advice", ["A joke about a medical emergency", "Disappointment about a missed class", "A refusal of the offer"], "'You're a lifesaver'는 큰 도움을 준 데 대한 고마움을 나타내요."),
 Q("Why does Marcus say \"my handwriting is awful\"?", "He is warning her that his notes might be hard to read.", ["He is refusing to lend them to her.", "He wants her to practice writing.", "He is asking her to rewrite the notes."], "글씨가 엉망이라 읽기 어려울 수 있다는 주의를 주는 말이에요."),
], ["12실영01-01", "12실영01-02"]),

D("At the Store Counter", `Customer: Excuse me, I bought this jacket here last week, but the zipper broke the first time I used it.
Clerk: I'm so sorry to hear that. May I see your receipt?
Customer: Here it is. I'd like to exchange it for another one, if that's possible.
Clerk: Let me check. Yes, you're still within the thirty-day return period. Would you like the same style, or would you prefer a refund?
Customer: I really like this style, so I'd rather have the same jacket in my size.
Clerk: Unfortunately, we only have it in black now. The navy one is sold out.
Customer: Black is fine, as long as the zipper works.
Clerk: I tested the zipper myself, and it works smoothly. I'll also include a card for an extra year of repairs.
Customer: That's very helpful. Thank you for sorting this out so quickly.
Clerk: My pleasure. Enjoy your new jacket.`, [
 Q("What is the customer's problem?", "The zipper on a new jacket broke.", ["The jacket was the wrong size.", "The store charged her too much.", "The color faded after one wash."], "새 재킷의 지퍼가 처음 사용할 때 고장 났어요."),
 Q("Why does the customer accept a black jacket?", "She likes the style and the zipper works.", ["The navy one costs more.", "She dislikes the color navy.", "The clerk insisted on black."], "스타일이 마음에 들고 지퍼가 잘 작동하면 괜찮다고 해요."),
 Q("What extra service does the clerk give?", "A card for another year of repairs", ["A discount on a future purchase", "Free delivery of the jacket", "A refund of the original price"], "수선 1년 추가 카드를 준다고 해요."),
 Q("What does the clerk's last remark \"My pleasure\" show?", "A polite reply to the customer's thanks", ["An apology for the customer's trouble", "A warning about the store's policy", "A request for the customer to return later"], "'My pleasure'는 감사 인사에 대한 공손한 응답이에요."),
], ["12실영01-07", "12실영01-08"]),

D("At the Lost Property Office", `Staff: Good afternoon. How can I help you?
Passenger: Hello. I think I left my laptop bag on the train this morning. I got off at the last stop, and when I got to work, it was gone.
Staff: I'm sorry about that. Can you describe the bag?
Passenger: It's a dark gray backpack with a red tag on the zipper. There's also a small sticker of a mountain on the front.
Staff: And roughly what time was the train?
Passenger: It left Central Station at about eight fifteen, and I sat in the third carriage.
Staff: Hold on a moment while I check the list. Yes, a gray backpack was handed in by a cleaner an hour ago. Can you tell me what's inside?
Passenger: A laptop, a blue notebook, and a charger with a yellow cable.
Staff: That matches. Please show me your ID, and you can take it.
Passenger: Thank you so much. I was so worried!`, [
 Q("What did the passenger lose?", "A gray backpack with a laptop", ["A blue notebook on the platform", "A phone with a yellow cable", "A coat with a red tag"], "노트북이 든 회색 배낭을 잃어버렸어요."),
 Q("Why does the staff member ask what is inside the bag?", "To confirm that it belongs to the passenger", ["To find out how heavy it is", "To decide how much to charge", "To see whether it is dangerous"], "소지품을 말하게 해 주인임을 확인하려는 거예요."),
 Q("Who found the bag?", "A cleaner who handed it in", ["Another passenger on the platform", "The station's security camera", "The passenger's colleague"], "청소원이 한 시간 전에 맡겼다고 해요."),
 Q("What must the passenger show before taking the bag?", "An ID", ["A train ticket", "A receipt for the laptop", "A letter from his employer"], "신분증을 보여 달라고 해요."),
 Q("What does \"Hold on a moment\" ask the passenger to do?", "Wait briefly", ["Speak more slowly", "Come back tomorrow", "Describe the bag again"], "'Hold on a moment'는 잠시 기다려 달라는 뜻이에요."),
], ["12실영01-01", "12실영01-06"]),
];

export const ms = [
M("A: \"I'm sorry, but I can't make it to your party on Saturday.\"\nB: \"___\"\nWhich reply is the most appropriate for B?", "That's too bad. Maybe we can get together some other time.", ["Never mind. I wasn't going to invite you in the first place.", "Great, because I really wanted fewer people to come.", "You can't? Then I'll cancel the whole party for you."], "거절을 받아들이고 다음을 기약하는 응답이 적절해요.", "functions"),
M("A caller says, \"Hello, may I speak to Ms. Park, please?\" Which reply is the most natural for the receptionist?", "I'm afraid she's in a meeting right now. Can I take a message?", ["Yes, I am speaking to Ms. Park, and she is very well.", "She spoke to me yesterday, so I know her quite well.", "Please send a letter because phones are not for talking."], "전화 응대에서는 부재를 알리고 메시지를 받겠다고 하는 것이 자연스러워요.", "phone"),
M("A guest says to the host, \"It's a little cold in here, isn't it?\" What does the guest most likely want?", "The host to close the window or turn up the heat", ["The host to explain how the weather forecast works", "The host to give her the price of the room", "The host to tell her where the thermometer is"], "간접적인 표현으로 창문을 닫거나 난방을 올려 달라는 완곡한 요청이에요.", "inference"),
M("Which request is the most polite way to ask a teacher to explain something again?", "Excuse me, would you mind explaining that once more?", ["Hey, could you just say that stuff one more time?", "Say that again, I wasn't paying attention at all.", "What? I didn't get any of it, so go back."], "would you mind -ing는 정중한 요청 표현이에요.", "register"),
M("Your friend says, \"We've been working for six hours. Let's call it a day.\" What does your friend mean?", "Let's stop working for now.", ["Let's start the project again tomorrow morning at six.", "Let's phone each other every day this week.", "Let's decide on a date for the party."], "call it a day는 '오늘 일은 여기까지 하자'는 관용 표현이에요.", "idioms"),
M("When someone says, \"I'll take a rain check,\" what do they usually mean?", "They cannot accept now but would like to do it another time.", ["They are ready to accept the invitation immediately.", "They want to know about tomorrow's weather forecast.", "They plan to pay the bill by personal check."], "rain check는 지금은 거절하지만 다음에 하자는 뜻이에요.", "idioms"),
M("A: \"Where should we eat tonight, pizza or noodles?\" B: \"It's up to you.\" What does B mean?", "You can decide; either choice is fine with me.", ["I do not want to eat anything tonight.", "I would like to pick the restaurant myself.", "Please ask someone else to decide."], "It's up to you는 '네가 정해'라는 뜻이에요.", "idioms"),
M("Your friend's essay has a weak ending. Which comment is the most tactful?", "Your ideas are strong; maybe the ending could be a bit clearer.", ["Your ending is terrible, so you should write it again.", "Nobody will understand your ending, so don't hand it in.", "The essay is fine, but I have not read the ending."], "장점을 먼저 말하고 완곡하게 개선점을 제안하는 것이 가장 배려 있는 표현이에요.", "feedback"),
M("You want to add a point while a classmate is speaking. Which expression is the most appropriate?", "Sorry to interrupt, but may I add one point?", ["Stop talking now, because I have something to say.", "Be quiet for a second; my point is far better.", "Excuse me, I will not add anything to your point."], "Sorry to interrupt, but ...는 끼어들 때 쓰는 공손한 표현이에요.", "turn-taking"),
M("You are talking with a new neighbor and want to end the conversation politely. What should you say?", "It was great talking to you. I'd better get going.", ["You talk a lot, so I will leave now.", "The conversation is over, and you may go.", "I hope we never have to speak about this again."], "대화를 마무리할 때는 즐거웠다는 말과 함께 가봐야 한다고 말해요.", "closing"),
M("Your friend says, \"I failed my driving test again.\" Which response shows the most sympathy?", "Oh no, I'm sorry to hear that. Do you want to talk about it?", ["Congratulations! You must be very pleased with yourself.", "That's nice. What are we having for lunch today?", "Well, you should have practiced harder, obviously."], "공감과 위로를 담은 표현이 적절해요.", "sympathy"),
M("A speaker says, \"So, if I understand you correctly, the meeting has moved to Friday?\" What is she mainly doing?", "Checking that she has understood the information", ["Refusing to attend the meeting", "Changing the topic of the conversation", "Offering to organize the next event"], "'if I understand you correctly'는 이해한 바를 확인하는 표현이에요.", "strategies"),
M("A student says, \"I might be wrong, but I think the second plan costs more.\" Why does he begin with \"I might be wrong\"?", "To make his opinion sound less forceful", ["To show that he is completely certain", "To ask the listener for money", "To end the discussion immediately"], "I might be wrong은 의견을 부드럽게 만드는 완화 표현(hedge)이에요.", "hedging"),
M("Someone asks, \"Could you give me a hand with these boxes?\" What does the speaker want?", "Your help in moving the boxes", ["You to applaud for the boxes", "You to hold the boxes upside down", "You to count the boxes for an hour"], "give me a hand는 '도와주다'라는 관용 표현이에요.", "idioms"),
M("A friend says, \"Thanks a lot for helping me move!\" Which reply is the most natural?", "No problem. I was glad to help.", ["Yes, I helped you a lot, so now you owe me.", "It does not matter because I am not helped.", "A lot of help is a lot of thanks for you."], "감사에는 No problem, You're welcome 등으로 응답해요.", "functions"),
M("A passer-by says, \"The post office is right across from the bank.\" Where is the post office?", "On the opposite side of the street from the bank", ["Inside the bank building", "Two streets away from the bank", "Directly behind the bank building"], "across from은 '건너편에'라는 뜻이에요.", "directions"),
M("A customer says, \"I asked for a small coffee, but this is a large.\" Which reply from the server is the most appropriate?", "I'm so sorry about that. I'll make you a small one right away.", ["That's your problem, because you ordered it.", "Large is better, so just drink it anyway.", "Small and large are the same thing here."], "실수를 인정하고 바로잡겠다고 하는 것이 적절한 서비스 응대예요.", "service"),
M("Which opening is the most suitable for an email to a professor you have not met?", "Dear Professor Kim, I am writing to ask about the assignment deadline.", ["Hey Prof, what's up with the assignment deadline?", "Yo Professor Kim! Tell me the deadline fast.", "Hi there, deadline question: when is it?"], "교수님께는 격식 있는 호칭과 목적을 밝히는 문장이 적절해요.", "register"),
M("A classmate says, \"That's a lovely jacket!\" Which reply is the most natural?", "Thank you! I got it last week.", ["You are wrong, because you cannot see well.", "I did not ask your opinion about my jacket.", "Please stop looking at my clothes."], "칭찬에는 감사로 응답하는 것이 자연스러워요.", "compliments"),
M("You want to suggest visiting the science museum on Saturday. Which sentence is correct?", "How about going to the science museum on Saturday?", ["How about go to the science museum on Saturday?", "Why we don't go to the science museum on Saturday?", "Let's to go to the science museum on Saturday."], "How about + -ing 형태로 제안해요.", "suggestions"),
M("You see a stranger struggling with a heavy bag. Which sentence offers help in a natural way?", "Would you like me to carry that bag for you?", ["Do you want that I carry your bag?", "Will you carrying my bag, please?", "May I to carry your bag for you?"], "Would you like me to + 동사원형은 도움을 제안하는 자연스러운 표현이에요.", "offers"),
M("At a first meeting, which question is NOT appropriate for small talk?", "How much money does your family make?", ["What do you like to do on weekends?", "How was your trip here?", "Have you been to this café before?"], "소득은 처음 만난 사이에 묻기에 부적절한 사적인 질문이에요.", "small-talk"),
M("Your teammate says, \"We should use the blue poster.\" You see it differently. Which reply disagrees politely?", "That's a fair point, but I see it a little differently.", ["That is nonsense, and you know it.", "I couldn't agree more with you.", "You are completely wrong about everything."], "상대 의견을 인정하며 부드럽게 반대하는 표현이에요.", "disagreeing"),
M("A friend says, \"I'm terribly sorry for being late. The bus broke down.\" Which reply accepts the apology?", "That's all right. These things happen.", ["I will never forgive you for this.", "You should have taken a taxi, obviously.", "No excuses are allowed in my meetings."], "That's all right는 사과를 받아들이는 표현이에요.", "apology"),
M("A receptionist says on the phone, \"Please hold the line.\" What should the caller do?", "Wait on the phone without hanging up", ["Hang up and call again tomorrow", "Speak more loudly so she can hear", "Give her a different phone number"], "hold the line은 전화를 끊지 않고 기다리라는 뜻이에요.", "phone"),
M("Which sentence is the most indirect and polite way to ask to borrow a classmate's notes?", "I was wondering if you could lend me your notes.", ["Lend me your notes.", "Give me your notes now, please.", "I want your notes, so lend them."], "I was wondering if ...는 매우 완곡한 요청 표현이에요.", "requests"),
M("Someone asks, \"Would you like tea or coffee?\" You prefer tea. Which reply is correct?", "I'd rather have tea, please.", ["I'd rather to have tea, please.", "I'd rather having tea, please.", "I'd rather had tea, please."], "would rather 다음에는 동사원형이 와요.", "preferences"),
M("Which closing is the most suitable for a formal letter that begins \"Dear Mr. Smith\"?", "Sincerely, Minji Han", ["Cheers, Minji", "See ya later, Minji", "Your pal, Minji"], "격식 있는 편지는 Sincerely로 끝맺는 것이 알맞아요.", "register"),
M("Someone says, \"I said Tuesday, not Thursday. We need to meet on Tuesday.\" What is the speaker doing?", "Correcting a misunderstanding about the day", ["Apologizing for arriving late", "Refusing an invitation to a meeting", "Asking for directions to the office"], "잘못 이해한 요일을 바로잡고 있어요.", "strategies"),
M("A shop assistant says, \"Is there anything else I can help you with?\" You have everything you need. Which reply is the most natural?", "No, that's all, thank you.", ["No, I am helping you with everything else.", "Yes, that's all, so please help me.", "That is not all, but I need nothing."], "필요한 게 없으면 No, that's all, thank you.라고 해요.", "service"),
M("Your friend says, \"Congratulations on winning the speech contest!\" Which reply is the most natural?", "Thanks! I was really nervous, but it went well.", ["No, congratulations to you for losing.", "Why are you telling me something I already know?", "It was nothing, and I hate speaking."], "축하에는 감사로 답하고 간단한 소감을 덧붙이는 것이 자연스러워요.", "compliments"),
];

export const ss = [
{ k: "s", good: "Could you tell me where the post office is?", ko: "우체국이 어디 있는지 알려 주시겠어요?", bad: ["Could you tell me where is the post office?", "Could you tell me where the post office?", "Could you tell me where does the post office is?"], cz: { st: "Could you tell me where the post office ___?", ok: "is", wr: ["are", "be", "does"] }, rule: "간접 의문문에서는 의문사 뒤에 '주어 + 동사' 순서를 써요.", hint: "의문사 뒤의 어순에 주의하세요." },
{ k: "s", good: "Would you mind opening the window?", ko: "창문을 좀 열어 주시겠어요?", bad: ["Would you mind to open the window?", "Would you mind open the window?", "Would you mind opened the window?"], cz: { st: "Would you mind ___ the window?", ok: "opening", wr: ["to open", "open", "opened"] }, rule: "Would you mind 뒤에는 동명사(-ing)가 와요.", hint: "mind 뒤에 오는 동사의 형태를 생각해 보세요." },
{ k: "s", good: "I wish you had told me earlier.", ko: "네가 더 일찍 말해 주었더라면 좋았을 텐데.", bad: ["I wish you have told me earlier.", "I wish you had tell me earlier.", "I wish you telling me earlier."], cz: { st: "I wish you ___ me earlier.", ok: "had told", wr: ["tell", "have told", "were telling"] }, rule: "과거 사실에 대한 아쉬움은 wish + 과거완료(had p.p.)로 나타내요.", hint: "과거에 일어나지 않은 일에 대한 아쉬움이에요." },
{ k: "s", good: "Do you happen to know what time the library closes?", ko: "도서관이 몇 시에 닫는지 혹시 아세요?", bad: ["Do you happen to know what time does the library close?", "Do you happen knowing what time the library closes?", "Do you happen to know what time the library close?"], cz: { st: "Do you happen to know what time the library ___?", ok: "closes", wr: ["close", "does close", "closing"] }, rule: "간접 의문문에서는 do/does를 쓰지 않고 '주어 + 동사' 순서이며, 주어가 3인칭 단수이므로 closes를 써요." },
{ k: "s", good: "Not only did she apologize, but she also offered to pay for the damage.", ko: "그녀는 사과했을 뿐만 아니라 피해를 보상하겠다고도 제안했다.", bad: ["Not only she apologized, but she also offered to pay for the damage.", "Not only did she apologized, but she also offered to pay for the damage.", "Not only she did apologize, but she also offered to pay for the damage."], cz: { st: "Not only ___ she apologize, but she also offered to pay for the damage.", ok: "did", wr: ["does", "had", "was"] }, rule: "Not only가 문장 앞에 오면 주어와 조동사가 도치되고, 본동사는 원형이 와요.", ord: false },
{ k: "s", good: "Let's meet at six, shall we?", ko: "6시에 만나자, 어때?", bad: ["Let's meet at six, will we?", "Let's meet at six, don't we?", "Let's meet at six, are we?"], cz: { st: "Let's meet at six, ___ we?", ok: "shall", wr: ["will", "don't", "are"] }, rule: "Let's로 시작하는 문장의 부가의문문은 shall we?를 써요.", hint: "제안하는 문장 끝에 붙는 부가의문문이에요." },
{ k: "s", good: "I'm looking forward to hearing from you.", ko: "답장을 기다리고 있겠습니다.", bad: ["I'm looking forward to hear from you.", "I'm looking forward hearing from you.", "I'm looking forward to heard from you."], cz: { st: "I'm looking forward to ___ from you.", ok: "hearing", wr: ["hear", "heard", "be hearing"] }, rule: "look forward to에서 to는 전치사이므로 뒤에 동명사가 와요.", hint: "to 뒤에 오는 말의 형태를 생각해 보세요." },
{ k: "s", good: "She suggested that we take a different route.", ko: "그녀는 우리에게 다른 길로 가자고 제안했다.", bad: ["She suggested us to take a different route.", "She suggested that we to take a different route.", "She suggested to take us a different route."], cz: { st: "She suggested that we ___ a different route.", ok: "take", wr: ["to take", "taking", "taken"] }, rule: "suggest 뒤의 that절에는 '주어 + 동사원형' 형태를 쓰고, suggest는 'suggest + 목적어 + to부정사'로 쓸 수 없어요." },
];
