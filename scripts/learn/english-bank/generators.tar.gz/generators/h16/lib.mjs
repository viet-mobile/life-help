let n = 0;
export const Q = (q, key, wrong, why) => {
  const pos = (n++ * 3 + 1) % 4;
  const o = [...wrong]; o.splice(pos, 0, key);
  return { q, o, a: pos, why };
};
export const R = (title, text, qs, std) => ({ k: "r", title, text, qs, ...(std ? { std } : {}) });
export const D = (title, text, qs, std) => ({ k: "d", title, text, qs, ...(std ? { std } : {}) });
export const M = (q, key, wrong, why, cat) => {
  const pos = (n++ * 3 + 2) % 4;
  const o = [...wrong]; o.splice(pos, 0, key);
  return { k: "m", q, o, a: pos, why, cat };
};
