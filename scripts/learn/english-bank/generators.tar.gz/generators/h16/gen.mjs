import fs from "node:fs";
import r1 from "./r1.mjs"; import r2 from "./r2.mjs"; import { dialogues, ms, ss } from "./rest.mjs";
import { fixes } from "./fix.mjs";
const dropM = (m) => !/^A shop assistant says|^Your friend says, "Congratulations on winning/.test(m.q);
const items = [...r1, ...r2, ...dialogues, ...ms.filter(dropM), ...ss];
const used = new Set();
for (const i of items) for (const q of (i.qs ?? (i.k === "m" ? [i] : []))) q.o = q.o.map((x) => { for (const [fi, [a, b]] of fixes.entries()) if (x === a && fi % 5 !== 0 && fi % 5 !== 2) { used.add(a); return b; } return x; });

const wc = (t) => t.split(/\s+/).length;
for (const i of items) if (i.text && wc(i.text) < 110 + (i.k === "d" ? 0 : 0)) console.log("SHORT", i.title, wc(i.text));
let L = 0, T = 0;
for (const i of items) { const qs = i.qs ?? (i.k === "m" ? [i] : []); for (const q of qs) { T++; const l = q.o.map((x) => x.length); const a = l[q.a]; if (a === Math.max(...l) && l.filter((x) => x === a).length === 1) { L++; if (process.argv[2]) console.log("LONG", (q.q).slice(0, 60)); } } }
console.log("items", items.length, "q", T, "longest", L, Math.round(100 * L / T) + "%");
console.log(["r","d","m","s"].map(k=>k+":"+items.filter(i=>i.k===k).length).join(" "));
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H16-h-conv.json", JSON.stringify({ packet: "H16-h-conv", sections: [{ skill: "e.h.conv", items }] }, null, 1));
