import r1 from "./r1.mjs"; import r2 from "./r2.mjs"; import { dialogues, ms } from "./rest.mjs";
const items=[...r1,...r2,...dialogues,...ms];
let id=0;
for (const i of items) { const qs=i.qs??[i]; qs.forEach((q,n)=>{ const l=q.o.map(x=>x.length); const a=l[q.a]; const long=a===Math.max(...l)&&l.filter(x=>x===a).length===1; console.log(`${i.title??"M"}|${n}|${long?"LONG":"ok"}|${q.q.slice(0,50).replace(/\n/g," ")}|${q.a}|${l.join(",")}`); }); }
