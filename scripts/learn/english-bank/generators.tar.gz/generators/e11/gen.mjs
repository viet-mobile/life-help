import fs from "node:fs";
const P = [2,0,3,1,1,3,0,2,3,1,2,0,0,2,1,3,2,3,0,1,1,0,3,2,3,0];
let pi = 0;
const ins = (c, w, pos) => { const o = [...w]; o.splice(pos, 0, c); return { o, a: pos }; };
const M = (q, c, w, why, cat) => { const { o, a } = ins(c, w, P[pi++ % P.length]); return { k: "m", q, o, a, why, ...(cat ? { cat } : {}) }; };
const Q = (q, c, w, why) => { const { o, a } = ins(c, w, P[pi++ % P.length]); return { q, o, a, why }; };
const S = (good, ko, bad, st, ok, wr, rule, hint, ord) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, hint, ...(ord === false ? { ord: false } : {}) });
const R = (title, text, qs) => ({ k: "r", title, text, qs, std: ["4영01-05"] });

const tenseS = [
 S("My brother plays soccer every Saturday.","우리 형은 토요일마다 축구를 해요.",["My brother play soccer every Saturday.","My brother playing soccer every Saturday.","My brother plaies soccer every Saturday."],"My brother ___ soccer every Saturday.","plays",["play","playing","plaies"],"반복되는 일은 현재형으로 말해요. 주어가 3인칭 단수(my brother)이면 동사에 -s를 붙여요.","주어가 한 사람이에요. 동사의 모양을 살펴보세요."),
 S("Yesterday, we visited the zoo.","어제 우리는 동물원에 갔어요.",["Yesterday, we visit the zoo.","Yesterday, we visiting the zoo.","Yesterday, we will visit the zoo."],"Yesterday, we ___ the zoo.","visited",["visit","visits","will visit"],"yesterday처럼 지난 일을 말할 때는 동사에 -ed를 붙여요.","어제 있었던 일이에요.",false),
 S("Mina will bake a cake tomorrow.","미나는 내일 케이크를 구울 거예요.",["Mina will bakes a cake tomorrow.","Mina will baked a cake tomorrow.","Mina will baking a cake tomorrow."],"Mina will ___ a cake tomorrow.","bake",["bakes","baked","baking"],"앞으로 할 일은 will 뒤에 동사원형을 써요. will 뒤에서는 동사에 -s나 -ed를 붙이지 않아요.","will 뒤에는 변하지 않은 기본 모양이 와요.",false),
 S("The sun rises in the east.","해는 동쪽에서 떠요.",["The sun rise in the east.","The sun rised in the east.","The sun rising in the east.","".trim()||"x"].slice(0,3),"The sun ___ in the east.","rises",["rise","rised","rising"],"늘 변하지 않는 사실은 현재형으로 말해요. the sun은 3인칭 단수라서 동사에 -s를 붙여요.","늘 사실인 내용이에요."),
 S("I went to the library last week.","나는 지난주에 도서관에 갔어요.",["I goed to the library last week.","I go to the library last week.","I will go to the library last week."],"I ___ to the library last week.","went",["goed","go","going"],"go의 과거형은 불규칙하게 변해서 went예요. goed라고 쓰지 않아요.","last week는 이미 지나간 때예요.",false),
 S("She watches TV after dinner.","그녀는 저녁 식사 후에 텔레비전을 봐요.",["She watch TV after dinner.","She watchs TV after dinner.","She watching TV after dinner."],"She ___ TV after dinner.","watches",["watch","watchs","watching"],"3인칭 단수 주어 뒤에서 -ch로 끝나는 동사는 -es를 붙여요.","동사의 끝 글자를 보고 어떻게 s를 붙일지 생각해 보세요."),
 S("We had pizza for lunch yesterday.","우리는 어제 점심으로 피자를 먹었어요.",["We haved pizza for lunch yesterday.","We have pizza for lunch yesterday.","We will have pizza for lunch yesterday."],"We ___ pizza for lunch yesterday.","had",["haved","have","will have"],"have의 과거형은 had예요. haved라고 쓰지 않아요.","yesterday가 있어요.",false),
 S("Tom was at home last night.","톰은 어젯밤에 집에 있었어요.",["Tom were at home last night.","Tom is at home last night.","Tom be at home last night."],"Tom ___ at home last night.","was",["were","is","am"],"be동사의 과거형은 주어가 I, he, she, it(단수)이면 was, you와 복수이면 were예요.","주어가 한 사람이고 과거예요.",false),
 S("My friends were in the gym yesterday afternoon.","내 친구들은 어제 오후에 체육관에 있었어요.",["My friends was in the gym yesterday afternoon.","My friends is in the gym yesterday afternoon.","My friends are in the gym yesterday afternoon."],"My friends ___ in the gym yesterday afternoon.","were",["was","is","am"],"복수 주어의 be동사 과거형은 were예요.","주어가 여러 명이에요.",false),
 S("I will help my dad on Sunday.","나는 일요일에 아빠를 도와드릴 거예요.",["I will helping my dad on Sunday.","I will helps my dad on Sunday.","I will to help my dad on Sunday."],"I will ___ my dad on Sunday.","help",["helps","helped","helping"],"will 다음에는 to 없이 동사원형을 바로 써요.","will 바로 뒤에는 어떤 모양이 올까요?",false),
 S("Birds fly south in winter.","새들은 겨울에 남쪽으로 날아가요.",["Birds flies south in winter.","Birds flying south in winter.","Birds is fly south in winter."],"Birds ___ south in winter.","fly",["flies","flying","flys"],"주어가 복수(birds)이면 현재형 동사는 -s 없이 원형을 써요.","주어가 하나인지 여러 개인지 보세요."),
 S("Jina studied English last night.","지나는 어젯밤에 영어를 공부했어요.",["Jina studyed English last night.","Jina studies English last night.","Jina studying English last night."],"Jina ___ English last night.","studied",["studyed","studies","study"],"자음+y로 끝나는 동사의 과거형은 y를 i로 바꾸고 -ed를 붙여요. (study → studied)","last night는 이미 지나간 때예요.",false),
 S("Dad will drive us to the beach next weekend.","아빠가 다음 주말에 우리를 바닷가에 태워 주실 거예요.",["Dad will drives us to the beach next weekend.","Dad will driving us to the beach next weekend.","Dad drive will us to the beach next weekend."],"Dad will ___ us to the beach next weekend.","drive",["drives","drove","driving"],"will 뒤에는 주어가 3인칭 단수여도 동사원형을 써요.","주어가 아빠여도 will 뒤의 모양은 같아요.",false),
 S("The baby cried loudly last night.","아기가 어젯밤에 크게 울었어요.",["The baby cryed loudly last night.","The baby cries loudly last night.","The baby crying loudly last night."],"The baby ___ loudly last night.","cried",["cryed","cries","crying"],"cry처럼 자음+y로 끝나는 동사는 y를 i로 고쳐 -ied로 써요.","지난밤에 있었던 일이에요.",false),
 S("My teacher always says hello to us.","우리 선생님은 늘 우리에게 인사를 하세요.",["My teacher always say hello to us.","My teacher always sayes hello to us.","My teacher always saying hello to us."],"My teacher always ___ hello to us.","says",["say","sayes","saying"],"always가 있는 습관은 현재형이에요. 주어가 3인칭 단수이면 say에 -s를 붙여요.","always는 늘 하는 일을 말해요."),
 S("We ate dinner at six yesterday.","우리는 어제 여섯 시에 저녁을 먹었어요.",["We eated dinner at six yesterday.","We eat dinner at six yesterday.","We eaten dinner at six yesterday."],"We ___ dinner at six yesterday.","ate",["eated","eat","eaten"],"eat의 과거형은 불규칙하게 ate예요.","어제 일어난 일이에요.",false),
 S("I will meet my friends at the park this Saturday.","나는 이번 토요일에 공원에서 친구들을 만날 거예요.",["I will met my friends at the park this Saturday.","I will meeting my friends at the park this Saturday.","I meet will my friends at the park this Saturday."],"I will ___ my friends at the park this Saturday.","meet",["met","meets","meeting"],"will 뒤에는 동사원형을 써요. 과거형 met을 쓰지 않아요.","미래의 일을 말하고 있어요.",false),
 S("She has a new bike.","그녀는 새 자전거가 있어요.",["She have a new bike.","She haves a new bike.","She having a new bike."],"She ___ a new bike.","has",["have","haves","having"],"have는 3인칭 단수 주어 뒤에서 has로 바뀌어요. haves라고 쓰지 않아요.","주어가 한 사람이에요."),
 S("The movie started at seven last night.","그 영화는 어젯밤 일곱 시에 시작했어요.",["The movie start at seven last night.","The movie starts at seven last night.","The movie will start at seven last night."],"The movie ___ at seven last night.","started",["start","starts","will start"],"last night처럼 지난 때를 나타내는 말이 있으면 동사를 과거형(-ed)으로 써요.","last night에 주목하세요.",false),
 S("Mom and I make cookies on Sundays.","엄마와 나는 일요일마다 쿠키를 만들어요.",["Mom and I makes cookies on Sundays.","Mom and I making cookies on Sundays.","Mom and I maked cookies on Sundays."],"Mom and I ___ cookies on Sundays.","make",["makes","making","maked"],"Mom and I는 복수 주어이므로 현재형 동사에 -s를 붙이지 않아요.","주어가 두 사람이에요."),
 S("He did his homework before dinner yesterday.","그는 어제 저녁 식사 전에 숙제를 했어요.",["He doed his homework before dinner yesterday.","He do his homework before dinner yesterday.","He does his homework before dinner yesterday."],"He ___ his homework before dinner yesterday.","did",["doed","do","does"],"do의 과거형은 did예요. doed라고 쓰지 않아요.","yesterday가 있어요.",false),
];
// fix item 4 bad list (3 entries)
tenseS[3].bad = ["The sun rise in the east.","The sun rised in the east.","The sun rising in the east."];

const tenseM = [
 M("Choose the word that completes the sentence: Last Sunday, my family ___ a picnic.","had",["have","has","will have"],"Last Sunday는 지난 일이라서 과거형 had를 써요."),
 M("Which sentence talks about the future?","I will go to the dentist on Friday.",["I went to the dentist on Friday.","I go to the dentist on Fridays.","I visited the dentist on Friday."],"will + 동사원형은 앞으로 할 일을 말해요."),
 M("다음 중 지난 일을 말하는 문장은?","Sora walked to school.",["Sora walks to school.","Sora will walk to school.","Sora walks to school every day."],"walked처럼 -ed가 붙은 동사는 지난 일을 나타내요."),
 M("내일 할 일을 말하는 문장을 고르세요. (tomorrow)","We will play chess tomorrow.",["We played chess tomorrow.","We playing chess tomorrow.","We will played chess tomorrow."],"내일의 일은 will + 동사원형으로 말해요. will 뒤에는 played처럼 과거형을 쓰지 않아요."),
 M("Which time word fits? I visited my grandma ___.","last month",["next month","tomorrow","next Friday"],"visited는 과거형이라서 last month처럼 지난 때를 나타내는 말과 함께 써요."),
 M("Which time word fits? She will bake bread ___.","tomorrow",["yesterday","last night","two days ago"],"will bake는 미래이므로 tomorrow가 알맞아요."),
 M("Which sentence tells about a habit?","I brush my teeth after every meal.",["I brushed my teeth an hour ago.","I will brush my teeth soon.","I brushed my teeth this morning."],"after every meal처럼 반복되는 일은 현재형으로 말해요."),
 M("'go'의 과거형은 무엇일까요?","went",["goed","gone","goes"],"go의 과거형은 불규칙하게 went예요."),
 M("'see'의 과거형은 무엇일까요?","saw",["seed","sees","seeing"],"see의 과거형은 saw예요."),
 M("'make'의 과거형은 무엇일까요?","made",["maked","makes","making"],"make의 과거형은 made예요."),
 M("'come'의 과거형은 무엇일까요?","came",["comed","comes","coming"],"come의 과거형은 came이에요."),
 M("'stop'의 과거형을 바르게 쓴 것은?","stopped",["stoped","stopt","stopping"],"짧은 모음 + 자음 하나로 끝나는 동사는 자음을 한 번 더 쓰고 -ed를 붙여요."),
 M("'carry'의 과거형을 바르게 쓴 것은?","carried",["carryed","carrid","carrys"],"자음+y로 끝나는 동사는 y를 i로 바꾸고 -ed를 붙여요."),
 M("Mina ___ a letter to her friend last week.","wrote",["write","writes","writed"],"write의 과거형은 불규칙하게 wrote예요."),
 M("Every morning, Jisu ___ her face with warm water.","washes",["wash","washing","washs"],"주어가 Jisu(3인칭 단수)이고 -sh로 끝나므로 -es를 붙여 washes가 돼요."),
 M("A: What will you do tomorrow?\nB: I ___ my grandparents.","will visit",["visited","visits","visiting"],"tomorrow를 묻는 질문에는 will + 동사원형으로 대답해요."),
 M("A: What did you do yesterday?\nB: I ___ my room.","cleaned",["will clean","clean","cleans"],"yesterday를 묻는 질문이므로 과거형 cleaned로 답해요."),
 M("yesterday가 들어간 문장 중 틀린 것은?","I play basketball yesterday.",["I played basketball yesterday.","We watched TV yesterday.","She was tired yesterday."],"yesterday는 지난 때이므로 동사도 과거형이어야 해요. play는 played가 되어야 해요."),
 M("every day가 들어간 문장 중 틀린 것은?","He walk to school every day.",["He walks to school every day.","They walk to school every day.","I walk to school every day."],"주어 he는 3인칭 단수이므로 현재형 동사에 -s가 필요해요. walk는 walks가 되어야 해요."),
 M("will 뒤에 오는 동사의 모양은 무엇일까요?","동사원형 (예: go)",["과거형 (예: went)","-ing 형 (예: going)","-s 형 (예: goes)"],"will 뒤에는 항상 동사원형을 써요."),
 M("Which sentence uses 'be' in the past?","The soup was hot.",["The soup is hot.","The soup will be hot.","The soup becomes hot."],"was는 is, am의 과거형이에요."),
 M("Which word is a clue for the PAST?","last night",["next week","tomorrow","every Sunday"],"last night은 지난 때를 나타내서 과거형과 함께 써요."),
 M("Which word is a clue for the FUTURE?","tomorrow",["yesterday","last year","an hour ago"],"tomorrow는 앞으로 올 때를 나타내서 will과 함께 써요."),
 M("We ___ a test next Monday.","will have",["had","haved","having"],"next Monday는 앞으로의 일이라서 will have를 써요."),
 M("Ben ___ his bike to the park yesterday.","rode",["ride","rides","rided"],"ride의 과거형은 불규칙하게 rode예요."),
 M("Penguins ___ in cold places.","live",["lives","living","lifes"],"주어가 복수(penguins)이고 늘 사실인 내용이므로 현재형 live를 써요."),
];

const tenseW = [
 { k:"w", en:"yesterday", pos:"adv", ko:"어제", ex:"We played soccer yesterday.", exko:"우리는 어제 축구를 했어요.", z:["tomorrow","soon","ago"], syn:[], sp:["yesturday","yestarday","yesterdai"], note:"yesterday는 지난 일을 말할 때 써요." },
 { k:"w", en:"tomorrow", pos:"adv", ko:"내일", ex:"I will see you tomorrow.", exko:"내일 만나요.", z:["yesterday","never","ago"], syn:[], sp:["tomorow","tommorow","tomorrov"], note:"tomorrow는 앞으로 할 일을 말할 때 써요." },
];

const tenseR = [
 R("My Weekend","Last Saturday, Jina went to her grandmother's house with her parents. They took a bus for two hours. Jina helped her grandmother in the garden, and they picked red tomatoes. In the evening, they ate tomato soup together. Tomorrow, Jina will tell her friends about the trip.",[
  Q("What is the passage mainly about?","Jina's visit to her grandmother",["A long bus ride in the city","How to grow red tomatoes","Jina's first day at school"],"지나가 할머니 댁을 방문한 이야기예요."),
  Q("How long was the bus ride?","Two hours",["One hour","Three hours","Half a day"],"They took a bus for two hours라고 했어요."),
  Q("What did Jina do in the garden?","She picked tomatoes.",["She planted flowers.","She painted a fence.","She washed the bus."],"they picked red tomatoes라고 했어요."),
  Q("What will Jina do tomorrow?","Tell her friends about the trip",["Go to the garden again","Take another long bus","Cook tomato soup"],"마지막 문장에서 Tomorrow, Jina will tell her friends about the trip이라고 했어요."),
 ]),
 R("Mr. Park's Day","Mr. Park is a baker. He gets up at four every morning. He makes bread and cakes in his small shop. The shop opens at seven, and many people come to buy fresh bread. Mr. Park closes the shop at six. Then he goes home and reads a book.",[
  Q("What time does Mr. Park get up?","At four",["At six","At seven","At five"],"He gets up at four every morning이라고 했어요."),
  Q("What does 'fresh' mean in the passage?","newly made",["very old","too hot","low in price"],"fresh bread는 막 만든 신선한 빵을 뜻해요."),
  Q("Why do many people come to the shop?","To buy bread",["To read books","To learn baking","To meet the baker's family"],"many people come to buy fresh bread라고 했어요."),
  Q("What does Mr. Park do after he closes the shop?","He goes home and reads.",["He opens another shop.","He bakes more cakes.","He visits his friends."],"Then he goes home and reads a book이라고 했어요."),
  Q("Which sentence is true?","The shop opens after Mr. Park starts baking.",["The shop opens at four.","Mr. Park sells books.","The shop closes at seven."],"그는 4시에 일어나 빵을 만들고 가게는 7시에 열려요."),
 ]),
 R("Our Class Trip","Next Friday, our class will go to the science museum. We will meet at the school gate at nine o'clock. A big yellow bus will take us there. We will see robots and a dinosaur skeleton. Our teacher says we must bring lunch and a water bottle. I can't wait!",[
  Q("What is the writer mostly doing in the passage?","Talking about a coming trip",["Telling a story about last year","Asking for lunch","Explaining how robots work"],"앞으로 있을 현장학습 계획을 이야기하고 있어요."),
  Q("What time will the class meet?","At nine o'clock",["At eight o'clock","At ten o'clock","At noon"],"We will meet at the school gate at nine o'clock이라고 했어요."),
  Q("What will the students see?","Robots and a dinosaur skeleton",["Planets and stars","Old paintings and coins","Live animals and plants"],"We will see robots and a dinosaur skeleton이라고 했어요."),
  Q("How does the writer feel?","Excited",["Bored","Sleepy","Angry"],"I can't wait!는 몹시 기다려진다는 뜻이라서 신이 난 기분을 나타내요."),
  Q("What must the students bring?","Lunch and a water bottle",["A camera and a hat","Money and a notebook","A robot and a map"],"our teacher says we must bring lunch and a water bottle이라고 했어요."),
 ]),
 R("Tom's Bad Day","Yesterday, Tom missed the school bus because he got up late. He ran to school, but he was late for class. His teacher was not angry. She said, \"Please set your alarm tonight.\" Tom will go to bed early and put his alarm next to his bed.",[
  Q("Why did Tom miss the bus?","He got up late.",["He lost his bag.","He was sick.","He forgot the way."],"because he got up late라고 했어요."),
  Q("What did the teacher ask Tom to do?","Set his alarm",["Run faster","Go to bed at nine","Take a different bus"],"She said, \"Please set your alarm tonight\"이라고 했어요."),
  Q("What will Tom do tonight?","Go to bed early",["Visit his teacher","Do extra homework","Walk to school"],"Tom will go to bed early라고 했어요."),
  Q("What does 'missed' mean in the passage?","did not catch",["cheered for","looked for","thought about"],"missed the school bus는 버스를 놓쳤다는 뜻이에요."),
  Q("How did the teacher feel?","She was kind to Tom.",["She was very angry.","She was afraid.","She was surprised by the bus."],"His teacher was not angry라고 했고 부드럽게 알려 줬어요."),
 ]),
];

const qnegS = [
 S("Do your friends walk to school?","네 친구들은 걸어서 학교에 가니?",["Does your friends walk to school?","Do your friends walks to school?","Are your friends walk to school?"],"___ your friends walk to school?","Do",["Does","Is","Are"],"주어가 복수(your friends)인 일반동사 질문은 Do로 시작하고 동사는 원형을 써요.","주어가 몇 명인지 보세요."),
 S("Does Tom play the piano?","톰은 피아노를 치니?",["Do Tom play the piano?","Does Tom plays the piano?","Is Tom play the piano?"],"Does Tom ___ the piano?","play",["plays","played","playing"],"Does 뒤에는 이미 3인칭 단수의 -s가 들어 있으므로 동사원형을 써요.","Does가 있으면 동사에는 -s를 또 붙이지 않아요."),
 S("I don't eat spicy food.","나는 매운 음식을 안 먹어요.",["I doesn't eat spicy food.","I don't eats spicy food.","I not eat spicy food."],"I don't ___ spicy food.","eat",["eats","ate","eating"],"일반동사의 부정문은 don't + 동사원형이에요.","don't 다음에는 어떤 모양이 올까요?"),
 S("My sister doesn't like carrots.","내 여동생은 당근을 안 좋아해요.",["My sister don't like carrots.","My sister doesn't likes carrots.","My sister not like carrots."],"My sister ___ like carrots.","doesn't",["don't","isn't","not"],"주어가 3인칭 단수(my sister)이면 doesn't + 동사원형으로 부정해요.","주어가 한 사람이에요."),
 S("Did you finish your homework?","너 숙제 다 했니?",["Did you finished your homework?","Does you finish your homework?","Were you finish your homework?"],"Did you ___ your homework?","finish",["finished","finishes","finishing"],"Did로 묻는 과거 질문에서는 동사를 원형으로 써요. 과거는 Did가 이미 나타내요.","Did가 과거를 이미 나타내요."),
 S("She didn't go to school yesterday.","그녀는 어제 학교에 가지 않았어요.",["She didn't went to school yesterday.","She doesn't went to school yesterday.","She not go to school yesterday."],"She didn't ___ to school yesterday.","go",["went","goes","going"],"didn't 뒤에는 동사원형을 써요. 과거는 didn't가 나타내요.","didn't 다음 동사의 모양을 생각해 보세요.",false),
 S("We won't be late for the bus.","우리는 버스에 늦지 않을 거예요.",["We won't to be late for the bus.","We don't will be late for the bus.","We willn't be late for the bus."],"We ___ be late for the bus.","won't",["don't","aren't","didn't"],"will not의 줄임말은 won't이고 뒤에 동사원형이 와요. willn't라고 쓰지 않아요.","미래의 부정이에요."),
 S("Will you come to my party?","너 내 파티에 올 거니?",["Do you will come to my party?","Will you to come to my party?","Will you comes to my party?"],"Will you ___ to my party?","come",["comes","came","coming"],"will로 묻는 질문은 Will + 주어 + 동사원형이에요.","Will 뒤의 동사 모양을 보세요."),
 S("Is this your pencil?","이거 네 연필이니?",["Do this your pencil?","Does this is your pencil?","Are this your pencil?"],"___ this your pencil?","Is",["Do","Does","Are"],"be동사 질문은 be동사(Is/Are)를 맨 앞에 써요. this에는 Is를 써요.","be동사 문장이에요."),
 S("Are they in the park?","그들은 공원에 있니?",["Is they in the park?","Do they in the park?","Are they is in the park?"],"___ they in the park?","Are",["Is","Do","Does"],"be동사 문장의 질문은 be동사를 앞으로 보내고, they에는 Are를 써요.","일반동사가 없는 문장이에요."),
 S("Where do you live?","너는 어디에 사니?",["Where you do live?","Where does you live?","Where do you lives?"],"Where ___ you live?","do",["does","are","is"],"의문사 질문은 의문사 + do/does + 주어 + 동사원형 순서예요.","주어는 you예요."),
 S("What time does the class start?","수업은 몇 시에 시작하니?",["What time do the class start?","What time does the class starts?","What does time the class start?"],"What time does the class ___?","start",["starts","started","starting"],"What time 뒤에 does가 오면 동사는 원형이에요. does가 -s를 이미 나타내요.","does 뒤 동사의 모양을 보세요."),
 S("How many pets do you have?","너는 반려동물이 몇 마리니?",["How many pets does you have?","How many pets you do have?","How many pet do you have?"],"How many pets ___ you have?","do",["does","are","is"],"How many + 복수 명사 + do + 주어 + 동사원형 순서로 물어요.","주어가 you예요."),
 S("Why did Mina cry yesterday?","미나는 어제 왜 울었니?",["Why did Mina cried yesterday?","Why Mina did cry yesterday?","Why does Mina cry yesterday?"],"Why did Mina ___ yesterday?","cry",["cried","cries","crying"],"did를 쓴 질문에서는 동사원형을 써요.","did가 이미 과거를 나타내요.",false),
 S("They don't have a car.","그들은 차가 없어요.",["They doesn't have a car.","They don't has a car.","They aren't have a car."],"They don't ___ a car.","have",["has","had","having"],"don't 뒤에는 동사원형을 써요. has는 쓸 수 없어요.","don't 뒤의 모양을 생각해 보세요."),
 S("He didn't call me last night.","그는 어젯밤에 나에게 전화하지 않았어요.",["He didn't called me last night.","He doesn't call me last night.","He not called me last night."],"He ___ call me last night.","didn't",["doesn't","don't","isn't"],"last night처럼 지난 일을 부정할 때는 didn't + 동사원형을 써요.","지난밤의 일이에요.",false),
 S("Does the library open on Sundays?","도서관은 일요일에 문을 여니?",["Do the library open on Sundays?","Does the library opens on Sundays?","Does the library is open on Sundays?"],"Does the library ___ on Sundays?","open",["opens","opened","opening"],"주어가 3인칭 단수일 때 Does로 묻고 동사는 원형이에요.","Does가 이미 있어요."),
 S("Do I need an umbrella today?","오늘 우산이 필요할까요?",["Does I need an umbrella today?","Do I needs an umbrella today?","Am I need an umbrella today?"],"___ I need an umbrella today?","Do",["Does","Am","Is"],"주어가 I일 때 일반동사 질문은 Do로 시작해요.","주어는 I예요."),
 S("Mia isn't at school today.","미아는 오늘 학교에 없어요.",["Mia don't at school today.","Mia doesn't at school today.","Mia not at school today."],"Mia ___ at school today.","isn't",["doesn't","don't","aren't"],"be동사(is)의 부정은 isn't예요. 일반동사가 없으므로 doesn't를 쓰지 않아요.","동사가 없고 장소만 있어요."),
 S("What did you eat for breakfast?","너는 아침으로 뭘 먹었니?",["What did you ate for breakfast?","What you did eat for breakfast?","What do you ate for breakfast?"],"What did you ___ for breakfast?","eat",["ate","eats","eaten"],"did 뒤에는 동사원형을 써요. ate를 쓰지 않아요.","did가 있으면 동사는 어떻게 될까요?",false),
 S("Does your grandmother live near the sea?","너희 할머니는 바다 가까이에 사시니?",["Do your grandmother live near the sea?","Does your grandmother lives near the sea?","Is your grandmother live near the sea?"],"___ your grandmother live near the sea?","Does",["Do","Is","Are"],"3인칭 단수 주어(your grandmother)의 일반동사 질문은 Does로 시작해요.","주어가 한 분이에요."),
];

const qnegM = [
 M("Which is the negative form of 'He plays tennis.'?","He doesn't play tennis.",["He don't play tennis.","He doesn't plays tennis.","He not play tennis."],"3인칭 단수 주어의 부정문은 doesn't + 동사원형이에요."),
 M("'They like soup.'를 의문문으로 바꾼 것은?","Do they like soup?",["Does they like soup?","Are they like soup?","Do they likes soup?"],"they는 복수이므로 Do로 시작하고 동사는 원형이에요."),
 M("'Ann has a pen.'을 의문문으로 바꾼 것은?","Does Ann have a pen?",["Do Ann have a pen?","Does Ann has a pen?","Is Ann have a pen?"],"Does로 묻는 문장에서는 has가 have(원형)로 바뀌어요."),
 M("A: Do you have a pet?\nB: No, I ___.","don't",["doesn't","am not","didn't"],"Do로 묻는 질문에는 Do를 써서 대답해요. 부정은 don't예요."),
 M("A: Does Jun like soccer?\nB: Yes, he ___.","does",["do","is","likes"],"Does로 묻는 질문에는 Yes, he does.로 대답해요."),
 M("A: Did you see the movie?\nB: No, I ___.","didn't",["don't","wasn't","won't"],"Did로 묻는 질문에는 didn't로 부정해서 대답해요."),
 M("A: Will it rain tomorrow?\nB: No, it ___.","won't",["doesn't","isn't","didn't"],"Will로 묻는 질문에는 will을 써서 No, it won't.로 대답해요."),
 M("A: Are you hungry?\nB: No, I ___.","am not",["don't","aren't","isn't"],"Are you ...?에는 I am not으로 대답해요. I aren't는 틀려요."),
 M("Which question asks about the PAST?","Did you wash the dishes?",["Do you wash the dishes?","Will you wash the dishes?","Does he wash the dishes?"],"Did로 시작하면 지난 일을 묻는 질문이에요."),
 M("Which question asks about the FUTURE?","Will Dad cook dinner?",["Did Dad cook dinner?","Is Dad a cook?","Do you cook dinner?"],"Will로 시작하면 앞으로의 일을 묻는 질문이에요."),
 M("doesn't 뒤에는 어떤 모양의 동사가 올까요?","동사원형 (예: eat)",["-s 형 (예: eats)","과거형 (예: ate)","-ing 형 (예: eating)"],"doesn't 뒤에는 항상 동사원형을 써요."),
 M("Which is a wh-question?","What do you want for lunch?",["Do you want lunch?","You want lunch.","I don't want lunch."],"What, Where, Who 같은 의문사로 시작하는 질문을 wh-question이라고 해요."),
 M("Which question word asks about a PLACE?","Where",["When","Who","Why"],"Where는 장소를 물을 때 써요."),
 M("Which question word asks about a PERSON?","Who",["Where","What","When"],"Who는 사람을 물을 때 써요."),
 M("Which question word asks for a REASON?","Why",["Who","Where","How many"],"Why는 이유를 물을 때 써요."),
 M("Which question word asks about a NUMBER of things?","How many",["Where","Who","When"],"How many는 셀 수 있는 것의 수를 물을 때 써요."),
 M("Which is a good answer to 'What time do you wake up?'","At seven o'clock.",["In the kitchen.","Yes, I do.","My brother."],"What time은 시각을 묻는 말이에요."),
 M("Which is a good answer to 'Where does Hana study?'","In the library.",["At seven.","Because she likes it.","Yes, she does."],"Where는 장소를 묻는 말이라서 장소로 대답해요."),
 M("Which is a good answer to 'Why were you late?'","Because the bus was slow.",["At the bus stop.","Yes, I was.","Every morning."],"Why로 물으면 Because로 이유를 대답해요."),
 M("Which is a good answer to 'Is your bag heavy?'","Yes, it is.",["Yes, it does.","No, I don't.","Yes, they are."],"Is로 묻는 질문에는 is로 대답해요."),
 M("Which is a good answer to 'Does your dog bark at night?'","No, it doesn't.",["No, it isn't.","No, I don't.","No, they don't."],"Does로 묻고 주어가 your dog(it)이므로 doesn't로 대답해요."),
 M("Which is a good answer to 'Do they play chess?'","Yes, they do.",["Yes, they does.","Yes, they are.","Yes, he does."],"Do they ...?에는 Yes, they do.로 대답해요."),
 M("다음 중 부정문은?","The bus doesn't stop here.",["The bus stops here.","Does the bus stop here?","The bus will stop here."],"doesn't가 있는 문장은 부정문이에요."),
 M("Which sentence needs a question mark (?)","Where do you live",["I live in Daegu","Come here","She is my friend"],"Where로 시작해서 묻는 문장 끝에는 물음표(?)를 써요."),
 M("'will not'의 줄임말은 무엇일까요?","won't",["willn't","wont't","wo'nt"],"will not은 won't로 줄여 써요."),
 M("'does not'의 줄임말을 바르게 쓴 것은?","doesn't",["do'esn't","does'nt","doesnt'"],"does not은 doesn't로 줄이고, 어퍼스트로피는 n과 t 사이에 써요."),
];

const qnegW = [
 { k:"w", en:"question", pos:"n", ko:"질문", ex:"Raise your hand and ask a question.", exko:"손을 들고 질문하세요.", z:["tree","shoe","cloud"], syn:[], sp:["quesion","qestion","questoin"] },
 { k:"w", en:"answer", pos:"n", ko:"답", ex:"Please write your answer here.", exko:"여기에 답을 쓰세요.", z:["snow","ocean","bridge"], syn:["reply"], sp:["anser","answor","ansver"] },
];

const qnegR = [
 R("A New Pet","Sam wants a dog, but his mother is not sure. \"Do you know how to take care of a dog?\" she asks. Sam says, \"Yes, I do. I will feed it and walk it every day.\" His mother smiles. She doesn't want a big dog because their house is small, so they will visit a pet shop on Sunday.",[
  Q("What is the passage mainly about?","Sam asks for a pet dog.",["Sam loses his dog","Sam's mother buys a house","A pet shop closes down"],"샘이 개를 키우고 싶어 하고 엄마와 이야기하는 내용이에요."),
  Q("What does Sam promise to do?","Feed the dog and walk it",["Wash the dog every night","Teach the dog tricks","Sell the dog later"],"I will feed it and walk it every day라고 했어요."),
  Q("Why doesn't his mother want a big dog?","Their house is small.",["Dogs are expensive.","Sam is afraid of dogs.","She likes cats better."],"because their house is small이라고 했어요."),
  Q("When will they visit the pet shop?","On Sunday",["On Friday","Tomorrow morning","Next month"],"they will visit a pet shop on Sunday라고 했어요."),
  Q("How does his mother seem at the end?","Happy about Sam's answer",["Angry at him","Worried about money","Bored by the talk"],"His mother smiles 라고 해서 샘의 대답에 만족한 것을 알 수 있어요."),
 ]),
 R("The Umbrella","Yuna waits at the bus stop. It is raining, but she doesn't have an umbrella. An old man asks, \"Are you cold?\" \"A little,\" says Yuna. He gives her his umbrella. \"Don't you need it?\" she asks. \"No, my house is near,\" he says. Yuna says thank you and smiles.",[
  Q("What problem does Yuna have?","She has no umbrella in the rain.",["She missed her bus.","She lost her phone.","She is lost in the city."],"It is raining, but she doesn't have an umbrella라고 했어요."),
  Q("What does the old man ask Yuna?","If she is cold",["If she is lost","Where her house is","What time it is"],"An old man asks, \"Are you cold?\"라고 했어요."),
  Q("In \"Don't you need it?\", what does 'it' mean?","The umbrella",["The bus","The rain","The bus stop"],"it은 바로 앞에서 노인이 준 우산을 가리켜요."),
  Q("Why doesn't the old man need the umbrella?","His house is near.",["He has a car.","The rain stops soon.","He has another one."],"No, my house is near라고 했어요."),
  Q("What kind of person is the old man?","Kind",["Rude","Shy","Lazy"],"추운 낯선 아이에게 우산을 주었으니 친절한 사람이에요."),
 ]),
 R("Lunch Survey","Mina asked her classmates about lunch. Does everyone like fish? Eight students said no. Do they like chicken? Fourteen students said yes. Most students don't like vegetables, but they love ice cream. Mina will tell the cooks the results on Monday.",[
  Q("Why did Mina ask her classmates questions?","To learn what they like to eat",["To plan a class trip","To find a new teacher","To check their homework"],"점심 메뉴에 대한 친구들의 취향을 조사했어요."),
  Q("How many students said yes to chicken?","Fourteen",["Eight","Eighteen","Four"],"Do they like chicken? Fourteen students said yes라고 했어요."),
  Q("What do most students NOT like?","Vegetables",["Chicken","Ice cream","Fish"],"Most students don't like vegetables라고 했어요."),
  Q("Who will hear the results on Monday?","The cooks",["The principal","Mina's parents","The bus driver"],"Mina will tell the cooks the results on Monday라고 했어요."),
  Q("Which sentence is true?","Eight students don't like fish.",["Everyone likes fish.","Mina will tell the results today.","Fourteen students love vegetables."],"Eight students said no to fish라고 했어요."),
 ]),
 R("Bolt the Robot","Zoe's school has a robot named Bolt. Bolt doesn't eat or sleep. It helps students find books in the library. Does Bolt talk? Yes, it does, but it speaks very softly. Last week, Bolt didn't work for one day, so the students looked for books by themselves.",[
  Q("What does Bolt do at school?","It helps students find books.",["It teaches English class.","It cooks lunch.","It cleans the classrooms."],"It helps students find books in the library라고 했어요."),
  Q("What does 'softly' mean in the passage?","in a quiet way",["in a funny way","in a fast way","in a sad way"],"speaks very softly는 아주 작게(조용히) 말한다는 뜻이에요."),
  Q("Which sentence about Bolt is true?","Bolt does not eat.",["Bolt sleeps at night.","Bolt cannot talk.","Bolt works every day."],"Bolt doesn't eat or sleep라고 했어요."),
  Q("Why did students look for books by themselves last week?","Bolt did not work that day.",["The library was closed.","Bolt was in another school.","They wanted more exercise."],"Bolt didn't work for one day라고 했어요."),
 ]),
];

const out = { packet: "E11-e4", sections: [
  { skill: "e.e4.tense", items: [...tenseS, ...tenseM, ...tenseR, ...tenseW] },
  { skill: "e.e4.qneg", items: [...qnegS, ...qnegM, ...qnegR, ...qnegW] },
]};
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E11-e4.json", JSON.stringify(out, null, 1) + "\n");
console.log(tenseS.length, tenseM.length, tenseR.length, tenseW.length, qnegS.length, qnegM.length, qnegR.length, qnegW.length);
