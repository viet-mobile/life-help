import fs from "node:fs";
const W=(en,pos,ko,ex,exko,z,sp)=>({k:"w",en,pos,ko,ex,exko,z,syn:[],sp});
const w=[
W("desk","n","책상","I sit at my desk.","나는 내 책상에 앉아요.",["apple","shoe","ball"],["dessk","dask","deks"]),
W("chair","n","의자","Sit on the chair.","의자에 앉으세요.",["pencil","crayon","clock"],["chiar","chare","cheir"]),
W("bag","n","가방","Put it in your bag.","그것을 네 가방에 넣어.",["door","chair","window"],["bagg","baag","bga"]),
W("pencil","n","연필","I write with a pencil.","나는 연필로 써요.",["door","chair","window"],["pensil","pencel","pencill"]),
W("book","n","책","I read a book.","나는 책을 읽어요.",["door","chair","desk"],["bok","boock","buk"]),
W("eraser","n","지우개","Erase it with an eraser.","지우개로 지우세요.",["chair","door","bag"],["erasor","erazer","erassr"]),
W("ruler","n","자","Draw a line with a ruler.","자로 선을 그으세요.",["bag","chair","door"],["rular","ruller","rooler"]),
W("notebook","n","공책","Write it in your notebook.","그것을 공책에 쓰세요.",["door","chair","window"],["notbook","notebok","nottebook"]),
W("scissors","n","가위","I cut paper with scissors.","나는 가위로 종이를 잘라요.",["bags","desks","doors"],["sissors","scisors","scizzors"]),
W("glue","n","풀","Use glue on the paper.","종이에 풀을 쓰세요.",["ruler","desk","door"],["glu","gloo","gleu"]),
W("crayon","n","크레용","I draw with a red crayon.","나는 빨간 크레용으로 그려요.",["door","desk","chair"],["cranyon","craion","crayen"]),
W("board","n","칠판","Write on the board with chalk.","분필로 칠판에 쓰세요.",["scissors","glue","apple"],["bord","baord","boad"]),
W("teacher","n","선생님","Ask the teacher a question.","선생님께 질문하세요.",["pencil","chair","desk"],["techer","teecher","teachar"]),
W("student","n","학생","I am a student.","나는 학생이에요.",["pencil","chair","desk"],["studnt","studint","stuedent"]),
W("door","n","문","Please close the door.","문을 닫아 주세요.",["pencil","chair","crayon"],["dor","doar","dooor"]),
W("window","n","창문","Open the window, please.","창문을 열어 주세요.",["pencil","crayon","ruler"],["windo","windoe","wendow"]),
W("clock","n","시계","I see the time on the clock.","나는 시계로 시간을 봐요.",["pencil","bag","crayon"],["cloc","clok","clockk"]),
W("map","n","지도","Find Korea on the map.","지도에서 한국을 찾아보세요.",["pencil","glue","eraser"],["mapp","mep","maap"]),
W("paper","n","종이","Cut the paper with scissors.","가위로 종이를 자르세요.",["door","chair","desk"],["papar","payper","pepar"]),
W("backpack","n","책가방","I wear my backpack on my back.","나는 책가방을 등에 메요.",["pencil","chair","door"],["bakpack","backpak","bagpack"]),
W("open","v","열다","Please open your book.","책을 펴 주세요.",["eat","sing","jump"],["opin","opan","openn"]),
W("sit","v","앉다","Please sit down.","앉아 주세요.",["eat","sing","read"],["sitt","sytt","sitd"]),
W("stand","v","서다","Please stand up and say your name.","일어나서 이름을 말하세요.",["sing","draw","cut"],["stend","standd","stannd"]),
W("read","v","읽다","Let's read a story.","이야기를 읽어요.",["eat","jump","swim"],["raed","reda","reaad"]),
W("write","v","쓰다","Please write your name here.","여기에 이름을 쓰세요.",["eat","jump","wash"],["wirte","wrigt","wryte"]),
W("listen","v","듣다","Please listen to your teacher.","선생님 말씀을 들으세요.",["eat","jump","wash"],["lisen","listin","lissen"]),
];
const S=(good,ko,bad,st,ok,wr,rule,hint)=>({k:"s",good,ko,bad,cz:{st,ok,wr},rule,...(hint?{hint}:{})});
const s=[
S("This is a desk.","이것은 책상이에요.",["This a desk.","This is desk.","This are a desk."],"This ___ a desk.","is",["am","are","be"],"가까이 있는 것을 가리킬 때 ‘This is ~.’라고 말해요. a를 빼거나 is를 빼면 안 돼요.","this 다음에 어떤 말이 와야 할까요?"),
S("I have an eraser.","나는 지우개가 있어요.",["I have a eraser.","I has an eraser.","I am have an eraser."],"I have ___ eraser.","an",["a","two","many"],"eraser는 모음 소리로 시작해서 a 대신 an을 써요. I 다음에는 have를 써요."),
S("Open your book.","책을 펴세요.",["Open you book.","Opening your book.","Open book your."],"Open ___ book.","your",["you","yours","me"],"‘너의’라는 뜻으로 명사 앞에는 your를 써요. 명령하는 말은 동사로 시작해요."),
S("That is my bag.","저것은 내 가방이에요.",["That my bag.","That are my bag.","That is me bag."],"That is ___ bag.","my",["me","I","mine"],"‘나의’라는 뜻으로 명사 앞에는 my를 써요. That is ~.는 멀리 있는 것을 가리켜요."),
S("I have two pencils.","나는 연필이 두 자루 있어요.",["I have two pencil.","I have two a pencil.","I two have pencils."],"I have two ___.","pencils",["pencil","a pencil","an pencil"],"둘 이상일 때는 낱말 끝에 -s를 붙여요."),
S("Is this a pen?","이것은 펜이에요?",["Is a this pen?","Are this a pen?","This a pen is?"],"___ this a pen?","Is",["Am","Are","Be"],"묻는 문장은 Is를 맨 앞에 써요.","묻는 문장은 맨 앞 낱말이 달라져요."),
];
const M=(q,o,a,why,cat)=>({k:"m",q,o,a,why,cat});
const m=[
M("다음 중 /b/ 소리로 시작하는 낱말은?",["desk","bag","pen","map"],1,"bag은 /b/ 소리로 시작해요. desk는 /d/, pen은 /p/, map은 /m/ 소리로 시작해요.","phonics"),
M("‘pencil’과 첫소리가 같은 낱말은?",["pen","book","desk","bag"],0,"pencil과 pen은 둘 다 /p/ 소리로 시작해요.","phonics"),
M("‘ruler’는 어떤 글자로 시작할까요?",["l","n","r","w"],2,"ruler는 r로 시작해요.","letters"),
M("알파벳 순서에서 ‘c’ 바로 다음에 오는 글자는?",["b","d","e","a"],1,"알파벳 순서는 a, b, c, d예요. c 다음은 d예요.","letters"),
M("대문자 ‘D’의 소문자는?",["b","p","q","d"],3,"D의 소문자는 d예요. b, p, q는 모양이 비슷하지만 다른 글자예요.","letters"),
M("소문자 ‘g’의 대문자는?",["Q","J","G","C"],2,"g의 대문자는 G예요.","letters"),
M("빈칸에 알맞은 말은?  ___ pencil",["an","a","two","many"],1,"pencil은 자음 소리로 시작하므로 a를 써요. two나 many 뒤에는 pencils처럼 -s가 필요해요.","articles"),
M("‘book’이 두 권일 때 알맞은 말은?  two ___",["book","bookes","books","a book"],2,"둘 이상일 때는 book 끝에 -s를 붙여 books라고 해요.","plural"),
M("‘box’가 두 개일 때 알맞은 말은?  two ___",["boxs","boxies","box","boxes"],3,"x로 끝나는 낱말은 -es를 붙여 boxes라고 해요.","plural"),
M("선생님이 “Stand up.”이라고 말하면 어떻게 해야 할까요?",["일어난다","앉는다","문을 연다","책을 읽는다"],0,"Stand up.은 ‘일어서세요.’라는 뜻이에요.","functions"),
M("“Be quiet, please.”의 뜻으로 알맞은 것은?",["빨리 오세요.","여기에 앉으세요.","조용히 해 주세요.","창문을 닫으세요."],2,"quiet는 ‘조용한’이라는 뜻이에요. Be quiet.는 조용히 하라는 말이에요.","functions"),
M("아침에 선생님을 만났을 때 하는 인사는?",["Good night.","Goodbye.","Good luck.","Good morning."],3,"Good morning.은 아침에 하는 인사예요.","functions"),
M("빈칸에 알맞은 부호는?  What is this___",["마침표 (.)","물음표 (?)","쉼표 (,)","따옴표 (“ ”)"],1,"묻는 문장 끝에는 물음표를 써요.","punctuation"),
M("‘i have a bag.’에서 대문자로 고쳐야 할 낱말은?",["i","have","a","bag"],0,"영어에서 ‘나’를 뜻하는 I는 언제나 대문자로 써요. 문장의 첫 글자도 대문자예요.","punctuation"),
M("숫자 5를 영어로 쓰면?",["four","five","nine","six"],1,"5는 five예요.","numbers"),
M("빨간색은 영어로?",["blue","green","black","red"],3,"red는 빨간색이에요.","colors"),
M("친구의 연필을 빌리고 싶을 때 하는 말은?",["Do you like my pencil?","Is your pencil red?","Can I use your pencil?","I have a pencil case."],2,"Can I use ~?는 ‘~을 써도 될까요?’라고 부탁하는 말이에요.","functions"),
M("‘map’과 끝소리가 비슷한 낱말은?",["cup","mop","men","cap"],3,"map과 cap은 끝소리 /ap/가 같아요.","phonics"),
];
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E03-e1.json",JSON.stringify({packet:"E03-e1",sections:[{skill:"e.e1.class",items:[...w,...s,...m]}]},null,1)+"\n");
console.log(w.length,s.length,m.length);
