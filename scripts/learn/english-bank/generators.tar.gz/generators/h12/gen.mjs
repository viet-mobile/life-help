import fs from "node:fs";
import { patches } from "./patch.mjs";
import p1 from "./p1.mjs"; import p2 from "./p2.mjs"; import p3 from "./p3.mjs";
import { dialogues } from "./p4.mjs"; import { ms } from "./p5.mjs"; import { ss } from "./p6.mjs";
const rs = [...p1, ...p2, ...p3];
const out = { packet: "H12-h3-tone", sections: [{ skill: "e.h3.tone", items: [...rs, ...dialogues, ...ms.slice(0, 40), ...ss] }] };
const all = out.sections[0].items; const opts = []; for (const it of all) { if (it.k === "m") opts.push(it.o); else if (it.qs) for (const q of it.qs) opts.push(q.o); }
for (const [a, b] of patches.filter((_, i) => i % 2 === 1)) { const hits = opts.flatMap((o) => o.map((x, i) => [o, i]).filter(([, i]) => o[i] === a)); if (hits.length === 0) console.log("NOMATCH", a); else if (hits.length > 1) { console.log("MULTI skipped", a); continue; } for (const [o, i] of hits) o[i] = b; }
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H12-h3-tone.json", JSON.stringify(out, null, 1) + "\n");
console.log(rs.length, dialogues.length, ms.slice(0,40).length, ss.length);
