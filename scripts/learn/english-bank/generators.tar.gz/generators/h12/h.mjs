let n = 0;
export const r = (title, text, std, qs, kind = "r") => ({ k: kind, title, text, std, qs: qs.map(([q, key, ws, why]) => { const pos = (n++ * 3 + 1) % 4; const o = [...ws]; o.splice(pos, 0, key); return { q, o, a: pos, why }; }) });
export const d = (title, text, std, qs) => r(title, text, std, qs, "d");
export const m = (q, key, ws, why, std) => { const pos = (n++ * 3 + 2) % 4; const o = [...ws]; o.splice(pos, 0, key); return { k: "m", q, o, a: pos, why, ...(std ? { std } : {}) }; };
