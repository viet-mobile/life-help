import { d, m } from "./h.mjs";
export const dialogues = [
d("A Very Quiet Dinner", `Jin: So, how was the test?
Dad: I asked you a question. How was it?
Jin: Fine.
Dad: Fine. That is your answer? I got a call from your teacher this afternoon.
Jin: Then you already know how it went.
Dad: I would rather hear it from you. I am not angry, Jin. I am worried.
Jin: Everyone says that, but you always sound angry.
Dad: Maybe I do. I am sorry. Let me try again. Tell me what happened, and I will listen until you are finished.
Jin: I froze. I knew the answers, but my mind went white. I did not want to disappoint you.
Dad: Thank you for telling me. You could never disappoint me by being human.
Jin: Even if I fail?
Dad: Especially then. Now, eat before the soup gets cold.`, ["12영독01-03","12영독01-05"], [
 ["How does the father's attitude change during the conversation?", "From stern to gentle and understanding", ["From playful to serious and cold","From calm to furious and shouting","From distant to proud of his son"], "처음의 추궁에서 사과와 경청으로 부드러워져요."],
 ["What is Jin's main emotion when he says \"I froze\"?", "Fear of letting his father down", ["Pride in his hard work","Anger toward the teacher","Boredom with the subject"], "아버지를 실망시킬까 두려웠다고 말해요."],
 ["What does the father mean by \"You could never disappoint me by being human\"?", "Making mistakes is natural and will not lower his love.", ["Only machines should make no mistakes.","Jin must study to become a better person.","He is pleased that Jin failed the test."], "실수는 인간적이며 사랑이 줄지 않는다는 뜻이에요."],
 ["Why does Jin answer \"Fine\" at the beginning?", "He wants to avoid talking about something that upset him.", ["He has just passed the test with a high score.","He has not heard his father's question.","He believes his father is not interested."], "불편한 이야기를 피하려는 짧은 대답이에요."],
 ["What is the purpose of the last line, \"eat before the soup gets cold\"?", "To end the tension and show everyday care", ["To order Jin to leave the table","To complain about the quality of the soup","To change the subject because he is bored"], "일상적인 말로 분위기를 풀고 배려를 표현해요."]
]),
d("Great Idea, Really", `Nora: So I told the manager that I would do all the posters by tomorrow.
Eli: All of them. By tomorrow. Alone.
Nora: Well, yes. How hard can it be?
Eli: Oh, fantastic. And of course you have nothing else to do, like your history project or sleep.
Nora: Are you making fun of me?
Eli: Me? Never. I think it is a wonderful plan. I especially admire the part where it collapses at midnight.
Nora: Okay, I get it. You think I took on too much.
Eli: I think forty posters is a lot for one person. Let me help with the drawing, and you handle the writing.
Nora: Really? You would do that after all your jokes?
Eli: What are friends for? Besides pointing out my own bad ideas, I mean.
Nora: Deal. Thank you.`, ["12영독01-03","12영독01-05"], [
 ["What is the tone of Eli's first remarks (\"Oh, fantastic...\")?", "Sarcastic", ["Sincere","Frightened","Admiring"], "칭찬하는 척하며 실제로는 계획을 비판하는 빈정거림이에요."],
 ["What does Eli really think of Nora's plan?", "It is unrealistic for one person to finish alone.", ["It is a wonderful plan that needs no help.","It is unnecessary because there are enough posters.","It will be a success within a few hours."], "40장을 혼자 하기는 많다고 직접 말해요."],
 ["How does the conversation end?", "Eli offers help and Nora accepts gratefully.", ["Nora refuses and leaves angrily.","Eli decides to stop being friends with Nora.","They agree to cancel the posters."], "Eli가 그림을 돕겠다고 하고 Nora가 고마워하며 수락해요."],
 ["What is suggested by Eli's last remark, \"Besides pointing out my own bad ideas\"?", "Eli can laugh at himself and has made similar mistakes.", ["Eli has no bad ideas at all.","Eli wants to blame Nora for his own mistakes.","Eli does not value their friendship."], "자기도 나쁜 계획을 세운 적이 있다는 자기 풍자예요."]
]),
d("At the Restaurant", `Waiter: Good evening. Are you ready to order?
Mr. Lee: Actually, I would like to mention something first. I ordered the grilled fish forty minutes ago.
Waiter: I am very sorry, sir. Let me check with the kitchen immediately.
Mr. Lee: I do not mean to cause trouble, but my guests have been waiting, and the other tables around us have already finished.
Waiter: Completely understandable. There was a mix-up with the orders, and that is our fault.
Mr. Lee: I appreciate your honesty. Is there any chance it could be ready in ten minutes?
Waiter: I will make sure of it. In the meantime, may I bring you some bread and a drink, on the house?
Mr. Lee: That is very kind of you. Thank you.
Waiter: Thank you for your patience, sir. I will return shortly.`, ["12영독01-03","12영독01-01"], [
 ["Which phrase best describes Mr. Lee's tone?", "Polite but firm", ["Rude and shouting","Joking and careless","Fearful and quiet"], "불만을 정중하게, 그러나 분명히 말해요."],
 ["What is the waiter's attitude?", "Apologetic and helpful", ["Defensive and annoyed","Bored and silent","Proud and boastful"], "사과하고 해결책을 제시해요."],
 ["Why does the waiter offer bread and a drink on the house?", "To make up for the delay", ["To tell the guests to leave quickly","To advertise the new menu","To collect money from the guests"], "지연에 대한 보상이에요."],
 ["What is the main problem in the conversation?", "The food order was served much later than expected.", ["The restaurant has run out of fish.","The guests have refused to pay the bill.","The tables are all full for the evening."], "40분이 지나도록 주문이 나오지 않았어요."]
]),
d("Before the Final", `Coach: Everybody sit down. Two minutes, then we go out.
Hana: Coach, I do not think I can do this. Their team is so much taller than ours.
Coach: Hana, look at me. How many times did we practice this last week?
Hana: I do not know. Maybe fifty.
Coach: Fifty. And how many times did you miss?
Hana: Not many, I suppose.
Coach: Exactly. You are ready. I did not bring you here to be afraid of a tall team.
Sam: But what if we lose?
Coach: Then we lose together, with our heads high, and we learn. But I do not think that will happen. Play like you did on Tuesday.
Hana: Okay. I will try.
Coach: No. Do not try. Do it. Now, hands in, everyone.`, ["12영독01-03","12영독01-05"], [
 ["What is the coach's tone?", "Confident and encouraging", ["Angry and mocking","Nervous and unsure","Bored and impatient"], "자신감을 주며 격려하는 어조예요."],
 ["Why does the coach ask how many times Hana missed?", "To remind her that she is well prepared", ["To scold her for making mistakes","To change the order of players","To find out who should leave the team"], "연습 성과를 일깨워 자신감을 주려는 거예요."],
 ["What is Hana's feeling at the beginning?", "Worried about the opposing team", ["Proud of her team","Disappointed with the coach","Excited about the match"], "상대 팀이 크다고 걱정해요."],
 ["What does the coach mean by \"Do not try. Do it\"?", "Hana should act with commitment instead of doubting herself.", ["Hana should stay out of the game.","Hana should practice fifty times again.","Hana should not talk to her teammates."], "망설임 없이 실행하라는 격려예요."]
]),
d("Planning the Surprise", `Ravi: Okay, everyone is here. Remember, Ms. Kwon arrives at four, so we have less than an hour.
Mei: I have the banner! It says "Thank you, Ms. Kwon" in four colors.
Ravi: Perfect. Leo, did you bring the cake?
Leo: Um, about that. I left it on the bus.
Ravi: You what?
Leo: Relax, I am joking! It is behind the door. Look at your face!
Mei: That was not funny, Leo. Ravi nearly fainted.
Ravi: I am fine, I am fine. Now, when she opens the door, we all shout together.
Mei: One, two, three, "Surprise!" I can hardly wait to see her smile.
Leo: Quiet, I hear footsteps. Hide, hide!
Ravi: Wait, it is only the janitor. Phew.
Mei: Shhh. The real one is coming. Places, everybody!`, ["12영독01-03"], [
 ["What is the mood of the conversation?", "Excited and playful", ["Gloomy and serious","Calm and sleepy","Angry and hostile"], "깜짝 파티를 준비하는 설레고 장난스러운 분위기예요."],
 ["Why does Ravi react strongly to Leo's remark about the cake?", "He believed that the cake was really lost.", ["He dislikes Leo's choice of cake.","He wanted to leave the party early.","He had just won a prize."], "Leo의 장난을 진짜로 믿고 놀랐어요."],
 ["What is Leo's attitude when he says \"Look at your face!\"?", "Teasing", ["Ashamed","Respectful","Worried"], "친구를 놀리는 장난기 어린 태도예요."],
 ["What is the purpose of the group's plan?", "To thank the teacher with a surprise", ["To complain to the teacher","To hold a class election","To prepare for a school exam"], "선생님께 감사를 전하는 깜짝 파티예요."]
]),
d("The Phone Call", `Ms. Berg: Mr. Adams, thank you for taking my call. I am calling about your son, Peter.
Father: Is something wrong? He did not come home on time yesterday.
Teacher: Nothing serious, I hope. He missed three classes this week, and I wanted to understand why.
Father: Three? I had no idea. He leaves every morning with his bag.
Teacher: I thought as much. Peter is a bright boy, and I do not want to punish him. I want to help.
Father: I appreciate that. I will talk to him tonight.
Teacher: If I may suggest, perhaps listen first. Sometimes there is something behind it.
Father: You are right. I tend to shout first and ask later.
Teacher: Many of us do. Please call me whenever you wish.
Father: Thank you, Ms. Berg. I will.`, ["12영독01-03","12영독01-01"], [
 ["What is the main purpose of Ms. Berg's call?", "To understand why Peter has been missing classes", ["To punish Peter for his bad grades","To invite Mr. Adams to a school festival","To report that Peter won an award"], "결석 이유를 이해하고 돕기 위한 전화예요."],
 ["How would you describe Ms. Berg's tone?", "Caring and tactful", ["Strict and threatening","Careless and joking","Cold and official"], "벌주기보다 돕고 싶다는 배려 있는 어조예요."],
 ["How does Mr. Adams feel when he learns about the absences?", "Surprised and concerned", ["Delighted and proud","Amused and relaxed","Angry at Ms. Berg"], "3번이나 빠진 줄 몰랐다며 놀라고 걱정해요."],
 ["What does Mr. Adams admit about himself?", "He often reacts angrily before listening.", ["He seldom speaks to his son.","He wants Peter to change schools.","He does not trust teachers."], "먼저 소리치고 나중에 묻는 편이라고 인정해요."]
])
];
