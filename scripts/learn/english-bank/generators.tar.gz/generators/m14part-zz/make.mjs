import fs from "node:fs";
import { S } from "./s.mjs"; import { Ms } from "./m.mjs"; import { Rs } from "./r.mjs";
const noOrd = /,|\b(at the|before the|yesterday|last year|near the|in the|for an hour|for breakfast|behind|along|on the desk|next to|at a low)\b/;
const s = S.map(([good, ko, bad, st, ok, wr, rule, hint]) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...(hint ? { hint } : {}), ...(noOrd.test(good) ? { ord: false } : {}) }));
const stds = [["9영01-03","9영01-02","9영01-05","9영01-07"],["9영01-02","9영01-03","9영01-06","9영01-07"],["9영01-02","9영01-07"],["9영01-02","9영01-06"],["9영01-02","9영01-05","9영01-07"],["9영01-02","9영01-07"],["9영01-02","9영01-05","9영01-07"],["9영01-02","9영01-06"],["9영01-02","9영01-05","9영01-07"],["9영01-02","9영01-03","9영01-07"]];
const r = Rs.map((x, i) => ({ ...x, std: stds[i] }));
const w = [
 { k: "w", en: "exhausted", pos: "adj", ko: "기진맥진한", ex: "After the marathon, the runners were completely exhausted.", exko: "마라톤이 끝난 뒤 주자들은 완전히 기진맥진했어요.", z: ["delicious", "northern", "wooden"], syn: ["tired", "worn out"], sp: ["exausted", "exhaustid", "exhosted"] },
 { k: "w", en: "fascinating", pos: "adj", ko: "매력적인", ex: "The museum has a fascinating exhibit about ancient ships.", exko: "그 박물관에는 고대 선박에 관한 매력적인 전시가 있어요.", z: ["hungry", "bitter", "sleepy"], syn: ["interesting", "captivating"], sp: ["fasinating", "fascinateing", "facsinating"] },
 { k: "w", en: "thrilled", pos: "adj", ko: "아주 신이 난", ex: "She was thrilled to win first prize in the contest.", exko: "그녀는 대회에서 1등상을 타서 아주 신이 났어요.", z: ["hungry", "wooden", "useful"], syn: ["delighted", "excited"], sp: ["thriled", "thrilld", "thrilleed"] },
];
const items = [...s, ...Ms, ...r, ...w];
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M14-m3-part.json", JSON.stringify({ packet: "M14-m3-part", sections: [{ skill: "e.m3.part", items }] }, null, 1));
console.log(s.length, Ms.length, r.length, w.length);
