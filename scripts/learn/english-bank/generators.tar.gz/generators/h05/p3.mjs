import { P, Q } from "./lib.mjs";
export default [
P("Choosing a Club",
`Mia: Have you decided which club to join this semester?
Tom: Not yet. The debate club sounds exciting, but I'm afraid I'll get nervous speaking in front of people.
Mia: That's exactly why you should join. Nobody becomes confident by avoiding what scares them.
Tom: True, but I also have the science exams next month, and the debate club meets twice a week.
Mia: Hmm. Maybe start with the photography club? It only meets on Fridays.
Tom: That's tempting, but I don't even own a camera.
Mia: Most members use their phones. Besides, you might discover a hobby you didn't know you had.
Tom: You make a good point. I'll visit the Friday meeting and then decide about debate next term.`,
[
Q("M", "What is the main topic of the conversation?", "Deciding which school club to join", ["Planning a science experiment", "Buying a new camera for a school club", "Preparing for a speech contest"], "동아리 선택에 대한 대화예요.", ),
Q("D", "Why is Tom hesitant about the debate club?", "He fears public speaking and has exams soon.", ["He dislikes photography and the Friday meetings.", "He has no time on Fridays.", "He wants to leave the school."], "발표가 걱정되고 시험이 있다고 해요."),
Q("I", "What does Mia imply when she says, “Nobody becomes confident by avoiding what scares them”?", "Facing a fear is how confidence grows.", ["Debate is the easiest club to join.", "Confident people never feel scared at all.", "Tom should stay away from clubs."], "두려움을 피하면 자신감이 생기지 않는다는 뜻이에요."),
Q("B", "What will Tom most likely do next?", "Attend a photography meeting on Friday", ["Join the debate club immediately this week", "Buy an expensive camera", "Give up all clubs this year"], "마지막에 금요일 모임에 가 보겠다고 해요."),
], "d"),
P("The Phone Rule",
`Ms. Lee: Class, the school board wants to ban phones during the whole school day. I'd like to hear your opinions.
Jiho: I think it's too strict. We use our phones for dictionaries and for checking schedules.
Ms. Lee: A fair point. Sora, what do you think?
Sora: Honestly, I agree with the ban. When phones are allowed, half the class is checking messages instead of listening.
Jiho: But a total ban doesn't teach responsibility. We should learn to control ourselves.
Sora: That sounds nice, but many of us can't. I know I can't.
Ms. Lee: Perhaps there is a middle path: phones stay in bags except when a teacher allows them for learning.
Jiho: I could accept that.
Sora: Me too, as long as the rule is the same for everyone.`,
[
Q("M", "What is the conversation mainly about?", "A debate over how to handle phones at school", ["A plan to buy school dictionaries for all students", "A complaint about a teacher's schedule", "A new homework policy for math"], "수업 중 휴대폰 규정에 대한 토론이에요."),
Q("D", "What is Jiho's argument against the total ban?", "It does not teach students responsibility.", ["It makes paper dictionaries much more expensive.", "It lets teachers use phones freely.", "It gives students too much homework."], "'a total ban doesn't teach responsibility'"),
Q("I", "Why does Sora support the ban?", "She knows messages easily distract her.", ["She never uses a phone.", "She wants longer lunch breaks.", "She dislikes using dictionaries at school."], "스스로를 통제하지 못함을 인정해요."),
Q("B", "How does the conversation end?", "The speakers agree on a compromise.", ["Ms. Lee cancels the discussion early.", "Sora refuses any new rule.", "Jiho leaves the classroom angrily."], "휴대폰은 가방에 두고 필요할 때만 쓰는 절충안에 동의해요."),
], "d"),
P("A Job Interview Tip",
`Dad: You look worried. Is it about tomorrow's interview at the bakery?
Eun: Yes. I keep thinking they'll ask me something I can't answer.
Dad: What if they ask why you want the job?
Eun: I'd say I like baking, but that sounds too ordinary.
Dad: Ordinary isn't bad if it's true. Add a short story, such as the first cake you made for your grandmother.
Eun: That's a nice idea. It shows who I am, not just what I like.
Dad: Exactly. Interviewers remember stories more than slogans. And don't forget to ask them a question at the end.
Eun: Like what?
Dad: Something simple, such as what a typical morning is like. It shows you are interested.`,
[
Q("M", "What is the dad mainly doing in the conversation?", "Advising Eun how to prepare for an interview", ["Asking Eun to quit her job", "Teaching Eun to bake a cake for the interview", "Complaining about a bakery"], "면접 준비 조언이에요."),
Q("D", "What does Eun worry about?", "Being asked a question she cannot answer", ["Arriving late at the bakery tomorrow morning", "Forgetting her grandmother's recipe", "Having too many interviewers"], "'they'll ask me something I can't answer'"),
Q("I", "Why does Dad suggest telling a short story?", "A story makes her answer personal and memorable.", ["Stories are required by the bakery's rules.", "Slogans are impossible to learn.", "The interviewers enjoy listening to long speeches."], "이야기가 더 기억에 남고 자신을 보여준다는 이유예요."),
Q("D", "What does Dad recommend doing at the end of the interview?", "Asking a simple question", ["Thanking everyone with a gift", "Leaving quietly", "Offering to bake a cake"], "'ask them a question at the end'"),
], "d"),
P("Planning a Trip on a Budget",
`Lena: I've found a hotel by the beach for our trip, but it costs twice what we planned.
Sam: That's way over our budget. Is there anything cheaper?
Lena: A hostel in the old town. It's farther from the sea, but the reviews are good.
Sam: How far is it?
Lena: About twenty minutes by bus.
Sam: That's not bad. We could save enough to pay for a boat tour.
Lena: But I wanted to wake up and see the waves from the window.
Sam: I understand. How about staying at the hotel for one night, just as a treat, and the hostel for the rest?
Lena: Now that's a compromise I can live with.`,
[
Q("M", "What is the conversation mainly about?", "Finding a place to stay within a budget", ["Booking a boat tour for tomorrow morning", "Choosing a bus route", "Writing hotel reviews for a travel site"], "예산에 맞는 숙소 정하기가 중심이에요."),
Q("D", "Why does Lena prefer the beach hotel?", "She wants to see the waves from her window.", ["It is much cheaper than the old-town hostel.", "It has a boat tour.", "It is closer to the old town than the hostel."], "'I wanted to wake up and see the waves'"),
Q("B", "What do they finally decide?", "To stay at both places", ["To cancel the trip", "To book only the hotel", "To walk to the old town"], "하룻밤은 호텔, 나머지는 호스텔로 해요."),
Q("T", "How does Lena feel about Sam's last suggestion?", "Satisfied", ["Annoyed", "Bored", "Surprised by the cost"], "'a compromise I can live with'는 만족한다는 뜻이에요."),
], "d"),
P("The Science Project",
`Haru: Our experiment didn't work. The plants in the dark box grew taller than the ones in the sun.
Ms. Cho: That's interesting. Why do you think that happened?
Haru: I don't know. I expected the sunny ones to do better.
Ms. Cho: Look at the data again. How tall are the dark ones compared with their color?
Haru: They're taller but very pale and thin.
Ms. Cho: Exactly. Plants without light stretch upward searching for it, but they can't make healthy leaves. So your experiment worked after all.
Haru: Because we learned something we didn't expect?
Ms. Cho: Yes. Unexpected results often teach more than the expected ones. Write that in your report.`,
[
Q("M", "What is the main point Ms. Cho makes?", "Surprising results can still be valuable.", ["Plants always grow better in the dark than in light.", "Experiments should be repeated three times.", "Reports should be short."], "예상 밖 결과가 더 많이 가르칠 수 있다는 것이 핵심이에요."),
Q("D", "How did the plants in the dark box look?", "Tall but pale and thin", ["Short, green, and strong", "Tall and healthy", "Dead and dry"], "'taller but very pale and thin'"),
Q("I", "Why did the dark-box plants grow so tall?", "They were stretching to find light.", ["They received far too much water.", "They were kept in a much warmer room.", "They had more space for leaves."], "빛을 찾아 위로 뻗은 것이에요."),
Q("T", "How does Haru feel at the beginning of the conversation?", "Let down", ["Overjoyed", "Amused", "Delighted"], "'Our experiment didn't work'에서 실망감이 드러나요."),
], "d"),
P("Feedback on an Essay",
`Seo: Mr. Han, thank you for reading my essay. Was it good?
Mr. Han: You have strong ideas, Seo. The problem is the order. Your best argument appears at the very end.
Seo: I wanted to build up to it.
Mr. Han: That works in a story, but in an essay the reader needs your main point early. Otherwise, they read the first three paragraphs without knowing where you are going.
Seo: So I should move the best argument to the beginning?
Mr. Han: Put it in your first paragraph, then use the rest to support it.
Seo: I see. And the conclusion?
Mr. Han: Remind the reader of your point in new words, instead of adding fresh ideas at the last moment.`,
[
Q("M", "What does Mr. Han mainly give Seo?", "Advice on how to organize an essay", ["A grade for the final exam in English", "A list of new essay topics for next term", "A warning about late homework in class"], "에세이 구성에 관한 조언이에요."),
Q("D", "What is the problem with Seo's essay?", "The best argument comes too late.", ["The ideas are weak.", "The paragraphs are all far too short.", "The spelling is full of errors."], "'Your best argument appears at the very end.'"),
Q("I", "Why did Seo put the best argument last?", "He wanted to build up to it.", ["He forgot to include it earlier.", "He wanted a longer essay.", "He misread the topic."], "Seo가 직접 'I wanted to build up to it'라고 말해요."),
Q("D", "What should the conclusion do, according to Mr. Han?", "Restate the main point in different words", ["Add several brand new ideas at the end", "Repeat the first paragraph exactly", "Ask the reader a very long question at the end"], "'Remind the reader of your point in new words'"),
], "d"),
];
