const STD = { R: "12영Ⅰ-01-01", M: "12영Ⅰ-01-02", B: "12영Ⅰ-01-04", D: "12영Ⅰ-01-01", I: "12영Ⅰ-01-05", V: "12영Ⅰ-01-05", P: "12영Ⅰ-01-03", T: "12영Ⅰ-01-03", S: "12영Ⅰ-01-06" };
const POSN = [2, 0, 3, 1, 1, 3, 0, 2, 3, 1, 2, 0, 0, 2, 1, 3];
let counter = 0;
export function Q(type, q, key, wrongs, why) {
  const pos = POSN[counter++ % POSN.length];
  const o = [...wrongs];
  o.splice(pos, 0, key);
  return { t: type, q, o, a: pos, why };
}
function stdOf(qs) { return [...new Set(qs.map((x) => STD[x.t]))]; }
export function P(title, text, qs, kind = "r") {
  return { k: kind, title, text, qs: qs.map(({ t, ...r }) => r), std: stdOf(qs) };
}
export function M(type, q, key, wrongs, why, cat) {
  const r = Q(type, q, key, wrongs, why);
  return { k: "m", q: r.q, o: r.o, a: r.a, why, cat, std: [STD[type]] };
}
