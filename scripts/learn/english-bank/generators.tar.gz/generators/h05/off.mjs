import fs from "node:fs";
const j = JSON.parse(fs.readFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H05-h1-main.json","utf8"));
let n=0,t=0;
for (const it of j.sections[0].items) {
  const qs = it.qs ?? (it.k==="m"?[it]:[]);
  for (const q of qs) { t++; const L=q.o.map(x=>x.length); const a=L[q.a]; if (a===Math.max(...L)&&L.filter(x=>x===a).length===1){ n++; console.log((it.title??"m")+" | "+q.q.slice(0,50).replace(/\n/g," ")+" | "+q.o.map((x,i)=>(i===q.a?"*":"")+x.length).join(",")); } }
}
console.log(n,t);
