import fs from "node:fs";
const j = JSON.parse(fs.readFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H05-h1-main.json","utf8"));
const r=[0,0,0,0];let t=0;
for (const it of j.sections[0].items){const qs=it.qs??(it.k==="m"?[it]:[]);for(const q of qs){t++;const L=q.o.map(x=>x.length);const rank=[...L].sort((a,b)=>b-a).indexOf(L[q.a]);r[rank]++;}}
console.log(t,r);
