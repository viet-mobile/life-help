import fs from "node:fs";
import p1 from "./p1.mjs";
import p2 from "./p2.mjs";
import p3 from "./p3.mjs";
import p4 from "./p4.mjs";

const S = (good, ko, bad, st, ok, wr, rule, hint, ord) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, hint, ...(ord === false ? { ord: false } : {}) });
const s = [
S("Not only did she finish the report, but she also helped her teammates.", "그녀는 보고서를 끝냈을 뿐만 아니라 팀원들도 도왔어요.",
  ["Not only she finished the report, but she also helped her teammates.", "Not only did she finished the report, but she also helped her teammates.", "Not only she did finish the report, but she also helped her teammates."],
  "Not only ___ finish the report, but she also helped her teammates.", "did she", ["she did", "she has", "she was"],
  "Not only가 문장 앞에 오면 주어와 동사가 도치되어 'did + 주어 + 동사원형'이 돼요.", "부정어구로 문장을 시작하면 어순이 바뀌어요.", false),
S("Had I known about the traffic, I would have left earlier.", "교통 상황을 알았더라면 더 일찍 출발했을 텐데요.",
  ["Had I knew about the traffic, I would have left earlier.", "Had I known about the traffic, I will leave earlier.", "If I would know about the traffic, I would have left earlier."],
  "___ I known about the traffic, I would have left earlier.", "Had", ["Have", "Did", "Was"],
  "if가 생략된 가정법 과거완료는 'Had + 주어 + 과거분사'로 쓰고, 주절은 would have + 과거분사예요.", "과거 사실과 반대되는 가정을 나타내요.", false),
S("The more you practice, the better you become.", "연습할수록 더 나아져요.",
  ["The more you practice, the best you become.", "The much you practice, the better you become.", "More you practice, the better you become."],
  "The more you practice, the ___ you become.", "better", ["best", "good", "well"],
  "'the + 비교급, the + 비교급'은 '~할수록 더 ~하다'라는 뜻이에요. 비교급 good → better를 써요.", "두 개의 비교급이 짝을 이루는 구문이에요."),
S("The book that I borrowed from the library was surprisingly funny.", "내가 도서관에서 빌린 책은 놀랄 만큼 재미있었어요.",
  ["The book that I borrowed it from the library was surprisingly funny.", "The book what I borrowed from the library was surprisingly funny.", "The book who I borrowed from the library was surprisingly funny."],
  "The book ___ I borrowed from the library was surprisingly funny.", "that", ["what", "who", "where"],
  "사물 선행사를 꾸미는 목적격 관계대명사에는 that(또는 which)을 쓰고, 목적어를 다시 쓰지 않아요.", "앞의 명사가 사물이에요.", false),
S("Despite being tired, he finished the race.", "그는 피곤했지만 경주를 끝마쳤어요.",
  ["Despite he was tired, he finished the race.", "Despite of being tired, he finished the race.", "In spite being tired, he finished the race."],
  "___ being tired, he finished the race.", "Despite", ["Because of", "Unless", "Therefore"],
  "Despite(= in spite of) 뒤에는 명사나 동명사가 와요. 'Despite of'나 'In spite' 뒤에 of 없이 쓰는 것은 틀려요.", "'~에도 불구하고'라는 양보의 뜻이에요.", false),
S("I wish I were taller.", "내가 더 키가 컸으면 좋겠어요.",
  ["I wish I am taller.", "I wish I will be taller.", "I wish I be taller."],
  "I wish I ___ taller.", "were", ["am", "will be", "be"],
  "현재 사실과 반대되는 소망은 wish 뒤에 과거형(be동사는 were)을 써요.", "현재 이루어지지 않은 일을 바라는 표현이에요."),
S("The results, which were published last week, surprised many scientists.", "지난주에 발표된 결과는 많은 과학자를 놀라게 했어요.",
  ["The results, that were published last week, surprised many scientists.", "The results, what were published last week, surprised many scientists.", "The results, who were published last week, surprised many scientists."],
  "The results, ___ were published last week, surprised many scientists.", "which", ["that", "what", "who"],
  "쉼표 뒤에서 부가 설명을 하는 계속적 용법에는 that을 쓸 수 없고, 사물이면 which를 써요.", "쉼표가 앞에 있는 관계사절이에요.", false),
S("It was so cold that we stayed indoors all day.", "너무 추워서 우리는 하루 종일 실내에 있었어요.",
  ["It was too cold that we stayed indoors all day.", "It was so cold what we stayed indoors all day.", "It was very cold that we stayed indoors all day."],
  "It was ___ cold that we stayed indoors all day.", "so", ["too", "very", "enough"],
  "'so + 형용사 + that ~'은 '너무 ~해서 ...하다'라는 결과를 나타내요. too는 'too ... to'로 써요.", "원인과 결과를 이어 주는 구문이에요.", false),
S("The bridge was built in 1998 by workers from many countries.", "그 다리는 1998년에 여러 나라의 노동자들이 지었어요.",
  ["The bridge was build in 1998 by workers from many countries.", "The bridge were built in 1998 by workers from many countries.", "The bridge built in 1998 by workers from many countries."],
  "The bridge ___ built in 1998 by workers from many countries.", "was", ["were", "been", "being"],
  "수동태는 'be동사 + 과거분사'예요. 주어가 단수이고 과거(in 1998)이므로 was built를 써요.", "행위자가 'by ~'로 나와 있어요.", false),
S("Hardly had we reached the station when the train left.", "우리가 역에 도착하자마자 기차가 떠났어요.",
  ["Hardly we had reached the station when the train left.", "Hardly have we reached the station when the train left.", "Hardly had we reach the station when the train left."],
  "Hardly ___ we reached the station when the train left.", "had", ["have", "did", "were"],
  "'Hardly + had + 주어 + 과거분사 ~ when ...'은 '~하자마자 ...했다'라는 도치 구문이에요.", "부정어로 시작하는 도치 구문이에요.", false),
S("I would rather stay home than go out in this rain.", "이런 비에 나가느니 차라리 집에 있겠어요.",
  ["I would rather staying home than go out in this rain.", "I would rather to stay home than go out in this rain.", "I would rather stay home than going out in this rain."],
  "I would rather ___ home than go out in this rain.", "stay", ["staying", "to stay", "stayed"],
  "'would rather + 동사원형 + than + 동사원형'은 '~하느니 차라리 ...하겠다'라는 뜻이에요.", "would rather 뒤의 동사 형태를 생각해 보세요.", false),
];

const items = [...p1, ...p2, ...p3, ...p4, ...s];
const out = { packet: "H05-h1-main", sections: [{ skill: "e.h1.main", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H05-h1-main.json", JSON.stringify(out, null, 1) + "\n");
const c = {}; for (const i of items) c[i.k] = (c[i.k] ?? 0) + 1; console.log(c);
