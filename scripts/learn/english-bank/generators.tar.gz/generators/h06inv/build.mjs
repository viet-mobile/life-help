import fs from "node:fs";
import { sItems } from "./s.mjs";
import { mItems } from "./m.mjs";
import { rItems } from "./r.mjs";
const w = [
 { k:"w", en:"seldom", pos:"adv", ko:"좀처럼 ~하지 않게", ex:"Our town seldom gets heavy snow.", exko:"우리 마을에는 폭설이 좀처럼 내리지 않아요.", z:["quietly","brightly","gently"], syn:["rarely","hardly ever"], sp:["seldem","selldom","seldome"] },
 { k:"w", en:"scarcely", pos:"adv", ko:"거의 ~하지 않게", ex:"There is scarcely any milk left in the fridge.", exko:"냉장고에 우유가 거의 남아 있지 않아요.", z:["gently","brightly","slowly"], syn:["hardly"], sp:["scarsely","scarcly","scarcley"] },
 { k:"w", en:"merely", pos:"adv", ko:"단지, 그저", ex:"It was merely a joke, so please do not be upset.", exko:"그건 그저 농담이었으니 속상해하지 마세요.", z:["quietly","heavily","happily"], syn:["only","just","simply"], sp:["merly","mearly","mirely"] },
 { k:"w", en:"nowhere", pos:"adv", ko:"어디에도 ~없는", ex:"There is nowhere to sit in this crowded room.", exko:"이 붐비는 방에는 앉을 곳이 어디에도 없어요.", z:["slowly","softly","gently"], syn:[], sp:["nowere","nowhear","noware"] },
];
const out = { packet: "H06-h2-inv", sections: [{ skill: "e.h2.inv", items: [...sItems, ...mItems, ...rItems, ...w] }] };
console.log(sItems.length, mItems.length, rItems.length, w.length);
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H06-h2-inv.json", JSON.stringify(out, null, 1));
