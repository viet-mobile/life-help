import fs from "node:fs";
const [a,b,c,d,e,f] = await Promise.all(["a","b","c","d","e","f"].map(x=>import(`./${x}.mjs`).then(m=>m.default)));
const items = [...a,...b,...c,...d,...e,...f];
const out = { packet: "H15-h3-sum", sections: [{ skill: "e.h3.sum", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H15-h3-sum.json", JSON.stringify(out, null, 1) + "\n");
const cnt = {}; for (const i of items) cnt[i.k] = (cnt[i.k]||0)+1; console.log(cnt);
