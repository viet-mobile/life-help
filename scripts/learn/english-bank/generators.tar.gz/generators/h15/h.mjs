let n = 0;
export const q = (stem, key, d1, d2, d3, why) => { const o = [d1, d2, d3]; const pos = (n++ * 3 + 1) % 4; o.splice(pos, 0, key); return { q: stem, o, a: pos, why }; };
export const r = (title, text, qs, std) => ({ k: "r", title, text, ...(std ? { std } : {}), qs });
export const d = (title, text, qs, std) => ({ k: "d", title, text, ...(std ? { std } : {}), qs });
export const m = (stem, key, d1, d2, d3, why, std) => { const x = q(stem, key, d1, d2, d3, why); return { k: "m", q: stem, o: x.o, a: x.a, why, ...(std ? { std } : {}) }; };
export const SUM = ["12영독02-04", "12영독01-02"];
