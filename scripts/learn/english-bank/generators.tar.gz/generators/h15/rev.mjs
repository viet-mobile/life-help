import fs from "node:fs";
const R = [
["Classrooms at home are always better than living abroad for every kind of learner.","Classrooms at home are always better than living abroad, said the writer."],
["To prove that living abroad is a complete waste of time and money for learners","To prove that living abroad is a waste of time"],
["Employees should be forced to work in the office every single day of the week.","Employees should be forced to work in the office every day."],
["People who always work from home and never see colleagues","People who work from home on most days"],
["Handwriting is always better than typing for every student in every class.","Handwriting is always better than typing for every student."],
["To prove that students should always stay silent in every class","To prove that students should stay silent"],
["Songs with lyrics improve every kind of writing and reading task.","Songs with lyrics improve every kind of writing."],
["Fiction readers never really care about other people.","Fiction readers never care about others."],
["Fiction should replace science textbooks in every school.","Fiction should replace science textbooks."],
["Everyone should stop wearing new clothes of any kind completely.","Everyone should stop wearing new clothes completely."],
["Doctors will stop using medicine soon because expectation is enough.","Doctors will stop using medicine soon."],
["Turn off the phone completely before every single trip.","Turn off the phone before every trip."],
["Customers are not allowed to donate money to projects of any kind.","Customers cannot donate to projects."],
["Children should never be praised in school for anything they do.","Children should never be praised in school."],
["They are large and have been found in every study so far.","They are large and found in every study."],
["Dolphins can breathe underwater without ever coming to the surface.","Dolphins breathe underwater without coming up."],
["It is completely true in every case, so dolphins stay awake.","It is completely true in every case."],
["Every bird in the world hunts only at dawn each day.","Every bird hunts only at dawn."],
["Fish are the favorite food of every animal in the water and on land.","Fish are the favorite food of all animals."],
["It proves that wind power is cheaper than any other source.","It proves that wind power is cheaper."],
["Governments should stop supporting any farmers who want to use new tools.","Governments should stop supporting farmers."],
];
const files = ["a","b","c","d","e","f"].map(x=>`${x}.mjs`);
const src = Object.fromEntries(files.map(f=>[f,fs.readFileSync(f,"utf8")]));
for (const [o,n] of R) { const needle=`"${o}"`; let hit=0,w; for (const f of files){const c=src[f].split(needle).length-1; if(c){hit+=c;w=f;}} if(hit!==1){console.log("MISS",hit,o);continue;} src[w]=src[w].replace(needle,()=>`"${n}"`); }
for (const f of files) fs.writeFileSync(f, src[f]);
