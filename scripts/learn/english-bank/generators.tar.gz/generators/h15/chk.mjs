import fs from "node:fs";
const j = JSON.parse(fs.readFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H15-h3-sum.json","utf8"));
let n=0,t=0;
for (const it of j.sections[0].items) {
  const qs = it.k==="m"?[it]:(it.qs||[]);
  qs.forEach((q,i)=>{ if(!q.o) return; t++; const L=q.o.map(x=>x.length); const a=L[q.a]; const lg = a===Math.max(...L)&&L.filter(x=>x===a).length===1; if(lg){n++; console.log(`${it.title??"m"}#${i+1} | key ${a} | others ${L.filter((_,k)=>k!==q.a).join(",")} | ${q.o[q.a]}`);} });
}
console.log(n,t,(100*n/t).toFixed(1));
