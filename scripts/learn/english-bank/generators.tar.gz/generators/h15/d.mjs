import { q, d } from "./h.mjs";
export default [
d("Choosing the Summary",
`Mina: Jun, have you finished reading the article about tidal energy?
Jun: Yes. It says the ocean's tides could supply steady power, unlike wind, which depends on the weather.
Mina: Right, but I noticed it also mentions high building costs.
Jun: True. The machines must survive salt water and strong currents, so repairs are expensive.
Mina: So how should we summarize it in one sentence for our report?
Jun: Maybe like this: tidal energy is reliable, but it is costly to build and maintain.
Mina: I like that, though I would add that engineers expect prices to fall as designs improve.
Jun: Good point. That shows the writer is hopeful, not only critical.
Mina: Then let's keep the first part short and spend more words on the future.
Jun: Agreed. I'll write the draft tonight, and you can check the grammar tomorrow.`,
[
q("What are Mina and Jun mainly doing?", "Preparing a one-sentence summary of an article", "Arguing about who read the article first and who understood it", "Choosing a topic for a science fair", "Comparing the weather in two seas", "두 사람은 기사를 한 문장으로 요약할 준비를 하고 있어요."),
q("Choose the pair that best fills in (A) and (B).\n\nSummary: Tidal energy is (A) but expensive, although its cost may (B) in the future.", "reliable / fall", "unreliable / fall", "reliable / rise", "weak / disappear", "조력 에너지는 안정적이지만 비싸고, 비용은 앞으로 내려갈 것으로 기대돼요."),
q("Why does Mina want to add the last part about engineers?", "It shows that the writer is hopeful about the future.", "It proves that wind power is cheaper.", "It explains why salt water is dangerous.", "It makes the report longer than other reports.", "미래에 대한 낙관적 태도를 보여 주기 위해서예요."),
q("What will Jun do next?", "Write a draft of the summary tonight", "Check Mina's grammar tomorrow", "Visit a tidal power station with Mina", "Ask the engineers about prices", "Jun이 오늘 밤 초안을 쓰기로 했어요.")
], ["12영독02-04","12영독01-01"]),

d("Too Much Detail",
`Teacher: Daniel, I read your summary of the chapter on coral reefs.
Daniel: Did I miss something?
Teacher: Not exactly. You included every example, so it is almost as long as the chapter itself.
Daniel: I thought more details would make it better.
Teacher: A summary should keep the main claim and drop most of the examples. Ask yourself what the writer wants the reader to remember.
Daniel: So I should keep the idea that warm water harms reefs, but not the list of fish?
Teacher: Exactly. Mention one example only if it is needed to explain the claim.
Daniel: And what about my own opinion that reefs are beautiful?
Teacher: Save that for your discussion. A summary reports the writer's ideas, not yours.
Daniel: I understand. I'll cut it to three sentences and send it again tonight.`,
[
q("What was the main problem with Daniel's summary?", "It was nearly as long as the chapter, with too many examples.", "It had too few details about the many fish species in a reef.", "It was written in a language other than English.", "It did not mention the title of the chapter.", "예시를 모두 넣어 원문만큼 길어진 것이 문제예요."),
q("According to the teacher, what should a summary keep?", "The main claim of the writer", "Every example from the chapter", "The summarizer's own feelings", "A list of all the species", "요약은 필자의 핵심 주장을 유지해야 해요."),
q("Why does the teacher say 'Save that for your discussion'?", "Personal opinions do not belong in a summary.", "Reefs are not beautiful at all, so his opinion is wrong.", "Daniel's discussion is already finished.", "The opinion is wrong and must be corrected.", "요약에는 필자의 생각을 담고 개인 의견은 넣지 않기 때문이에요."),
q("What will Daniel most likely do next?", "Shorten the summary and submit it again", "Add many more examples to every paragraph", "Write about the beauty of reefs", "Ask another student to rewrite it", "세 문장으로 줄여 다시 제출하겠다고 했어요.")
], ["12영독02-04","12영독01-02"]),

d("Saturday Plans",
`Sora: Should we go hiking on Saturday, or visit the science museum?
Hana: I'd like to hike, but the forecast says it will rain after lunch.
Sora: Then the mountain could be slippery in the afternoon.
Hana: Exactly. The museum is open all day, though it will probably be crowded.
Sora: What if we do both? We could hike in the morning and go to the museum after lunch.
Hana: That sounds good. The trail is short, so we can finish by noon.
Sora: Should we take the bus or ask my brother for a ride?
Hana: The bus is cheaper, but it only comes once an hour.
Sora: Then let's ask my brother. He can drop us at the trail and pick us up at the museum.
Hana: Perfect. I'll bring sandwiches for a quick lunch in the car.`,
[
q("What problem do the two friends solve?", "How to enjoy both an outdoor activity and an indoor one", "How to choose between two different science museums in the city", "Where to buy sandwiches on Saturday", "How to avoid asking Sora's brother for help", "야외 활동과 실내 활동을 모두 즐길 계획을 세워요."),
q("Choose the pair that best fills in (A) and (B).\n\nSummary: Because rain is expected (A), they will hike (B) and visit the museum afterwards.", "after lunch / in the morning", "in the morning / after lunch", "all day / at night", "after lunch / on Sunday", "점심 후에 비가 올 예정이라 오전에 하이킹을 하고 오후에 박물관에 가요."),
q("Why do they decide not to take the bus?", "It runs only once an hour.", "It is more expensive than a car.", "It does not go near the museum.", "It is too crowded on Saturdays.", "버스가 한 시간에 한 대뿐이라 포기해요."),
q("What can be inferred about Sora's brother?", "He will help them travel between the two places.", "He dislikes both hiking and museums, so he will wait at home.", "He will join them for the entire day.", "He lives near the mountain trail.", "그가 등산로에 내려 주고 박물관에서 태워 주는 역할이에요.")
], ["12영독01-01","12영독01-04"]),

d("The Recycling Campaign Meeting",
`Leader: Thanks for coming, everyone. We need to decide how to promote our recycling campaign.
Eun: I suggest posters in the hallways. They are cheap, and everyone walks past them.
Minho: But students rarely read posters. A short video on the school website might reach more people.
Eun: That's a fair point, but only a few students visit the website.
Leader: What if we make a video and show it during homeroom?
Minho: That would work, and we could use the posters as a reminder afterward.
Eun: Our budget is small, though. Posters need paper and color printing.
Leader: We can print them in black and white on used paper. That fits the theme of the campaign.
Minho: I like that. I can film the video this week if someone writes the script.
Eun: I'll write it. Let's show the video on Monday.`,
[
q("What was the final decision of the meeting?", "To use both a video and low-cost posters", "To make only posters in color", "To put a video on the school website only", "To cancel the campaign for lack of money", "영상과 저렴한 포스터를 함께 쓰기로 했어요."),
q("Choose the pair that best fills in (A) and (B).\n\nSummary: Since few students read posters or visit the website, the club will show a (A) in homeroom and print (B) posters on used paper.", "video / black-and-white", "poster / color", "video / color", "script / large and colorful", "영상은 조회 시간에 보여 주고 포스터는 재활용지에 흑백으로 인쇄해요."),
q("Why does the leader suggest printing posters on used paper?", "It matches the theme of the campaign.", "It makes the posters easier to read.", "It is required by the school rules.", "It helps the posters last much longer.", "재활용 캠페인의 주제와 어울리기 때문이에요."),
q("Who will write the script?", "Eun", "Minho", "The leader", "A teacher", "Eun이 대본을 쓰겠다고 했어요.")
], ["12영독01-01","12영독01-04"]),

d("Do Dolphins Ever Sleep?",
`Host: Dr. Lee, many people believe that dolphins never sleep. Is that true?
Dr. Lee: Not exactly. Dolphins do rest, but they do it in an unusual way.
Host: How is it different from our sleep?
Dr. Lee: A dolphin must come to the surface to breathe, so it cannot fall completely unconscious. Instead, it rests one half of its brain at a time.
Host: So the other half stays awake?
Dr. Lee: Yes. That half controls breathing and keeps an eye on the surroundings. After a few hours, the halves switch roles.
Host: That sounds very practical. Do other animals do this?
Dr. Lee: Some birds appear to rest half of their brains while flying long distances, but dolphins are the best-known example.
Host: So the idea that dolphins never sleep is a myth.
Dr. Lee: It is a simplification. They do sleep, just not in the way humans do.`,
[
q("What is the main point of Dr. Lee's explanation?", "Dolphins sleep with half the brain resting at a time.", "Dolphins never need any rest at all.", "Dolphins sleep as deeply as humans do.", "Dolphins breathe underwater without coming up.", "돌고래는 뇌의 절반씩 번갈아 쉬며 잔다는 것이 핵심이에요."),
q("Choose the pair that best fills in (A) and (B).\n\nSummary: Dolphins rest one half of the brain at a time because they must (A) to breathe and need to stay (B).", "surface / alert", "dive / asleep", "surface / hungry", "hide / alert", "호흡하려면 수면으로 올라와야 하고 주변을 살피며 깨어 있어야 해요."),
q("Why does Dr. Lee call the common idea 'a simplification'?", "It is partly true but leaves out how dolphins really rest.", "It is completely true in every case.", "It was invented by the host.", "It describes animals that fly.", "돌고래가 아예 자지 않는다는 말은 일부만 맞고 실제 방식을 생략했다는 뜻이에요."),
q("What does the mention of birds show?", "Some other animals may also rest half the brain.", "Birds cannot fly for long distances.", "Birds sleep far more deeply than dolphins do at night.", "Dolphins were once a kind of bird that lived near the sea.", "일부 새도 비슷하게 쉬는 것으로 보인다는 예를 들었어요.")
], ["12영독01-02","12영독01-01"]),

d("The Screen Time Deal",
`Tom: Dad said I can only use my tablet for one hour a day, but that's not enough.
Yuna: Why do you need more? You only play games.
Tom: That's not true. I also watch videos about drawing, and I practice what I learn.
Yuna: Hmm, that's different. Did you tell Dad about the drawing?
Tom: I tried, but he thinks I'm making excuses.
Yuna: Maybe you should show him your drawings. Evidence is stronger than words.
Tom: Good idea. What if I propose a deal? One hour for games, and an extra half hour for learning.
Yuna: That might work, especially if you keep a record of what you do during the extra time.
Tom: I'll make a chart this weekend and talk to him on Sunday.
Yuna: Don't forget to stay calm. Dad listens better when you don't argue.`,
[
q("What does Tom want?", "More time on the tablet for learning to draw", "To stop drawing and spend all his time on games", "To buy a new tablet with his own savings", "To play games for the whole day", "그림을 배우기 위한 추가 태블릿 시간을 원해요."),
q("Choose the pair that best fills in (A) and (B).\n\nSummary: Tom will offer his father a (A) with extra time for learning, supported by a (B) of his activities.", "deal / record", "gift / secret", "deal / complaint", "rule / game", "추가 학습 시간을 거래로 제안하고 활동 기록으로 뒷받침해요."),
q("Why does Yuna suggest showing Dad the drawings?", "Evidence is more convincing than words alone.", "Dad enjoys looking at drawings on tablets.", "Tom's drawings are better than her own drawings.", "Dad has already promised to give more time.", "증거가 말보다 설득력이 있다고 했어요."),
q("What advice does Yuna give for the talk with Dad?", "Stay calm instead of arguing", "Talk to him as soon as possible tonight", "Pretend to agree with him", "Bring a friend to help argue", "침착하게 말하라고 조언해요.")
], ["12영독01-03","12영독01-04"]),
];
