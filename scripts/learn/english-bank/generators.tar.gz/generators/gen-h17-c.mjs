import fs from "node:fs";
import { rs1 } from "./gen-h17-a.mjs";
import { rs2, ds } from "./gen-h17-b.mjs";

const POSM = [1, 3, 0, 2, 2, 0, 3, 1, 0, 2, 1, 3, 3];
let n = 0;
const M = (q, key, ds3, why, cat, std) => {
  const a = POSM[n++ % POSM.length];
  const o = [...ds3]; o.splice(a, 0, key);
  return { k: "m", q, o, a, why, cat, ...(std ? { std } : {}) };
};
const ms = [
M("Which closing is most suitable at the end of a formal email to a client?", "Kind regards,", ["See ya later!", "Bye-bye for now,", "Catch you soon,"], "격식 있는 이메일의 맺음말로는 Kind regards가 알맞아요. 나머지는 친구 사이의 구어체예요.", "email", ["12직영01-06"]),
M("In a workplace email, “Please send the file ASAP” means that you should send it", "as soon as possible", ["after a short meeting", "at the same place", "with a separate note"], "ASAP는 as soon as possible의 약어예요.", "abbreviation"),
M("A colleague writes “FYI” before a message. What does this abbreviation stand for?", "for your information", ["for your invitation", "from your inbox", "find your instructions"], "FYI는 for your information(참고로 알려 드립니다)이에요.", "abbreviation"),
M("An invitation to a company dinner ends with “RSVP by Friday.” What are you asked to do?", "Reply to say whether you will attend", ["Bring a guest to the dinner on Friday", "Pay for your meal before the event", "Choose a seat on the bus on Friday"], "RSVP는 참석 여부를 회신해 달라는 표시예요.", "abbreviation"),
M("You “cc” your supervisor on an email. What does this mean?", "She receives a copy of the message", ["She must reply before anyone else", "She cannot see who got the email", "She has been removed from the team"], "cc는 carbon copy, 참조로 사본을 보낸다는 뜻이에요.", "email"),
M("Choose the best word: “The meeting has been ___ until next Monday because the manager is ill.”", "postponed", ["interrupted", "reduced", "finished"], "postpone은 일정을 뒤로 미룬다는 뜻이에요. until next Monday와 어울려요.", "collocation"),
M("Choose the best phrase: “Could you ___ a meeting with the supplier for Friday?”", "set up", ["put up", "give up", "take off"], "set up a meeting은 회의를 잡다라는 뜻의 연어예요.", "phrasal verb"),
M("A person who works for a company and receives wages is called a(n)", "employee", ["employer", "applicant", "customer"], "employee는 고용된 사람, employer는 고용주예요.", "job vocabulary"),
M("Which document lists a person's education and work experience for a job application?", "A résumé", ["An invoice for services", "The minutes of a meeting", "A receipt for goods"], "résumé(이력서)는 학력과 경력을 정리한 문서예요.", "job vocabulary", ["12직영01-06"]),
M("Choose the best word: “Mr. Kim receives a fixed ___ of 3,000 dollars on the 25th of every month.”", "salary", ["receipt", "invoice", "discount"], "salary는 매달 정해진 급여를 뜻해요.", "job vocabulary"),
M("The project deadline is Friday. A deadline is", "the latest time a task must be finished", ["the first day of a new project", "a list of people on a team", "a short break between two long tasks"], "deadline은 마감 기한을 뜻해요.", "job vocabulary"),
M("Which sentence is the most polite way to ask a customer to wait?", "Would you mind waiting a moment, please?", ["Wait here until I call your name, and don't ask again.", "You have to stand there and wait, and I am busy.", "Just sit over there and stop asking me questions."], "Would you mind ...ing는 정중한 부탁의 표현이에요.", "politeness", ["12직영01-04"]),
M("Choose the best phrase: “I'm writing to ___ on our phone call yesterday.”", "follow up", ["give away", "look up", "break down"], "follow up on은 이전 연락의 후속 조치를 하다라는 뜻이에요.", "phrasal verb"),
M("Choose the best word: “We are running ___ of printer paper, so please order more.”", "out", ["off", "over", "away"], "run out of는 ~이 떨어지다라는 뜻의 표현이에요.", "phrasal verb"),
M("Which opening is the most suitable for a formal inquiry letter?", "I am writing to inquire about your internship program.", ["Hey, what's up with all that internship stuff you do there?", "So, I was kinda wondering a little bit about interns.", "Yo! Tell me everything about the internship thing."], "격식 있는 문의 편지는 I am writing to ...로 시작해요.", "register", ["12직영01-06"]),
M("You receive an automatic “Out of Office” reply from a colleague. What does it tell you?", "She is away and cannot answer for now", ["She has left the company for good", "She is waiting for your reply today", "She has sent your message to a client"], "Out of Office는 부재중이라 지금은 답하기 어렵다는 자동 응답이에요.", "email"),
M("The manager says, “Let's get the ball rolling on the new project.” She means that they should", "begin the activity", ["buy equipment for a game", "finish the work early", "stop the project at once"], "get the ball rolling은 일을 시작하다라는 관용 표현이에요.", "idiom"),
M("A colleague says, “Let's touch base next week.” What does she suggest?", "Contact each other briefly to update", ["Play a game together after work", "Finish all of the work before next week ends", "Stop working together from now on"], "touch base는 잠깐 연락해서 상황을 나눈다는 뜻이에요.", "idiom"),
M("Choose the correct word: “She is responsible ___ the monthly report.”", "for", ["of", "at", "with"], "be responsible for ~는 ~에 책임이 있다는 뜻이에요.", "preposition"),
M("Choose the correct word: “He is very good ___ solving customer problems.”", "at", ["of", "with", "by"], "be good at ~ing 형태로 쓰여요.", "preposition"),
M("Choose the correct word: “The company is looking for a ___ person who always arrives on time.”", "reliable", ["reliably", "reliance", "relying"], "명사 person을 꾸미므로 형용사 reliable이 필요해요.", "word form"),
M("Choose the correct word: “Her ___ to the team meeting was very valuable.”", "contribution", ["contribute", "contributed", "contributing"], "소유격 her 뒤에는 명사가 와야 하므로 contribution이에요.", "word form"),
M("A sign on the floor says “CAUTION: WET FLOOR.” What should you do?", "Walk carefully because it is slippery", ["Clean the floor with water at once", "Wait outside until the floor is dry", "Take off your shoes before you enter the room"], "Caution은 주의하라는 표지로, 바닥이 젖어 미끄러우니 조심해서 걸어야 해요.", "signs", ["12직영01-08"]),
M("A door has the sign “STAFF ONLY.” Who is allowed to enter?", "Only people who work there", ["Anyone who needs some help", "Customers who bring a guest", "People with a ticket to enter"], "Staff only는 직원만 출입할 수 있다는 뜻이에요.", "signs"),
M("Which email subject line is the clearest for asking to move a meeting?", "Request to reschedule Tuesday's 3 p.m. meeting", ["Something I wanted to ask you about soon", "Urgent!!! Please read this message right now", "Meeting stuff and other related things for later"], "구체적인 목적과 시간을 알려 주는 제목이 가장 분명해요.", "email", ["12직영01-06"]),
M("Which action is the safest way to handle your work account password?", "Use a different password for each account", ["Write it on a note stuck to your monitor", "Share it with a busy colleague to save time", "Choose your birthday so it is easy to recall"], "계정마다 다른 비밀번호를 쓰는 것이 안전해요.", "security", ["12직영01-08"]),
M("Your manager asks, “Could you send me the report by noon?” Which reply is the most appropriate?", "Certainly. I'll send it before twelve.", ["Why don't you ask someone else to do it?", "No, I really hate writing reports at all.", "Not my job, so I'm not going to do it."], "정중하고 분명하게 수락하는 응답이 적절해요.", "politeness", ["12직영01-04"]),
M("Which job fits this duty: “answers customers' questions by phone and solves their problems”?", "Customer service agent", ["Accountant for a bank", "Architect for houses", "Librarian at a school"], "고객 문의에 응대하는 직무는 고객 서비스 담당자예요.", "job vocabulary"),
M("Which phrase best completes the email? “Thank you for your quick reply. I ___ your help.”", "really appreciate", ["am really appreciating", "really appreciates", "really to appreciate"], "appreciate는 감사 표현으로 쓰이고 주어 I 뒤에 원형이 와요.", "grammar"),
];

const s = (good, ko, bad, st, ok, wr, rule, extra = {}) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...extra });
const ss = [
s("Had I known about the deadline, I would have started earlier.", "마감일을 알았더라면 더 일찍 시작했을 텐데요.",
 ["If I knew about the deadline, I would have started earlier.", "Had I knew about the deadline, I would have started earlier.", "Had I known about the deadline, I would started earlier."],
 "___ I known about the deadline, I would have started earlier.", "Had", ["If", "Have", "Did"], "과거 사실의 반대를 나타내는 가정법 과거완료에서 if를 생략하면 Had + 주어 + p.p. 순서로 도치돼요."),
s("The manager asked whether I could attend the meeting.", "관리자는 내가 회의에 참석할 수 있는지 물었어요.",
 ["The manager asked whether could I attend the meeting.", "The manager asked whether I could attending the meeting.", "The manager asked whether I attend could the meeting."],
 "The manager asked whether I ___ attend the meeting.", "could", ["can I", "to", "attending"], "간접의문문에서는 whether 뒤에 평서문 어순(주어 + 동사)을 써요."),
s("The report must be submitted by Friday.", "그 보고서는 금요일까지 제출되어야 해요.",
 ["The report must submit by Friday.", "The report must be submit by Friday.", "The report must been submitted by Friday."],
 "The report must be ___ by Friday.", "submitted", ["submit", "submitting", "submits"], "조동사의 수동태는 조동사 + be + 과거분사로 써요."),
s("She suggested that we hold the meeting online.", "그녀는 우리가 회의를 온라인으로 열자고 제안했어요.",
 ["She suggested us to hold the meeting online.", "She suggested to hold the meeting online.", "She suggested that we to hold the meeting online."],
 "She suggested that we ___ the meeting online.", "hold", ["to hold", "holding", "to holding"], "suggest 뒤에는 that절(주어 + 동사원형)이나 동명사를 쓰고 to부정사는 쓰지 않아요."),
s("The candidate whose résumé impressed us most has accepted the offer.", "이력서가 우리에게 가장 깊은 인상을 준 지원자가 제안을 수락했어요.",
 ["The candidate who résumé impressed us most has accepted the offer.", "The candidate whose his résumé impressed us most has accepted the offer.", "The candidate whom résumé impressed us most has accepted the offer."],
 "The candidate ___ résumé impressed us most has accepted the offer.", "whose", ["who", "whom", "which"], "소유를 나타내는 관계대명사는 whose이며, 뒤에 소유격 대명사를 또 쓰지 않아요."),
s("She is interested in working for an international company.", "그녀는 국제적인 회사에서 일하는 데 관심이 있어요.",
 ["She is interested in work for an international company.", "She is interested in to work for an international company.", "She is interested in works for an international company."],
 "She is interested in ___ for an international company.", "working", ["work", "to work", "worked"], "전치사 뒤에는 동명사(-ing)가 와요.", { hint: "전치사 다음에 오는 동사의 형태를 생각해 보세요." }),
s("I wish I had more time to prepare for the presentation.", "발표를 준비할 시간이 더 있으면 좋겠어요.",
 ["I wish I have more time to prepare for the presentation.", "I wish I having more time to prepare for the presentation.", "I wish I will have more time to prepare for the presentation."],
 "I wish I ___ more time to prepare for the presentation.", "had", ["have", "having", "will have"], "현재 사실과 반대되는 소망은 wish + 과거형으로 나타내요."),
s("Having finished the report, she sent it to her supervisor.", "보고서를 끝낸 뒤에 그녀는 그것을 상사에게 보냈어요.",
 ["Having finish the report, she sent it to her supervisor.", "Finished the report, she sent it to her supervisor.", "Having finishing the report, she sent it to her supervisor."],
 "___ the report, she sent it to her supervisor.", "Having finished", ["Having finish", "To finishing", "Have finished"], "먼저 일어난 일은 완료 분사구문 Having + p.p.로 나타내요."),
];

const out = { packet: "H17-h-job", sections: [{ skill: "e.h.job", items: [...rs1, ...rs2, ...ds, ...ms, ...ss] }] };
const kinds = {}; for (const i of out.sections[0].items) kinds[i.k] = (kinds[i.k] ?? 0) + 1;
console.log(kinds);
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H17-h-job.json", JSON.stringify(out, null, 1) + "\n");
