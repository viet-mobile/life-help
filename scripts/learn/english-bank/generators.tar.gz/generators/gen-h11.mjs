import fs from "node:fs";

const items = [];
const S = (good, ko, bad, st, ok, wr, rule, extra = {}) => items.push({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...extra });
const PH = "and/but/or로 이어진 어구의 형태를 서로 비교해 보세요.";
const AH = "주어의 핵심 명사가 무엇인지 먼저 찾아보세요.";
const NL = { ord: false };

// ---------- sentence items: parallel structure
S("The new library offers free tutoring, quiet study rooms, and access to online journals.", "새 도서관은 무료 개인 지도, 조용한 학습실, 온라인 학술지 이용을 제공해요.",
  ["The new library offers free tutoring, quiet study rooms, and accessing online journals.", "The new library offers free tutoring, quiet study rooms, and to access online journals.", "The new library offers free tutoring, quiet study rooms, and that students can access online journals."],
  "The new library offers free tutoring, quiet study rooms, and ___ to online journals.", "access", ["accessing", "accessible", "to access"],
  "나열하는 세 항목은 모두 명사구(tutoring, study rooms, access)로 맞춰야 해요.", { hint: PH, ...NL });
S("The training program is designed not only to improve speed but also to reduce errors.", "그 훈련 프로그램은 속도를 높일 뿐 아니라 실수도 줄이도록 설계되었어요.",
  ["The training program is designed not only to improve speed but also reducing errors.", "The training program is designed not only improving speed but also to reduce errors.", "The training program is designed not only to improve speed but also reduction of errors."],
  "The training program is designed not only to improve speed but also ___ errors.", "to reduce", ["reducing", "reduction of", "reduced"],
  "not only A but also B에서 A와 B는 같은 형태여야 해요. 여기서는 둘 다 to부정사예요.", { hint: PH });
S("He is both intelligent and considerate.", "그는 똑똑하고 배려심도 깊어요.",
  ["He is both intelligent and with consideration.", "He is both intelligence and considerate.", "He is both intelligent and considerately."],
  "He is both intelligent and ___.", "considerate", ["considerately", "consideration", "to consider"],
  "both A and B에서는 A와 B의 품사와 형태를 같게 해요. 둘 다 형용사예요.", { hint: PH });
S("You can either submit the form online or bring it to the office.", "양식을 온라인으로 제출하거나 사무실로 가져오면 돼요.",
  ["You can either submit the form online or bringing it to the office.", "You can either submitting the form online or bring it to the office.", "You can either submit the form online or to bring it to the office."],
  "You can either submit the form online or ___ it to the office.", "bring", ["brings", "bringing", "to bring"],
  "조동사 can 뒤의 either A or B는 모두 동사원형으로 맞춰요.", { hint: PH });
S("The candidate had neither the experience nor the confidence to lead the team.", "그 후보는 팀을 이끌 경험도 자신감도 없었어요.",
  ["The candidate had neither the experience or the confidence to lead the team.", "The candidate had neither the experience nor to be confident to lead the team.", "The candidate had neither experienced nor the confidence to lead the team."],
  "The candidate had neither the experience ___ the confidence to lead the team.", "nor", ["or", "and", "but"],
  "neither는 nor와 짝을 이루고, 연결되는 두 어구도 같은 명사구예요.", { hint: PH });
S("Living in a small town is less expensive than living in a big city.", "작은 마을에서 사는 것은 큰 도시에서 사는 것보다 비용이 덜 들어요.",
  ["Living in a small town is less expensive than a big city.", "Living in a small town is less expensive than live in a big city.", "Living in a small town is less expensive than lives in a big city."],
  "Living in a small town is less expensive than ___ in a big city.", "living", ["live", "lived", "lives"],
  "비교의 대상은 같은 형태여야 해요. '사는 것'과 '사는 것'을 비교하므로 living ... than living이에요.", { hint: "비교되는 두 대상이 같은 종류인지 확인해 보세요.", ...NL });
S("She prefers walking to work to taking the bus.", "그녀는 버스를 타는 것보다 걸어서 출근하는 것을 더 좋아해요.",
  ["She prefers walking to work than taking the bus.", "She prefers to walk to work to taking the bus.", "She prefers walking to work over take the bus."],
  "She prefers walking to work to ___ the bus.", "taking", ["taken", "takes", "took"],
  "prefer A to B에서 A와 B는 같은 형태예요. walking에 맞춰 B도 동명사(taking)로 써요.", { hint: PH });
S("The apartment is spacious, bright, and close to the station.", "그 아파트는 넓고 밝고 역에서 가까워요.",
  ["The apartment is spacious, brightly, and close to the station.", "The apartment is spacious, brightness, and close to the station.", "The apartment is spacious, bright, and has a location close to the station."],
  "The apartment is spacious, ___, and close to the station.", "bright", ["brightly", "brightness", "brighten"],
  "is 뒤의 보어로 나열되는 어구는 모두 형용사(구)로 맞춰요.", { hint: PH, ...NL });
S("The coach told the players to arrive early, to wear their uniforms, and to bring water.", "코치는 선수들에게 일찍 도착하고, 유니폼을 입고, 물을 가져오라고 말했어요.",
  ["The coach told the players to arrive early, wearing their uniforms, and to bring water.", "The coach told the players to arrive early, to wear their uniforms, and bringing water.", "The coach told the players arriving early, to wear their uniforms, and to bring water."],
  "The coach told the players to arrive early, to wear their uniforms, and ___ water.", "to bring", ["bringing", "brought", "brings"],
  "to부정사를 반복해 나열할 때는 마지막 항목도 to부정사로 써요.", { hint: PH, ...NL });
S("Reading widely, thinking critically, and writing clearly are skills that every student needs.", "폭넓게 읽기, 비판적으로 생각하기, 명확하게 쓰기는 모든 학생에게 필요한 기술이에요.",
  ["Reading widely, to think critically, and writing clearly are skills that every student needs.", "Reading widely, thinking critically, and to write clearly are skills that every student needs.", "Reading widely, thinking critically, and written clearly are skills that every student needs."],
  "Reading widely, thinking critically, and ___ clearly are skills that every student needs.", "writing", ["to write", "written", "wrote"],
  "주어 자리에 나열된 세 동명사구는 형태를 맞추고, 복합 주어이므로 동사는 are예요.", { hint: PH, ...NL });
S("The tourists wandered through the market, bargained for souvenirs, and sampled local snacks.", "관광객들은 시장을 거닐고, 기념품을 흥정하고, 현지 간식을 맛보았어요.",
  ["The tourists wandered through the market, bargain for souvenirs, and sampled local snacks.", "The tourists wandered through the market, bargaining for souvenirs, and sampled local snacks.", "The tourists wandered through the market, bargained for souvenirs, and sampling local snacks."],
  "The tourists wandered through the market, bargained for souvenirs, and ___ local snacks.", "sampled", ["sample", "sampling", "samples"],
  "하나의 주어에 이어지는 동사들은 시제와 형태를 같게 해요. 모두 과거형이에요.", { hint: PH, ...NL });
S("The report explains what caused the delay, how the company responded, and why prices rose.", "그 보고서는 지연의 원인, 회사의 대응 방식, 가격이 오른 이유를 설명해요.",
  ["The report explains what caused the delay, how the company responded, and the reason of price increase.", "The report explains what caused the delay, the response of the company, and why prices rose.", "The report explains what caused the delay, how did the company respond, and why prices rose."],
  "The report explains what caused the delay, how the company responded, and ___ prices rose.", "why", ["because", "therefore", "which"],
  "explains의 목적어로 의문사절 세 개를 같은 어순(의문사+주어+동사)으로 나열해요.", { hint: PH, ...NL });
S("She is known for her honesty, her humor, and her willingness to help others.", "그녀는 정직함, 유머, 그리고 남을 기꺼이 도우려는 마음으로 알려져 있어요.",
  ["She is known for her honesty, her humor, and she is willing to help others.", "She is known for being honest, her humor, and her willingness to help others.", "She is known for her honesty, humorous, and her willingness to help others."],
  "She is known for her honesty, her humor, and her ___ to help others.", "willingness", ["willing", "willingly", "willed"],
  "for 뒤에 소유격+명사 형태(her honesty, her humor, her willingness)를 나란히 써요.", { hint: PH, ...NL });
S("The committee has not decided whether to expand the program or to close it.", "위원회는 그 프로그램을 확대할지 폐지할지 아직 결정하지 못했어요.",
  ["The committee has not decided whether to expand the program or closing it.", "The committee has not decided whether expanding the program or to close it.", "The committee has not decided whether to expand the program or if closing it."],
  "The committee has not decided whether to expand the program or ___ it.", "to close", ["closing", "closed", "closes"],
  "whether to A or to B처럼 두 선택지를 같은 to부정사 형태로 맞춰요.", { hint: PH });
S("Our goal is to cut waste, save energy, and protect wildlife.", "우리의 목표는 낭비를 줄이고, 에너지를 아끼고, 야생동물을 보호하는 것이에요.",
  ["Our goal is to cut waste, saving energy, and protect wildlife.", "Our goal is to cut waste, save energy, and protecting wildlife.", "Our goal is to cut waste, save energy, and the protection of wildlife."],
  "Our goal is to cut waste, save energy, and ___ wildlife.", "protect", ["protecting", "protection of", "protected"],
  "to cut, (to) save, (to) protect처럼 to부정사의 동사원형을 나열해요. 두 번째부터 to는 생략할 수 있어요.", { hint: PH, ...NL });
S("The job requires someone who can work independently, communicate clearly, and meet tight deadlines.", "그 일에는 독립적으로 일하고, 분명하게 소통하고, 촉박한 기한을 맞출 수 있는 사람이 필요해요.",
  ["The job requires someone who can work independently, communicates clearly, and meet tight deadlines.", "The job requires someone who can work independently, communicate clearly, and meeting tight deadlines.", "The job requires someone who can work independently, a clear communicator, and meet tight deadlines."],
  "The job requires someone who can work independently, communicate clearly, and ___ tight deadlines.", "meet", ["meets", "meeting", "met"],
  "조동사 can 뒤에 오는 동사들은 모두 동사원형으로 맞춰요.", { hint: PH, ...NL });
S("The climate of Jeju is milder than that of Seoul.", "제주의 기후는 서울의 기후보다 온화해요.",
  ["The climate of Jeju is milder than Seoul.", "The climate of Jeju is milder than those of Seoul.", "The climate of Jeju is milder than it of Seoul."],
  "The climate of Jeju is milder than ___ of Seoul.", "that", ["those", "it", "them"],
  "기후와 기후를 비교해야 하므로 반복되는 단수 명사 climate를 that으로 받아요.", { hint: "무엇과 무엇을 비교하는지 생각해 보세요." });
S("The prices in this shop are lower than those in the mall.", "이 가게의 가격은 쇼핑몰의 가격보다 낮아요.",
  ["The prices in this shop are lower than that in the mall.", "The prices in this shop are lower than them in the mall.", "The prices in this shop are lower than the mall."],
  "The prices in this shop are lower than ___ in the mall.", "those", ["that", "it", "them"],
  "복수 명사 prices의 반복을 피하려면 those를 써서 같은 종류끼리 비교해요.", { hint: "비교되는 대상의 수에 주목해 보세요." });
S("The island is famous not only for its beaches but also for its seafood.", "그 섬은 해변뿐 아니라 해산물로도 유명해요.",
  ["The island is famous not only for its beaches but also because of its seafood.", "The island is famous not only for its beaches but also famous seafood.", "The island is famous not only its beaches but also for its seafood."],
  "The island is famous not only for its beaches but also ___ its seafood.", "for", ["because", "by", "to"],
  "not only for A but also for B처럼 전치사구를 같은 형태로 맞춰요.", { hint: PH });
S("She has worked as a nurse, a teacher, and a clinic manager.", "그녀는 간호사, 교사, 그리고 진료소 관리자로 일한 적이 있어요.",
  ["She has worked as a nurse, a teacher, and managing a clinic.", "She has worked as a nurse, taught, and a clinic manager.", "She has worked as a nurse, a teacher, and she manages a clinic."],
  "She has worked as a nurse, a teacher, and ___.", "a clinic manager", ["managing a clinic", "she manages a clinic", "to manage a clinic"],
  "as 뒤에 직업을 나타내는 명사구를 같은 형태로 나열해요.", { hint: PH, ...NL });
S("You will be judged by what you do, not by what you say.", "당신은 말하는 것이 아니라 행동하는 것으로 평가받을 거예요.",
  ["You will be judged by what you do, not by saying.", "You will be judged by what you do, not by what do you say.", "You will be judged by what you do, not by what you saying."],
  "You will be judged by what you do, not by ___ you say.", "what", ["that", "which", "whose"],
  "by what you do와 not by what you say처럼 대비되는 두 어구를 같은 구조로 써요.", { hint: PH, ...NL });
S("The harder she studied, the better she performed.", "그녀는 열심히 공부할수록 더 잘 해냈어요.",
  ["The harder she studied, better she performed.", "The harder she studied, the best she performed.", "Harder she studied, the better she performed."],
  "The harder she studied, ___ she performed.", "the better", ["better", "the best", "the well"],
  "the + 비교급 ..., the + 비교급 ...은 앞뒤를 같은 형태로 맞추는 구문이에요.", { hint: "앞 절과 뒤 절의 짝이 맞는지 확인해 보세요." });
S("My brother enjoys cooking Korean dishes, baking bread, and trying new recipes.", "내 형은 한식 요리하기, 빵 굽기, 새 요리법 시도하기를 즐겨요.",
  ["My brother enjoys cooking Korean dishes, to bake bread, and trying new recipes.", "My brother enjoys cooking Korean dishes, baking bread, and to try new recipes.", "My brother enjoys cooking Korean dishes, baking bread, and try new recipes."],
  "My brother enjoys cooking Korean dishes, baking bread, and ___ new recipes.", "trying", ["to try", "tried", "try"],
  "enjoy의 목적어로 나열되는 항목은 모두 동명사(-ing)로 맞춰요.", { hint: PH, ...NL });
S("The guidebook describes where to stay, what to eat, and how to move around the city.", "그 안내서는 어디에 머물지, 무엇을 먹을지, 도시를 어떻게 돌아다닐지 설명해요.",
  ["The guidebook describes where staying, what to eat, and how to move around the city.", "The guidebook describes where to stay, eating what, and how to move around the city.", "The guidebook describes where to stay, what to eat, and how moving around the city."],
  "The guidebook describes where to stay, what to eat, and how ___ around the city.", "to move", ["moving", "moved", "move"],
  "의문사 + to부정사를 나열할 때 세 항목 모두 같은 구조(where to stay, what to eat, how to move)로 써요.", { hint: PH, ...NL });

// ---------- sentence items: agreement
S("Each of the volunteers has received a certificate.", "자원봉사자 한 명 한 명이 증서를 받았어요.",
  ["Each of the volunteers have received a certificate.", "Each of the volunteers are receiving a certificate.", "Each of the volunteer has received a certificate."],
  "Each of the volunteers ___ received a certificate.", "has", ["have", "are", "were"],
  "Each of + 복수명사는 each가 핵심 주어이므로 단수 동사를 써요.", { hint: AH });
S("The number of students who commute by bike is increasing.", "자전거로 통학하는 학생 수가 늘고 있어요.",
  ["The number of students who commute by bike are increasing.", "The number of students who commutes by bike is increasing.", "The number of students who commute by bike were increasing."],
  "The number of students who commute by bike ___ increasing.", "is", ["are", "were", "have"],
  "The number of ...의 핵심 주어는 number(단수)예요. who commute의 주어는 students(복수)라 따로 일치해요.", { hint: AH });
S("A number of residents have complained about the noise.", "많은 주민이 소음에 대해 불평해 왔어요.",
  ["A number of residents has complained about the noise.", "A number of residents is complaining about the noise.", "A number of resident have complained about the noise."],
  "A number of residents ___ complained about the noise.", "have", ["has", "is", "was"],
  "A number of + 복수명사는 '많은 ~'라는 뜻의 복수 취급이에요.", { hint: AH });
S("Neither the manager nor the employees were aware of the change.", "관리자도 직원들도 그 변경 사실을 알지 못했어요.",
  ["Neither the manager nor the employees was aware of the change.", "Neither the manager or the employees were aware of the change.", "Neither the manager nor the employees is aware of the change."],
  "Neither the manager nor the employees ___ aware of the change.", "were", ["was", "is", "has been"],
  "neither A nor B가 주어일 때 동사는 가까운 B(employees, 복수)에 일치시켜요.", { hint: "동사와 가장 가까운 명사가 무엇인지 보세요." });
S("Either the players or the coach is going to speak at the press conference.", "선수들이나 코치 중 한쪽이 기자회견에서 말할 예정이에요.",
  ["Either the players or the coach are going to speak at the press conference.", "Either the players and the coach is going to speak at the press conference.", "Either the players or the coach were going to speak at the press conference."],
  "Either the players or the coach ___ going to speak at the press conference.", "is", ["are", "were", "have been"],
  "either A or B가 주어일 때 동사는 가까운 B(coach, 단수)에 일치시켜요.", { hint: "동사와 가장 가까운 명사가 무엇인지 보세요." });
S("Measles is a contagious disease that vaccines can prevent.", "홍역은 백신으로 예방할 수 있는 전염병이에요.",
  ["Measles are a contagious disease that vaccines can prevent.", "Measles is a contagious disease that vaccine can prevent.", "Measles are contagious diseases that vaccines can prevent."],
  "Measles ___ a contagious disease that vaccines can prevent.", "is", ["are", "were being", "have been"],
  "measles처럼 -s로 끝나지만 병 이름은 단수로 취급해요.", { hint: "-s로 끝나는 주어가 정말 복수인지 생각해 보세요." });
S("The news about the merger was a surprise to everyone.", "합병 소식은 모두에게 놀라움이었어요.",
  ["The news about the merger were a surprise to everyone.", "The news about the merger are a surprise to everyone.", "The newses about the merger was a surprise to everyone."],
  "The news about the merger ___ a surprise to everyone.", "was", ["were", "are", "have been"],
  "news는 -s로 끝나지만 셀 수 없는 단수 명사라 단수 동사를 써요.", { hint: "-s로 끝나는 주어가 정말 복수인지 생각해 보세요." });
S("The teacher, as well as the students, is excited about the trip.", "학생들뿐 아니라 선생님도 그 여행에 들떠 있어요.",
  ["The teacher, as well as the students, are excited about the trip.", "The teacher, as well as the students, were excited about the trip.", "The teacher, as well as the students, have been excited about the trip."],
  "The teacher, as well as the students, ___ excited about the trip.", "is", ["are", "were", "have been"],
  "as well as 뒤의 어구는 주어에 더해지는 부가 정보이므로 동사는 핵심 주어 teacher(단수)에 일치시켜요.", { hint: AH });
S("There were several reasons for the sudden change in policy.", "정책이 갑자기 바뀐 데에는 여러 이유가 있었어요.",
  ["There was several reasons for the sudden change in policy.", "There were several reason for the sudden change in policy.", "There be several reasons for the sudden change in policy."],
  "There ___ several reasons for the sudden change in policy.", "were", ["was", "is", "has been"],
  "There is/are 구문에서는 뒤에 오는 진짜 주어(reasons, 복수)에 동사를 일치시켜요.", { hint: "there 뒤에 오는 진짜 주어를 찾아보세요." });
S("The majority of the voters were satisfied with the result.", "유권자의 대다수가 그 결과에 만족했어요.",
  ["The majority of the voters was satisfied with the result.", "The majority of the voters is satisfied with the result.", "The majority of the voter were satisfied with the result."],
  "The majority of the voters ___ satisfied with the result.", "were", ["was", "is", "has been"],
  "the majority of + 복수명사는 of 뒤 명사(voters)에 동사를 일치시켜요.", { hint: "of 뒤의 명사가 동사의 수를 정해요." });
S("Two-thirds of the land is used for farming.", "그 땅의 3분의 2는 농사에 쓰여요.",
  ["Two-thirds of the land are used for farming.", "Two-thirds of the land were used for farming.", "Two-thirds of the lands is used for farming."],
  "Two-thirds of the land ___ used for farming.", "is", ["are", "were", "have been"],
  "분수 of + 명사에서는 of 뒤 명사(land, 단수)에 동사를 일치시켜요.", { hint: "of 뒤의 명사가 동사의 수를 정해요." });
S("Half of the apples in the basket were rotten.", "바구니 안의 사과 중 절반이 썩어 있었어요.",
  ["Half of the apples in the basket was rotten.", "Half of the apples in the basket is rotten.", "Half of the apple in the basket were rotten."],
  "Half of the apples in the basket ___ rotten.", "were", ["was", "is", "has been"],
  "Half of + 복수명사는 복수 동사를 써요. 뒤 명사 apples가 기준이에요.", { hint: "of 뒤의 명사가 동사의 수를 정해요." });
S("One of the reasons for the failure was a lack of funding.", "실패의 이유 중 하나는 자금 부족이었어요.",
  ["One of the reasons for the failure were a lack of funding.", "One of the reason for the failure was a lack of funding.", "One of the reasons for the failure are a lack of funding."],
  "One of the reasons for the failure ___ a lack of funding.", "was", ["were", "are", "have been"],
  "One of + 복수명사의 핵심 주어는 one이므로 단수 동사를 써요.", { hint: AH });
S("She is one of the scientists who work at the observatory.", "그녀는 그 관측소에서 일하는 과학자들 중 한 명이에요.",
  ["She is one of the scientists who works at the observatory.", "She is one of the scientist who work at the observatory.", "She is one of the scientists who is working at the observatory."],
  "She is one of the scientists who ___ at the observatory.", "work", ["works", "is working", "has worked"],
  "one of the + 복수명사 + who에서 who의 선행사는 scientists(복수)이므로 복수 동사를 써요.", { hint: "관계대명사 who가 가리키는 말을 찾아보세요." });
S("Nowhere in the report were the risks explained clearly.", "그 보고서 어디에도 위험이 명확하게 설명되어 있지 않았어요.",
  ["Nowhere in the report was the risks explained clearly.", "Nowhere in the report were the risk explained clearly.", "Nowhere in the report the risks were explained clearly."],
  "Nowhere in the report ___ the risks explained clearly.", "were", ["was", "is", "has"],
  "부정 부사가 문장 앞에 오면 도치되고, 동사는 뒤의 주어(the risks, 복수)에 일치시켜요.", { hint: "도치된 문장에서 진짜 주어는 어디에 있는지 보세요." });
S("Learning a foreign language takes time and patience.", "외국어를 배우는 일에는 시간과 인내가 필요해요.",
  ["Learning a foreign language take time and patience.", "Learning a foreign language are taking time and patience.", "Learned a foreign language takes time and patience."],
  "Learning a foreign language ___ time and patience.", "takes", ["take", "have taken", "are taking"],
  "동명사구 주어는 단수로 취급하므로 단수 동사를 써요.", { hint: AH });
S("The boxes on the top shelf contain old photographs.", "맨 위 선반에 있는 상자들에는 오래된 사진이 들어 있어요.",
  ["The boxes on the top shelf contains old photographs.", "The boxes on the top shelf is containing old photographs.", "The boxes on the top shelf has contained old photographs."],
  "The boxes on the top shelf ___ old photographs.", "contain", ["contains", "is containing", "has contained"],
  "전치사구(on the top shelf)는 주어의 수에 영향을 주지 않아요. 핵심 주어는 boxes(복수)예요.", { hint: AH });
S("Beside the lake stand three old oak trees.", "호숫가에는 오래된 참나무 세 그루가 서 있어요.",
  ["Beside the lake stands three old oak trees.", "Beside the lake standing three old oak trees.", "Beside the lake is stand three old oak trees."],
  "Beside the lake ___ three old oak trees.", "stand", ["stands", "standing", "is standing"],
  "장소 어구가 앞에 나와 도치된 문장에서도 동사는 뒤의 주어(trees, 복수)에 일치시켜요.", { hint: "도치된 문장에서 진짜 주어는 어디에 있는지 보세요.", ...NL });
S("What worries many parents is the amount of time children spend online.", "많은 부모를 걱정시키는 것은 아이들이 온라인에서 보내는 시간의 양이에요.",
  ["What worries many parents are the amount of time children spend online.", "What worry many parents is the amount of time children spend online.", "What worries many parents were the amount of time children spend online."],
  "What worries many parents ___ the amount of time children spend online.", "is", ["are", "were", "have been"],
  "what절 주어는 단수로 취급하고, 보어 the amount(단수)와도 수가 맞아요.", { hint: AH, ...NL });
S("Stories of Courage is a book that my class read last term.", "'Stories of Courage'는 우리 반이 지난 학기에 읽은 책이에요.",
  ["Stories of Courage are a book that my class read last term.", "Stories of Courage were a book that my class read last term.", "Stories of Courage is a book that my class reads last term."],
  "Stories of Courage ___ a book that my class read last term.", "is", ["are", "were", "have been"],
  "책이나 작품 제목은 복수형이어도 하나의 대상이므로 단수 동사를 써요.", { hint: "제목 전체가 가리키는 대상은 몇 개인지 생각해 보세요." });
S("Ten kilometers is a long way to walk in this heat.", "이 더위에 10킬로미터는 걷기에 먼 거리예요.",
  ["Ten kilometers are a long way to walk in this heat.", "Ten kilometers were a long way to walk in this heat.", "Ten kilometer is a long way to walk in this heat."],
  "Ten kilometers ___ a long way to walk in this heat.", "is", ["are", "were", "have been"],
  "거리나 시간, 금액처럼 하나의 덩어리로 보는 수량 표현은 단수로 취급해요.", { hint: "수량을 하나의 덩어리로 보는지 생각해 보세요." });
S("The elderly in this town are looked after by volunteers.", "이 마을의 노인들은 자원봉사자들의 보살핌을 받아요.",
  ["The elderly in this town is looked after by volunteers.", "The elderly in this town has been looked after by volunteers.", "The elderly in this town was looked after by volunteers."],
  "The elderly in this town ___ looked after by volunteers.", "are", ["is", "was", "has been"],
  "the + 형용사(the elderly)는 '~한 사람들'이라는 뜻의 복수 취급이에요.", { hint: "the elderly가 가리키는 대상이 한 명인지 여러 명인지 생각해 보세요." });
S("The scissors on the desk are sharp, so be careful.", "책상 위의 가위는 날카로우니 조심하세요.",
  ["The scissors on the desk is sharp, so be careful.", "The scissors on the desk was sharp, so be careful.", "The scissor on the desk are sharp, so be careful."],
  "The scissors on the desk ___ sharp, so be careful.", "are", ["is", "was", "has been"],
  "scissors처럼 두 부분으로 이루어진 물건은 복수 동사를 써요. 한 개를 가리킬 때는 a pair of를 붙이고 단수로 받아요.", { hint: "이 물건 이름이 복수형으로만 쓰이는지 생각해 보세요." });
S("Everybody in the audience was moved by her speech.", "청중 모두가 그녀의 연설에 감동했어요.",
  ["Everybody in the audience were moved by her speech.", "Everybody in the audiences are moved by her speech.", "Everybody in the audience have been moved by her speech."],
  "Everybody in the audience ___ moved by her speech.", "was", ["were", "are", "have been"],
  "everybody, everyone, everything 같은 부정대명사는 단수로 취급해요.", { hint: AH });
S("Her ability to solve problems and her willingness to listen make her an excellent leader.", "문제를 해결하는 능력과 귀 기울이려는 마음이 그녀를 훌륭한 지도자로 만들어요.",
  ["Her ability to solve problems and her willingness to listen makes her an excellent leader.", "Her ability to solve problems and her willingness to listen is making her an excellent leader.", "Her ability to solve problems and her willingness to listen has made her an excellent leader."],
  "Her ability to solve problems and her willingness to listen ___ her an excellent leader.", "make", ["makes", "is making", "has made"],
  "서로 다른 두 명사가 and로 연결된 주어는 복수 동사를 써요.", { hint: "and로 연결된 주어가 몇 개의 대상인지 세어 보세요." });

// ---------- standalone m
const M = [];
const m = (q, ok, wr, why, extra = {}) => M.push({ q, ok, wr, why, extra });
const V = "빈칸에 알맞은 동사 형태는?\n";
const P = "빈칸에 알맞은 말은?\n";
m(V + "The collection of rare coins, which was donated by several families, ___ displayed on the second floor.", "is", ["are", "have been", "were"], "핵심 주어는 collection(단수)이에요. coins와 families는 수식어구 안의 명사라 동사의 수를 정하지 않아요.");
m(V + "The results of the survey ___ that most teenagers sleep less than eight hours a night.", "suggest", ["suggests", "is suggesting", "has suggested"], "주어 results가 복수이므로 복수 동사 suggest를 써요.");
m(V + "Not only the lawyer but also her assistants ___ called to testify.", "were", ["was", "is", "has been"], "not only A but also B가 주어이면 동사는 B(assistants, 복수)에 일치시켜요.");
m(V + "A box of old letters ___ discovered in the attic last week.", "was", ["were", "are", "have been"], "핵심 주어는 box(단수)이고 시제는 과거이므로 was예요.");
m(V + "The founder and director of the orchestra (두 직함을 가진 한 사람) ___ retiring this spring.", "is", ["are", "were", "have been"], "the + 명사 and 명사에서 관사가 하나뿐이면 한 사람을 가리키므로 단수 동사를 써요.");
m(V + "Everything on the shelves ___ been sorted by size.", "has", ["have", "are", "were"], "everything은 단수 취급하므로 has been이 알맞아요.");
m(V + "Ten minutes ___ not enough time to finish the whole exam.", "is", ["are", "were", "have been"], "시간의 양을 하나의 덩어리로 볼 때는 단수 취급해요.");
m(V + "The students who ___ the highest scores will receive scholarships.", "earn", ["earns", "is earning", "has earned"], "who의 선행사는 students(복수)이므로 복수 동사 earn을 써요.");
m(V + "My sister is the only one of my cousins who ___ abroad.", "lives", ["live", "are living", "have lived"], "the only one이 선행사일 때 who절의 동사는 단수 one에 일치시켜요.");
m(V + "Hardly any of the food ___ left after the party.", "was", ["were", "are", "have been"], "food는 셀 수 없는 명사이므로 단수 취급해요. 시제는 과거예요.");
m(V + "The criteria for the award ___ clearly explained on the website.", "are", ["is", "has been", "was"], "criteria는 criterion의 복수형이므로 복수 동사 are를 써요.");
m(V + "Where ___ the keys to the storage room?", "are", ["is", "was", "does"], "의문문에서도 주어(keys)가 복수이면 복수 동사를 써요.");
m(V + "Mathematics ___ one of the most useful subjects for future engineers.", "is", ["are", "were", "have been"], "학문 이름은 -s로 끝나도 단수로 취급해요.");
m(V + "Both spreading rumors and ignoring facts ___ trust between neighbors.", "damage", ["damages", "is damaging", "has damaged"], "both A and B 주어는 항상 복수 취급이므로 복수 동사를 써요.");
m(V + "The old man and his dogs ___ every morning along the beach.", "walk", ["walks", "is walking", "has walked"], "and로 연결된 두 주어이므로 복수 동사 walk를 써요.");
m(V + "Some of the advice you gave me ___ really helpful.", "was", ["were", "are", "have been"], "advice는 셀 수 없는 명사이므로 단수 취급하고, 시제는 과거예요.");

const E = "다음 문장에서 어법상 어색한 부분의 기호는?\n";
const L = ["(A)", "(B)", "(C)", "(D)"];
const lm = (sent, ans, why) => { const o = L.slice(); const ok = o[ans]; m(E + sent, ok, o.filter((_, i) => i !== ans), why, { std: ["12영Ⅰ-02-06"] }); };
lm("The new coach is known for (A)his patience, (B)his sense of humor, (C)being strict about time, and (D)his skill in training young players.", 2, "known for 뒤에 'his + 명사'가 나열되므로 (C)도 his strictness about time 같은 명사구여야 해요.");
lm("Our science club (A)collects data, (B)writes reports, and (C)presented (D)its findings every semester.", 2, "같은 주어의 동사들은 형태를 맞춰야 해요. collects, writes에 맞춰 (C)는 presents여야 해요.");
lm("Applicants must (A)be at least eighteen, (B)have a valid license, and (C)to provide (D)two references.", 2, "must 뒤에는 동사원형이 나열되어야 하므로 (C)는 provide여야 해요.");
lm("(A)The price of (B)the tickets for the three concerts (C)have risen (D)sharply this year.", 2, "핵심 주어 price가 단수이므로 (C)는 has risen이어야 해요.");
lm("(A)Neither the director (B)nor the actors (C)was (D)ready for the rehearsal.", 2, "neither A nor B에서는 가까운 B(actors, 복수)에 일치시켜 were를 써야 해요.");
lm("(A)The effects of (B)the new law, which was passed last year, (C)is still (D)being debated.", 2, "핵심 주어 effects가 복수이므로 (C)는 are여야 해요.");
lm("(A)Not only the singer (B)but also her (C)band members (D)was invited to the party.", 3, "not only A but also B에서는 B(band members, 복수)에 일치시켜 were invited가 되어야 해요.");
lm("She (A)neither wanted to (B)wait for the bus (C)nor (D)taking a taxi.", 3, "neither ... nor로 이어진 두 어구는 형태가 같아야 하므로 (D)는 to take a taxi여야 해요.");
lm("The workshop will teach you (A)how to write a résumé, (B)how to prepare for an interview, and (C)the way of negotiating a salary (D)effectively.", 2, "how to ...가 나열되었으므로 (C)도 how to negotiate a salary로 맞춰야 해요.");
lm("My goals for next year are (A)to save money, (B)to eat out less, and (C)cooking more meals (D)at home.", 2, "보어로 나열되는 to부정사 구조에 맞춰 (C)는 to cook more meals여야 해요.");
lm("The hotel is (A)clean, (B)comfortable, and (C)convenience (D)for tourists.", 2, "형용사 clean, comfortable에 맞춰 (C)도 형용사 convenient여야 해요.");
lm("(A)The young woman and her two brothers, (B)who live next door, (C)has joined (D)our book club.", 2, "and로 연결된 복수 주어이므로 (C)는 have joined여야 해요.");

const R = "다음 문장을 병렬 구조에 맞게 가장 알맞게 고친 것은?\n";
const rm = (q, ok, wr, why, extra = {}) => m(R + q, ok, wr, why, { std: ["12영Ⅰ-02-06"], ...extra });
rm("\"The tour includes visiting the palace, a lunch at a local restaurant, and to take a boat ride.\"", "The tour includes visiting the palace, having lunch at a local restaurant, and taking a boat ride.",
  ["The tour includes to visit the palace, having lunch at a local restaurant, and taking a boat ride.", "The tour includes visiting the palace, lunch at a local restaurant, and taking a boat ride.", "The tour includes visiting the palace, having lunch at a local restaurant, and to take a boat ride."], "세 항목을 모두 동명사(visiting, having, taking)로 맞춰요.");
rm("\"The new phone is faster than the old one, has a better camera, and the battery lasts longer.\"", "The new phone is faster than the old one, has a better camera, and has a longer-lasting battery.",
  ["The new phone is faster than the old one, a better camera, and the battery lasts longer.", "The new phone is faster than the old one, has a better camera, and the battery is lasting longer.", "The new phone is faster than the old one, having a better camera, and has a longer-lasting battery."], "주어 The new phone에 이어지는 서술어를 is faster, has, has로 같은 구조로 맞춰요.");
rm("\"The cost of repairing the bridges and roads are higher than expected.\"", "The cost of repairing the bridges and roads is higher than expected.",
  ["The costs of repairing the bridges and roads is higher than expected.", "The cost of repairing the bridges and roads are being higher than expected.", "The cost of repairing the bridges and roads were higher than expected."], "핵심 주어 cost가 단수이므로 is를 써요. bridges and roads는 repairing의 목적어예요.");
rm("\"She is both a talented pianist and sings beautifully.\"", "She is both a talented pianist and a beautiful singer.",
  ["She is both a talented pianist and she sings beautifully.", "She is both a talented pianist and singing beautifully.", "She is both talented pianist and a beautiful singer."], "both A and B에서 A와 B를 같은 명사구(a ... pianist, a ... singer)로 맞춰요.");
rm("\"Students can either register online, by phone, or visiting the office.\"", "Students can register online, by phone, or in person.",
  ["Students can register online, by phone, or to visit the office.", "Students can register online, by calling, or in person.", "Students can register online, by phone, or they visit the office."], "online, by phone, in person은 모두 방법을 나타내는 부사(구)로 형태가 맞아요.");
m("다음 중 주어와 동사의 수가 일치하는 문장은?", "The leader of the hikers, along with two guides, was waiting at the gate.",
  ["Each of the hikers carry a map and a flashlight.", "The members of the committee has already voted on the proposal.", "A number of the hikers is waiting at the gate for the bus."], "along with 뒤는 부가 어구라 핵심 주어 leader(단수)에 was가 일치해요. 나머지는 각각 Each(단수), members(복수), A number of(복수)에 맞지 않아요.", { std: ["12영Ⅰ-02-06"] });
m("다음 중 병렬 구조가 어색한 문장은?", "She enjoys painting, hiking, and to play chess.",
  ["He wants to travel, to study, and to work abroad.", "The soup was hot, salty, and delicious.", "We cleaned the room, washed the dishes, and took out the trash."], "enjoy 뒤의 항목은 동명사로 맞춰야 하므로 to play는 playing이어야 해요.");
m("다음 중 병렬 구조가 어색한 문장은?", "The speaker was clear, funny, and with confidence.",
  ["The film is short, serious, and surprisingly moving.", "Please open the window, turn on the fan, and close the door.", "I like swimming in summer, skating in winter, and hiking in autumn."], "형용사 clear, funny에 맞춰 with confidence도 형용사(confident)여야 해요.");
m("다음 중 주어와 동사의 일치가 틀린 문장은?", "The book of poems written by my grandfather are on the shelf.",
  ["Economics is a required subject for first-year students.", "The students in the back row were whispering during the film.", "Neither the pilot nor the passengers were injured in the incident."], "핵심 주어 book이 단수이므로 are는 is여야 해요.");
m("다음 중 주어와 동사의 일치가 틀린 문장은?", "There is two bus stops within walking distance of my school.",
  ["Every child in the program receives a free lunch.", "The cost of the repairs was higher than we expected.", "Mathematics and physics are required for this course."], "there 뒤의 진짜 주어 stops가 복수이므로 There are이어야 해요.");
m("다음 중 병렬 구조가 올바른 문장은?", "Teenagers need to sleep enough, eat well, and exercise regularly.",
  ["Teenagers need to sleep enough, eating well, and exercise regularly.", "Teenagers need to sleep enough, eat well, and exercising regularly.", "Teenagers need sleeping enough, to eat well, and exercise regularly."], "need to 뒤에 sleep, eat, exercise 동사원형이 나란히 이어져요.", { std: ["12영Ⅰ-02-06"] });
m("다음 중 비교 대상이 논리적으로 같은 종류끼리 비교된 문장은?", "The windows of the old house are smaller than those of the new house.",
  ["The windows of the old house are smaller than the new house.", "The windows of the old house are smaller than that of the new house.", "The windows of the old house are smaller than it of the new house."], "windows(복수)와 windows를 비교하므로 복수 대명사 those로 받아요.");

const C = (stem, ok, wr, why) => m(P + stem, ok, wr, why);
C("The software is easy to install, simple to use, and ___ to update.", "quick", ["quickly", "quickness", "to be quick"], "easy, simple처럼 형용사를 나열하므로 quick이 알맞아요.");
C("The mayor is expected to announce a new budget, to meet union leaders, and ___ at the opening ceremony.", "to speak", ["speaking", "speech", "spoken"], "앞의 to announce, to meet에 맞춰 to speak으로 이어요.");
C("The company is known for its quality, its low prices, and ___.", "its fast delivery", ["delivering fast", "that it delivers fast", "fast to deliver"], "its + 명사 구조를 세 번 나열해야 해요.");
C("Visitors may either walk along the coast or ___ a bicycle from the hotel.", "rent", ["renting", "to rent", "rented"], "may 뒤의 either A or B는 모두 동사원형이에요.");
C("Her speech was not long but ___.", "powerful", ["powerfully", "power", "to be powerful"], "not long(형용사)과 but으로 이어지므로 형용사 powerful이에요.");
C("I would rather stay home than ___ in the rain.", "walk", ["walking", "walked", "walks"], "would rather A than B에서 A, B 모두 동사원형이에요.");
C("The new rules require drivers to wear seat belts and ___ their phones while driving.", "avoid using", ["avoiding using", "they avoid using", "avoided using"], "require drivers to wear ... and (to) avoid ...처럼 to 뒤 동사원형이 이어져요.");
C("He explained why the experiment failed and ___.", "what the team should do next", ["what should the team do next", "the team should do what next", "what to do the team next"], "why절과 같은 의문사절 어순(의문사+주어+동사)으로 이어야 해요.");
C("Neither the film's plot nor its music ___ memorable.", "was", ["were", "are", "have been"], "neither A nor B는 가까운 B(music, 단수)에 일치시켜요.");
C("Both the book and the movie ___ popular among teenagers.", "are", ["is", "has been", "does"], "both A and B는 복수 주어이므로 복수 동사를 써요.");
C("The instructions say to turn off the machine, unplug the cable, and ___ the lid before cleaning.", "remove", ["removing", "removal", "removed"], "turn off, unplug처럼 명령형 동사원형을 나열해요.");

m("다음 문장에서 핵심 주어를 골라 동사의 수를 정할 때, 동사 are 와 일치하는 명사는?\nThe effects of the new policy on small farms are still unclear.", "effects", ["policy", "farms", "new policy"], "전치사구(of the new policy, on small farms) 안의 명사는 동사의 수를 정하지 않아요. 핵심 주어는 effects예요.");
m("Either the guide or the tourists have to carry the map. 이 문장에서 have 는 어느 명사에 일치하는가?", "tourists", ["guide", "map", "either"], "either A or B에서 동사는 가까운 B(tourists)에 일치해요.");
m("He plans to study law at a university, to travel widely in Asia, to learn two new languages, and working as a news reporter. 형태가 나머지와 다른 어구는?", "working as a news reporter", ["to study law at a university", "to travel widely in Asia", "to learn two new languages"], "plans 뒤의 항목은 to부정사로 맞춰야 하므로 working은 to work여야 해요.");
m("다음 중 짝이 올바른 상관접속사 표현은?", "either ... or", ["neither ... or", "both ... or", "not only ... and"], "neither는 nor, both는 and, not only는 but also와 짝이에요.");
m("'not only A ___ B'에서 빈칸에 들어갈 알맞은 말은?", "but also", ["and also", "but only", "or also"], "not only A but also B는 'A뿐만 아니라 B도'라는 뜻이에요.");
m("'each of + 복수명사'가 주어일 때 동사의 수는 어떻게 맞추는가?", "단수 동사를 쓴다", ["복수 동사를 쓴다", "of 뒤 명사의 수에 따라 달라진다", "주어의 시제에 따라 달라진다"], "each가 핵심 주어이므로 of 뒤가 복수여도 단수 동사를 써요.");
m("A number of 와 The number of 에 대한 설명으로 옳은 것은?", "A number of는 복수 취급하고 The number of는 단수 취급한다", ["A number of는 단수 취급하고 The number of는 복수 취급한다", "둘 다 복수 취급하며 뒤의 명사와 상관없이 복수 동사를 쓴다", "둘 다 단수 취급하며 뒤의 명사와 상관없이 단수 동사를 쓴다"], "A number of는 '많은'이라는 뜻의 복수 취급이고, The number of는 '~의 수'라는 뜻이라 number가 주어(단수)예요.");
m("사무직 업무를 설명하는 문장 중 병렬 구조가 올바른 것을 고르세요.", "The job involves answering calls, scheduling meetings, and organizing files.",
  ["The job involves answering calls, to schedule meetings, and organizing files.", "The job involves answering calls, scheduling meetings, and file organization.", "The job involves answering calls, scheduling meetings, and to organize files."], "involve 뒤의 세 항목을 모두 동명사로 맞춰요.");

// rotate correct option position
const seq = [1, 3, 0, 2, 3, 1, 2, 0];
M.forEach((x, i) => {
  const a = seq[i % seq.length]; const o = x.wr.slice(); o.splice(a, 0, x.ok);
  items.push({ k: "m", q: x.q, o, a, why: x.why, ...x.extra });
});

// ---------- reading
const Rd = [];
const seqR = [2, 0, 3, 1, 1, 3, 0, 2];
let rc = 0;
const r = (title, text, qs) => Rd.push({ title, text, qs });
const q = (qq, ok, wr, why, std) => { const a = seqR[rc++ % seqR.length]; const o = wr.slice(); o.splice(a, 0, ok); return { q: qq, o, a, why, std }; };

r("Rooftop Bees",
  "When Hana's neighbors first heard that the apartment building would keep bees on its roof, many of them objected. They imagined swarms in the stairwell, stings in the playground, and endless complaints from the landlord. The building's residents' committee, however, listened to every worry, invited an experienced beekeeper to answer questions, and agreed to a six-month trial. During that time, none of the feared problems appeared. The bees flew toward the city's parks, not toward the balconies, and the only visible change was a row of flowerpots that tenants planted to feed them. By autumn, the roof hives had produced enough honey for every household to receive a small jar. Several former critics now volunteer to help with the harvest. What changed their minds was not an argument but an experience: they saw that careful planning had turned a risky idea into a shared project.",
  [q("What is the passage mainly about?", "How a rooftop beekeeping plan won over doubtful neighbors", ["Why bees are disappearing from large modern cities", "How to harvest honey safely without protective clothing", "Why landlords should forbid unusual activities on roofs"], "처음에는 반대하던 이웃들이 신중한 계획과 시범 운영을 거쳐 생각을 바꾼 과정이 중심 내용이에요.", ["12영Ⅰ-01-02"]),
   q("What did the committee do before the project began?", "It invited an expert to answer questions and set up a trial", ["It asked every tenant to sign a contract with the landlord", "It moved the hives to a nearby park for the first winter", "It bought flowerpots for the balconies of every household"], "위원회는 양봉가를 초청해 질문에 답하게 하고 6개월 시범 운영에 합의했어요.", ["12영Ⅰ-01-01"]),
   q("In the passage, the word \"objected\" is closest in meaning to", "protested", ["hesitated", "surrendered", "volunteered"], "문맥상 이웃들이 양봉 계획에 반대했다는 뜻이므로 protested와 가장 가까워요.", ["12영Ⅰ-01-05"]),
   q("What can be inferred about the former critics?", "Their opinions improved after they saw the results themselves", ["They still fear the bees but are too polite to say so", "They received larger jars of honey than other residents", "They moved out of the building during the six-month trial"], "마지막 문장에서 논쟁이 아니라 경험이 생각을 바꾸었다고 해요. 이들은 이제 수확을 돕는 자원봉사자가 되었어요.", ["12영Ⅰ-01-05"]),
   q("Why does the writer list \"swarms in the stairwell, stings in the playground, and endless complaints\"?", "To show the range of problems the neighbors had imagined", ["To prove that those problems actually happened in the end", "To compare this building with others in the same city", "To explain how the committee solved each of the problems"], "나열된 항목들은 이웃들이 상상했던 문제들이고, 결국 어느 것도 일어나지 않았어요.", ["12영Ⅰ-01-06"])]);

r("A Later Bell",
  "Many teenagers struggle to wake up for an eight o'clock class, and scientists have an explanation. During adolescence the body clock shifts, so young people feel sleepy later at night and want to sleep later in the morning. A school in a small town tested a simple change: lessons began forty minutes later. Teachers reported that students arrived calmer, paid closer attention, and made fewer mistakes in the first period. Absences dropped, too. Not everyone was pleased, however. Bus drivers had to change their routes, and sports teams lost part of their afternoon practice time. Parents who worked early shifts worried about leaving their children alone at home. The principal admitted that the plan was not perfect but argued that the benefits for learning outweighed the costs. Other schools in the region are now watching the results closely before they decide whether to follow.",
  [q("What is the main point of the passage?", "A later start brought learning benefits as well as practical difficulties", ["Teenagers should be allowed to choose their own class schedules", "Sports teams are more important than early morning lessons", "Bus drivers are the group most harmed by changes in schools"], "늦은 등교의 학습상 이점과 현실적인 어려움을 함께 보여 주는 글이에요.", ["12영Ⅰ-01-02"]),
   q("Which problem was caused by the new schedule?", "Some sports teams had less time to practice", ["Many students began to miss more days of school", "Teachers had to shorten every lesson in the morning", "Bus companies refused to continue serving the school"], "방과 후 연습 시간이 줄어든 팀이 있었다고 해요. 결석은 오히려 줄었어요.", ["12영Ⅰ-01-01"]),
   q("Why are other schools \"watching the results closely\"?", "They are not yet sure the change is worth making", ["They have already decided to copy the new schedule", "They believe the plan has failed in the small town", "They want to hire the principal as a consultant"], "아직 따라 할지 결정하지 않았다는 말에서 변화의 가치를 확신하지 못한다고 추론할 수 있어요.", ["12영Ⅰ-01-05"]),
   q("In the passage, \"outweighed\" is closest in meaning to", "were more important than", ["were similar to", "were hidden by", "were paid for by"], "이점이 비용보다 더 중요했다는 뜻이에요.", ["12영Ⅰ-01-05"]),
   q("Which statement is NOT supported by the passage?", "Students were absent more often after the change.", ["Students made fewer mistakes in the first period.", "The body clock shifts during adolescence.", "The principal admits that the plan has weaknesses."], "결석은 줄었다고 했으므로 '더 자주 결석했다'는 진술은 지문과 맞지 않아요.", ["12영Ⅰ-01-01"])]);

r("A Request for the Courtyard",
  "Dear Mr. Okafor,\nI am writing on behalf of the Green Hands Club to request permission to use the school courtyard for a spring cleanup. Our members plan to remove litter, plant native flowers, and repair the wooden benches that rain has damaged. We expect about thirty students to take part on Saturday, April 12, from nine o'clock until noon. Because the work involves tools and soil, we would like at least one teacher to supervise. The club will buy all materials with money from last year's bake sale, so the school will not need to pay anything. If you approve, we also hope to display a short report about the project in the main hallway. Thank you for considering our request, and I look forward to hearing from you.\nSincerely,\nMinseo Park, Club President",
  [q("Why did Minseo write this letter?", "To ask for permission to hold a cleanup event", ["To report that a bench had been damaged by rain", "To invite Mr. Okafor to join the club as a member", "To thank the school for paying for the materials"], "글쓴이는 교정 안뜰을 봄맞이 청소에 사용해도 되는지 허락을 구하고 있어요.", ["12영Ⅰ-01-02"]),
   q("Who will pay for the materials?", "The club, with money from a bake sale", ["The school, using its yearly budget", "Mr. Okafor, out of his own pocket", "The students, with a fee on the day"], "동아리가 지난해 베이크 세일에서 번 돈으로 재료를 산다고 해요.", ["12영Ⅰ-01-01"]),
   q("Why does the club want a teacher to be present?", "The work includes tools and soil that need supervision", ["The students are not allowed to enter the courtyard alone", "Mr. Okafor has asked to inspect every project", "The report for the hallway must be signed by a teacher"], "도구와 흙을 다루는 작업이라 감독할 교사가 필요하다고 설명해요.", ["12영Ⅰ-01-04"]),
   q("Which activity is NOT in the club's plan?", "Painting the walls of the main hallway", ["Removing litter from the courtyard", "Planting native flowers", "Repairing the wooden benches"], "복도에 보고서를 전시할 계획은 있지만 벽을 칠한다는 말은 없어요.", ["12영Ⅰ-01-01"]),
   q("Which phrase best describes the tone of the letter?", "Polite and well organized", ["Angry and demanding", "Humorous and casual", "Nervous and uncertain"], "정중한 인사와 구체적인 계획으로 쓰인 격식 있는 편지예요.", ["12영Ⅰ-01-03"])]);

r("Life in the Tide Pool",
  "A tide pool looks calm, yet life there is anything but easy. Twice a day, the sea retreats and leaves small basins of water on the rocks. Animals living in these pools must survive hot sunshine, sudden rain, and waves that crash against them without warning. Sea stars hold on with hundreds of tiny tube feet, limpets clamp themselves tightly to the stone, and crabs hide in cracks until the water returns. Even the water itself changes quickly: as it warms under the sun, it loses oxygen and grows saltier, a combination that would kill many ocean animals within hours. The creatures of the tide pool have adapted to this, which makes them valuable to scientists. By studying how they cope with sudden change, researchers hope to predict how other sea life might respond as oceans grow warmer.",
  [q("What is the passage mainly about?", "How tide-pool animals survive rapid changes in their surroundings", ["Why the sea leaves the rocks twice every day", "Which sea animals are most dangerous to people", "How scientists build artificial pools in laboratories"], "조수 웅덩이 생물들이 급격한 환경 변화를 견디는 방식과 그 연구 가치를 다뤄요.", ["12영Ⅰ-01-02"]),
   q("How do sea stars stay in place?", "They hold on with many tiny tube feet", ["They clamp their shells tightly to the stone", "They hide in cracks until the water returns", "They float near the surface of the pool"], "불가사리는 수백 개의 작은 관족으로 달라붙어요. 삿갓조개와 게의 방식과 구분해야 해요.", ["12영Ⅰ-01-01"]),
   q("What happens to the water as it warms under the sun?", "It holds less oxygen and becomes saltier", ["It becomes colder and holds more oxygen", "It rises quickly and floods nearby rocks", "It turns clear and attracts new animals"], "따뜻해지면 산소를 잃고 더 짜진다고 해요.", ["12영Ⅰ-01-01"]),
   q("In the passage, \"cope with\" is closest in meaning to", "deal successfully with", ["feel sorry about", "stay far away from", "make a record of"], "급격한 변화에 잘 대처한다는 뜻이에요.", ["12영Ⅰ-01-05"]),
   q("Why are tide-pool creatures valuable to scientists?", "They may show how other sea life will react to warmer oceans", ["They are easier to catch than animals in deep water", "They produce oxygen that cools the ocean", "They have never been affected by changes in the sea"], "급변에 적응한 이들을 연구하면 바다가 따뜻해질 때 다른 생물의 반응을 예측할 수 있다고 해요.", ["12영Ⅰ-01-04"])]);

r("The Price of Working at Home",
  "Working from home has changed how people think about the office. Employees save hours of commuting, spend more time with family, and can often arrange their day to match their energy. Employers, meanwhile, save on rent and can hire people from distant cities. Yet the arrangement has costs that are easy to overlook. New workers miss the casual conversations through which experienced colleagues pass on unwritten rules. Creative teams find that brainstorming through a screen is slower and less spontaneous. Some employees also discover that, without a clear boundary between work and rest, they answer messages late at night and feel unable to relax. Companies that handle remote work well tend to set clear hours, schedule occasional meetings in person, and train managers to measure results rather than hours at a desk. In other words, success depends less on where people work than on how the work is organized.",
  [q("Which statement best expresses the writer's main point?", "The success of remote work depends on how it is organized", ["Offices will soon disappear from every large company", "Employees are always happier when they work at home", "Managers should check their staff more often during the day"], "마지막 문장이 요지를 직접 말해요. 어디서 일하느냐보다 일을 어떻게 조직하느냐가 성패를 좌우해요.", ["12영Ⅰ-01-02"]),
   q("In the passage, \"the arrangement\" refers to", "working from home", ["saving money on office rent", "hiring people from other cities", "meeting colleagues in person"], "앞 문장들에서 다룬 재택근무 방식을 가리켜요.", ["12영Ⅰ-01-04"]),
   q("Why are new workers disadvantaged by remote work?", "They miss informal chats where unwritten rules are shared", ["They are not allowed to join any official meetings", "They must work longer hours than experienced colleagues", "They receive less pay while they are learning the job"], "경험 많은 동료가 불문율을 전해 주는 가벼운 대화를 놓친다고 해요.", ["12영Ⅰ-01-01"]),
   q("What can be inferred about employees who answer messages late at night?", "They find it hard to separate work from rest", ["They enjoy working more than they enjoy resting", "They have been told to reply to messages immediately", "They work for companies that set clear working hours"], "일과 휴식의 경계가 불분명하면 밤늦게 답장하고 쉬지 못한다는 내용에서 추론할 수 있어요.", ["12영Ⅰ-01-05"]),
   q("Which method do successful companies use, according to the passage?", "Judging employees by results instead of hours at a desk", ["Asking employees to keep their cameras on all day", "Replacing in-person meetings with weekly written reports", "Giving every worker the freedom to set no hours at all"], "성공적인 회사는 관리자가 책상에 앉은 시간보다 성과를 측정하도록 교육한다고 해요.", ["12영Ⅰ-01-01"])]);

r("The Thief in the East Gallery",
  "The night guard at the small town museum, Mr. Lee, had one rule: never touch anything after closing time. On the evening of the winter festival, however, a loud crash echoed from the east gallery. His heart pounding, he grabbed his flashlight and hurried down the corridor. The beam swept across the polished floor, the glass cases, and finally a broken vase lying beneath an open window. Beside it sat a gray cat, licking its paw as if nothing had happened. Mr. Lee let out a long breath and began to laugh. He wrapped the pieces carefully in a cloth, closed the window, and carried the surprised cat to the staff room. In the morning, the director found a note on her desk: \"The vase was already cracked, the window was open, and the thief is asleep in your armchair.\" She read it twice and smiled.",
  [q("How did Mr. Lee feel when he first heard the crash?", "Alarmed", ["Amused", "Bored", "Embarrassed"], "심장이 뛰는 채로 손전등을 들고 달려갔다는 데서 놀라고 긴장했음을 알 수 있어요.", ["12영Ⅰ-01-03"]),
   q("What did Mr. Lee do after finding the broken vase?", "He gathered the pieces, shut the window, and took the cat away", ["He called the director and waited for her at the gate", "He chased the cat out through the open window", "He searched the other galleries for a human thief"], "그는 조각을 천에 싸고 창문을 닫은 뒤 고양이를 직원실로 데려갔어요.", ["12영Ⅰ-01-01"]),
   q("What can be inferred about how the vase broke?", "The cat most likely knocked it over after entering through the window", ["Mr. Lee dropped it while hurrying down the corridor", "A visitor hid it before the museum closed", "It fell because the winter festival shook the building"], "열린 창문, 깨진 꽃병 옆의 고양이, 쪽지의 '도둑' 표현에서 고양이가 원인임을 추론할 수 있어요.", ["12영Ⅰ-01-05"]),
   q("What is the tone of the note on the director's desk?", "Playful", ["Furious", "Sorrowful", "Formal"], "고양이를 '도둑'이라 부르는 장난스러운 표현이고, 이사는 읽고 미소 지었어요.", ["12영Ⅰ-01-03"]),
   q("In the passage, \"echoed\" is closest in meaning to", "sounded again and again", ["faded away slowly", "was explained clearly", "was heard only once"], "큰 소리가 갤러리에 울려 퍼졌다는 뜻이에요.", ["12영Ⅰ-01-05"])]);

r("Singing to Remember",
  "Many learners swear that they remember English words better when the words come with a melody. There may be good reasons. Songs repeat phrases, group them into rhythmic patterns, and connect them to emotions, all of which help memory. A teacher in a language school asked her students to learn ten common expressions in two ways: half of the class read them from a list, while the other half sang them to a simple tune. A week later, the singers recalled more of the expressions and used them more naturally in conversation. However, the teacher cautioned against drawing large conclusions from one small class. Differences in motivation, age, and prior knowledge could also have affected the results. She plans to repeat the experiment with larger groups. Meanwhile, she recommends that students try music as one tool among many, not as a replacement for regular practice.",
  [q("What is the passage mainly about?", "A small experiment on learning expressions through singing", ["The best songs for beginners to study in English class", "Why reading from a list is the worst way to study", "How teachers should choose students for a class choir"], "노래로 표현을 외우는 효과를 작은 학급 실험으로 살펴보는 글이에요.", ["12영Ⅰ-01-02"]),
   q("How was the class divided in the experiment?", "Half read the expressions and half sang them", ["Half studied at home and half studied in class", "Half learned ten expressions and half learned twenty", "Half were beginners and half were advanced learners"], "절반은 목록을 읽고 나머지 절반은 간단한 곡조에 맞춰 노래했어요.", ["12영Ⅰ-01-01"]),
   q("Why does the teacher warn against large conclusions?", "Other factors may have influenced the results of one small class", ["The singers forgot most expressions after a week", "The experiment was not allowed by the school", "The list readers actually did better in conversation"], "동기, 나이, 사전 지식의 차이가 결과에 영향을 줬을 수 있다고 말해요.", ["12영Ⅰ-01-04"]),
   q("In the passage, \"them\" in \"connect them to emotions\" refers to", "phrases", ["learners", "memories", "melodies"], "노래는 구절을 반복하고 리듬으로 묶으며 감정과 연결한다는 흐름이에요.", ["12영Ⅰ-01-04"]),
   q("What is the teacher's attitude toward music in language study?", "Positive but careful", ["Strongly opposed", "Completely certain", "Quite indifferent"], "음악을 여러 도구 중 하나로 권하지만 정규 연습의 대체는 아니라고 신중하게 말해요.", ["12영Ⅰ-01-03"])]);

r("Tiny Pieces, Big Problem",
  "Scientists use the word \"microplastics\" for plastic fragments smaller than five millimeters. Some are made that small on purpose, such as the beads once added to certain face scrubs. Others form slowly as larger items, including bottles, bags, and fishing nets, break down in sunlight and waves. Washing synthetic clothing also releases tiny fibers that pass through household drains. Because the pieces are so small, they are hard to remove from water, and they can be swallowed by animals at every level of the food chain, from plankton to fish. Researchers are still investigating whether the particles harm human health, and results so far are mixed. Even so, many countries have limited the sale of products containing plastic beads, and some manufacturers now sell washing machine filters that trap fibers. These steps will not solve the problem alone, but they show that practical solutions exist.",
  [q("Which of the following is a source of microplastics mentioned in the passage?", "Synthetic clothing that is washed at home", ["Natural cotton thread used for sewing", "Glass bottles that break on the beach", "Paper bags that dissolve in the rain"], "합성 섬유 옷을 세탁하면 미세한 섬유가 나온다고 해요.", ["12영Ⅰ-01-01"]),
   q("Why are microplastics hard to remove from water?", "The pieces are extremely small", ["They sink to the bottom of the sea", "They dissolve completely in salt water", "They are hidden inside fishing nets"], "Because로 시작하는 문장에서 입자가 너무 작아서 제거하기 어렵다고 해요.", ["12영Ⅰ-01-04"]),
   q("What does the writer imply by saying results about human health are \"mixed\"?", "Scientists have not reached a clear conclusion yet", ["Most studies have proved that the particles are harmless", "Researchers refuse to study the question any further", "Different countries have banned different products"], "연구 결과가 엇갈린다는 말은 아직 명확한 결론이 없다는 뜻이에요.", ["12영Ⅰ-01-05"]),
   q("In the passage, \"trap\" is closest in meaning to", "catch and hold", ["throw away", "break apart", "pass through"], "필터가 섬유를 걸러 잡아 둔다는 뜻이에요.", ["12영Ⅰ-01-05"]),
   q("What is the purpose of the last sentence?", "To show that the problem can be reduced in practical ways", ["To argue that the measures are a complete solution", "To warn that no solution will ever be found", "To explain why researchers disagree about the problem"], "이 조치들만으로 해결되지는 않지만 현실적인 해법이 있음을 보여 주는 결론이에요.", ["12영Ⅰ-01-06"])]);

r("After Dark at the Night Market",
  "A night market is more than a place to buy dinner. As the sun sets, vendors string up lights, light their grills, and arrange their goods on narrow tables. Soon the air fills with the smell of grilled skewers, the sizzle of oil, and the calls of sellers who know their regular customers by name. Families wander slowly from stall to stall, couples share sweet pancakes, and groups of students compare the prices of phone cases. Most visitors leave with a full stomach, but what many remember is the atmosphere: the crowd, the music from a street performer, and the feeling of belonging to a place that never seems to rush. For the vendors, the market is both a livelihood and a community, and many say they would not trade it for a quiet shop with fixed hours.",
  [q("What is the main idea of the passage?", "A night market offers a lively social experience beyond shopping", ["Vendors earn more money at night than during the day", "Street food is cheaper than the food in restaurants", "Markets should close early to protect the neighborhood"], "단순한 저녁 식사 장소를 넘어서 분위기와 공동체를 제공하는 곳이라는 내용이에요.", ["12영Ⅰ-01-02"]),
   q("What do visitors remember most, according to the passage?", "The atmosphere of the place", ["The prices of phone cases", "The names of the sellers", "The taste of the pancakes"], "많은 사람들이 기억하는 것은 분위기라고 해요.", ["12영Ⅰ-01-01"]),
   q("What does the writer suggest about the vendors?", "They value the community more than a quiet, fixed schedule", ["They are tired of selling to the same customers", "They dislike the noise of street performers", "They plan to open shops with fixed hours soon"], "상인들에게 시장은 생계이자 공동체이며 고정된 시간의 조용한 가게와 바꾸지 않겠다고 해요.", ["12영Ⅰ-01-05"]),
   q("In the passage, \"livelihood\" is closest in meaning to", "means of earning a living", ["place to rest at night", "habit of making friends", "way of travelling abroad"], "시장이 상인들에게 생계 수단이라는 뜻이에요.", ["12영Ⅰ-01-05"]),
   q("Which sentence from the passage is a general statement rather than a description of what happens in the evening?", "\"A night market is more than a place to buy dinner.\"", ["\"Vendors string up lights, light their grills, and arrange their goods.\"", "\"Families wander slowly from stall to stall.\"", "\"Couples share sweet pancakes.\""], "첫 문장만 일반적인 주장이고 나머지는 저녁에 벌어지는 장면을 묘사해요.", ["12영Ⅰ-01-06"])]);

r("The Helpful Mistake Machine",
  "Most people have sent a message that autocorrect has turned into nonsense, but the feature does far more good than harm. Behind the scenes, the software compares what you type with a large list of words, estimates which word you probably meant, and replaces the error before you press send. Modern versions also learn from your habits: they remember the names of your friends, the slang you use, and the phrases you often repeat. The system is not perfect, because it cannot read your mind and it sometimes mistakes a rare word for a mistake. Experts therefore advise users to read quickly before sending any important message. They add that the tool should support careful writing, not replace it. Ironically, people who rely on it completely may notice their own spelling skills slowly weaken.",
  [q("What is the writer's main message?", "Autocorrect is useful, but users should still write carefully", ["Autocorrect should be removed from every phone", "Software can already read what users are thinking", "Spelling skills no longer matter in modern life"], "자동 고침이 유용하지만 신중한 글쓰기를 대체해서는 안 된다는 내용이에요.", ["12영Ⅰ-01-02"]),
   q("According to the passage, how does autocorrect work?", "It compares typed words with a list and guesses the intended word", ["It asks the user to check each word before sending", "It copies the words that friends have typed before", "It sends the message to experts for approval"], "입력한 단어를 단어 목록과 비교해 의도한 단어를 추정하고 오류를 바꿔요.", ["12영Ⅰ-01-01"]),
   q("In the passage, \"it\" in \"people who rely on it completely\" refers to", "autocorrect", ["the message", "the habit", "the list"], "자동 고침 기능에 완전히 의존하는 사람들을 말해요.", ["12영Ⅰ-01-04"]),
   q("What is the function of the word \"Ironically\" in the last sentence?", "It introduces a result that is the opposite of what one would expect", ["It shows that the writer is joking about every expert", "It signals that a new topic is about to begin", "It repeats the advice given in the previous sentence"], "도움을 주는 도구에 의존하면 오히려 철자 실력이 약해질 수 있다는 반대되는 결과를 소개해요.", ["12영Ⅰ-01-06"]),
   q("Why does autocorrect sometimes make mistakes?", "It cannot know exactly what the user means", ["It has no list of words to compare with", "It forgets the names of the user's friends", "It only works for messages that are short"], "사용자의 마음을 읽을 수 없고 드문 단어를 실수로 착각하기도 해서예요.", ["12영Ⅰ-01-04"])]);

r("The Garden at the End of Our Street",
  "When my family moved to the city, I missed the open fields behind our old house. The concrete, the traffic, and the crowds felt endless. Then my grandmother discovered a community garden at the end of our street. Each family there rents a small plot, and everybody shares the tools, the compost, and the knowledge. At first I only carried water cans, but soon Mr. Alvarez, the oldest gardener, taught me how to sow carrots, tie tomato plants to stakes, and tell weeds from seedlings. Over the summer I noticed that the garden gave me more than vegetables. It gave me neighbors who greeted me by name, a reason to leave my phone at home, and a quiet corner where I could think. This autumn, when we harvested our first pumpkin, my grandmother cried a little, and I understood that we had finally started to belong.",
  [q("What is the passage mainly about?", "How a community garden helped the writer feel at home in a new city", ["Why growing vegetables is easier in the city than in the country", "How the writer's grandmother became a famous gardener", "Why the writer wants to move back to the old house"], "새 도시에 적응하지 못하던 글쓴이가 공동체 텃밭을 통해 소속감을 찾게 된 이야기예요.", ["12영Ⅰ-01-02"]),
   q("What did Mr. Alvarez teach the writer?", "How to sow carrots and care for tomato plants", ["How to rent a plot from the city office", "How to cook a pumpkin for the family dinner", "How to build tools for the garden"], "당근 심기, 토마토를 지지대에 묶기, 잡초와 모종 구별하기를 가르쳐 주었어요.", ["12영Ⅰ-01-01"]),
   q("In the passage, \"plot\" is closest in meaning to", "a small piece of land", ["the main events of a story", "a secret plan to cause harm", "a long list of tasks"], "가족마다 빌리는 작은 땅 한 구획을 뜻해요.", ["12영Ⅰ-01-05"]),
   q("Why did the grandmother cry a little at the harvest?", "The pumpkin showed that the family had begun to belong there", ["She was disappointed with the size of the pumpkin", "She missed the fields behind the old house", "She was sad that the summer was over"], "첫 호박을 수확하며 가족이 이곳에 뿌리내리기 시작했음을 느꼈다는 흐름이에요.", ["12영Ⅰ-01-03"]),
   q("What does the writer imply by mentioning \"a reason to leave my phone at home\"?", "The garden offered a more satisfying activity than the phone", ["The writer was forbidden to use a phone in the city", "The phone was broken when the family moved", "The grandmother disliked all modern technology"], "텃밭이 휴대전화를 두고 나올 만한 이유가 되었다는 뜻이에요.", ["12영Ⅰ-01-05"])]);

Rd.forEach((p) => items.push({ k: "r", title: p.title, text: p.text, qs: p.qs }));

// ---------- vocabulary
items.push({ k: "w", en: "consistent", pos: "adj", ko: "일관된", ex: "A good writer keeps a consistent style from the first page to the last.", exko: "좋은 작가는 첫 쪽부터 마지막 쪽까지 일관된 문체를 유지해요.", z: ["tasty", "bitter", "empty"], syn: ["steady", "uniform"], sp: ["consistant", "concistent", "consitent"] });
items.push({ k: "w", en: "revise", pos: "v", ko: "수정하다", ex: "Please revise your essay before you hand it in.", exko: "제출하기 전에 에세이를 수정해 주세요.", z: ["bury", "boil", "cheer"], syn: ["edit", "amend", "correct"], sp: ["reveise", "revize", "rivise"] });
items.push({ k: "w", en: "clarify", pos: "v", ko: "명확히 하다", ex: "The teacher drew a diagram to clarify the difficult rule.", exko: "선생님은 어려운 규칙을 명확히 하려고 도표를 그렸어요.", z: ["whisper", "harvest", "bounce"], syn: ["explain", "illustrate"], sp: ["clarrify", "clairfy", "clarefy"] });
items.push({ k: "w", en: "convey", pos: "v", ko: "전달하다", ex: "A single photograph can convey more than a long paragraph.", exko: "사진 한 장이 긴 문단보다 더 많은 것을 전달할 수 있어요.", z: ["freeze", "scatter", "tremble"], syn: ["communicate", "express"], sp: ["conveigh", "convy", "convei"] });

const out = { packet: "H11-h3-par", sections: [{ skill: "e.h3.par", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H11-h3-par.json", JSON.stringify(out, null, 1) + "\n");
const c = {}; for (const i of items) c[i.k] = (c[i.k] ?? 0) + 1; console.log(c);
