import fs from "node:fs";
import p1 from "./p1.mjs"; import p2 from "./p2.mjs"; import { extraR, dialogues } from "./p3.mjs"; import { ms } from "./p4.mjs";
let n = 0, f = 0; const out = [];
const chk = (qq, tag) => { const L = qq.o.map(x => x.length); const a = L[qq.a]; n++; if (a === Math.max(...L) && L.filter(x => x === a).length === 1) { f++; out.push(`${tag} | ${qq.q.slice(0, 50).replace(/\n/g," ")} | ${L.join(",")} a=${qq.a}`); } };
for (const p of [...p1, ...p2, ...extraR, ...dialogues]) p.qs.forEach((q, i) => chk(q, p.title + "#" + i));
for (const m of ms) chk(m, "M");
console.log(f, n); console.log(out.join("\n"));
