let c = 0;
const SEQ = [1, 3, 0, 2, 2, 0, 3, 1, 0, 2, 1, 3, 3, 1, 2, 0];
export const Q = (q, key, ds, why, std) => {
  const a = SEQ[c++ % SEQ.length];
  const o = [...ds]; o.splice(a, 0, key);
  return { q, o, a, why, ...(std ? { std: [std] } : {}) };
};
export const R = (title, text, qs, d) => ({ k: "r", title, text, qs, ...(d ? { d } : {}) });
export const D = (title, text, qs) => ({ k: "d", title, text, qs });
export const M = (q, key, ds, why, cat, std) => { const x = Q(q, key, ds, why, std); return { k: "m", q: x.q, o: x.o, a: x.a, why, cat, ...(x.std ? { std: x.std } : {}) }; };
export const S = (good, ko, bad, st, ok, wr, rule, extra = {}) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...extra });
export const DET = "12영Ⅱ-01-01", MAIN = "12영Ⅱ-01-02", MOOD = "12영Ⅱ-01-03", LOG = "12영Ⅱ-01-04", IMP = "12영Ⅱ-01-05", STR = "12영Ⅱ-01-06";
