import fs from "node:fs";
import p1 from "./p1.mjs"; import p2 from "./p2.mjs"; import { extraR, dialogues } from "./p3.mjs"; import { ms, ss } from "./p4.mjs";
const items = [...p1, ...p2, ...extraR, ...dialogues, ...ms, ...ss];
const patches = fs.readFileSync("patches.txt","utf8").trim().split("\n").filter((_,i)=>i%5>=2).map(l=>l.split("|"));
const mi = new Map(ms.map((m,i)=>["M"+i,m]));
const tag = new Map(); for (const p of [...p1,...p2,...extraR,...dialogues]) p.qs.forEach((q,i)=>tag.set(p.title+"#"+i,q));
for (const [t,di,txt] of patches) { const q = tag.get(t) ?? mi.get(t); if(!q) throw new Error("no "+t); let n=-1; for (let j=0;j<4;j++){ if(j===q.a) continue; n++; if(n===+di){ q.o[j]=txt; break; } } }
const cnt = {}; for (const i of items) cnt[i.k] = (cnt[i.k] ?? 0) + 1; console.log(cnt);
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H10-h2-logic.json", JSON.stringify({ packet: "H10-h2-logic", sections: [{ skill: "e.h2.logic", items }] }, null, 1) + "\n");
