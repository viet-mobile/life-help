const q = (q, o, a, why) => ({ q, o, a, why });
export const D = [
{ k: "d", title: "Book Club: A Poem About a Bridge", std: ["12영문01-05", "12영문01-03", "12영문01-06"], text:
`Nora: Did everyone read the poem about the old stone bridge?
Ben: I did, but I am not sure I understood it. It seems to be about a bridge, yet the speaker never crosses it.
Nora: That is exactly the point, I think. The bridge is more than stone. It is a symbol of a connection the speaker is afraid to make.
Ben: Hmm. I read it as a simple description of a quiet evening.
Mei: There are too many hints for that. The bridge is "worn by a thousand footsteps", but the speaker's shoes stay dry on the bank.
Ben: Fair enough. And the last line, "the river keeps what it cannot carry", is strange.
Mei: To me it means that some feelings are too heavy to cross over, so they stay behind.
Nora: I would add that the river is also a barrier. Water divides, while the bridge joins.
Ben: So the poem is about the wish to reach another person, and the fear of doing it.
Nora: Yes. Next time, shall we choose something more cheerful?
Mei: Only if you promise not to explain it all before I finish my tea.`,
  qs: [
    q("What is the group mainly doing in this conversation?", ["Interpreting the meaning of a poem together", "Planning a trip across a bridge", "Arguing about a river's name", "Writing a poem as a team"], 0, "They exchange readings of the poem's symbols and decide what it means."),
    q("According to Nora, the bridge in the poem is", ["a symbol of a connection the speaker fears to make", "a plain description of a place the speaker visits", "a warning of a flood", "a memory of the speaker's childhood"], 0, "Nora says the bridge stands for a connection that the speaker is afraid to make."),
    q("Which detail does Mei use to support her view?", ["The speaker's shoes remain dry on the bank.", "The poem has a regular rhyme scheme.", "The speaker names the bridge's builder.", "The poem was written long ago."], 0, "She points to the contrast between the worn bridge and the dry shoes, which show the speaker never crosses."),
    q("What does Ben finally conclude?", ["The poem is about wanting to reach someone and fearing to do so.", "The poem is only about stone and water.", "The poem is too cheerful to analyse.", "The poem should be removed from the list."], 0, "Ben restates the group's reading in his last long turn."),
    q("What is the tone of Mei's last remark?", ["Gently teasing", "Deeply angry", "Quite fearful", "Formal and serious"], 0, "She jokes about Nora explaining everything, which is a friendly tease."),
  ] },
{ k: "d", title: "Teacher and Student: The Ending of a Story", std: ["12영문01-02", "12영문01-04", "12영문01-03"], text:
`Teacher: You told me you were unhappy with the ending of \"The Red Door\". Why?
Jisoo: Because nothing is solved. The girl stands in front of the door and the story just stops.
Teacher: Do you think the author forgot to finish?
Jisoo: No, but it felt unfair. We followed her for twenty pages.
Teacher: Let us look at the last sentence together. She "put her hand on the handle and felt it turn". What is the author showing us?
Jisoo: That the door is not locked. It could open.
Teacher: And what has the story been about up to this point?
Jisoo: Her fear of leaving home.
Teacher: So the real question was never what is behind the door.
Jisoo: It was whether she would try the handle. Oh. So the story is complete after all.
Teacher: An open ending asks the reader to do some of the work. Whether you like it is a separate matter.`,
  qs: [
    q("Why was Jisoo unhappy with the ending at first?", ["She felt nothing was resolved.", "She thought the story was too long.", "She did not understand the vocabulary.", "She disliked the main character's name."], 0, "She says nothing is solved and the story stops."),
    q("What does the detail of the handle turning show?", ["The girl has taken the step that matters.", "The door is broken.", "Someone is on the other side.", "The story will continue next week."], 0, "The turn of the handle shows she takes action, which answers the real question of whether she dares to leave."),
    q("What does the teacher mean by an \"open ending\"?", ["One that leaves part of the meaning for the reader to decide", "One that has exactly twenty pages", "One that explains every detail", "One that is written for children"], 0, "The teacher says the ending asks the reader to do some of the work."),
    q("How does Jisoo's opinion change?", ["She sees that the ending suits the story's central concern.", "She decides the author made a mistake.", "She wants to write a new ending.", "She asks to read a different book."], 0, "She realises the story was about trying the handle, so the ending is complete."),
    q("The teacher's last sentence suggests that", ["understanding an ending and liking it are different things", "readers must always enjoy open endings", "teachers choose the endings of books", "stories should never end clearly"], 0, "The teacher separates comprehension from personal taste."),
  ] },
{ k: "d", title: "Comparing a Film and the Book", std: ["12영문01-06", "12영문01-03", "12영문01-02"], text:
`Hyun: Have you seen the film of \"The Glass Orchard\"?
Dana: Last weekend. I read the novel first, so I was disappointed.
Hyun: Really? I liked the film more. The orchard looks beautiful on screen.
Dana: It does, but the book spends a hundred pages on the narrator's thoughts, and the film has almost none of them.
Hyun: Maybe that is not possible in a film. A camera shows faces, not thoughts.
Dana: True, but they changed the ending. In the novel, the sisters never speak again.
Hyun: Yes, and in the film they hug. It felt too neat to me as well.
Dana: So you agree with me!
Hyun: In part. I think the director wanted a hopeful message for a wide audience.
Dana: That may be, but the sad ending was what made the book honest.
Hyun: Perhaps we should say the two works are not trying to do the same thing.`,
  qs: [
    q("What is the main topic of the conversation?", ["Differences between a novel and its film version", "The best way to grow an orchard", "A plan to visit the cinema", "The history of glass making"], 0, "They compare how the book and the film treat the narrator's thoughts and the ending."),
    q("Why does Dana prefer the book?", ["It gives access to the narrator's thoughts and has a more honest ending.", "It is shorter than the film.", "It has more beautiful pictures.", "It was written by her friend."], 0, "She mentions the hundred pages of thoughts and says the sad ending made the book honest."),
    q("According to Hyun, why might the film ending be different?", ["The director wanted to give a hopeful message to many viewers.", "The actors refused to say certain lines.", "The studio ran out of money.", "The book was out of print."], 0, "Hyun suggests the director aimed at a wide audience with a hopeful message."),
    q("What does Hyun mean by \"A camera shows faces, not thoughts\"?", ["Film cannot easily present inner thinking as a book can.", "Cameras are not good at filming faces.", "Actors should not show emotion.", "Books have better covers than films."], 0, "He points out a limit of the medium: a camera records what is outside, not inner thoughts."),
    q("Which statement best summarises their final position?", ["The book and the film may have different aims.", "The film is wrong and the book is right.", "Neither work deserves attention.", "Both works have the same ending."], 0, "Hyun's last line proposes that the two works aim to do different things, a balanced view."),
  ] },
{ k: "d", title: "An Interview With a Young Poet", std: ["12영문01-05", "12영문01-02", "12영문01-08"], text:
`Host: Today my guest is Leila Moreno, whose first collection of poems appeared this spring. Leila, welcome.
Leila: Thank you. It is strange to hear it described as a "collection". Most of the poems began on bus tickets.
Host: On bus tickets?
Leila: I commute for two hours a day. If a line comes to me, I write it on whatever I have. Later I find it in my coat pocket, and it is a stranger's handwriting, even though it is mine.
Host: Many of your poems are very short. Is that deliberate?
Leila: Yes. I think a short poem is like a small window. You cannot put the whole house in it, so you must choose carefully what the reader sees.
Host: What do you hope readers take away?
Leila: Not a lesson. I would be happy if someone read one poem and then looked out of a bus window differently.
Host: A lovely goal. Thank you for your time.`,
  qs: [
    q("Where did most of Leila's poems begin?", ["On bus tickets while she was commuting", "In a classroom at university", "During a stay in a mountain cabin", "At the radio station"], 0, "She says most of the poems began on bus tickets during her daily commute."),
    q("What does Leila mean when she compares a short poem to a small window?", ["The poet must choose carefully what to show.", "Short poems are easier to write.", "Poems should be written near windows.", "A poem needs a frame made of glass."], 0, "A small window shows only part of the house, so the poet selects what the reader will see."),
    q("What is Leila's hope for her readers?", ["That a poem might change the way they notice ordinary things", "That they will memorise every line", "That they will learn a clear moral", "That they will buy several copies"], 0, "She wants a reader to look out of a bus window differently after reading, rather than receive a lesson."),
    q("Why does she describe her own handwriting as \"a stranger's\"?", ["She has forgotten the moment of writing by the time she finds it.", "She writes with her left hand.", "Someone else copies her notes.", "She cannot read English."], 0, "Because the line is found later in a pocket, it seems to come from someone else, showing the distance between the moment of writing and the finding."),
  ] },
];

export const M = [
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "Read the line: \"The classroom was a zoo by noon.\" Which figure of speech is used?", o: ["Metaphor", "Simile", "Alliteration", "Onomatopoeia"], a: 0, why: "The classroom is directly said to be a zoo, without \"like\" or \"as\", so it is a metaphor." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "Which sentence contains a simile?", o: ["Her voice was as smooth as warm honey.", "Time is a thief.", "The wind whispered through the trees.", "Peter Piper picked a peck of peppers."], a: 0, why: "A simile compares two things using \"as\" or \"like\"; the first sentence uses \"as smooth as\"." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "In the line \"The old house sighed and settled into the night\", the house is given a human action. This device is called", o: ["personification", "hyperbole", "irony", "allusion"], a: 0, why: "Giving human qualities, such as sighing, to a non-human object is personification." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "\"I have told you a million times to close the window!\" The phrase \"a million times\" is an example of", o: ["hyperbole", "understatement", "rhyme", "flashback"], a: 0, why: "It is a deliberate exaggeration to stress feeling, which is hyperbole." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "Which line is an example of alliteration?", o: ["Silver streams of sunlight slipped through the shutters.", "The door creaked and then slammed.", "He ran as fast as a hare.", "All the world's a gentle dream."], a: 0, why: "The repeated /s/ sound at the beginning of several words (silver, streams, sunlight, slipped, shutters) is alliteration." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "The words \"buzz\", \"crash\" and \"hiss\" imitate sounds. This device is called", o: ["onomatopoeia", "irony", "foreshadowing", "metaphor"], a: 0, why: "Words that imitate the sounds they describe are onomatopoeia." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "A fire station is destroyed by fire on the day of its opening. What kind of irony is this?", o: ["Situational irony", "Verbal irony", "Dramatic irony", "Sound irony"], a: 0, why: "The outcome is the opposite of what we expect; this is situational irony." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "Watching a storm, someone says \"What lovely weather!\" while the rain pours into her shoes. The speaker is using", o: ["verbal irony", "personification", "alliteration", "foreshadowing"], a: 0, why: "She says the opposite of what she means, which is verbal irony." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "In a story, the narrator mentions early on that the bridge \"looked a little weaker each day\". Later the bridge falls. The early hint is an example of", o: ["foreshadowing", "flashback", "hyperbole", "symbolism"], a: 0, why: "A hint about later events is foreshadowing." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "\"A deafening silence filled the room.\" The phrase joins two opposite ideas. It is an example of", o: ["an oxymoron", "an onomatopoeia", "an alliteration", "a rhyme"], a: 0, why: "A phrase that joins contradictory terms, such as deafening silence, is an oxymoron." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "In a poem, a white dove appears at the end of a war. The dove most likely stands for", o: ["peace", "winter", "danger", "wealth"], a: 0, why: "In literature a white dove is a traditional symbol of peace." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "\"She had the patience of Job.\" This phrase assumes that the reader knows a famous figure from an older text. This device is called", o: ["allusion", "rhyme", "alliteration", "onomatopoeia"], a: 0, why: "A brief reference to a well-known person, event or text is an allusion." },
{ k: "m", cat: "devices", std: ["12영문01-05"], q: "\"The fog crept in on little cat feet\" gives us a picture of the fog's soft, silent movement. The picture created in the reader's mind is called", o: ["imagery", "plot", "rhythm", "dialogue"], a: 0, why: "Language that appeals to the senses to form a mental picture is imagery." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "In a story, the main character who wants something and drives the action is called the", o: ["protagonist", "narrator", "antagonist", "audience"], a: 0, why: "The protagonist is the central character of the story." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "A detective story tells of a clever thief who always escapes the detective. Who is the antagonist?", o: ["The thief who opposes the detective", "The detective who follows clues", "The reader who tries to guess", "The author who wrote the story"], a: 0, why: "The antagonist is the force or character that opposes the protagonist; here the detective is the protagonist and the thief opposes him." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "Which part of the plot contains the greatest tension, the point where the outcome is decided?", o: ["The climax", "The exposition", "The resolution", "The title"], a: 0, why: "The climax is the peak of tension and turning point of the story." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "Which element of a story do the words \"a foggy harbour town in the 1920s\" mainly describe?", o: ["The setting", "The theme", "The conflict", "The point of view"], a: 0, why: "Time and place make up the setting." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "\"I knew the stairs would creak, so I stepped around the third one.\" Which point of view is used?", o: ["First person", "Second person", "Third-person limited", "Third-person omniscient"], a: 0, why: "The narrator uses \"I\", which is first-person narration." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "A narrator who knows every character's thoughts, as in \"Anna feared the test while Tom secretly wished she would fail\", has", o: ["an omniscient point of view", "a first-person point of view", "a second-person point of view", "a limited point of view"], a: 0, why: "Access to the thoughts of several characters shows an omniscient narrator." },
{ k: "m", cat: "elements", std: ["12영문01-04"], q: "A story pauses and shows events from ten years earlier to explain a character's behaviour. This technique is called", o: ["a flashback", "a prologue", "a rhyme", "a stanza"], a: 0, why: "Moving back to earlier events is a flashback." },
{ k: "m", cat: "elements", std: ["12영문01-01", "12영문01-02"], q: "A story shows a boy who gives up his last coin to help a stranger, and later he is helped in return. Which sentence states a possible theme?", o: ["Kindness often comes back to those who give it.", "Boys should save their coins.", "Strangers are always dangerous.", "The story takes place in a market."], a: 0, why: "A theme is a general idea about life; the first sentence states such an idea, while the others are advice, a mistaken idea, or setting." },
{ k: "m", cat: "poetry", std: ["12영문01-05"], q: "A group of lines in a poem, separated from the next by a space, is called a", o: ["stanza", "chapter", "scene", "paragraph"], a: 0, why: "Poems are divided into stanzas." },
{ k: "m", cat: "poetry", std: ["12영문01-05"], q: "In a four-line poem the last words of the lines are \"light\", \"day\", \"night\", \"way\". What is the rhyme scheme?", o: ["AABB", "ABAB", "ABBA", "ABCD"], a: 1, why: "Lines 1 and 3 rhyme (light, night) and lines 2 and 4 rhyme (day, way), so the pattern is ABAB." },
{ k: "m", cat: "poetry", std: ["12영문01-05"], q: "A poem of fourteen lines, usually with a fixed rhyme pattern, is a", o: ["sonnet", "limerick", "ballad", "riddle"], a: 0, why: "A sonnet has fourteen lines." },
{ k: "m", cat: "poetry", std: ["12영문01-05"], q: "Two consecutive lines that rhyme and complete a thought, such as \"The night was long, the stars were few; / I walked alone and thought of you\", form a", o: ["couplet", "stanza of six lines", "sonnet", "haiku"], a: 0, why: "Two successive rhyming lines make a couplet." },
{ k: "m", cat: "poetry", std: ["12영문01-05"], q: "The regular pattern of stressed and unstressed syllables in a poem is called", o: ["rhythm (meter)", "plot", "setting", "dialogue"], a: 0, why: "Rhythm or meter describes the pattern of stress in poetry." },
{ k: "m", cat: "drama", std: ["12영문01-04"], q: "In a play, a character alone on stage speaks his thoughts aloud so that the audience can hear them. This speech is a", o: ["soliloquy", "prologue", "stanza", "caption"], a: 0, why: "A soliloquy is a speech by a lone character revealing inner thoughts." },
{ k: "m", cat: "drama", std: ["12영문01-04"], q: "In a script, the line \"(She slams the door.)\" is a", o: ["stage direction", "title", "theme", "rhyme"], a: 0, why: "Words in brackets that describe action are stage directions." },
{ k: "m", cat: "tone", std: ["12영문01-02", "12영문01-03"], q: "\"The empty swings creaked in the grey drizzle, and nobody came to the park all afternoon.\" The mood of this sentence is best described as", o: ["lonely and gloomy", "excited and joyful", "angry and violent", "silly and playful"], a: 0, why: "Empty swings, grey drizzle and nobody around create a lonely, gloomy mood." },
];
