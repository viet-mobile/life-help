const q = (q, o, a, why) => ({ q, o, a, why });
export const R1 = [
{ k: "r", title: "The Lighthouse Keeper", std: ["12영문01-01", "12영문01-03"], text:
`Every evening at dusk, Tomas climbed the one hundred and twelve steps to the lamp room, just as his father had done before him. The sea below was the colour of slate, and the wind pulled at his coat as if it wanted him to hurry. He did not hurry. Years of practice had taught him that the lamp, like a nervous horse, must be approached slowly and with a steady hand. Tonight the new harbour lights glittered across the bay, brighter and cheaper than anything his lamp could offer, and the ferry captains no longer looked up at his tower. Tomas lit the flame anyway. "Somebody might still need it," he muttered, and he watched the beam sweep over the empty water, patient and faithful, like a promise nobody had asked him to keep.`,
  qs: [
    q("What is the passage mainly about?", ["A man who keeps doing his duty although it is no longer valued", "A young sailor who loses his way in a dangerous storm", "A ferry company that plans to build a brand-new harbour", "A father who is teaching his son how to repair a lamp"], 0, "Tomas continues to light the lamp even though the new harbour lights have made it unnecessary, so the passage is about faithful duty."),
    q("Why have the ferry captains stopped looking up at the tower?", ["The old lamp has become too dim to be seen from the bay.", "The new harbour lights now do the lamp's job for them.", "Tomas has asked them to stay away from the rocks.", "The captains are afraid of the wind near the cliffs."], 1, "The text says the new harbour lights are brighter and cheaper than the lamp, so the captains no longer rely on it."),
    q("In the passage, the word \"faithful\" is closest in meaning to", ["curious", "loyal", "cheerful", "careless"], 1, "\"Faithful\" describes something that stays true to its duty, so it means loyal."),
    q("What is the tone of the final sentence?", ["Angry and bitter about being replaced", "Playful and full of jokes about the sea", "Quietly sad, yet respectful of Tomas's devotion", "Cold and unconcerned about what happens next"], 2, "The simile of a promise nobody asked him to keep is gentle and sad, but it also admires his loyalty."),
  ] },
{ k: "r", title: "Morning Market", std: ["12영문01-05", "12영문01-08"], text:
`Before the sun has cleared the roofs,
the awnings snap open like green wings.
A woman stacks her oranges in pyramids,
each one a small lamp lit for the day.
Fish lie silver on their beds of ice,
their round eyes full of last night's sea.
A boy runs past with bread held high,
a trophy warm against his chest.
The air is thick with mint and smoke
and prices called in a dozen tongues.
Nobody here is standing still;
even the pigeons seem to haggle.
Then comes the bell from the church tower,
and for a moment all the noise
folds down, as if the street itself
were taking one long breath
before it starts to sing again.`,
  qs: [
    q("\"each one a small lamp lit for the day\" compares the oranges to lamps. What does this metaphor suggest?", ["They are heavy and hard to carry", "They are bright and add warmth to the scene", "They are very expensive for most buyers", "They will not last until the evening"], 1, "A lamp gives light and warmth, so the metaphor shows the bright colour of the oranges."),
    q("Which sense does the line \"The air is thick with mint and smoke\" appeal to most?", ["Smell", "Hearing", "Touch", "Taste"], 0, "Mint and smoke are known by their scent, so the image appeals mainly to the sense of smell."),
    q("Which line is an example of personification?", ["the awnings snap open like green wings", "A boy runs past with bread held high", "even the pigeons seem to haggle", "Fish lie silver on their beds of ice"], 2, "Pigeons are given the human habit of bargaining over prices, which is personification. The other lines use a simile, plain description, or a metaphor."),
    q("What happens when the church bell rings?", ["The market closes and the sellers go home.", "The noise stops for a moment before life continues.", "The boy drops his bread and begins to cry.", "The fish are sold quickly to the first buyers."], 1, "The street \"folds down\" its noise for a moment, as if taking a breath, and then it \"starts to sing again\"."),
  ] },
{ k: "r", title: "The Heron and the Pond", std: ["12영문01-01", "12영문01-04"], text:
`A grey heron lived beside a pond so clear that every pebble on the bottom could be counted. For many years she caught a fish whenever she was hungry, and she was content. Then one summer she grew proud. "Small fish are beneath me," she said, and she refused them. She waited for a large, golden carp instead. Days passed. The small fish swam past her legs and laughed quietly, and still she waited. When the carp finally appeared, it was too quick and too clever, and it slipped away into deep water. By autumn the pond had grown cold, the small fish had hidden in the mud, and the heron stood alone on one thin leg, hungrier than she had ever been. Her pride, it seemed, had been the only meal she had eaten.`,
  qs: [
    q("Which lesson does this fable teach?", ["Clever animals always win in the end.", "Being too proud can make us lose what we have.", "Large fish are easier to catch than small ones.", "Autumn is the hardest season for hunting."], 1, "The heron's pride makes her refuse small fish and end up with nothing, so the moral is about the cost of pride."),
    q("How is the passage organised?", ["It begins with a problem and shows how it is solved at once.", "It shows a calm situation, a change in attitude, and a harsh result.", "It compares two ponds and says which one is better.", "It tells the story backward, starting from the ending."], 1, "The heron is content, becomes proud, and then suffers; this is a sequence of situation, turning point, and result."),
    q("What does the last sentence mean by \"Her pride... had been the only meal she had eaten\"?", ["She had actually eaten her own pride.", "She had received nothing from her choices except pride.", "She had enjoyed several meals of pride.", "She was proud of the meal she had caught."], 1, "It is a figure of speech: the only thing she gained was pride, which cannot feed her."),
    q("Why did the small fish \"laugh quietly\"?", ["They were amused that the heron ignored them while waiting for something else.", "They were about to be caught by the heron.", "They were telling a joke about the carp.", "They were happy that autumn was coming."], 0, "The heron looked down on them and waited for the carp, so the small fish found her behaviour funny and safe for them."),
  ] },
{ k: "r", title: "A Letter to My Younger Sister", std: ["12영문01-02", "12영문01-03"], text:
`Dear Mina,

By the time you read this, you will have unpacked your boxes and found out that the dormitory radiator makes a noise like an angry cat. Do not be discouraged. I remember my own first week at university: I ate lunch alone, I got lost twice a day, and I wrote home every night to say I wanted to come back. Mother kept all of those letters, and last month she showed them to me. I laughed until I cried, because the girl who wrote them seemed so far away.

I am not telling you this to make you feel better, though I hope it does. I am telling you because nobody told me. Be patient with yourself, and open your door sometimes. People will knock.

With love,
Joo-won`,
  qs: [
    q("What is the main purpose of this letter?", ["To describe the writer's own university courses in detail", "To warn Mina about problems with the dormitory building", "To comfort and encourage Mina as she begins a new life", "To ask Mina to send news back to the family"], 2, "The writer shares her own difficult first week to reassure Mina that the beginning is hard but gets better."),
    q("Why did Joo-won laugh until she cried when she read her old letters?", ["Her younger self seemed very distant from who she is now.", "The letters were full of jokes about the radiator.", "Her mother had changed the words as a prank.", "She had forgotten how to write in her own language."], 0, "She says the girl who wrote the letters \"seemed so far away\", showing how much she has changed."),
    q("Which of the following is stated in the letter?", ["Mina's dormitory room has no radiator.", "Joo-won once wrote home every night during her first week.", "Their mother has thrown away the old letters.", "Joo-won ate lunch with many friends on her first day."], 1, "The letter says she \"wrote home every night\" to say she wanted to come back."),
    q("The sentence \"People will knock\" suggests that", ["noisy neighbours will complain about Mina", "Mina should expect new friends to come to her", "the radiator will need to be repaired soon", "visitors will interrupt Mina's studies often"], 1, "After telling Mina to open her door, the writer promises that others will come to her, meaning friendship will follow."),
  ] },
{ k: "r", title: "The Kitchen Table (a scene)", std: ["12영문01-04", "12영문01-02"], text:
`SETTING: A small kitchen, late at night. A single lamp is on. HANA sits at the table with a pile of unopened envelopes. HER BROTHER, JIN, enters in his pyjamas.

JIN: (yawning) You are still awake?

HANA: (not looking up) Someone has to pay the bills.

JIN: (sitting down) We could do it together tomorrow.

HANA: (pushing an envelope towards him) You said that last week. And the week before.

(A long pause. The clock ticks. JIN picks up the envelope and turns it over, as if the paper might bite.)

JIN: (quietly) I did not want to see how bad it was.

HANA: (softening) Neither did I. That is why I could not sleep.

(She slides a second envelope across the table. This time, he opens it.)`,
  qs: [
    q("What is the function of the stage directions in brackets?", ["They give the actors' real names and ages.", "They tell how lines are spoken and what the characters do.", "They summarise the whole plot of the play.", "They explain difficult words to the audience."], 1, "Stage directions describe tone and action, such as \"yawning\" or \"softening\", so that the scene can be performed."),
    q("What conflict is shown at the start of the scene?", ["Hana and Jin are arguing about who owns the kitchen.", "Hana is annoyed because Jin has put off an unpleasant task.", "Jin is angry that Hana has woken him in the night.", "Both are afraid of a noise outside the house."], 1, "Hana says Jin has promised to help for weeks and has not, so the tension comes from avoidance."),
    q("Why does Jin turn the envelope over \"as if the paper might bite\"?", ["He wants to check whether it has been opened before.", "He is afraid of what the bill will show.", "He thinks the paper is torn at one corner.", "He is looking for a name on the back."], 1, "The simile suggests he fears bad news, which he confirms when he says he did not want to see how bad it was."),
    q("What does the final stage direction suggest about Jin?", ["He is ready to face the problem with his sister.", "He is going to leave the room in anger.", "He has decided to ignore the bills again.", "He is falling asleep at the table."], 0, "By opening the envelope, Jin takes the first step to share the responsibility."),
  ] },
{ k: "r", title: "From a Winter Diary", std: ["12영문01-03", "12영문01-08"], text:
`3 December. Snow fell all night, and when I opened the curtains this morning the garden had vanished. The bench, the apple tree, even the old wheelbarrow had been wrapped in white as carefully as presents. For a few minutes I forgot the cold, forgot the exam on Friday, forgot that my grandfather's chair has been empty since October. I just stood there with my breath making small clouds against the glass.

Then Mum called me for breakfast, and the ordinary day rushed back in. But something small had changed. I think I understood, for the first time, why Grandfather used to say that silence is not the absence of sound but the presence of attention. This morning I was paying attention, and the world was kind enough to reward me.`,
  qs: [
    q("What is the writer's main experience in this entry?", ["A brief moment of calm and awareness in the snowy garden", "A frightening night spent alone in a cold house", "A quarrel with a parent over the exam", "A long walk to a faraway village"], 0, "The entry centres on the quiet moment at the window, when the writer pays attention to the beautiful scene."),
    q("The phrase \"wrapped in white as carefully as presents\" is an example of", ["a simile", "a contradiction", "a rhyme", "an exaggeration"], 0, "The snow-covered objects are compared to presents using \"as... as\", which is a simile."),
    q("What can be inferred about the writer's grandfather?", ["He has recently died.", "He lives in a different country.", "He is angry about the exam.", "He is waiting in the kitchen."], 0, "His chair \"has been empty since October\" and the writer remembers his sayings in the past tense, so he has likely passed away."),
    q("Which statement best expresses the writer's insight?", ["Cold weather helps people to study better.", "Quiet moments can be full of meaning if we notice them.", "Gifts are more precious when they are wrapped well.", "Old sayings are usually wrong about the world."], 1, "The grandfather's saying about attention helps the writer understand that silence has value when we are attentive."),
  ] },
{ k: "r", title: "Autumn Leaf", std: ["12영문01-05"], text:
`I am the last one on the branch,
a small brass coin of summer,
and the wind keeps asking for me
in a voice both rough and kind.
My sisters left in October,
spinning down like paper dancers.
They did not look back at the tree
that had held them through the rain.

Now I hang on, thin and bright,
while the sky turns the colour of ash.
Below, the children kick my sisters
into heaps and shout with joy.
Perhaps that is a kind of ending too:
to be the thing that someone leaps in.
The wind asks again. I loosen my fingers,
and the whole cold world rushes up to meet me.`,
  qs: [
    q("Who is the speaker of the poem?", ["A child playing in the park", "The tree that lost its leaves", "A leaf that is still on the branch", "The wind blowing through the garden"], 2, "The speaker calls itself \"the last one on the branch\" and refers to \"my sisters\", so it is a leaf."),
    q("\"a small brass coin of summer\" is a metaphor that suggests the leaf is", ["valuable and golden but small", "heavy and likely to break", "noisy and difficult to ignore", "round and good for trade"], 0, "A brass coin is small and shiny and has value; the metaphor stresses the leaf's colour and preciousness."),
    q("What does the last line suggest about the leaf's attitude toward falling?", ["It is terrified and tries to hold on.", "It accepts the fall with calm and courage.", "It is angry with the wind for calling.", "It feels nothing at all."], 1, "The leaf \"loosens its fingers\" and the world rushes up to meet it, showing willing acceptance."),
    q("In the second stanza, how does the poem look at the fallen leaves?", ["As rubbish that spoils the ground", "As a sign that the tree is unhealthy", "As something that still brings happiness to children", "As a warning of a long and cruel winter"], 2, "The children shout with joy as they kick the leaves, so falling leaves still bring delight, which is a gentler view of ending."),
  ] },
{ k: "r", title: "The Cracked Cup", std: ["12영문01-04", "12영문01-01"], text:
`Grandmother's blue cup sat at the back of the cupboard, and no one was allowed to use it. It had a thin crack running from the rim to the handle, like a river on a map. Clara had always wondered why it was kept at all.

On the morning of her departure for the city, Grandmother took the cup down, filled it with tea, and set it before her. "Drink," she said. Clara did, and the warm tea began to seep, very slowly, through the crack. By the time she reached the bottom, a small dark stain had spread across the saucer.

"You see?" said Grandmother, smiling. "It leaks. But it has never once been empty when I needed it." Clara said nothing. She only held the cup a little more tightly.`,
  qs: [
    q("What does the cracked cup most likely symbolise?", ["Something imperfect that is still deeply valuable", "A gift that was bought in a faraway city", "A danger that Clara must avoid at all costs", "A mistake that Grandmother wants to hide"], 0, "The cup leaks but is never empty when needed; it stands for flawed but faithful care, perhaps Grandmother herself."),
    q("Which part of the plot is the turning point?", ["Clara wonders why the cup is kept.", "Grandmother fills the cup and gives it to Clara.", "The stain spreads over the saucer.", "Clara goes to the city by train."], 1, "The moment Grandmother serves tea in the forbidden cup breaks the pattern of the story and leads to the lesson."),
    q("Why does Clara hold the cup \"a little more tightly\" at the end?", ["She is afraid that it will fall from her hands.", "She has understood something moving about the cup.", "She wants to take it with her without asking.", "She is angry that the tea has leaked."], 1, "Her silence and tighter grip show she is moved; she has grasped what the cup means to Grandmother."),
    q("What is the effect of the simile \"like a river on a map\"?", ["It shows that the crack is thin but long and winding.", "It proves that Grandmother is good at drawing.", "It suggests the cup came from another country.", "It makes the crack seem dangerous to everyone."], 0, "A river on a map is a thin winding line, which matches the crack from rim to handle."),
  ] },
{ k: "r", title: "Why Read Stories?", std: ["12영문01-02", "12영문01-06"], text:
`People sometimes ask what the use of fiction is. After all, the characters never lived and the events never happened. Yet I would argue that stories are among the most practical tools we own. A good novel lets us stand, for a few hundred pages, inside a mind that is not our own. We feel the shame of a boy who cannot read, or the fear of a woman crossing a border at night, and then we close the book and carry that borrowed feeling back into our own lives. In this way, fiction trains the imagination that kindness depends on. It is true that a story cannot repair a bridge or cure a fever. But a society that has forgotten how to imagine its neighbours will, sooner or later, stop building bridges for them.`,
  qs: [
    q("What is the writer's main argument?", ["Fiction is useful because it develops our ability to understand others.", "Novels are more accurate than newspapers.", "Readers should avoid stories about unhappy people.", "Bridges should be built by writers rather than engineers."], 0, "The writer says stories train the imagination that kindness depends on, which makes them practical."),
    q("Why does the writer say \"a story cannot repair a bridge or cure a fever\"?", ["To admit the limits of fiction before making a further point", "To show that the writer dislikes science", "To suggest that doctors read too little", "To warn readers against dangerous bridges"], 0, "The sentence concedes what fiction cannot do and then adds a deeper claim about imagining neighbours."),
    q("In the passage, \"borrowed feeling\" refers to", ["a feeling taken from a character's experience", "an emotion that a friend gave back", "money lent by a library", "an idea that is taken without permission"], 0, "The reader feels the character's shame or fear and brings that feeling into his or her own life, so it is a feeling borrowed from the story."),
    q("What is the likely effect of the last sentence on the reader?", ["It makes the reader laugh at the idea of bridges.", "It gives a warning that links imagination to social care.", "It changes the topic to engineering.", "It repeats the first sentence in other words."], 1, "The final sentence warns that without imagination people stop caring for others, and it ties the essay together."),
  ] },
{ k: "r", title: "The Sewing Machine", std: ["12영문01-04", "12영문01-03"], text:
`The machine arrived in a wooden crate, scratched and smelling of oil. Soo-ah's grandmother had used it for forty years, and now it belonged to her.

She set it on the desk and turned the wheel. Suddenly she was seven again, lying on the floor of the old apartment while the needle chattered above her like a small, busy bird. Her grandmother had been hemming school uniforms, and every few minutes she would stop to bite a thread and say, "Never trust a straight line you did not draw yourself."

Now the apartment was gone, and so was the voice. Soo-ah threaded the needle on her third try and pressed the pedal. The machine coughed, hesitated, and began to sing. She did not stop until the first uneven seam was finished, crooked and perfect.`,
  qs: [
    q("Which narrative technique does the second paragraph use?", ["A flashback to the past", "A prediction of the future", "A change of narrator", "A direct question to the reader"], 0, "Soo-ah remembers being seven years old, so the story moves back in time with a flashback."),
    q("What does the phrase \"crooked and perfect\" suggest?", ["The seam is flawed, but it matters deeply to Soo-ah.", "The seam is exactly straight like a ruler.", "The machine is broken beyond repair.", "Soo-ah has no wish to sew again."], 0, "A crooked seam is imperfect, yet it is perfect for her because it continues her grandmother's work, so the contradiction is intended."),
    q("The needle is compared to \"a small, busy bird\" because", ["it moves quickly and makes light, repeated sounds", "it flies about the room in the night", "it hurts the child on the floor", "it is coloured like a feathered animal"], 0, "The comparison shows the speed and the chattering sound of the needle."),
    q("What is the mood of the final paragraph?", ["Tender and quietly hopeful", "Frightened and tense", "Bitter and resentful", "Silly and playful"], 0, "Soo-ah's effort and the machine beginning to \"sing\" create a warm, moving mood of continuing a loved one's memory."),
  ] },
{ k: "r", title: "City Rain", std: ["12영문01-05", "12영문01-08"], text:
`The rain comes down on the city street
with a thousand tiny feet,
tapping the roofs and the parking meters,
drumming the taxis in the heat
that lingers from the day.
The gutters gargle, the windows blur,
and the neon signs begin to stir
and bleed their colours into the road
like paint in a glass of water.

A man with a newspaper over his head
runs for the bus. A dog stands still,
content to be soaked. The shop girl smiles
at nothing, at the grey, at the thrill
of being out of reach for a while.
And I, at the window, with my cold tea,
think how the whole loud city
has been told to slow down, and has agreed.`,
  qs: [
    q("What do \"a thousand tiny feet\" represent?", ["The raindrops hitting the ground", "The crowd of people running home", "The paws of stray animals in the street", "The wheels of passing taxis"], 0, "The raindrops are imagined as tiny feet tapping on roofs and meters; the line is a metaphor."),
    q("Which line contains a simile?", ["the whole loud city has been told to slow down", "The gutters gargle, the windows blur", "and bleed their colours into the road like paint in a glass of water", "A dog stands still, content to be soaked"], 2, "The neon colours spreading in the wet road are compared to paint in water using \"like\"."),
    q("What is the speaker's feeling about the rain?", ["Calm appreciation for the way it slows the city", "Strong anger at the damage it causes", "Fear of being alone in the room", "Disappointment that the day is spoiled"], 0, "The speaker watches from the window and enjoys the city's slowing, as the last lines show."),
    q("The poem mentions the shop girl smiling \"at nothing\". This suggests that", ["she is making fun of the customers", "the rain has put people into a lighter, dreamy mood", "she has lost her job", "she is confused by the noise"], 1, "She smiles without a clear reason, which shows the rain's soft effect on the mood of the city."),
  ] },
{ k: "r", title: "The Umbrella", std: ["12영문01-04", "12영문01-02"], text:
`Mr. Park had saved for six months to buy his wife a silver umbrella for her birthday. It was slim and elegant, with a handle shaped like a swan's neck. She had admired it in a shop window every Tuesday since spring.

On the morning of the birthday, he wrapped it in tissue paper and tied a ribbon around it. At the same moment, his wife was in the next room, wrapping a small box for him. Inside was a leather case for his old reading glasses, bought with the money from selling her second-best coat.

It rained all afternoon. They ate dinner, exchanged their presents, and laughed, and then, a little embarrassed, both fell silent. He had no need of a case; he had lost his glasses on Monday. And she had nothing to wear in the rain, because she had no coat.`,
  qs: [
    q("What literary device is the main feature of the ending?", ["Situational irony", "Alliteration", "Onomatopoeia", "Rhyme"], 0, "Each person sacrifices something for a gift that has become useless, which is the opposite of what was intended: situational irony."),
    q("What can be inferred about the couple?", ["They love each other but have little money.", "They are rich and love to compete.", "They dislike giving and receiving gifts.", "They often quarrel about money."], 0, "Saving for six months and selling a coat show that they care about one another and have few resources."),
    q("Why did the couple become \"a little embarrassed\"?", ["They realised that their gifts did not fit their present needs.", "They had forgotten the date of the birthday.", "They were afraid that the guests would arrive early.", "They found the presents were too cheap."], 0, "The case is useless without glasses and the umbrella is useful only to someone who has a coat, so the sacrifices cancelled each other out."),
    q("What does the story mainly suggest about gifts?", ["The love behind a gift matters more than its use.", "Gifts should always be bought in shops.", "It is better to give money than objects.", "Rain spoils all celebrations."], 0, "Despite the awkward result, the couple's willingness to sacrifice shows the value of love and care."),
  ] },
{ k: "r", title: "The Moon Merchant", std: ["12영문01-01", "12영문01-04"], text:
`In a village at the foot of the mountains, there was once a merchant who claimed that he could sell the moon. Every night he set up a stall, filled a large bowl with water, and invited the villagers to look. The moon trembled in the water, round and white. "Ten coins for a night's loan," he said, and many people paid, for the water seemed to hold a beauty that the sky could not.

One night a little girl named Seon leaned over the bowl and said, "But the moon is above us. You are only selling its reflection." The crowd murmured. The merchant did not argue. He simply tipped the bowl onto the road, and the moon disappeared. "Then look up," he said gently, "and keep your coins." From that day the villagers watched the sky for free, and they say the moon has never looked brighter.`,
  qs: [
    q("What happens at the climax of the tale?", ["The girl points out the truth and the merchant gives up his trick.", "The merchant sells the moon to a rich visitor.", "The villagers chase the merchant out of town.", "The bowl is stolen by a stranger."], 0, "The girl's remark is the point of greatest tension, and the merchant's reaction resolves the story."),
    q("Which theme does the tale express?", ["Real beauty is available to all if we look in the right place.", "Children should never speak to merchants.", "Water is more valuable than silver.", "Mountains protect villages from thieves."], 0, "The villagers learn that they can enjoy the real moon for free by looking up, so the theme is about true beauty."),
    q("What is the merchant's attitude at the end?", ["Gentle and wise, though he loses his income", "Furious at being exposed", "Afraid of the villagers", "Proud of his fine trick"], 0, "He speaks \"gently\" and tells them to keep their coins, which shows grace in defeat."),
    q("\"the moon has never looked brighter\" is the narrator's way of showing that", ["people now appreciate what was always there", "the weather has turned warmer", "the water in the bowl was very clean", "the merchant has made the moon larger"], 0, "The change is in the villagers' attention and appreciation, not in the moon itself."),
  ] },
{ k: "r", title: "The Gardener Robot", std: ["12영문01-01", "12영문01-06"], text:
`Unit 7 had tended the rooftop garden for eleven years, but it had never been asked what it thought of tomatoes. When a small boy named Eli posed the question, the robot paused, its sensors whirring.

"I do not eat," it said at last. "I cannot taste. And yet, when the first red fruit appears, my processors run faster than they do for any other event. I do not know whether that is liking. Perhaps you can tell me."

Eli considered this seriously. "It sounds like liking to me," he said. "You wait for it, and you are happy when it comes."

The robot recorded the conversation in its memory and, for the first time in eleven years, labelled the file with a single word: "joy". Then it went back to the tomatoes, whose leaves were beginning, quietly, to turn.`,
  qs: [
    q("What question does this story raise?", ["Can a machine have feelings like humans do?", "Why do tomatoes grow best on roofs?", "How long can a robot work without repairs?", "Who should be in charge of the garden?"], 0, "Unit 7 cannot taste yet reacts strongly to the fruit; the boy suggests that this may be liking, so the story raises the question of machine feelings."),
    q("Which words best describe Eli's reaction to the robot?", ["Thoughtful and kind", "Frightened and impatient", "Rude and bored", "Amused and cruel"], 0, "He \"considered this seriously\" and gives a kind, helpful answer."),
    q("Why does the robot label the file \"joy\"?", ["It has accepted Eli's idea about its own response.", "It is following a rule in its program.", "It wants to share the file with the boy.", "It is trying to hide the information."], 0, "After hearing Eli say it sounds like liking, the robot names its experience with a human word, joy."),
    q("What is the effect of the final sentence?", ["It shows that life continues and time passes quietly.", "It introduces a sudden danger to the garden.", "It suggests that the robot is about to break.", "It begins a new conversation with Eli."], 0, "Leaves beginning to turn hints at the change of season and the calm routine that carries on after the emotional moment."),
  ] },
];
