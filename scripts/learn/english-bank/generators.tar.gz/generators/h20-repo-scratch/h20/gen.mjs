import fs from "node:fs";
import { P } from "./patch.mjs"; import { R1 } from "./r1.mjs"; import { R2 } from "./r2.mjs"; import { D, M } from "./dms.mjs";
const S = (good, ko, bad, st, ok, wr, rule, extra = {}) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...extra });
const Ss = [
S("By the time the rescuers arrived, the old keeper had already left the island.", "구조대가 도착했을 때 늙은 관리인은 이미 섬을 떠난 뒤였어요.",
  ["By the time the rescuers arrived, the old keeper had already leave the island.", "By the time the rescuers arrived, the old keeper had already leaving the island.", "By the time the rescuers arrived, the old keeper have already left the island."],
  "By the time the rescuers arrived, the old keeper had already ___ the island.", "left", ["leave", "leaving", "leaves"],
  "이야기에서 다른 과거 시점보다 먼저 일어난 일은 과거완료(had + 과거분사)로 나타내요.", { ord: false }),
S("Never had she heard a silence so heavy.", "그녀는 그렇게 무거운 침묵을 들어 본 적이 없었어요.",
  ["Never she had heard a silence so heavy.", "Never had heard she a silence so heavy.", "Never she heard had a silence so heavy."],
  "Never ___ she heard a silence so heavy.", "had", ["did", "was", "would"],
  "부정 부사(never)가 문장 앞에 오면 조동사가 주어 앞으로 가는 도치가 일어나요. 문학 작품에서 강조하려고 자주 쓰여요."),
S("If I were the narrator, I would trust the old man less.", "내가 화자라면 그 노인을 덜 믿을 거예요.",
  ["If I am the narrator, I would trust the old man less.", "If I were the narrator, I will trust the old man less.", "If I would be the narrator, I would trust the old man less."],
  "If I ___ the narrator, I would trust the old man less.", "were", ["am", "would be", "will be"],
  "현재 사실과 반대되는 가정은 'If + 주어 + were ..., 주어 + would + 동사원형'으로 나타내요.", { ord: false }),
S("Not only does the poem rhyme, but it also tells a story.", "그 시는 운을 맞출 뿐만 아니라 이야기도 들려줘요.",
  ["Not only the poem does rhyme, but it also tells a story.", "Not only the poem rhymes, but it also tells a story.", "Not only does the poem rhymes, but it also tells a story."],
  "Not only ___ the poem rhyme, but it also tells a story.", "does", ["do", "is", "has"],
  "Not only가 문장 앞에 오면 'does + 주어 + 동사원형'처럼 도치되고, does 뒤의 동사는 원형이에요.", { ord: false }),
S("The writer whose poems we studied was born in a small village.", "우리가 공부한 시를 쓴 작가는 작은 마을에서 태어났어요.",
  ["The writer who poems we studied was born in a small village.", "The writer which poems we studied was born in a small village.", "The writer whom poems we studied was born in a small village."],
  "The writer ___ poems we studied was born in a small village.", "whose", ["who", "which", "whom"],
  "소유를 나타내는 관계대명사는 whose이고, 뒤에 명사(poems)가 바로 와요.", { ord: false }),
S("Having finished the novel, she wrote a short review.", "그 소설을 다 읽은 뒤에 그녀는 짧은 서평을 썼어요.",
  ["Having finish the novel, she wrote a short review.", "Having finishing the novel, she wrote a short review.", "Having been finished the novel, she wrote a short review."],
  "Having ___ the novel, she wrote a short review.", "finished", ["finish", "finishing", "finishes"],
  "주절보다 앞서 일어난 일은 분사구문 'Having + 과거분사'로 나타내요.", { ord: false }),
S("The ending was so surprising that several readers gasped.", "결말이 너무 놀라워서 여러 독자가 숨을 헉 들이마셨어요.",
  ["The ending was too surprising that several readers gasped.", "The ending was so surprising what several readers gasped.", "The ending was such surprising that several readers gasped."],
  "The ending was ___ surprising that several readers gasped.", "so", ["such", "too", "very"],
  "'so + 형용사 + that ~'은 '너무 ~해서 …하다'는 뜻이에요. such 뒤에는 명사가 와요.", { ord: false }),
S("The detective must have known that the butler was lying.", "탐정은 집사가 거짓말을 하고 있다는 것을 알았음이 틀림없어요.",
  ["The detective must have know that the butler was lying.", "The detective must has known that the butler was lying.", "The detective must had known that the butler was lying."],
  "The detective must ___ known that the butler was lying.", "have", ["has", "had", "having"],
  "'must have + 과거분사'는 과거 일에 대한 강한 추측을 나타내요. must 뒤에는 항상 동사원형이 와요.", { ord: false }),
];
const items = [...R1, ...R2, ...D, ...M.map(({ cat, ...r }) => ({ ...r, cat })), ...Ss];
for (const [t, qi, edits] of P) {
  const it = qi < 0 ? items.find((x) => x.k === "m" && x.q.startsWith(t)) : items.find((x) => x.title === t);
  if (!it) { console.log("NOT FOUND", t); continue; }
  const tgt = qi < 0 ? it : it.qs[qi];
  for (const [i, txt] of edits) tgt.o[i] = txt;
}
const fs4 = items.find((x) => x.title === "Four Seasons in Short");
fs4.text = fs4.text.replace("looking out of a hospital window.)", "looking out of a hospital window, where the only things to see were a plane tree, a bus stop and a strip of sky, so the seasons had to be imagined as much as seen.)");
const out = { packet: "H20-h-lit", sections: [{ skill: "e.h.lit", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H20-h-lit.json", JSON.stringify(out, null, 1) + "\n");
console.log(items.length);
