const q = (q, o, a, why) => ({ q, o, a, why });
export const R2 = [
{ k: "r", title: "First Day in a New Country", std: ["12영문01-07", "12영문01-03"], text:
`On my first morning in Canada, my host mother handed me a mug of hot chocolate and said, "Make yourself at home." I stood in the kitchen, mug in hand, and did not know what to do. At home, a guest would never open a refrigerator in someone else's house. Here, apparently, that was exactly what "at home" meant. She laughed when I finally asked permission to take a glass of water, and she opened the fridge herself, saying that from now on I should help myself whenever I was thirsty.

It was a tiny moment, but I thought about it for days. Two families, two ways of showing care: one by never intruding, the other by inviting you to take. Neither is wrong. I only had to learn the language that the kindness was written in.`,
  qs: [
    q("Why did the writer hesitate in the kitchen?", ["She was taught that guests should not open a refrigerator uninvited.", "She did not like hot chocolate very much.", "She could not understand any English words.", "She thought the host mother was angry."], 0, "In her own culture a guest does not open someone's fridge, so \"make yourself at home\" confused her."),
    q("What is the writer's conclusion about the two customs?", ["Both are valid ways of expressing care.", "The Canadian way is clearly better.", "Her own custom is rude to hosts.", "The difference is not worth thinking about."], 0, "She says neither is wrong; they are different languages of kindness."),
    q("What does \"the language that the kindness was written in\" mean?", ["The customs through which kindness is shown", "The English words in the host's letters", "A secret code between the two families", "The grammar rules the writer studied"], 0, "It is a metaphor: kindness exists in every culture but is expressed through different customs that must be learned."),
    q("The host mother opened the fridge herself in order to", ["show that the guest was truly welcome to help herself", "look for something to cook for dinner", "teach the writer a lesson about manners", "hide food from the writer"], 0, "She wanted to make the guest feel at home and to show that taking a drink was fine."),
  ] },
{ k: "r", title: "The Missing Key", std: ["12영문01-04", "12영문01-01"], text:
`The key was not on the hook. Inspector Hale knew this before he looked, because the hook had a clean circle of dust around it, the sort that appears only when something hangs there for years and is suddenly taken away.

"The housekeeper says she last saw it on Tuesday," said the young constable.

"The housekeeper says a great many things." Hale crouched by the cellar door and ran a finger along the lock. There were no scratches. Whoever had opened it had come with the key, and not just any key; the right one. He straightened up, frowning at the dim hall. Somebody in this house, he suspected, had practised walking quietly down these stairs, and had been rehearsing for rather longer than one night.`,
  qs: [
    q("Which part of a story does this passage represent?", ["The exposition that introduces a mystery", "The final resolution of all questions", "The reflection of the narrator many years later", "A description of the setting without any conflict"], 0, "A crime is introduced, clues are seen, and no solution has yet been reached, so this is an opening that sets up the mystery."),
    q("What does the lack of scratches on the lock suggest?", ["The person who opened the door had the real key.", "The lock was recently replaced.", "The door was never locked at all.", "A thief used a very sharp tool."], 0, "The lock shows no signs of forced entry, so Hale concludes that the right key was used."),
    q("What does the inspector suspect at the end?", ["The act was planned in advance by someone in the house.", "The young constable has made an error.", "The housekeeper has left the country.", "The cellar has been empty for years."], 0, "\"Rehearsing for rather longer than one night\" suggests careful planning by a member of the household."),
    q("The phrase \"The housekeeper says a great many things\" shows that Hale", ["does not fully trust what the housekeeper says", "enjoys long conversations with her", "wants to hire her as an assistant", "is worried that she may be ill"], 0, "The remark is mildly sarcastic and suggests that her statements may not be reliable."),
  ] },
{ k: "r", title: "Mr. Alder the Baker", std: ["12영문01-02", "12영문01-08"], text:
`Mr. Alder rose at three each morning, when the town was still a dark rumour, and by five his shop smelled of bread so rich that passers-by slowed down without knowing why. He was a large man with small, careful hands, and he handled dough the way other people handle sleeping babies. To the children he gave the crusts, which he claimed were the best part; to the lonely widows he gave the ends of the loaf and a remark about the weather, which was the best part for them.

He never advertised, and he never raised his prices. "Bread," he liked to say, "is not a business. It is a conversation that happens to end in breakfast." The accountants shook their heads. The town, however, kept him alive, which is the only sort of profit a baker can really spend.`,
  qs: [
    q("Which description best characterises Mr. Alder?", ["Generous and devoted to his craft", "Greedy and careless", "Shy and fearful of customers", "Lazy and forgetful"], 0, "He works hard at dawn, treats dough gently, and gives to children and widows."),
    q("The comparison between dough and \"sleeping babies\" emphasises his", ["gentleness and care", "speed and strength", "ambition and cleverness", "anger and impatience"], 0, "People handle sleeping babies very softly, so the simile shows his tenderness with dough."),
    q("Why did the accountants \"shake their heads\"?", ["They thought his way of doing business made little financial sense.", "They disliked the smell of bread.", "They were too busy to eat breakfast.", "They wanted to buy his shop."], 0, "He did not advertise or raise prices, which seems unwise to people concerned with money."),
    q("What is the meaning of \"the only sort of profit a baker can really spend\"?", ["The community's support is what supports his living.", "He earns more money than other bakers.", "He sells bread at a very high price.", "He spends his profits on advertising."], 0, "The town \"kept him alive\", meaning the customers' loyalty provided what he needed to live."),
  ] },
{ k: "r", title: "Four Seasons in Short", std: ["12영문01-05", "12영문01-08"], text:
`Spring
Thin rain on the roof,
a green hum in the garden.
The earth clears her throat.

Summer
Cicadas shouting,
the road a shimmering sheet.
Even shade is hot.

Autumn
Red leaves on the stream
carry small boats to the sea.
Nobody sends word.

Winter
White fields, black branches.
The kettle starts to whisper.
Someone is coming.

(Four poems, each of three lines. The writer wrote them in a single week while recovering from an illness and looking out of a hospital window.)`,
  qs: [
    q("Which line is an example of personification?", ["The earth clears her throat.", "Thin rain on the roof", "White fields, black branches.", "Red leaves on the stream"], 0, "The earth is given a human action, clearing her throat, to suggest the first signs of spring."),
    q("What is the effect of \"Even shade is hot\"?", ["It stresses how intense the summer heat is.", "It shows that the writer likes sitting in the sun.", "It suggests that trees have died.", "It explains how shade is made."], 0, "If even the cool shade feels hot, the heat must be extreme; this is a deliberate contradiction for effect."),
    q("What mood does the winter poem create?", ["Quiet anticipation and warmth", "Anger and noise", "Complete despair", "Silly excitement"], 0, "The whispering kettle and the line \"Someone is coming\" create a calm, warm feeling of waiting."),
    q("What does the note in brackets add to our reading?", ["It suggests the poems may reflect a patient's hopeful view from a window.", "It proves that all four poems are about illness.", "It tells us that the writer is a famous doctor.", "It explains how to write poems in three lines."], 0, "Knowing the writer was recovering and looking out of a window helps explain the quiet watching and hope in the poems."),
  ] },
{ k: "r", title: "The Spelling Bee", std: ["12영문01-01", "12영문01-04", "12영문01-03"], text:
`When the judge said "necessary", Dahye's mouth went dry. She had practised that word a hundred times, but the stage lights were hot and the audience was a dark wall of faces. "N-E-C," she began, and stopped. In the second row her father, who had never learned English properly, held up a card on which he had written one letter: the second S. He had copied it from her notebook the night before.

She could have laughed or cried. Instead she breathed, closed her eyes, and said, "N-E-C-E-S-S-A-R-Y."

The judge nodded. The room exploded in applause. Later, when reporters asked what she had been thinking, Dahye said only, "I was thinking about a card." Only her father understood why he was crying behind his programme.`,
  qs: [
    q("What is the main idea of the passage?", ["A girl succeeds with the quiet support of her father.", "A judge makes a mistake with a difficult word.", "Reporters discover a secret about the contest.", "A father teaches his daughter English at home."], 0, "Dahye overcomes her fear with the help of her father's card, so the story is about support and courage."),
    q("What does the father's card show about him?", ["He wants to help though he does not know English well.", "He is trying to cheat for his own gain.", "He disagrees with the judge's decision.", "He is angry that Dahye is nervous."], 0, "He copied the letter from her notebook, showing effort and love without strong English."),
    q("Why does Dahye say, \"I was thinking about a card\"?", ["She wants to thank her father without revealing too much to others.", "She has forgotten the reporters' question.", "She is trying to confuse the audience.", "She hopes to win a prize for the card."], 0, "Only her father understands the answer, so it is a private gesture of thanks."),
    q("Which phrase best describes how the story ends?", ["Emotional and warm", "Mysterious and dark", "Bitter and cold", "Silly and loud"], 0, "The applause, the quiet answer, and the father crying behind his programme create a moving, warm ending."),
  ] },
{ k: "r", title: "The Ferry (a scene)", std: ["12영문01-04", "12영문01-02", "12영문01-03"], text:
`SETTING: The deck of a small ferry at dawn. Mist covers the water. OLD MAN LEE leans on the railing. A girl, YUNA, with a heavy rucksack, approaches him.

YUNA: (shyly) Is this the boat to the island?

LEE: (without turning) The only one. Are you running away or coming home?

YUNA: (surprised) Why do you ask?

LEE: Nobody carries a bag that heavy for a holiday. (He finally looks at her, kindly.) I have made this crossing for fifty years. People who run away look at the water. People who go home look at the horizon.

(YUNA turns to the horizon. A pause. The ferry horn sounds.)

YUNA: (softly) Then I suppose I am going home.

(LEE nods and offers her a cup from his flask. The sun begins to rise.)`,
  qs: [
    q("What can the audience infer from Lee's first question?", ["He can read people's situations from small signs.", "He is the ferry's captain.", "He is worried about the weather.", "He wants to take Yuna's bag."], 0, "He guesses her reason for travelling from her heavy bag, showing experience in reading people."),
    q("What is the symbolic meaning of the sunrise at the end?", ["A new beginning and hope", "A coming storm", "The end of the story's setting", "A warning for the passengers"], 0, "Sunrise at the moment she accepts she is going home symbolises renewal."),
    q("Why does Yuna turn to the horizon?", ["She wants to find out what kind of traveller she is.", "She hears a noise from the island.", "She is trying to avoid Lee's flask.", "She wants to take a photograph."], 0, "Lee's remark makes her test herself: looking at the horizon suggests she is going towards something, not away from it."),
    q("How do the stage directions help build the characters?", ["They show Yuna's shyness and Lee's gentle kindness.", "They list the actors' costumes in detail.", "They give historical facts about the ferry.", "They state the ending of the play in advance."], 0, "Words such as \"shyly\" and \"kindly\" reveal the manner of each character."),
  ] },
{ k: "r", title: "Crossing the Dunes", std: ["12영문01-04", "12영문01-08"], text:
`The caravan had been walking since midnight. By noon the dunes rose on every side like a frozen sea, and the sun lay on the travellers' shoulders like a hand that refused to lift. No one spoke. Even the camels, usually so scornful, had lowered their heads and fallen into a steady, swaying silence.

Amira counted her steps to keep her mind from the water that was almost gone. Four hundred, she told herself, and then she would let herself look at the horizon. At four hundred, there was nothing. At eight hundred, nothing. At one thousand, something shimmered, green and impossibly small, and she wondered whether the desert had begun to play tricks.

Behind her, the old guide lifted his head and, for the first time that day, smiled.`,
  qs: [
    q("What is the mood of the opening paragraph?", ["Heavy, hot and exhausting", "Cheerful and relaxed", "Funny and noisy", "Cold and mysterious"], 0, "Images of a heavy sun, silence, and lowered heads create a draining mood."),
    q("\"the sun lay on the travellers' shoulders like a hand that refused to lift\" is an example of", ["a simile with a sense of weight", "an onomatopoeia", "a rhyme scheme", "a rhetorical question"], 0, "The sun is compared to a heavy hand using \"like\", and the image conveys the oppressive weight of the heat."),
    q("What is Amira's reason for counting steps?", ["To distract herself from worry about water", "To measure the size of the desert", "To compete with the camels", "To plan her route on a map"], 0, "She counts \"to keep her mind from the water that was almost gone\"."),
    q("Why does the guide smile at the end?", ["He recognises that the green shape means they are near water.", "He is pleased that Amira has finished counting.", "He hears the camels speak.", "He remembers a joke from his childhood."], 0, "The green thing that shimmers is likely an oasis; the experienced guide would know this and smile with relief."),
  ] },
{ k: "r", title: "A Review of \"The Salt Road\"", std: ["12영문01-06", "12영문01-02"], text:
`In her second novel, \"The Salt Road\", Helena Marsh follows a family of merchants through three generations, and the result is a book of unusual patience. Marsh refuses the easy thrills of her genre. There are no battles, no villains; instead, the tension comes from small decisions made over small meals. When a daughter chooses silence at the dinner table, an entire marriage trembles.

The prose can be demanding. Long, winding sentences sometimes lose the reader, and the middle section moves so slowly that I checked the page count more than once. Yet the final chapters repay every minute. The closing image, a grandmother rubbing salt from her palms onto a child's tongue, is one of the most moving things I have read this year. Not a perfect novel, but a memorable one.`,
  qs: [
    q("What is the reviewer's overall opinion of the novel?", ["Mostly positive, with some reservations", "Completely negative", "Fully positive without any criticism", "Neutral and without any opinion"], 0, "The reviewer praises the patience and ending but also criticises the dense prose and slow middle."),
    q("According to the review, what creates tension in the novel?", ["Small choices within the family", "Violent fights between merchants", "A mystery about a hidden treasure", "Natural disasters on the road"], 0, "The review says there are no battles or villains; tension comes from small decisions at meals."),
    q("What does the phrase \"repay every minute\" suggest?", ["The ending makes the long reading worthwhile.", "The book must be returned to the library on time.", "The reader should count each minute while reading.", "The author is paid by the minute."], 0, "Although the middle is slow, the final chapters reward the reader for his or her time."),
    q("Which statement would the reviewer most likely agree with?", ["A book can be moving even if it is flawed.", "Readers should avoid slow novels.", "Long sentences are always an advantage.", "Thrillers are better than family stories."], 0, "\"Not a perfect novel, but a memorable one\" shows that flaws do not prevent a strong impact."),
  ] },
{ k: "r", title: "Why the Owl Hunts at Night", std: ["12영문01-01", "12영문01-04"], text:
`In the early days of the world, the owl was the proudest bird of the forest, and her feathers shone like polished copper in the sun. All the other birds admired her, and she believed their admiration was her due. One spring, when the king of the birds called a meeting to choose who should guard the sleeping eggs, the owl alone refused to attend. "I do not take orders from creatures who sing so badly," she said.

The king answered her quietly. "Then you shall guard the dark hours, when nobody sings and nobody sees you. Perhaps there you will learn what it is to listen." From that day on, the owl hunted by night. They say that her round eyes grew large in the dark, and that she hears the smallest rustle, because she is still learning to listen.`,
  qs: [
    q("What problem begins the myth?", ["The owl is too proud to join the others.", "The eggs are stolen by a fox.", "The king loses his crown.", "The forest suffers from a long drought."], 0, "The owl refuses to attend the meeting and insults the other birds, which causes the king's judgement."),
    q("What is the purpose of this kind of story?", ["To explain how something in nature came to be", "To give a scientific report on birds", "To advertise a forest hotel", "To describe a historical battle"], 0, "It is a myth that gives an imaginative explanation for why the owl hunts at night and has large eyes."),
    q("The king's punishment is best described as", ["a lesson that matches the owl's fault", "a random act of anger", "a reward for her bravery", "a trick he plays on her"], 0, "She would not listen, so she receives a life that teaches listening; the punishment fits the fault."),
    q("In the sentence \"she believed their admiration was her due\", the phrase \"her due\" means", ["something she deserved", "something she owed", "something she feared", "something she stole"], 0, "\"Due\" here means what is rightfully owed to her; she thought she deserved the admiration."),
  ] },
{ k: "r", title: "The Parrot Who Told the Truth", std: ["12영문01-01", "12영문01-02"], text:
`Madame Orlova's parrot had a talent that no one had asked for: he repeated everything he overheard. For years this was harmless, even charming. Visitors enjoyed hearing him imitate the doorbell, the kettle and the postman's cough.

Then came the dinner party. Madame had invited her richest neighbour, and she spent an hour describing how delighted she was to see him. The parrot, in the corner, listened to every compliment. Later that evening, just as the neighbour was lifting his dessert fork, the bird said in Madame's own voice, "What a bore he is! If only he would go home!"

The silence lasted nearly a minute. Madame turned the colour of her tablecloth. The neighbour, to everyone's surprise, burst out laughing. "At last," he said, "an honest voice in this house." They became the closest of friends, and the parrot was given the best seat at every dinner.`,
  qs: [
    q("What is the humour in the story based on?", ["A creature repeats what was meant to be private.", "A guest forgets his own name.", "A servant breaks an expensive plate.", "A host is late for her own party."], 0, "The parrot repeats Madame's private insult at the worst possible time, which creates comic embarrassment."),
    q("Why did the neighbour laugh?", ["He valued honesty more than polite flattery.", "He did not understand the parrot's words.", "He wanted to hide his anger.", "He planned to take the bird home."], 0, "He called it \"an honest voice\", showing that he appreciated plain truth."),
    q("What is the likely message of the story?", ["Sincerity can build deeper friendship than empty praise.", "Parrots should never be kept as pets.", "Dinner parties are always dangerous.", "Rich people prefer to be insulted."], 0, "The friendship that results from the honest remark shows the value of sincerity."),
    q("The phrase \"Madame turned the colour of her tablecloth\" suggests that she", ["went pale with shock", "felt very proud", "became extremely angry", "began to feel sleepy"], 0, "A white tablecloth suggests she went pale from embarrassment or shock."),
  ] },
{ k: "r", title: "A Word for Home", std: ["12영문01-07", "12영문01-02"], text:
`My grandmother, who has lived in three countries, says that there is no true translation of the word \"home\". In her first language it can mean a house, a village, a smell, even a particular song. In English, she complains, it sounds too much like a place on a map.

I used to think this was an old person's complaint. But last summer, living for six weeks in a flat with strangers, I noticed that I did not call it home until the evening a flatmate left the light on for me. Nothing else had changed: the sink still leaked, the walls were still thin. The word arrived with the light.

I now suspect my grandmother is right. A language gives us labels, but it is people who fill them.`,
  qs: [
    q("What is the writer's main point about the word \"home\"?", ["Its meaning depends on feeling more than on place.", "It can be translated easily into every language.", "It describes only a house with a roof.", "It is a word that old people use too often."], 0, "The writer concludes that the word is filled by people and feelings, not only by geography."),
    q("Why does the grandmother think English is lacking?", ["The English word seems to refer only to a location.", "English has too many difficult sounds.", "English does not have a word for houses.", "English speakers dislike travelling."], 0, "She says \"home\" in English sounds too much like a place on a map."),
    q("What caused the writer to feel the flat was home?", ["Someone's small act of thoughtfulness", "Repairs made to the leaking sink", "The thick walls that kept out noise", "A letter from her grandmother"], 0, "The word came when a flatmate left the light on for her."),
    q("The sentence \"The word arrived with the light\" is an example of", ["a figure of speech linking a feeling to a small event", "a literal description of a delivery", "a question put to the reader", "a rhyme"], 0, "The word is treated as if it could arrive; the image links the sense of home to the kind gesture of the light."),
  ] },
{ k: "r", title: "Inheritance", std: ["12영문01-05", "12영문01-03"], text:
`From my father I inherited a watch
that has not told the time for twenty years,
a pair of hands that fold the same way his did
when he was thinking, and a distrust of banks.

From my mother I inherited the habit
of keeping the radio on in an empty room,
so that the house will not feel abandoned,
and a way of saying "fine" that means the opposite.

Neither of them left me land or money.
The lawyer, when he read the will,
looked faintly sorry. I thanked him.
I did not tell him that I already held
everything they had ever owned
and that it fit, quite easily, inside a life.

I wind the watch. It does not move.
But the hands, when I look down, are theirs.`,
  qs: [
    q("What does the speaker mean by \"it fit, quite easily, inside a life\"?", ["Her parents' real legacy was habits and memories, not objects.", "The speaker lives in a very small house.", "The lawyer packed the parents' belongings neatly.", "The speaker plans to sell the watch."], 0, "The phrase suggests that the true inheritance is a way of living, which is carried inside the speaker."),
    q("What does the broken watch symbolise?", ["The father's lasting presence, though time has stopped for him", "A mistake the speaker made as a child", "A modern gift from the lawyer", "The speaker's fear of banks"], 0, "The watch no longer works but is treasured; it stands for the father's memory."),
    q("What is the tone of the poem?", ["Quiet, affectionate and thoughtful", "Furious and bitter", "Joking and careless", "Excited and loud"], 0, "The speaker lists small details of her parents with tenderness, without anger or noise."),
    q("The phrase \"a way of saying 'fine' that means the opposite\" shows that the mother", ["hid her real feelings behind a short word", "always told the exact truth", "disliked the radio", "spoke very little English"], 0, "When she said \"fine\" she did not mean it, so she hid her troubles."),
  ] },
{ k: "r", title: "The Last Train", std: ["12영문01-04", "12영문01-01"], text:
`The platform was empty except for a boy and an old woman at opposite ends. The clock above them said eleven fifty-two. Jun checked his phone again; the battery was at two per cent.

"It is not coming, you know," said the woman, without raising her voice. She seemed to speak to the rails. "They stopped the last train on Sundays years ago. I only come here to remember."

Jun looked at her properly. She wore a green coat that was too thin for the night. "What do you remember?" he asked, and was surprised to find that he truly wanted to know.

She told him about a young man, a suitcase, and a promise made on this very platform. By the time she finished, the phone had died, and Jun did not mind at all. They walked out together into the cold, sharing the long, slow business of a story.`,
  qs: [
    q("What is the central conflict at the beginning?", ["Jun is stranded and the train will not arrive.", "Two travellers argue about the clock.", "The woman steals Jun's phone.", "The station is being closed for repairs."], 0, "He waits for a train that has stopped running, which creates the problem."),
    q("How does Jun's attitude change during the passage?", ["From impatience to interest in another person", "From calm to rage", "From curiosity to fear", "From joy to sadness"], 0, "He begins by checking his phone but ends up caring more about her story than about his own situation."),
    q("Why does the woman come to the platform?", ["She comes to remember a promise from her past.", "She works as a guard at the station.", "She wants to sell tickets to travellers.", "She is waiting for Jun's phone call."], 0, "She says \"I only come here to remember\" and then tells of a promise made there."),
    q("The sentence \"the long, slow business of a story\" suggests that", ["telling and listening to a story takes time and care", "stories are a type of paid job", "the train is moving slowly", "the woman is making up a lie"], 0, "The phrase presents the story as a patient shared activity."),
  ] },
];
