let ctr = 0;
export const Q = (q, key, wr, why, std) => {
  const a = (ctr++ * 3 + 1) % 4;
  const o = [...wr]; o.splice(a, 0, key);
  return { q, o, a, why, ...(std ? { std } : {}) };
};
export const R = (title, text, qs) => ({ k: "r", title, text, qs });
export const D = (title, text, qs) => ({ k: "d", title, text, qs });
export const M = (q, key, wr, why, std, cat) => { const x = Q(q, key, wr, why, std); return { k: "m", q: x.q, o: x.o, a: x.a, why, cat: cat || "reading", ...(std ? { std } : {}) }; };
