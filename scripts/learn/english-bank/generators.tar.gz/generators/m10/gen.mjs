import fs from "node:fs";
import p1 from "./p1.mjs"; import p2 from "./p2.mjs"; import p3 from "./p3.mjs"; import { extraR, dialogues } from "./p4.mjs"; import m from "./pm.mjs"; import s from "./ps.mjs"; import patch from "./patch.mjs";
const items = [...p1, ...p2, ...p3, ...extraR, ...dialogues, ...m, ...s];
for(const [id,o] of Object.entries(patch)){const [i,j]=id.split(".").map(Number);const q=items[i].k==="m"?items[i]:items[i].qs[j];if(!q)throw id;q.o=o;}
s.forEach(x=>{ if(x.ord===true) delete x.ord; });
const out = { packet: "M10-m2-read", sections: [{ skill: "e.m2.read", items }] };
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M10-m2-read.json", JSON.stringify(out, null, 1) + "\n");
const c = {}; for (const i of items) c[i.k] = (c[i.k] ?? 0) + 1; console.log(c);
