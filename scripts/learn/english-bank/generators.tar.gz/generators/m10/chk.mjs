import fs from "node:fs";
const p = JSON.parse(fs.readFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/M10-m2-read.json"));
let n=0,L=0; const out=[];
p.sections[0].items.forEach((it,ii)=>{
  const qs = it.k==="m"?[it]:it.qs||[];
  qs.forEach((q,qi)=>{ if(!q.o) return; n++; const l=q.o.map(x=>x.length); const a=l[q.a]; if(a===Math.max(...l)&&l.filter(x=>x===a).length===1){L++; out.push(`${ii}.${qi} [${(it.title||it.q).slice(0,20)}] ${l.join(",")} a=${q.a}`);} });
});
console.log(L,n,Math.round(100*L/n)+"%"); if(process.argv[2]) console.log(out.join("\n"));
