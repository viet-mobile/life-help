import fs from "node:fs";
const w = (en,pos,ko,ex,exko,z,syn,sp,note) => ({k:"w",en,pos,ko,ex,exko,z,syn,sp,...(note?{note}:{})});
const s = (good,ko,bad,st,ok,wr,rule,hint) => ({k:"s",good,ko,bad,cz:{st,ok,wr},rule,...(hint?{hint}:{})});
const m = (q,o,a,why,extra={}) => ({k:"m",q,o,a,why,...extra});

const vocabW = [
 w("huge","adj","거대한","The mountain was so huge that it touched the clouds.","그 산은 구름에 닿을 만큼 거대했어요.",["tiny","narrow","shallow"],["enormous","giant","gigantic","massive","immense","vast","large","big"],["hugh","hudge","huege"],"huge는 giant와 뜻이 비슷하고, tiny와는 반대예요."),
 w("tiny","adj","아주 작은","The ant was so tiny that I could hardly see it.","그 개미는 너무 작아서 거의 보이지 않았어요.",["huge","loud","heavy"],["small","little","minuscule"],["tiney","tinee","tyny"],"tiny는 huge와 반대되는 낱말이에요."),
 w("ancient","adj","고대의","The museum has ancient tools made of stone.","그 박물관에는 돌로 만든 고대의 도구가 있어요.",["sleepy","hungry","thirsty"],["old","prehistoric"],["ansient","ancint","ancent"],"ancient는 modern과 반대되는 낱말이에요."),
 w("modern","adj","현대적인","My school has a modern library with new computers.","우리 학교에는 새 컴퓨터가 있는 현대적인 도서관이 있어요.",["shy","angry","dizzy"],["new","up-to-date","contemporary"],["modren","modorn","moderen"]),
 w("brave","adj","용감한","He was so brave that he was not afraid of the dark.","그는 아주 용감해서 어둠도 무섭지 않았어요.",["polite","noisy","wet"],["courageous","bold","fearless"],["brav","braive","brayve"]),
 w("generous","adj","너그러운","She is very generous, so she shares her lunch with everyone.","그녀는 아주 너그러워서 모두와 점심을 나눠 먹어요.",["selfish","jealous","rude"],["kind","giving","unselfish","charitable"],["generus","genarous","jenerous"],"generous는 selfish와 반대되는 낱말이에요."),
 w("selfish","adj","이기적인","A selfish person never shares anything with others.","이기적인 사람은 다른 사람과 아무것도 나누지 않아요.",["generous","kind","giving"],["greedy","self-centered"],["selfsh","selfich","sellfish"]),
 w("dangerous","adj","위험한","It is dangerous to swim in the river after a storm.","폭풍이 지난 뒤 강에서 수영하는 것은 위험해요.",["delicious","sleepy","colorful"],["risky","unsafe","hazardous"],["dangrous","dangeros","dangerus"],"dangerous는 safe와 반대되는 낱말이에요."),
 w("safe","adj","안전한","The playground is safe because it has soft ground.","그 놀이터는 바닥이 푹신해서 안전해요.",["dangerous","risky","harmful"],["secure","protected"],["saef","saif","safee"]),
 w("empty","adj","텅 빈","The box was empty, so I put my toys in it.","상자가 텅 비어 있어서 나는 거기에 장난감을 넣었어요.",["full","crowded","noisy"],["vacant","bare"],["empti","emptey","emty"],"empty는 full과 반대되는 낱말이에요."),
 w("polite","adj","예의 바른","Be polite and say thank you to the bus driver.","예의 바르게 버스 기사님께 고맙다고 말하세요.",["rude","lazy","angry"],["courteous","well-mannered","respectful"],["polit","poilte","pollite"]),
 w("borrow","v","빌리다","Can I borrow your eraser for a minute?","네 지우개를 잠깐 빌려도 될까?",["lend","sing","grow"],[],["borow","borrou","borrrow"],"borrow는 빌려 오는 것, lend는 빌려주는 것이에요."),
 w("lend","v","빌려주다","Could you lend me your umbrella? It is raining.","우산 좀 빌려줄래? 비가 오고 있어.",["borrow","wash","enjoy"],["give"],["lende","lennd","laend"]),
 w("arrive","v","도착하다","The bus will arrive at the school at nine.","버스는 9시에 학교에 도착할 거예요.",["wash","paint","forget"],["reach","get"],["arive","aryve","arrieve"],"arrive는 leave와 반대되는 뜻으로 쓰여요."),
 w("leave","v","떠나다","The bus will leave the station at nine.","버스는 9시에 정류장을 떠날 거예요.",["arrive","paint","wash"],["depart","go away from"],["leev","leeve","lieve"]),
 w("invite","v","초대하다","I will invite my friends to my birthday party.","나는 친구들을 내 생일 파티에 초대할 거예요.",["describe","repair","forget"],[],["invate","envite","inviet"]),
 w("increase","v","증가하다","The number of visitors will increase in summer.","방문객 수는 여름에 증가할 거예요.",["sleep","cook","wash"],["grow","rise","go up"],["increas","incrase","inkrease"],"increase는 decrease와 반대되는 낱말이에요."),
 w("decrease","v","감소하다","The number of birds began to decrease when the forest was cut down.","숲이 베어지자 새의 수가 줄어들기 시작했어요.",["dance","wash","paint"],["fall","drop","reduce","shrink"],["decreas","decrese","dicrease"]),
 w("reply","v","답장하다","Please reply to my message by Friday.","금요일까지 내 메시지에 답장해 주세요.",["paint","wash","climb"],["answer","respond"],["repli","replai","riply"]),
 w("discover","v","발견하다","Scientists discover new animals in the deep sea every year.","과학자들은 해마다 깊은 바다에서 새로운 동물을 발견해요.",["sleep","jump","climb"],["find","uncover"],["discovar","dicover","discoverr"]),
 w("journey","n","여행","The journey to my grandmother's house takes two hours.","할머니 댁까지의 여행은 두 시간이 걸려요.",["window","kitchen","bottle"],["trip","travel"],["jorney","journy","journney"]),
 w("festival","n","축제","People sing and dance at the spring festival in my town.","우리 동네의 봄 축제에서 사람들은 노래하고 춤을 춰요.",["spoon","pencil","window"],["fair","celebration"],["festivel","festibal","fesitval"]),
 w("habit","n","습관","Reading before bed is a good habit.","자기 전에 책을 읽는 것은 좋은 습관이에요.",["window","pencil","bottle"],["custom","routine"],["habet","habbit","habbbit"]),
 w("quickly","adv","빨리","Please walk quickly, or we will miss the bus.","빨리 걸으세요, 안 그러면 버스를 놓칠 거예요.",["slowly","softly","politely"],["fast","rapidly","swiftly","speedily"],["quikly","quickley","kwickly"]),
 w("carefully","adv","조심스럽게","Carry the glass carefully, or it will break.","유리컵을 조심해서 옮기세요, 안 그러면 깨질 거예요.",["loudly","happily","always"],["gently","cautiously","slowly"],["carefuly","carfully","carefullly"]),
 w("suddenly","adv","갑자기","We were playing outside when it suddenly began to rain.","우리가 밖에서 놀고 있을 때 갑자기 비가 오기 시작했어요.",["kindly","hungrily","politely"],["abruptly"],["sudenly","suddnly","sudddenly"]),
];
const vocabS = [
 s("Please lend me your pen.","내게 네 펜을 빌려줘.",["Please borrow me your pen.","Please lend to me your pen.","Please me lend your pen."],"Please ___ me your pen.","lend",["borrow","lends","lending"],"남에게 빌려주는 것은 lend, 남에게 빌리는 것은 borrow예요.","빌려주는 사람과 빌리는 사람이 누구인지 생각해 보세요."),
 s("She drives carefully.","그녀는 조심스럽게 운전해요.",["She drives careful.","She drive carefully.","She driving carefully."],"She drives ___.","carefully",["careful","care","carefulness"],"동사를 꾸밀 때는 careful 같은 형용사가 아니라 -ly가 붙은 부사를 써요.","동사를 꾸미는 말은 어떤 종류의 낱말일까요?"),
 s("It is unfair to take all the cookies.","쿠키를 전부 가져가는 것은 불공평해요.",["It is disfair to take all the cookies.","It is infair to take all the cookies.","It is fairless to take all the cookies."],"It is ___ to take all the cookies.","unfair",["disfair","infair","fairless"],"fair(공평한) 앞에 un-을 붙이면 반대말 unfair(불공평한)가 돼요."),
 s("The story was interesting.","그 이야기는 재미있었어요.",["The story was interested.","The story interesting was.","The story was interest."],"The story was ___.","interesting",["interested","interest","interestingly"],"사물이 재미를 주는 것은 -ing(interesting), 사람이 재미를 느끼는 것은 -ed(interested)예요.","이야기가 어떤 느낌을 주는지 생각해 보세요."),
 s("There are many people at the festival.","축제에 사람이 많이 있어요.",["There are much people at the festival.","There is many people at the festival.","There are a lot people at the festival."],"There are ___ people at the festival.","many",["much","a lot","a little"],"셀 수 있는 복수 명사 앞에는 many를 써요. much는 셀 수 없는 명사 앞에 써요."),
 s("I am afraid of spiders.","나는 거미가 무서워요.",["I am afraid at spiders.","I am afraid with spiders.","I am afraid to spiders."],"I am afraid ___ spiders.","of",["at","with","to"],"be afraid of ~는 '~을 무서워하다'라는 뜻의 짝이 되는 표현이에요."),
];
const vocabM = [
 m("big과 비슷한 뜻을 가진 낱말은?",["small","large","thin","short"],1,"big(큰)과 large(큰)는 뜻이 비슷해요."),
 m("hot의 반대말은?",["cold","wet","dry","soft"],0,"뜨거운(hot)의 반대말은 차가운(cold)이에요."),
 m("fast와 반대되는 뜻의 낱말은?",["quick","early","loud","slow"],3,"빠른(fast)의 반대말은 느린(slow)이에요. quick은 fast와 비슷한 말이에요."),
 m("happy와 비슷한 뜻의 낱말은?",["angry","tired","glad","sleepy"],2,"happy(행복한)와 glad(기쁜)는 뜻이 비슷해요."),
 m("다음 중 나머지와 뜻이 다른 낱말은?",["huge","small","tiny","little"],0,"small, tiny, little은 '작은'이라는 뜻이고, huge는 '아주 큰'이라는 뜻이에요."),
 m("다음 중 반대말끼리 짝지은 것은?",["big - large","early - late","happy - glad","quick - fast"],1,"early(이른)와 late(늦은)는 반대말이에요. 나머지는 비슷한 뜻이에요."),
 m("다음 중 비슷한 뜻끼리 짝지은 것은?",["buy - sell","come - go","open - close","begin - start"],3,"begin과 start는 둘 다 '시작하다'라는 뜻이에요. 나머지는 반대말이에요."),
 m("빈칸에 알맞은 낱말은?\nThe soup was too hot, so I waited until it became ___.",["tall","dark","cool","kind"],2,"수프가 너무 뜨거워서 식을 때까지 기다렸으니 cool(시원한, 식은)이 알맞아요."),
 m("다음 중 낱말 앞에 un-을 붙여 반대말을 만들 수 있는 것은?",["table","happy","apple","rain"],1,"happy 앞에 un-을 붙이면 unhappy(불행한)가 돼요."),
 m("help에 -ful을 붙여 만든, '도움이 되는'이라는 뜻의 낱말은?",["helpfull","helping","helpful","helpness"],2,"help에 -ful을 붙이면 helpful(도움이 되는)이에요. l은 하나만 써요."),
 m("-less는 '~이 없는'이라는 뜻이에요. 'without hope'를 뜻하는 낱말은?",["hopeless","hopeful","hoping","hoped"],0,"hope에 -less를 붙인 hopeless는 '희망이 없는'이라는 뜻이에요."),
 m("snow와 man을 합쳐 '눈사람'을 뜻하는 한 낱말은?",["mansnow","snowman","snowing","snowy"],1,"snow와 man이 합쳐져 snowman(눈사람)이 돼요."),
 m("빈칸에 알맞은 동사는?\nI always ___ my bed in the morning.",["cook","sing","wash","make"],3,"'침대를 정리하다'는 make my bed라고 해요."),
 m("'사진을 찍다'를 영어로 바르게 말한 것은?",["take a photo","make a photo","do a photo","put a photo"],0,"사진을 찍다는 take a photo라고 해요."),
 m("다음 중 요일 이름이 아닌 것은?",["Monday","Friday","Sunday","October"],3,"October(10월)는 달 이름이고, 나머지는 요일 이름이에요."),
 m("다음 중 장소를 나타내는 낱말이 아닌 것은?",["library","teacher","hospital","museum"],1,"teacher(선생님)는 사람이고, 나머지는 장소예요."),
 m("빈칸에 알맞은 낱말은?\nI am so ___ that I can eat a whole pizza.",["noisy","angry","sleepy","hungry"],3,"피자를 통째로 먹을 수 있을 만큼이니 hungry(배고픈)가 알맞아요."),
 m("'It's a piece of cake.'는 무슨 뜻일까요?",["작은 선물이에요.","아주 맛있는 케이크예요.","아주 쉬운 일이에요.","아주 어려운 일이에요."],2,"a piece of cake은 '식은 죽 먹기', 즉 아주 쉬운 일을 뜻하는 표현이에요."),
];

const clauseW = [
 w("because","conj","왜냐하면","I took an umbrella because it was raining.","비가 오고 있어서 나는 우산을 가져갔어요.",["so","or","until"],["since","as"],["becouse","becuase","becasue"],"because 뒤에는 이유가 와요."),
 w("until","conj","~할 때까지","Please wait here until I come back.","내가 돌아올 때까지 여기서 기다려 주세요.",["so","or","because"],["till"],["untill","untl","untel"]),
];
const clauseS = [
 s("I stayed home because I was sick.","나는 아파서 집에 있었어요.",["I stayed home because of I was sick.","I stayed home because sick I was.","I stayed because home I was sick."],"I stayed home ___ I was sick.","because",["so","or","that"],"because 뒤에는 '주어 + 동사'가 와서 이유를 말해요.","이유를 말하는 부분이 어디인지 찾아보세요."),
 s("We cannot go outside because it is snowing heavily.","눈이 많이 와서 우리는 밖에 나갈 수 없어요.",["We cannot go outside because snowing heavily.","We cannot go outside because of it is snowing heavily.","We cannot go outside because it snowing heavily."],"We cannot go outside ___ it is snowing heavily.","because",["so","or","than"],"because 뒤에도 완전한 문장(주어 + be동사 + 동사-ing)이 와야 해요."),
 s("I like summer because I can swim in the sea.","나는 바다에서 수영할 수 있어서 여름이 좋아요.",["I like summer because of I can swim in the sea.","I like summer because I can swimming in the sea.","I like summer because can I swim in the sea."],"I like summer ___ I can swim in the sea.","because",["because of","why","what"],"because 뒤의 문장은 평서문 어순(주어 + 동사)을 지키고, can 뒤에는 동사원형을 써요."),
 s("It was very cold, so I wore a coat.","매우 추워서 나는 외투를 입었어요.",["It was very cold, so wore I a coat.","It was very cold, so I wearing a coat.","It was very cold, so I wore coat a."],"It was very cold, ___ I wore a coat.","so",["because","or","than"],"so는 앞의 일의 결과를 이어 줘요. (추웠다 → 그래서 입었다)","원인과 결과 중 어느 쪽이 먼저 나오는지 보세요."),
 s("My phone broke, so I bought a new one.","내 휴대폰이 고장 나서 나는 새것을 샀어요.",["My phone broke, so I bought new one.","My phone broke, so I bought a new.","My phone broke, so I buyed a new one."],"My phone broke, ___ I bought a new one.","so",["because","or","which"],"so 뒤에는 결과가 오고, 새것 하나는 a new one이라고 해요. buy의 과거형은 bought예요."),
 s("Jiho studied hard, so he passed the test.","지호는 열심히 공부해서 시험에 합격했어요.",["Jiho studied hard, so he pass the test.","Jiho studied hard, so he passing the test.","Jiho studied hard, so passed he the test."],"Jiho studied hard, so he ___ the test.","passed",["pass","passing","to pass"],"so 뒤에도 '주어 + 동사' 어순을 지키고, 과거의 일이므로 동사는 과거형(passed)으로 써요."),
 s("Mina is small, but she is very strong.","미나는 작지만 매우 힘이 세요.",["Mina is small, but she very strong.","Mina is small, but she is strongly.","Mina is small, but is she very strong."],"Mina is small, ___ she is very strong.","but",["so","because","or"],"but은 서로 반대되는 내용을 이어 줘요. (작다 ↔ 힘이 세다)"),
 s("He wants a dog, but his mother says no.","그는 개를 갖고 싶어 하지만 어머니는 안 된다고 하세요.",["He wants a dog, but his mother say no.","He wants a dog, but his mother saying no.","He wants dog a, but his mother says no."],"He wants a dog, but his mother ___ no.","says",["say","saying","to say"],"주어(his mother)가 3인칭 단수이고 현재의 일이므로 동사에 -s를 붙여요."),
 s("If it rains tomorrow, we will stay home.","내일 비가 오면 우리는 집에 있을 거예요.",["If it rain tomorrow, we will stay home.","If it rains tomorrow, we stay will home.","If it raining tomorrow, we will stay home."],"If it ___ tomorrow, we will stay home.","rains",["rain","raining","rained"],"if가 이끄는 부분에서는 앞으로의 일도 현재형으로 말해요. it은 3인칭 단수라서 rains예요.","if가 이끄는 부분의 동사 모양을 살펴보세요."),
 s("If you are hungry, you can eat my sandwich.","배고프면 내 샌드위치를 먹어도 돼.",["If you hungry, you can eat my sandwich.","If you are hungry, you can to eat my sandwich.","If are you hungry, you can eat my sandwich."],"___ you are hungry, you can eat my sandwich.","If",["So","But","Or"],"if는 '만약 ~라면'이라는 조건을 나타내요. can 뒤에는 동사원형을 써요."),
 s("I will call you if I need help.","도움이 필요하면 내가 너에게 전화할게.",["I will call you if I needs help.","I will call you if need I help.","I will call you if I need helps."],"I will call you ___ I need help.","if",["so","or","than"],"if 뒤에는 조건이 와요. I 다음에는 need처럼 동사원형을 써요."),
 s("When I got home, my dog ran to me.","내가 집에 왔을 때 우리 개가 내게 달려왔어요.",["When I got home, my dog runned to me.","When I got home, my dog ran me to.","When got I home, my dog ran to me."],"___ I got home, my dog ran to me.","When",["So","Or","But"],"when은 '~할 때'라는 뜻으로 때를 나타내요. run의 과거형은 ran이에요."),
 s("When it is sunny, we play soccer after school.","날씨가 맑을 때 우리는 방과 후에 축구를 해요.",["When it is sunny, we plays soccer after school.","When is it sunny, we play soccer after school.","When it sunny, we play soccer after school."],"When it is sunny, we ___ soccer after school.","play",["plays","playing","to play"],"주어가 we이면 동사에 -s를 붙이지 않아요. when 뒤에도 주어 + be동사 어순을 지켜요."),
 s("I washed my hands and ate lunch.","나는 손을 씻고 점심을 먹었어요.",["I washed my hands and eating lunch.","I washed my hands and ate lunchs.","I washed my hands and ated lunch."],"I washed my hands and ___ lunch.","ate",["eat","eating","eats"],"and로 이어진 동작은 같은 시제로 맞춰요. eat의 과거형은 ate예요."),
 s("Do you want tea or juice?","차를 마실래, 주스를 마실래?",["Do you wants tea or juice?","Do want you tea or juice?","Do you want tea juice or?"],"Do you want tea ___ juice?","or",["but","so","because"],"or는 둘 중에서 하나를 고를 때 써요."),
 s("Please wash your hands before you eat.","먹기 전에 손을 씻으세요.",["Please wash your hands before you eating.","Please wash your hands before you eats.","Please wash your hands before eat you."],"Please wash your hands before you ___.","eat",["eating","eats","ate"],"before는 '~하기 전에'라는 뜻이에요. 주어 you 뒤에는 동사원형을 써요."),
 s("We went to the park after it stopped raining.","비가 그친 뒤에 우리는 공원에 갔어요.",["We went to the park after it stopped rained.","We went to the park after stopped it raining.","We went to the park after it stopping raining."],"We went to the park after it ___ raining.","stopped",["stops","stopping","stop"],"after는 '~한 뒤에'라는 뜻이에요. 지난 일이므로 stopped를 쓰고, stop 뒤에는 raining을 써요."),
 s("She listened to music while she was cooking.","그녀는 요리하는 동안 음악을 들었어요.",["She listened to music while she cooking.","She listened to music while was she cooking.","She listened to music while she were cooking."],"She listened to music while she ___ cooking.","was",["were","be","been"],"while은 '~하는 동안'이라는 뜻이에요. 주어가 she이면 be동사 과거형은 was예요."),
 s("Wait here until the bell rings.","종이 울릴 때까지 여기서 기다려라.",["Wait here until the bell ringing.","Wait here until rings the bell.","Wait here until the bell to ring."],"Wait here until the bell ___.","rings",["ring","ringing","to ring"],"until은 '~할 때까지'라는 뜻이에요. the bell은 3인칭 단수이므로 rings예요."),
 s("We stayed inside because of the heavy rain.","심한 비 때문에 우리는 안에 있었어요.",["We stayed inside because the heavy rain.","We stayed inside because of the heavy rain falls.","We stayed inside of because the heavy rain."],"We stayed inside ___ the heavy rain.","because of",["because","so","but"],"because 뒤에는 문장이, because of 뒤에는 명사(구)가 와요.","뒤에 문장이 오는지 명사가 오는지 확인해 보세요."),
 s("I wanted to go out, but it was raining, so I stayed home.","나는 나가고 싶었지만 비가 와서 집에 있었어요.",["I wanted to go out, so it was raining, but I stayed home.","I wanted to go out, but it raining, so I stayed home.","I wanted to go out, but it was raining, so stayed I home."],"I wanted to go out, but it was raining, ___ I stayed home.","so",["because","or","than"],"but은 반대되는 내용을, so는 결과를 이어 줘요."),
];
const clauseM = [
 m("빈칸에 알맞은 말은?\nJina was very hungry, ___ she ate two bowls of rice.",["because","so","or","than"],1,"배가 고팠다는 원인 뒤에 결과(밥을 두 그릇 먹었다)가 오므로 so가 알맞아요."),
 m("빈칸에 알맞은 말은?\nShe was late for school ___ she missed the bus.",["so","but","because","or"],2,"지각한 이유가 버스를 놓친 것이므로 because가 알맞아요."),
 m("빈칸에 알맞은 말은?\nI like winter, ___ I don't like the cold wind.",["so","or","till","but"],3,"겨울은 좋지만 찬바람은 싫다는 반대되는 내용이므로 but이 알맞아요."),
 m("빈칸에 알맞은 말은?\n___ you press this button, the door will open.",["Or","But","So","If"],3,"단추를 누르면 문이 열린다는 조건이므로 If가 알맞아요."),
 m("빈칸에 알맞은 말은?\nWhen I was five, I ___ in Jeju.",["live","living","lived","lives"],2,"다섯 살 때는 과거이므로 동사도 과거형 lived를 써요."),
 m("빈칸에 알맞은 말은?\nI take a bath ___ I eat dinner, so I am clean at the table.",["before","after","but","or"],0,"식탁에서 깨끗하려면 저녁을 먹기 전에 목욕해야 하므로 before가 알맞아요."),
 m("'If it rains, I will stay home.'은 무슨 뜻일까요?",["비가 와서 집에 있었어요.","비가 오면 집에 있을 거예요.","비가 오지만 집에 있어요.","비가 그치면 나갈 거예요."],1,"If는 '만약 ~라면'이라는 뜻이라서 '비가 오면 집에 있을 거예요'가 돼요.",{std:["6영01-03"]}),
 m("'I was sick, so I didn't go to school.'에서 so 뒤의 내용은 무엇을 나타낼까요?",["이유","조건","결과","반대"],2,"so는 앞의 일(아팠다)의 결과(학교에 가지 않았다)를 이어 줘요."),
 m("'I smiled because I got a gift.'에서 because 뒤의 내용은 무엇을 나타낼까요?",["이유","결과","조건","시간"],0,"because 뒤에는 이유(선물을 받았다)가 와요."),
 m("'만약 ~라면'이라는 조건을 나타내는 낱말은?",["but","so","and","if"],3,"if는 '만약 ~라면'이라는 뜻의 조건을 나타내요."),
 m("'값은 비싸지만 맛있어요'처럼 서로 반대되는 내용을 이을 때 쓰는 낱말은?",["if","because","but","so"],2,"but은 '그러나, ~지만'이라는 뜻으로 반대되는 내용을 이어요."),
 m("'I was thirsty. I drank water.'를 한 문장으로 알맞게 이은 것은?",["I was thirsty, so I drank water.","I was thirsty, if I drank water.","I was thirsty, or I drank water.","I was thirsty, but I drank water."],0,"목말랐기 때문에 물을 마신 것이므로 결과를 이어 주는 so를 써요."),
 m("다음 중 so의 쓰임이 알맞은 문장은?",["He stayed home, so he was sick.","So he was sick, he stayed home.","He was sick, so he stayed home.","He was sick, so but he stayed home."],2,"아픈 것이 원인이고 집에 있은 것이 결과이므로 'He was sick, so he stayed home.'이 알맞아요."),
 m("빈칸에 알맞은 말은?\nI was happy ___ I won the game.",["because","so","or","than"],0,"경기에서 이겨서 기뻤다는 이유를 나타내므로 because가 알맞아요."),
 m("빈칸에 알맞은 말은?\nI will lend you my book ___ you promise to return it.",["but","so","if","or"],2,"돌려주겠다고 약속하면 빌려주겠다는 조건이므로 if가 알맞아요."),
 m("because와 바꿔 쓸 수 있는, 이유를 나타내는 낱말은?",["since","until","but","or"],0,"이유를 말할 때 since는 because처럼 쓸 수 있어요."),
 m("'I was late because I woke up late.'와 같은 뜻의 문장은?",["I was late, so I woke up late.","I woke up late, but I was late.","I woke up late, so I was late.","I woke up late, or I was late."],2,"늦게 일어난 것이 원인이고 지각이 결과이므로 'I woke up late, so I was late.'가 같은 뜻이에요."),
 m("'I got a cold, so I stayed home.'과 같은 뜻의 문장은?",["I got a cold because I stayed home.","I stayed home because I got a cold.","I stayed home, but I got a cold.","I got a cold if I stayed home."],1,"감기에 걸린 것이 이유이므로 'I stayed home because I got a cold.'가 같은 뜻이에요."),
 m("다음 중 when이 '~할 때'라는 뜻의 접속사로 쓰인 문장은?",["When is the party?","What time is it?","I smile when I see my dog.","Where is my bag?"],2,"I smile when I see my dog.에서 when은 '~할 때'라는 뜻으로 두 문장을 이어 줘요."),
 m("다음 낱말 중 문장과 문장을 이어 주는 말이 아닌 것은?",["because","table","but","if"],1,"table(탁자)은 명사이고, 나머지는 문장을 이어 주는 접속사예요."),
 m("다음 중 두 문장을 이어 줄 수 없는 낱말은?",["happy","so","and","or"],0,"happy(행복한)는 형용사이고, 나머지는 문장을 이어 주는 접속사예요."),
 m("다음 문장의 뒷부분으로 가장 알맞은 것은?\nI missed the bus, so ___.",["it is my favorite color","I have a red bag","I walked to school","she is my teacher"],2,"버스를 놓친 결과로 학교에 걸어갔다는 내용이 자연스러워요."),
 m("빈칸에 알맞은 말은?\nYou can choose a pen ___ a pencil.",["but","or","so","because"],1,"둘 중에서 하나를 고를 때는 or를 써요."),
 m("'I like cats and dogs.'에서 and의 뜻은?",["그리고","그러나","그래서","만약"],0,"and는 '그리고'라는 뜻으로 같은 종류의 낱말이나 문장을 이어요."),
 m("'I read a book while I wait.'에서 while의 뜻은?",["~하기 전에","~하는 동안","~하기 때문에","~하지만"],1,"while은 '~하는 동안'이라는 뜻이에요."),
 m("빈칸에 알맞은 말은?\nDon't open your eyes ___ I say go.",["until","or","so","but"],0,"내가 '가'라고 말할 때까지 눈을 뜨지 말라는 뜻이므로 until이 알맞아요."),
];

const R = (title,text,qs,std,ko) => ({k:"r",title,text,qs:qs.map(([q,o,a,why])=>({q,o,a,why})),std,...(ko?{ko}:{})});
const clauseR = [
 R("A Rainy Sports Day","Our school sports day was on Tuesday. When we woke up, it was raining hard, so the teacher moved the games to Friday. I was a little sad because I practiced running for two weeks. But my friend Sara said, \"If it is sunny on Friday, we can run even faster!\" I felt better after that.",[
  ["Why did the teacher move the games?",["Several students were sick that day.","It was raining hard that morning.","The playground was being repaired.","The games were not ready yet."],1,"글에서 비가 많이 와서(raining hard, so ...) 선생님이 경기를 금요일로 옮겼다고 했어요."],
  ["Why was the writer a little sad?",["The writer lost a race against Sara.","The writer forgot about the sports day.","The writer had practiced running for two weeks.","The writer did not like the teacher."],2,"because 뒤에 이유가 나와요. 두 주 동안 달리기를 연습했기 때문에 조금 슬펐어요."],
  ["What does Sara say about Friday?",["She wants to cancel all the games.","She will be absent on that day.","She hopes to practice more at home.","They can run even faster if it is sunny."],3,"Sara는 금요일에 날씨가 맑으면 더 빨리 달릴 수 있다고 했어요."],
  ["How did the writer feel at the end?",["The writer became angry at Sara.","The writer felt better after Sara spoke.","The writer wanted to go home early.","The writer decided to stop running."],1,"마지막 문장에서 I felt better after that이라고 했어요."],
 ],["6영01-04"]),
 R("Grandma's Garden","My grandmother has a small garden behind her house. She grows tomatoes and peppers, but she does not grow carrots because the soil is too hard. When I visit her in summer, I help her water the plants. If the tomatoes are red, we pick them and make a salad together. I love spending time in her garden.",[
  ["이 글의 중심 내용으로 가장 알맞은 것은?",["할머니의 정원에서 보내는 즐거운 시간","집 근처 시장에서 채소를 사는 방법","여름방학에 가기 좋은 여행 장소","샐러드에 어울리는 여러 가지 채소"],0,"글 전체가 할머니의 정원과 그곳에서 함께 보내는 시간에 대한 이야기예요."],
  ["할머니가 당근을 기르지 않는 이유는?",["정원이 너무 작아서","당근을 싫어하셔서","흙이 너무 단단해서","물이 부족해서"],2,"because 뒤에 이유가 나와요. 흙이 너무 단단하기 때문이에요."],
  ["글쓴이는 여름에 할머니 댁에 가면 무엇을 하나요?",["잡초를 뽑아요","씨앗을 사 와요","울타리를 칠해요","식물에 물을 줘요"],3,"여름에 가면 할머니를 도와 식물에 물을 준다고 했어요."],
  ["토마토가 빨갛게 익으면 어떻게 하나요?",["시장에 가져가 팔아요","따서 함께 샐러드를 만들어요","그대로 두고 더 키워요","이웃에게 모두 나눠 줘요"],1,"토마토가 빨가면 따서 함께 샐러드를 만든다고 했어요."],
  ["글쓴이는 할머니의 정원을 어떻게 생각하나요?",["그곳에서 시간을 보내는 것을 좋아해요","그곳이 조금 무섭다고 생각해요","그곳에 관심이 별로 없어요","그곳이 너무 좁아서 싫어해요"],0,"마지막 문장에서 정원에서 시간을 보내는 것을 매우 좋아한다고 했어요."],
 ],["6영01-04","6영01-05"]),
 R("A Note to My Teacher","Dear Ms. Kim,\nI am sorry that I was late today. My alarm did not ring, so I woke up late. I ran to the bus stop, but the bus was already gone. Then I walked to school and arrived at nine. I will use two alarms tomorrow if my mother lends me her old clock.\nThank you,\nEunji",[
  ["Why did Eunji write this note?",["To say sorry for being late","To ask for a new clock","To invite her teacher to lunch","To tell about a school trip"],0,"첫 문장 I am sorry that I was late today에서 지각을 사과하려는 글임을 알 수 있어요."],
  ["Why did Eunji wake up late?",["She stayed up to watch TV.","Her alarm did not ring.","Her mother forgot to call her.","She was feeling sick."],1,"My alarm did not ring, so I woke up late. 알람이 울리지 않았기 때문이에요."],
  ["What did Eunji do after she missed the bus?",["She waited for her mother.","She went back home.","She took a taxi to school.","She walked to school."],3,"버스가 이미 가 버린 뒤 Then I walked to school이라고 했어요."],
  ["When will Eunji use two alarms tomorrow?",["If her teacher asks her to","If her mother lends her an old clock","If she wakes up early today","If she buys a new phone"],1,"if 뒤에 조건이 나와요. 엄마가 오래된 시계를 빌려주면 알람 두 개를 쓸 거예요."],
 ],["6영01-04","6영01-05"]),
 R("Why Leaves Change Color","In autumn, the days get shorter and the weather gets cooler. When this happens, leaves stop making green color, so we can see red, yellow, and orange. Many trees drop their leaves because they need to save energy in winter. But pine trees keep their needles all year. If you walk in a forest in October, you can see many beautiful colors.",[
  ["가을에 잎이 빨강, 노랑, 주황색으로 보이는 이유는?",["비가 많이 내리기 때문에","초록색을 만드는 일을 멈추기 때문에","햇빛이 더 강해지기 때문에","나무가 물을 더 많이 마시기 때문에"],1,"잎이 초록색을 만드는 일을 멈추면(so) 빨강, 노랑, 주황색이 보인다고 했어요."],
  ["많은 나무가 잎을 떨어뜨리는 이유는?",["벌레가 잎을 먹어서","새 잎이 너무 빨리 자라서","바람이 너무 세서","겨울에 에너지를 아끼기 위해서"],3,"because 뒤에 이유가 나와요. 겨울에 에너지를 아껴야 하기 때문이에요."],
  ["소나무에 대해 알맞은 것은?",["일 년 내내 잎을 달고 있어요","가을에 노란색으로 변해요","겨울에는 잎이 모두 떨어져요","10월에만 볼 수 있어요"],0,"But pine trees keep their needles all year. 소나무는 일 년 내내 잎을 달고 있어요."],
  ["이 글의 중심 내용은?",["숲에서 길을 찾는 방법","가을에 나무가 변하는 모습과 그 까닭","겨울잠을 자는 동물의 생활","나무를 심는 알맞은 때"],1,"글 전체가 가을에 나뭇잎의 색이 변하고 잎이 지는 까닭을 설명하고 있어요."],
 ],["6영01-04","6영01-05"]),
];

const out = { packet:"E18-e6", sections:[
 {skill:"e.e6.vocab", items:[...vocabW,...vocabS,...vocabM]},
 {skill:"e.e6.clause", items:[...clauseS,...clauseM,...clauseR,...clauseW]},
]};
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/E18-e6.json", JSON.stringify(out,null,1)+"\n");
console.log(vocabW.length,vocabS.length,vocabM.length,clauseS.length,clauseM.length,clauseR.length,clauseW.length);
