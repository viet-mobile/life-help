import fs from "node:fs";
import { Q, reading } from "./gen-h19a.mjs";

const D = (title, lines, std, qs) => ({ k: "d", title, text: lines.join("\n"), std, qs });
const dialogues = [
D("A Dinner with the Host Family", [
"Hana: Thank you for inviting me, Mrs. Brown. Dinner smells wonderful.",
"Mrs. Brown: You're welcome, Hana. Please help yourself. Do you eat everything?",
"Hana: Almost everything. At home, we usually say \"I will eat well\" before a meal, and I feel a little strange starting without saying it.",
"Mrs. Brown: That sounds lovely. Here we often just say \"enjoy,\" but please say it your way.",
"Hana: May I ask something? In my country it is polite to finish all the rice. Is that the same here?",
"Mrs. Brown: Not exactly. Leaving a little on the plate is perfectly fine, and nobody will think you are rude.",
"Hana: Oh, that is a relief. I was worried that I would have to eat everything.",
"Mrs. Brown: Not at all. If you want more, just ask, and if you're full, a simple \"no, thank you\" is enough.",
"Hana: Then I'll try a little more of the potatoes. They are delicious!",
"Mrs. Brown: I'm glad. Tomorrow I'd love to hear about the meals you cook at home.",
], ["12세영01-04", "12세영01-06"],
[
Q("What is the main purpose of the conversation?", "To compare table manners in two cultures", ["To plan a trip to a restaurant", "To explain how to cook potatoes", "To complain about a late dinner"], "두 문화의 식사 예절을 비교하는 대화예요."),
Q("What does Hana feel strange about at the start of the meal?", "Beginning to eat without a customary phrase", ["Sitting on a different kind of chair", "Using a knife and fork", "Being served before the host"], "she feels a little strange starting without saying her phrase."),
Q("What does Mrs. Brown say about leaving food on the plate?", "It is perfectly acceptable.", ["It is considered impolite.", "It means the cook should be thanked.", "It is a sign of being hungry."], "Leaving a little on the plate is perfectly fine."),
Q("Why does Hana say \"that is a relief\"?", "She no longer has to worry about finishing everything.", ["She has just finished her dinner.", "She has found the potatoes too spicy.", "She learned that the meal is free."], "접시를 다 비워야 한다는 걱정이 사라졌어요."),
Q("What will Mrs. Brown probably do tomorrow?", "Ask Hana about meals from her country", ["Teach Hana how to say a new phrase", "Cook rice for the whole family", "Take Hana to a market"], "Tomorrow I'd love to hear about the meals you cook at home."),
]),
D("Preparing a Presentation", [
"Jin: Our topic is a local festival, but I don't know how to begin.",
"Sara: Let's start with something visual. We can show two photos, one from the parade and one from the market.",
"Jin: Good idea. But I'm afraid the audience will only see the colors and the food.",
"Sara: That is exactly the problem. The iceberg idea in our textbook says those are only the visible parts.",
"Jin: Then we should also explain the hidden part, like why people gather and what the festival means to them.",
"Sara: Right. I can interview my grandmother. She has joined the festival every year for more than fifty years.",
"Jin: Great. I'll look for some written sources, and I'll check that the information is correct.",
"Sara: We should also credit every photo and quote. That's part of being honest with other people's work.",
"Jin: Agreed. Shall we meet again on Friday to put the slides together?",
"Sara: Perfect. I'll bring the interview notes.",
], ["12세영01-09", "12세영01-10", "12세영01-02"],
[
Q("Why are the speakers worried about showing only photos?", "The audience may notice only the surface of the festival.", ["The photos are too small to see.", "The festival has no meaning at all.", "The teacher dislikes visual material."], "색과 음식만 보게 될까 봐 걱정해요."),
Q("What does Sara plan to do?", "Interview a family member", ["Visit a museum abroad", "Buy tickets for the parade", "Design a new festival"], "I can interview my grandmother."),
Q("What does Sara mean by \"credit every photo and quote\"?", "Say where each item came from", ["Pay money for each item", "Keep the sources secret", "Replace the quotes with new ones"], "credit는 출처를 밝힌다는 뜻이에요."),
Q("What can be inferred about the two speakers' attitude toward the project?", "They want to present accurate and honest information.", ["They want to finish as quickly as possible.", "They think the textbook is useless.", "They plan to ignore the festival's meaning."], "정확성과 출처 표기를 중시해요."),
Q("When will they work together next?", "On Friday", ["Tomorrow morning", "On the day of the festival", "Next month"], "Shall we meet again on Friday?"),
]),
D("Does Yes Mean Yes?", [
"Ken: I asked Mr. Sato if he could join our team meeting, and he said, \"That might be difficult.\"",
"Emma: That sounds like a no to me. Maybe he is just too busy.",
"Ken: But he didn't say no. I thought he might still come.",
"Emma: In some cultures, people avoid a direct refusal because it could hurt the other person's feelings.",
"Ken: So \"difficult\" could actually mean \"I can't\"?",
"Emma: Quite possibly. In my family, we would say the same thing to a polite neighbor.",
"Ken: Then I should ask a question that is easier to answer, such as which day would be convenient.",
"Emma: Exactly. That way he can suggest another time without feeling uncomfortable.",
"Ken: I see. I always thought being clear meant being direct.",
"Emma: Being clear can mean different things. Sometimes it means being kind and careful.",
], ["12세영01-05", "12세영01-06"],
[
Q("What does Emma think Mr. Sato's answer means?", "He probably cannot attend.", ["He will definitely come.", "He wants to change the topic.", "He has not heard the question."], "That sounds like a no to me."),
Q("Why do some people avoid a direct refusal, according to Emma?", "It might hurt the other person's feelings.", ["It takes too much time to say.", "It is against a school rule.", "It makes meetings shorter."], "because it could hurt the other person's feelings."),
Q("What does Ken decide to do next?", "Ask which day would be convenient", ["Cancel the meeting", "Ask Mr. Sato to apologize", "Send a longer message with many questions"], "ask a question that is easier to answer."),
Q("What does Emma suggest about being clear?", "It can include being kind and careful.", ["It always means speaking loudly.", "It is never possible between cultures.", "It means avoiding all questions."], "Sometimes it means being kind and careful."),
Q("The phrase \"a direct refusal\" in the conversation means", "saying no plainly", ["asking for a delay", "making a joke", "writing a long reply"], "direct refusal은 분명하게 거절하는 것을 뜻해요."),
]),
D("Two Kinds of English", [
"Lucy: I'm confused. My cousin from London told me to take the lift, but I couldn't find any lifts.",
"Daniel: In American English we say elevator. Lift is the British word.",
"Lucy: And she also said she lives in a flat. I thought she meant a flat tire!",
"Daniel: Ha! In British English, a flat is an apartment. There are many pairs like that.",
"Lucy: Is one of them correct and the other one wrong?",
"Daniel: No. Both are standard, and they simply belong to different regions.",
"Lucy: Then which one should I use in my English class in Korea?",
"Daniel: Either is fine, but try to stay consistent in one piece of writing, and learn to recognize the other.",
"Lucy: That makes sense. Being able to understand both seems more useful than choosing a winner.",
"Daniel: Exactly. English belongs to everyone who uses it.",
], ["12세영01-08", "12세영01-04"],
[
Q("Why was Lucy confused?", "She did not know a British word.", ["She had never ridden in an elevator.", "Her cousin spoke a different language.", "She could not find London."], "lift라는 영국식 단어를 몰라 헷갈렸어요."),
Q("What does Daniel say about British and American words?", "Both are standard in their own regions.", ["British words are older and better.", "American words are wrong in school.", "Only one of them is used in Korea."], "Both are standard."),
Q("What advice does Daniel give about writing?", "Be consistent within one text", ["Switch varieties in every sentence", "Avoid using any British words", "Write only in the spoken style"], "try to stay consistent in one piece of writing."),
Q("Which statement would Daniel most likely agree with?", "Understanding several varieties is valuable.", ["English belongs only to its native speakers.", "A single variety should replace all the others.", "Regional words are not worth learning."], "English belongs to everyone who uses it."),
]),
];

const M = (q, key, wrongs, why) => { const x = Q(q, key, wrongs, why); return { k: "m", q: x.q, o: x.o, a: x.a, why: x.why }; };
const S = (good, ko, bad, st, ok, wr, rule, extra = {}) => ({ k: "s", good, ko, bad, cz: { st, ok, wr }, rule, ...extra });

const ms = [
M("Which word means \"a set of rules for polite behavior in a society\"?", "etiquette", ["heritage", "diversity", "currency"], "etiquette는 사회에서 예의 바른 행동에 관한 규범을 뜻해요."),
M("Which word means \"something that a society strongly forbids people to do or talk about\"?", "taboo", ["ritual", "souvenir", "landmark"], "taboo는 사회가 강하게 금지하는 행동이나 화제를 말해요."),
M("Which word means \"an oversimplified belief about a whole group of people\"?", "stereotype", ["festival", "ancestor", "dialect"], "stereotype은 집단 전체에 대한 지나치게 단순한 믿음이에요."),
M("Choose the best word. The old fortress is part of the nation's cultural ____ and must be protected.", "heritage", ["harvest", "weather", "currency"], "cultural heritage는 '문화유산'이에요."),
M("In British English, which word is used for the American \"elevator\"?", "lift", ["lorry", "queue", "pavement"], "영국식 영어에서 elevator는 lift예요."),
M("Which word is the British equivalent of the American \"sidewalk\"?", "pavement", ["lorry", "flat", "biscuit"], "미국의 sidewalk는 영국에서 pavement라고 해요."),
M("Which spelling is typical of British English rather than American English?", "centre", ["center", "color", "favorite"], "centre는 영국식 철자이고 center는 미국식이에요."),
M("What does the idiom \"break the ice\" mean?", "to make people feel comfortable at the start of a meeting", ["to damage something during cold weather", "to refuse a request from a new colleague", "to end a long conversation suddenly"], "break the ice는 어색한 분위기를 풀다라는 뜻이에요."),
M("What does the saying \"When in Rome, do as the Romans do\" advise?", "Follow the local customs where you are visiting.", ["Always travel to ancient cities in summer.", "Never change your habits in a foreign place.", "Learn history before every trip abroad."], "그 지역에 가면 그 지역의 관습을 따르라는 뜻이에요."),
M("In a culture where much of the meaning is understood from the situation and not stated in words, communication is called ____.", "high-context", ["low-context", "double-context", "no-context"], "말보다 상황에서 의미를 읽는 방식은 high-context communication이에요."),
M("A guest does not want a second helping. Which reply is the most polite?", "No, thank you. It was delicious, but I'm full.", ["No. I don't like this food.", "I'm finished. Please take it away.", "Why do you keep offering me more?"], "감사와 칭찬을 곁들여 거절하는 것이 가장 공손해요."),
M("Choose the best word. The city is famous for its cultural ____, with people from many backgrounds living together.", "diversity", ["diversion", "devotion", "division"], "cultural diversity는 '문화적 다양성'이에요."),
M("Choose the correct word. The festival attracts thousands of ____ every year.", "tourists", ["tourism", "tourist", "tour"], "thousands of 뒤에는 복수 명사가 와요."),
M("Choose the best word. Learning another language helps us see the world from a different ____.", "perspective", ["permission", "personality", "performance"], "from a different perspective는 '다른 관점에서'예요."),
M("Which word means \"genuine and not copied\"?", "authentic", ["artificial", "ordinary", "temporary"], "authentic은 '진짜의'라는 뜻이에요."),
M("What does \"assimilate\" mean?", "to adopt the ways of a new society and become part of it", ["to leave a country without telling anyone", "to teach a foreign language to children", "to sell traditional goods to tourists"], "assimilate는 새로운 사회에 동화되는 것이에요."),
M("From the point of view of the country they leave, a person who moves abroad to live is called an ____.", "emigrant", ["immigrant", "ambassador", "translator"], "떠나는 나라의 입장에서는 emigrant, 들어가는 나라의 입장에서는 immigrant예요."),
M("What does \"culture shock\" mean?", "the confusion a person feels in an unfamiliar way of life", ["a loud noise at a cultural festival", "a sudden fall in the price of tickets", "the pride a person feels in their traditions"], "culture shock는 낯선 문화에서 느끼는 혼란이에요."),
M("What is a \"lingua franca\"?", "a language used by people who have different mother tongues", ["a language spoken by only one family", "a language that is written without letters", "a language taught only in universities"], "lingua franca는 모국어가 서로 다른 사람들이 공통으로 쓰는 언어예요."),
M("Which sentence is the most culturally sensitive way to describe another culture?", "Their customs are different from ours, and I would like to learn why.", ["Their customs are strange and backward.", "Their customs are wrong and should be changed.", "They all behave exactly the same way."], "판단하지 않고 호기심을 보이는 표현이 가장 적절해요."),
M("Choose the best connector. ____ some people prefer direct feedback, others find it rude.", "While", ["Because", "Unless", "So"], "While은 '~인 반면'이라는 대조를 나타내요."),
M("Choose the correct preposition. A visitor should be familiar ____ local customs.", "with", ["in", "on", "by"], "be familiar with는 '~에 익숙하다'예요."),
M("Choose the best word. Many festivals honor the ____ who lived long ago.", "ancestors", ["descendants", "ancestry", "ancestral"], "ancestors는 '조상들'이에요."),
M("Which is an example of intangible cultural heritage?", "A folk song passed down by singing from parents to children", ["A stone bridge built by the river", "A palace with a large garden", "An ancient coin kept in a museum"], "무형 유산은 형태가 없는 전승 문화예요."),
M("Which word means \"belonging naturally to a place, like the first people who lived in a region\"?", "indigenous", ["foreign", "modern", "popular"], "indigenous는 '토착의'라는 뜻이에요."),
M("Choose the correct particle. This tradition has been handed ____ from generation to generation.", "down", ["up", "in", "off"], "hand down은 '대대로 물려주다'예요."),
M("Choose the best word. Her warm ____ made the exchange student feel at home.", "hospitality", ["hostility", "hospital", "hostage"], "hospitality는 '환대'예요."),
M("Choose the best verb. The museum aims to ____ awareness of endangered languages.", "raise", ["rise", "arise", "lift"], "raise awareness는 '인식을 높이다'예요."),
M("Which expression is closest in meaning to \"a melting pot\"?", "a place where people of many cultures mix together", ["a place where only one tradition is allowed", "a place where old tools are displayed", "a place where food is cooked at night"], "melting pot은 여러 문화가 섞이는 곳이에요."),
];

const ss = [
S("Although the two cultures differ in many ways, they share some basic values.", "두 문화는 여러 면에서 다르지만 몇 가지 기본 가치를 공유해요.",
 ["Although the two cultures differ in many ways, but they share some basic values.", "Despite the two cultures differ in many ways, they share some basic values.", "Although differ the two cultures in many ways, they share some basic values."],
 "___ the two cultures differ in many ways, they share some basic values.", "Although", ["Despite", "Because of", "Unless"],
 "Although는 절을 이끄는 접속사이고, 주절 앞에 but을 함께 쓰지 않아요. Despite는 뒤에 명사(구)가 와요.", { ord: false, hint: "접속사 뒤에는 주어와 동사가 오는지 생각해 보세요." }),
S("Many English words have been borrowed from other languages.", "많은 영어 단어가 다른 언어에서 빌려 온 것이에요.",
 ["Many English words have borrowed from other languages.", "Many English words has been borrowed from other languages.", "Many English words are been borrowed from other languages."],
 "Many English words ___ borrowed from other languages.", "have been", ["have", "has been", "are been"],
 "복수 주어와 수동태 현재완료는 have been + 과거분사로 써요.", { hint: "단어가 '빌려진' 것인지 '빌린' 것인지 생각해 보세요." }),
S("The festival, which takes place every autumn, attracts visitors from around the world.", "그 축제는 매년 가을에 열리며 전 세계에서 방문객을 끌어들여요.",
 ["The festival, that takes place every autumn, attracts visitors from around the world.", "The festival, what takes place every autumn, attracts visitors from around the world.", "The festival, which it takes place every autumn, attracts visitors from around the world."],
 "The festival, ___ takes place every autumn, attracts visitors from around the world.", "which", ["that", "what", "who"],
 "쉼표가 있는 계속적 용법의 관계대명사로는 that을 쓸 수 없고, 사물 선행사에는 which를 써요. 관계사절에서는 대명사 it을 반복하지 않아요."),
S("If I lived abroad, I would try to learn the local language.", "내가 외국에 산다면 그 지역 언어를 배우려 할 거예요.",
 ["If I would live abroad, I would try to learn the local language.", "If I lived abroad, I will try to learn the local language.", "If I live abroad, I would try to learn the local language."],
 "If I ___ abroad, I would try to learn the local language.", "lived", ["would live", "will live", "am living"],
 "현재 사실과 반대되는 가정은 If + 과거형, 주어 + would + 동사원형으로 나타내요.", { ord: false, hint: "현재 사실과 다른 상상을 하는 문장이에요." }),
S("I am looking forward to meeting people from different cultures.", "나는 다양한 문화권의 사람들을 만나기를 기대하고 있어요.",
 ["I am looking forward to meet people from different cultures.", "I am looking forward to be meet people from different cultures.", "I am looking forward for meeting people from different cultures."],
 "I am looking forward to ___ people from different cultures.", "meeting", ["meet", "met", "have met"],
 "look forward to의 to는 전치사라서 뒤에 동명사(-ing)가 와요."),
S("Not only does the festival celebrate music, but it also showcases local food.", "그 축제는 음악을 기념할 뿐만 아니라 지역 음식도 선보여요.",
 ["Not only the festival celebrates music, but it also showcases local food.", "Not only does the festival celebrates music, but it also showcases local food.", "Not only the festival does celebrate music, but it also showcases local food."],
 "Not only ___ the festival celebrate music, but it also showcases local food.", "does", ["do", "is", "has"],
 "Not only가 문장 앞에 오면 주어와 조동사가 도치되고(does + 주어 + 동사원형), 동사는 원형이 돼요."),
S("The guide said that the castle had been built over five hundred years ago.", "안내원은 그 성이 오백 년도 더 전에 지어졌다고 말했어요.",
 ["The guide said that the castle has been built over five hundred years ago.", "The guide said that the castle is built over five hundred years ago.", "The guide said that the castle had built over five hundred years ago."],
 "The guide said that the castle ___ built over five hundred years ago.", "had been", ["has been", "is", "have been"],
 "전달 동사가 과거이고 그보다 앞선 일을 수동으로 말할 때는 had been + 과거분사를 써요. ago는 현재완료와 함께 쓰지 않아요.", { ord: false }),
S("The more we learn about other cultures, the less we rely on stereotypes.", "다른 문화에 대해 더 많이 배울수록 고정관념에 덜 의존하게 돼요.",
 ["The more we learn about other cultures, the lesser we rely on stereotypes.", "More we learn about other cultures, less we rely on stereotypes.", "The most we learn about other cultures, the least we rely on stereotypes."],
 "The more we learn about other cultures, the ___ we rely on stereotypes.", "less", ["lesser", "fewer", "least"],
 "the + 비교급 ~, the + 비교급 ...은 '~할수록 더 ...하다'라는 구문이에요. 동사 rely를 꾸미는 부사는 less예요."),
];

import { P } from "./patches.mjs";
const items = [...reading, ...dialogues, ...ms, ...ss];
for (const [t, qi, old, nw] of P) {
  const it = items.find((x) => x.title && x.title.includes(t));
  if (!it) throw new Error("no item " + t);
  const q = it.qs[qi]; const j = q.o.indexOf(old);
  if (j < 0 || j === q.a) throw new Error("no option " + t + qi + old);
  q.o[j] = nw;
}
const cnt = items.reduce((m, x) => ((m[x.k] = (m[x.k] ?? 0) + 1), m), {});
console.log(cnt);
fs.writeFileSync("/home/user/life-help-eng/scripts/learn/english-bank/pools/H19-h-world.json", JSON.stringify({ packet: "H19-h-world", sections: [{ skill: "e.h.world", items }] }, null, 1) + "\n");
